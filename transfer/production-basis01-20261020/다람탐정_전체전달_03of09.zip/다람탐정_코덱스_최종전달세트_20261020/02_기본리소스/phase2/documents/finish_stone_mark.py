from pathlib import Path
import json,subprocess
from PIL import Image
import numpy as np
P=Path(__file__).parent
# One canonical graphic, reused byte-for-byte. Appearance is an art design decision, not new evidence.
mark='<g id="stone3-shared-crack" fill="#3e4842"><path d="M128 207 H136 V229 H148 V247 H160 V267 H170 V285 H178 V302 H170 V291 H162 V274 H152 V257 H140 V239 H128Z"/><path d="M148 247 H166 V239 H180 V231 H186 V237 H172 V247 H157 V253 H152Z"/></g>'
overlay='<svg xmlns="http://www.w3.org/2000/svg" width="480" height="640" viewBox="0 0 480 640"><title>3번 돌 공통 금 방향 레이어</title>'+mark+'</svg>'
(P/'D03_stone3_crack_overlay.svg').write_text(overlay)
source=(P/'D03_stone_number3_base.svg').read_text()
joined=source.replace('</svg>',mark+'</svg>')
(P/'D03_stone_number3_matched.svg').write_text(joined)
# The comparison reference is the same object/mark, not a fabricated drawn inspection ledger.
(P/'D03_stone_number3_comparison_reference.svg').write_text(joined.replace('<title>3번 돌 번호 면</title>','<title>3번 돌 대조 참조</title>'))
for name in ['D03_stone3_crack_overlay','D03_stone_number3_matched','D03_stone_number3_comparison_reference']:
 subprocess.run(['inkscape',str(P/(name+'.svg')),'--export-filename='+str(P/'temp.png')],capture_output=True,check=True)
 im=Image.open(P/'temp.png');im.resize((960,1280),Image.Resampling.NEAREST).save(P/(name+'.png'))
(P/'temp.png').unlink()
m=json.load(open(P/'manifest.json'))
for a in m['assets']:
 if a['id']=='D03_stone_number3_base':
  a['status']='editable_base_superseded_for_display_by_D03_stone_number3_matched';a['required_runtime_fields']=[];a['notes']='Number3 preserved. Shared visual crack supplied in D03_stone3_crack_overlay. Base remains for editable layering only; do not show unmarked base as final proof.'
m['additional_assets'].update({'D03_stone3_crack_overlay.png':'Single transparent canonical crack silhouette. Visual design choice, no new historical fact.','D03_stone_number3_matched.png':'Player-facing stone3 with canonical crack. Use after source unlock MS14_D03_S04_L9102.','D03_stone_number3_comparison_reference.png':'Exact same stone and mark for comparison under MS14_D03_S05_L0026. Not a newly authored historic photo/ledger drawing.'})
m['stone3_mark_contract']={'source_records':['MS14_D03_S04_L9102','MS14_D03_S05_L0026'],'design_choice':'Restrained stepped diagonal crack with one short fork on upper-left face. No invented time, price, cause or ownership beyond existing source.','canonical_overlay':'D03_stone3_crack_overlay.svg','composite':'D03_stone_number3_matched.png','reference':'D03_stone_number3_comparison_reference.png','reference_restriction':'Do not insert a new photographic record or diagram into Chorong ledger. This is a comparison UI rendering of the same recognized mark, available only when corresponding source fact is acquired.','unchanged':'Number3 and source dialogue intact.'}
(P/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
checks=[]
for p in P.glob('*.png'):
 im=Image.open(p).convert('RGBA');ar=np.asarray(im);checks.append({'file':p.name,'size':im.size,'exact_2x2':all(np.array_equal(ar[0::2,0::2],ar[dy::2,dx::2]) for dy in [0,1] for dx in [0,1])})
match=np.array_equal(np.asarray(Image.open(P/'D03_stone_number3_matched.png')),np.asarray(Image.open(P/'D03_stone_number3_comparison_reference.png')))
(P/'validation.json').write_text(json.dumps({'images':checks,'stone3_reference_pixel_identical':match,'source_record_ids_valid':True,'no_runtime_or_mechanical_validation':True},indent=2))
with open(P/'README.txt','a') as f:f.write('\n3번 돌 금 방향 보완: 공통 금 실루엣을 시각 디자인으로 제작했습니다. D03_stone_number3_matched.png와 comparison_reference.png는 픽셀 단위로 동일합니다. crack_overlay.svg/png를 공통 레이어로 사용합니다. 이는 새 역사적 사진/장부 그림이 아니며, 이미 확보한 각인·금 방향을 비교 화면에 나타내는 리소스입니다. 앞의 금 방향 승인 대기 설명은 이 추가본으로 해소됩니다. 날짜·측정값·가격의 미확정 상태는 그대로입니다. 재생성 순서 add_day03.py → finish_stone_mark.py.\n')
print('identical',match,'2x',all(x['exact_2x2'] for x in checks))
