from pathlib import Path
import json,html,textwrap,subprocess,base64
from PIL import Image
P=Path(__file__).parent
D=json.load(open('/workspace/shared/daram-production-basis/다람탐정_제작기준본01_대사연출조건.json'))
records={r['id']:(s,b,r) for s in D['scenes'] for b in s['blocks'] for r in b['records']}
assets=[]
def rect(x,y,w,h,c):return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{c}"/>'
def txt(x,y,t,size=22,font='Noto Sans CJK KR',color='#493b30'):
 return f'<text x="{x}" y="{y}" font-family="{font}" font-size="{size}" fill="{color}">{html.escape(t)}</text>'
def start(title,header=True):
 a=['<svg xmlns="http://www.w3.org/2000/svg" width="480" height="640" viewBox="0 0 480 640">',f'<title>{html.escape(title)}</title>',rect(12,16,460,616,'#3c2d24'),'<path d="M16 8 H448 V16 H464 V604 H456 V620 H16Z" fill="#ad895e"/>',rect(20,16,436,596,'#e7cea3'),rect(26,22,424,584,'#f0dfbd'),rect(26,22,424,4,'#fff0d0'),rect(26,600,424,6,'#c4a273')]
 if header:a +=[rect(32,30,412,58,'#405d57'),txt(48,67,title,25,color='#fff0d0')]
 return a
def acorn(x,y):
 return f'<g transform="translate({x} {y})" fill="#73583b"><path d="M0 8 H8 V4 H24 V8 H32 V16 H0Z"/><path d="M4 18 H28 V30 H24 V34 H20 V38 H12 V34 H8 V30 H4Z"/><rect x="16" width="4" height="6"/></g>'
def save(name,a,ids,visible,privacy='public',fields=None,status='exact_text_art',notes=''):
 a+=['</svg>'];(P/(name+'.svg')).write_text(''.join(a))
 subprocess.run(['inkscape',str(P/(name+'.svg')),'--export-filename='+str(P/(name+'_base.png'))],capture_output=True,check=True)
 im=Image.open(P/(name+'_base.png'));im.resize((960,1280),Image.Resampling.NEAREST).save(P/(name+'.png'));(P/(name+'_base.png')).unlink()
 sources=[]
 for rid in ids:
  s,b,r=records[rid];sources.append(dict(scene_id=s['scene_id'],block_id=b['id'],record_id=rid,scene_entry=s.get('enter_when'),block_when=b.get('when'),record_requires=r.get('requires'),source_text=r['text']))
 assets.append(dict(id=name,png=name+'.png',svg=name+'.svg',dimensions=[960,1280],source=sources,visible_text=visible,privacy=privacy,status=status,required_runtime_fields=fields or [],notes=notes))
def letter(name,title,content,rid,ac=False,private='public',font='Noto Serif CJK KR'):
 a=start(title,False);y=120;lines=[]
 # Exact text with whitespace-only visual wrapping; no editorial clue emphasis.
 for para in content.split('\n'):
  for line in textwrap.wrap(para,17,break_long_words=True,replace_whitespace=False):
   a.append(txt(55,y,line,22,font));lines.append(line);y+=39
  y+=15
 if ac:a.append(acorn(365,min(y+5,550)))
 save(name,a,[rid],content,private,notes='No new signature, date, address or authorship verdict added. Font difference is illustrative, not standalone proof.')
letter('D01_invitation','초대 편지','다람이를 데리고 와 줘. 여관 13호실에서 기다릴게.','MS14_D01_S01_L9101',font='Noto Sans CJK KR')
letter('D01_mother_note','13호실 메모','내가 자리를 비웠으면 광장 등의 초롱에게 소식을 물어봐. 물건은 책상 아래에 두었어.','MS14_D01_S05_L0018',True)
letter('D05_warning_private','엄마의 경고','당신과 다람이를 부른 적 없어. 그 편지는 내가 쓴 게 아니야. 나를 찾는 곳이나 이 편지 이야기를 여관에 말하지 마. 당장 만나러 내려갈 수 없어. 초롱에게 답을 맡겨 줘. 먹을 것과 마른 천이 필요해. 다람이 손은 괜찮아? 겨울이면 또 트는데.','MS14_D05_S04_L0006',True,'family_only_never_D10P_public')
letter('D11_mother_reply_private','연락함 답장','과자 남겨 뒀다는 말 읽었어. 여관 뒤 전나무 뿌리 집으로 와. 내려가는 길이 보이는 쪽이야. 나를 못 만나면 눌러 둔 돌 밑을 봐. 다른 곳으로 옮길 때 거기에 남길게.','MS14_D11_S00_L0010',True,'family_only_after_actual_box_open')
letter('D11_relocation_note_private','이동 쪽지','여기는 들켰다. 폐온실 아래로 옮긴다. 낮은 문 옆 등 표식을 두 번 두드려.','MS14_D11_S01_L0005',False,'family_only_after_stone_note_open')
# Partial data templates: blanks must not be shown as completed evidence.
a=start('핀 수선 기록');a += [txt(48,145,'수선 날짜',19),rect(48,160,380,2,'#c1ab81'),txt(48,208,'사용 재료  구리선',22),txt(48,254,'사용량',19),rect(130,265,298,2,'#c1ab81'),txt(48,311,'수령인  여관 할머니',22),txt(48,360,'수령 서명',19),rect(160,371,268,2,'#c1ab81'),rect(48,410,180,150,'#e7cea3'),rect(248,410,180,150,'#e7cea3'),txt(60,440,'수선 전',18),txt(260,440,'수선 후',18)]
save('D09_pin_repair_template',a,['MS14_D09_S02_L0012','MS14_D09_S02_L0016','MS14_D09_S02_L0019','MS14_D10_S03_L0014'],['수선 날짜','사용 재료  구리선','사용량','수령인  여관 할머니','수령 서명','수선 전','수선 후'],fields=[{'key':'repair_date','region':[48,165,380,32]},{'key':'copper_quantity','region':[130,234,298,32]},{'key':'recipient_signature','region':[160,339,268,32]},{'key':'approved_before_diagram','region':[48,450,180,110]},{'key':'approved_after_diagram','region':[248,450,180,110]}],status='runtime_template_not_complete_evidence',notes='Dates, amounts, actual signature and mechanically approved diagrams missing from exact prose. Do not fabricate. Repair ownership only unlocks after valid observation/comparison.')
a=start('여관 묶음 보조표');a += [txt(48,150,'묶음 번호',19),rect(170,162,258,2,'#c1ab81'),txt(48,225,'맡긴 곳  여관',22),txt(48,285,'인계 표시',19),rect(170,297,258,2,'#c1ab81'),txt(48,365,'수신인',19),rect(150,377,278,2,'#c1ab81')]
save('D09_post_auxiliary_template',a,['MS14_D09_S04_L0008','MS14_D10_P01_L0017'],['묶음 번호','맡긴 곳  여관','인계 표시','수신인'],fields=[{'key':'bundle_number','region':[170,130,258,32]},{'key':'granny_handover_mark','region':[170,265,258,32]},{'key':'recipient_exact','region':[150,345,278,32]}],status='runtime_template_not_complete_evidence',notes='Handover mark does not prove handwriting or forgery. No mother current contact details.')
a=start('우편 날짜 대조');ys=[160,310,460]
for label,y in zip(['반송 접수','본보기 작업','초대 발송'],ys):a +=[txt(48,y,label,22),rect(48,y+63,380,2,'#c1ab81')]
save('D09_post_dates_template',a,['MS14_D09_S04_L0015','MS14_D10_P01_L0036'],['반송 접수','본보기 작업','초대 발송'],fields=[{'key':k,'region':[48,y+16,380,42]} for k,y in zip(['returned_date','copy_work_date','invitation_sent_date'],ys)],status='runtime_template_not_complete_evidence',notes='Only relative order is authored. Display after player comparison, not a replacement for three original pieces. No invented calendar dates.')
# Safe folded outer face. No rendering of hidden content anywhere.
a=['<svg xmlns="http://www.w3.org/2000/svg" width="480" height="640" viewBox="0 0 480 640">','<title>접힌 종이 바깥 면</title>',rect(35,181,414,294,'#3c2d24'),rect(27,171,414,294,'#ad895e'),rect(33,177,402,282,'#f0dfbd'),rect(33,177,402,5,'#fff0d0'),rect(35,441,400,12,'#d5be94'),'<path d="M35 182 L430 438" fill="none" stroke="#dbc69f" stroke-width="2"/>',txt(64,249,'6일',24),txt(64,317,'수건 두 장',24),txt(64,385,'소금 한 꾸러미',24)]
save('D10P_receipt_folded_outer',a,['MS14_D10_P01_L0056','MS14_D10_P01_L0070'],['6일','수건 두 장','소금 한 꾸러미'],'father_view_only_at_L0056; public_board_copy_confirmation_at_L0070',notes='Route face is not included in this SVG or PNG, even under folds. No unfold interaction permitted in public duel. Paper must be handed to family closed.')
a=start('남은 온기');fields=[]
for i,label in enumerate(['남은 조각','현재 사용처','실제 받은 사람','다음 확인 시점']):
 y=150+i*112;a +=[txt(48,y,label,21),rect(48,y+65,380,2,'#c1ab81')];fields.append({'key':['remaining','in_use','recipient','next_check'][i],'region':[48,y+16,380,42]})
save('D11_D14_heat_ledger_template',a,['MS14_D11_S03_L0010','MS14_D14_S04_L0016','MS14_D14_S04_L0027'],['남은 조각','현재 사용처','실제 받은 사람','다음 확인 시점'],fields=fields,status='runtime_template_not_complete_evidence',notes='Derive from actual recovery/consumption/handover. D14 display labels are simple UI wording, not additional story evidence. No fabricated stock, guaranteed winter, removal of active school stones, or new manager.')
a=['<svg xmlns="http://www.w3.org/2000/svg" width="480" height="640" viewBox="0 0 480 640">','<title>광장 이름판</title>',rect(10,12,460,616,'#362920'),rect(18,20,444,600,'#70553d'),rect(26,28,428,584,'#9d7a54')]
for y in [126,226,326,426,526]:a +=[rect(32,y,416,6,'#71543c'),rect(32,y+6,416,3,'#b28c61')]
for x in [34,438]:
 for y in [38,590]:a +=[rect(x,y,6,6,'#493b30')]
a +=[txt(56,103,'보미',30,color='#f4e6c9')]
save('D14_names_board_runtime',a,['MS14_D14_S04_L0001','MS14_D14_S04_L0005'],['보미'],fields=[{'key':'confirmed_deceased_names','region':[48,151,380,410]}],status='runtime_template_conditional_names',notes='Show Bomi only after Tosil writes at L0005, not scene start. Additional names only verified historical victims and actual dead this run. Never include Mogwa merely missing, or saved Piko/Owl/Nero/children. Blank slots are intentional.')
# Without Bomi is the true pre-write background.
p=P/'D14_names_board_runtime.svg';s=p.read_text();s=s.replace(txt(56,103,'보미',30,color='#f4e6c9'),'');(P/'D14_names_board_before_write.svg').write_text(s)
subprocess.run(['inkscape',str(P/'D14_names_board_before_write.svg'),'--export-filename='+str(P/'tmp.png')],capture_output=True,check=True);im=Image.open(P/'tmp.png');im.resize((960,1280),Image.Resampling.NEAREST).save(P/'D14_names_board_before_write.png');(P/'tmp.png').unlink()
manifest={'version':'DOCUMENT_PROPS_01','story_basis':D['version'],'assets':assets,'additional_assets':{'D14_names_board_before_write.png':'Before L0005; empty board. Runtime confirmed-deceased overlays only.'},'pixel_grid':'480x640 source rendered and nearest 2x. SVG text editable; Noto Sans/Serif CJK KR required.','source_unchanged':True,'runtime_fields':'Coordinates refer to 480x640 SVG. Multiply by2 in PNG. Block game display of incomplete evidence templates until all required authored fields approved.'}
(P/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
(P/'README.txt').write_text('문서 소품 01\n\n초대장·엄마 메모·경고·답장·이동 쪽지·접힌 인수표는 원문으로 제작했습니다. 원고에 없는 수선 날짜/수량, 우편 날짜/번호, 실시간 재고를 임의로 만들지 않았습니다. template 파일은 개발용 빈 서식이며 완료된 증거로 그대로 출력하지 마세요. manifest.json의 필수 칸을 확정 데이터로 채워야 합니다.\n\n엄마의 경고 및 연락 쪽지는 가족 비공개입니다. 10-P 공개 제시창에 넣지 않습니다. 접힌 인수표에는 경로 면 자체가 들어 있지 않습니다. 이름판은 토실이 보미를 쓰기 전후 파일을 나눴으며 생존 주민 이름을 자동 추가하지 않습니다.\n\nSVG는 글씨를 편집할 수 있고 PNG는 960×1280, 2×2 픽셀 격자입니다. 배경/문서 본문은 레퍼런스 스타일이며 실제 게임 내 필적 감정의 물리적 증거를 추가하지 않습니다. 본편·분기·대사 원본은 수정하지 않았습니다.\n')
# Verification contact sheet.
thumbs=[]
for a in assets:
 im=Image.open(P/a['png']).convert('RGB').resize((240,320));thumbs.append((a['id'],im))
canvas=Image.new('RGB',(1200,960),'#263735')
for i,(name,im) in enumerate(thumbs):canvas.paste(im,((i%5)*240,(i//5)*320))
canvas.save(P/'documents_contact_sheet.jpg',quality=92)
checks=[]
for p in P.glob('*.png'):
 im=Image.open(p).convert('RGBA');import numpy as np
 ar=np.asarray(im);ok=all(np.array_equal(ar[0::2,0::2],ar[dy::2,dx::2]) for dy in [0,1] for dx in [0,1]);checks.append({'file':p.name,'size':im.size,'exact_2x2':ok})
(P/'validation.json').write_text(json.dumps({'images':checks,'source_record_ids_valid':all(rid in records for a in assets for rid in [s['record_id'] for s in a['source']]),'no_runtime_or_mechanical_validation':True},ensure_ascii=False,indent=2))
print(len(assets),'assets')
