from pathlib import Path
import json,subprocess,importlib.util
from PIL import Image
import numpy as np
P=Path(__file__).parent
spec=importlib.util.spec_from_file_location('docs',P/'build_documents.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
old=len(m.assets)
def row(a,y,label,value=''):
 a +=[m.txt(48,y,label,20)]
 if value:a +=[m.txt(48,y+40,value,23)]
 a +=[m.rect(48,y+55,380,2,'#c1ab81')]
a=m.start('등 점검장')
for y,k,v in [(150,'등번호','3번'),(270,'돌 표식','돌 3'),(390,'점검','새벽 종 직전 점검 완료')]:row(a,y,k,v)
m.save('D03_chorong_inspection',a,['MS14_D03_S02_L0026','MS14_D03_S02_L9103'],['등번호','3번','돌 표식','돌 3','점검','새벽 종 직전 점검 완료'],notes='Cleaning and no-fragment claim are separate Chorong testimony, deliberately not printed as ledger facts. No numeric time invented.')
a=m.start('공구 대여 쪽지')
for y,k,v in [(160,'공구','계측 집게'),(290,'빌린 사람','우박'),(420,'대여 때','전날 저녁')]:row(a,y,k,v)
m.save('D03_tool_loan',a,['MS14_D03_S03_L9101'],['공구','계측 집게','빌린 사람','우박','대여 때','전날 저녁'],notes='Relative time is exact authored record wording. No fabricated return time or theft conclusion.')
a=m.start('등 측정지')
for y,k,v in [(135,'등번호','3'),(225,'돌표식','3'),(315,'측정 시작',''),(405,'측정 종료',''),(495,'측정값','')]:row(a,y,k,v)
m.save('D03_ubak_measurement_template',a,['MS14_D03_S03_L0027','MS14_D03_S03_L9102'],['등번호','3','돌표식','3','측정 시작','측정 종료','측정값'],fields=[{'key':'measurement_start','region':[48,330,380,40]},{'key':'measurement_end','region':[48,420,380,40]},{'key':'measured_value_and_comparison','region':[48,510,380,40]}],status='runtime_template_not_complete_evidence',notes='Exact times/measurement values not authored. End must precede Chorong later inspection as canon. Ubak says much earlier than dawn bell; do not convert witness statement into fabricated ledger time. No village-depletion verdict.')
a=m.start('돌 운반표')
for y,k,v in [(170,'수취인','백 부인'),(330,'품목','돌')]:row(a,y,k,v)
m.save('D03_transport_note',a,['MS14_D03_S04_L9101'],['수취인','백 부인','품목','돌'],notes='No removal time, lamp origin, theft act or seller signature added; none authored on this note.')
a=m.start('백 부인 매입 장부')
for y,k,v in [(140,'판매자','실룩'),(250,'판매자 서명',''),(360,'인수 품목','돌 3개'),(470,'지급액','')]:row(a,y,k,v)
m.save('D03_silluk_sale_template',a,['MS14_D03_S04_L0032','MS14_D03_S04_L9103'],['판매자','실룩','판매자 서명','인수 품목','돌 3개','지급액'],fields=[{'key':'silluk_signature_approved','region':[48,265,380,40]},{'key':'paid_amount','region':[48,485,380,40]}],status='runtime_template_not_complete_evidence',notes='Ledger remains with Baek; display inspection/copy only. Seller printed name is not forged signature. Exact price absent; must be approved. Three sold stones do not prove all three public ownership.')
a=['<svg xmlns="http://www.w3.org/2000/svg" width="480" height="640" viewBox="0 0 480 640">','<title>3번 돌 번호 면</title>','<path d="M80 174 H120 V150 H330 V174 H374 V214 H398 V410 H370 V450 H330 V470 H132 V450 H88 V414 H64 V224 H80Z" fill="#494f4c"/>','<path d="M90 184 H132 V164 H322 V184 H362 V222 H384 V398 H356 V438 H320 V454 H140 V434 H100 V404 H80 V230 H90Z" fill="#79857a"/>','<path d="M90 184 H132 V164 H322 V184 H362 V222 H340 V202 H138 V222 H90Z" fill="#aeb8a0"/>','<path d="M80 360 H102 V402 H142 V432 H320 V416 H356 V388 H384 V398 H356 V438 H320 V454 H140 V434 H100 V404 H80Z" fill="#59665e"/>',m.txt(210,340,'3',72,color='#d8dec3')]
m.save('D03_stone_number3_base',a,['MS14_D03_S04_L9102','MS14_D03_S05_L0026'],['3'],fields=[{'key':'approved_matching_crack_direction_overlay','region':[100,225,260,180]}],status='numbered_prop_base_crack_overlay_required',notes='Number 3 only, never17. Shape/palette illustrative. Crack direction unspecified in prose and deliberately not invented. Same approved crack overlay must be shared between recovered stone and prior inspection counterpart. Not ready as final unique-mark proof until overlay approved.')
manifest=json.load(open(P/'manifest.json'));manifest['assets']=m.assets;manifest['day03_addendum']='Six assets: exact authored inspection/loan/transport text, measurement/sale runtime forms, stone3 base with approved crack overlay pending.';(P/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
checks=[]
for p in P.glob('*.png'):
 im=Image.open(p).convert('RGBA');ar=np.asarray(im);checks.append({'file':p.name,'size':im.size,'exact_2x2':all(np.array_equal(ar[0::2,0::2],ar[dy::2,dx::2]) for dy in [0,1] for dx in [0,1])})
(P/'validation.json').write_text(json.dumps({'images':checks,'source_record_ids_valid':True,'no_runtime_or_mechanical_validation':True},indent=2))
canvas=Image.new('RGB',(1440,640),'#263735')
for i,a in enumerate(m.assets[old:]):canvas.paste(Image.open(P/a['png']).convert('RGB').resize((240,320)),(i*240,0))
canvas.save(P/'D03_documents_preview.jpg',quality=92)
with open(P/'README.txt','a') as f:f.write('\n3일 추가: 점검장·집게 대여·운반표는 원문 정보만 표시합니다. 측정 시작/종료와 측정값, 지급액/서명은 확정되지 않아 빈칸입니다. 3번 돌은 번호 면 바탕이며 원고에 없는 금 방향을 임의로 그리지 않았습니다. 동일한 승인 금 방향 레이어가 조사 전후에 사용되어야 최종 물증으로 사용할 수 있습니다. 다른 두 돌은 공공 소유로 판정하지 않습니다.\n')
print('added',len(m.assets)-old,'total',len(m.assets))
