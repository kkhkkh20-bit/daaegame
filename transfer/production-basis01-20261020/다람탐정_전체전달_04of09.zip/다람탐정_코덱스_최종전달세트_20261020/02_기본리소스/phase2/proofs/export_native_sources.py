from pathlib import Path
import subprocess,json,hashlib
from PIL import Image
P=Path(__file__).resolve().parent
# Native vector masters. Raster export uses 1 logical pixel = 2 output pixels.
def svg(name,defs,body,w=400,h=320):
 s=f'<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="{w*2}" height="{h*2}" viewBox="0 0 {w} {h}" shape-rendering="crispEdges"><defs>{defs}</defs>{body}</svg>'
 (P/(name+'.svg')).write_text(s)
 subprocess.run(['inkscape',str(P/(name+'.svg')),'--export-type=png',f'--export-filename={P/(name+".png")}',f'--export-width={w}',f'--export-height={h}'],capture_output=True,check=True)
 im=Image.open(P/(name+'.png')).convert('RGBA');im.resize((w*2,h*2),Image.Resampling.NEAREST).save(P/(name+'.png'))
def use(i):return '<use xlink:href="#'+i+'"/>'
# Rim fracture imported unchanged in its own local coordinates, translated/scaled with bottle.
rim='266,70 320,70 320,145 296,145 296,128 282,128 282,108 266,108'
# Entire bottle built at logical scale, old rim coordinates transformed 0.5 then translation.
body='''<g id="bottle">
<path d="M140 106 H260 V120 H272 V132 H284 V148 H290 V270 H282 V280 H118 V270 H110 V148 H116 V132 H128 V120 H140 Z" fill="#243d38"/>
<path d="M146 108 H254 V126 H266 V138 H278 V154 H282 V264 H274 V272 H126 V264 H118 V154 H124 V138 H136 V126 H146 Z" fill="#637d6b"/>
<path d="M146 112 H158 V132 H142 V148 H134 V258 H146 V266 H128 V258 H126 V152 H132 V138 H146 Z" fill="#a1b69a"/>
<path d="M254 118 V136 H268 V154 H272 V256 H264 V266 H274 V264 H282 V154 H278 V148 H266 V138 H254 Z" fill="#435f52"/>
<path d="M158 140 H250 V148 H262 V240 H254 V250 H148 V240 H140 V152 H150 V144 H158 Z" fill="#738d75"/>
<path d="M243 110 V270" stroke="#38564b" stroke-width="2"/>
<path d="M144 180 H258 V238 H144 Z" fill="#364c3e"/>
<path d="M142 176 H256 V234 H142 Z" fill="#c8b98d"/>
<path d="M148 182 H250 V228 H148 Z" fill="#e0d3ac"/>
<path d="M154 188 H244 V190 H154 Z M154 218 H244 V220 H154 Z" fill="#ab986f"/>
<path d="M158 198 H184 V202 H158 Z M158 208 H222 V210 H158 Z" fill="#8c8061"/>
<path d="M150 258 H234 V262 H150 Z" fill="#99ad8a"/>
<!-- Existing rim source, half scale, offset 100 35. -->
<g transform="translate(100 35) scale(.5)">
<path d="M80 70 H320 V145 H80 Z" fill="#29483f"/>
<path d="M84 74 H316 V141 H84 Z" fill="#718a73"/>
<path d="M88 78 H312 V86 H88 Z" fill="#b3c2a2"/>
<path d="M88 90 H312 V98 H88 Z" fill="#3c5b4d"/>
<path d="M88 104 H312 V132 H88 Z" fill="#81967b"/>
<path d="M286 70 V145" stroke="#304e47" stroke-width="4"/>
<path d="M86 82 H314" stroke="#d3d9b3" stroke-width="2"/>
</g></g>'''
fragment=f'<polygon points="{rim}" transform="translate(100 35) scale(.5)"/>'
defs=body+f'<clipPath id="fragclip">{fragment}</clipPath><mask id="remain" maskUnits="userSpaceOnUse" x="0" y="0" width="400" height="320"><rect width="400" height="320" fill="white"/><g fill="black">{fragment}</g></mask><g id="main"><g mask="url(#remain)">{use("bottle")}</g></g><g id="fragment"><g clip-path="url(#fragclip)">{use("bottle")}</g></g>'
cap='''<g id="seal"><path d="M138 52 H262 V76 H138 Z" fill="#382f27"/><path d="M144 46 H256 V68 H144 Z" fill="#9a7850"/><path d="M150 50 H250 V56 H150 Z" fill="#b89866"/><path d="M148 62 H254 V68 H148 Z" fill="#705438"/><path d="M188 46 H208 V118 H188 Z" fill="#8b4b3c"/><path d="M192 48 H204 V116 H192 Z" fill="#b36b4f"/><path d="M194 54 H202 V104 H194 Z" fill="#c18b62"/></g>'''
for name,content in [('D12_bottle_open_intact',use('bottle')),('D12_bottle_sealed',use('bottle')+use('seal')),('D12_bottle_broken',use('main')),('D12_rim_fragment',use('fragment')),('D12_bottle_reassembled_DEV',use('main')+use('fragment'))]:svg(name,defs+cap,content)
svg('D12_comparison_DEV',defs+cap,'<rect width="800" height="320" fill="#dfd2ac"/>'+use('main')+'<g transform="translate(135 140)">'+use('fragment')+'</g><g transform="translate(400 0)">'+use('main')+use('fragment')+'</g>',800)
# Knife source imported, preserving original fracture/texture coordinates. Add handle outside blade mask.
ks=(P/'_D03_previous_geometry.svg').read_text()
kdefs=ks.split('<defs>')[1].split('</defs>')[0]
kdefs=kdefs.replace('href=', 'xlink:href=')
# Handle attached before the blade, no hidden serial numbers or newly asserted evidence.
handle='''<g id="handle"><path d="M8 78 H58 V152 H8 V146 H2 V84 H8 Z" fill="#382d26"/><path d="M10 84 H52 V146 H10 Z" fill="#795339"/><path d="M12 86 H20 V144 H12 Z" fill="#a07a50"/><path d="M24 90 H28 V136 H24 Z M40 94 H44 V140 H40 Z" fill="#573c2c"/><path d="M32 96 H40 V104 H32 Z M32 126 H40 V134 H32 Z" fill="#b2a075"/><path d="M52 76 H62 V154 H52 Z" fill="#58605b"/><path d="M54 78 H58 V152 H54 Z" fill="#c0b99c"/></g>'''
kdefs+=handle
for name,content in [('D03_knife_intact_DEV',use('handle')+use('source')),('D03_knife_broken',use('handle')+use('main')),('D03_knife_fragment',use('fragment')),('D03_knife_reassembled_DEV',use('handle')+use('main')+use('fragment'))]:svg(name,kdefs,'<g transform="translate(20 54)">'+content+'</g>')
svg('D03_knife_comparison_DEV',kdefs,'<rect width="800" height="320" fill="#dfd2ac"/><g transform="translate(20 54)">'+use('handle')+use('main')+'</g><g transform="translate(410 54)">'+use('fragment')+'</g>',800)
# Same lantern exterior in closed/open images. Layer toggles, no fabricated time or identity markings.
frame='''<g id="frame"><path d="M180 22 H220 V28 H232 V40 H240 V66 H252 V76 H270 V86 H282 V256 H272 V270 H128 V256 H118 V86 H130 V76 H148 V66 H160 V40 H168 V28 H180 Z" fill="#293a35"/><path d="M184 30 H216 V36 H226 V48 H230 V64 H170 V48 H174 V36 H184 Z" fill="#b4ad83"/><path d="M154 76 H246 V82 H262 V90 H138 V82 H154 Z" fill="#5d7161"/><path d="M130 94 H270 V250 H130 Z" fill="#1f302e"/><path d="M136 100 H264 V244 H136 Z" fill="#45574c"/><path d="M138 102 H144 V242 H138 Z M256 102 H262 V242 H256 Z" fill="#83917a"/><path d="M132 250 H268 V262 H132 Z" fill="#71806a"/><path d="M142 264 H258 V270 H142 Z" fill="#172d29"/></g>'''
holder='''<g id="holder"><path d="M152 210 H248 V222 H252 V234 H148 V222 H152 Z" fill="#192c29"/><path d="M158 212 H242 V218 H158 Z" fill="#abb096"/><path d="M158 222 H220 V226 H158 Z" fill="#6c7a65"/><path d="M224 220 H240 V228 H224 Z" fill="#0e201e"/><path d="M232 224 H238 V226 H232 V230 H226 V228 H230 V226 H232 Z" fill="#c0c6be"/></g>'''
latch='''<g id="latch"><path d="M268 158 H294 V178 H268 Z" fill="#172b27"/><path d="M270 160 H292 V166 H270 Z M284 166 H290 V180 H284 Z" fill="#acaa85"/><path d="M272 166 H280 V174 H272 Z" fill="#677763"/><path d="M286 172 H292 V174 H286 Z" fill="#d0c7a3"/></g>'''
door='''<g id="door"><path d="M144 100 H254 V244 H144 Z" fill="#9eae87"/><path d="M150 106 H248 V238 H150 Z" fill="#71866d"/><path d="M154 110 H160 V234 H154 Z M162 110 H174 V114 H162 Z" fill="#bfca9d"/><path d="M220 118 H226 V230 H220 Z" fill="#8c9b77"/><path d="M144 100 H254 V106 H144 Z M144 238 H254 V244 H144 Z" fill="#364d40"/></g>'''
ldefs=frame+holder+latch+door
svg('D03_lantern_closed',ldefs,use('frame')+use('door')+use('latch'))
svg('D03_lantern_open_empty',ldefs,use('frame')+use('holder')+use('latch'))
svg('D03_lantern_positions_DEV',ldefs,'<rect width="800" height="320" fill="#dfd2ac"/>'+use('frame')+use('door')+use('latch')+'<g transform="translate(400 0)">'+use('frame')+use('holder')+use('latch')+'</g>',800)
# Validate from rendered exports, never alter generated AI bitmaps.
checks={}
for prefix,master,main,frag in [('D12','D12_bottle_open_intact','D12_bottle_broken','D12_rim_fragment'),('D03','D03_knife_intact_DEV','D03_knife_broken','D03_knife_fragment')]:
 a=Image.open(P/(master+'.png')).convert('RGBA');b=Image.open(P/(main+'.png')).convert('RGBA');c=Image.open(P/(frag+'.png')).convert('RGBA')
 checks[prefix]={'reconstruction_equal':Image.alpha_composite(b,c).tobytes()==a.tobytes(),'dimensions':a.size}
checks['grid_2x']={}
for f in P.glob('*.png'):
 im=Image.open(f).convert('RGBA');checks['grid_2x'][f.name]=im.resize((im.width//2,im.height//2),Image.Resampling.NEAREST).resize(im.size,Image.Resampling.NEAREST).tobytes()==im.tobytes()
(P/'validation.json').write_text(json.dumps(checks,indent=2))
(P/'manifest.json').write_text(json.dumps({'version':'DT_PROP_SHARED_MASTER_02','raster_grid':'2 output pixels / logical pixel','assets':[{'file':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(P.glob('*')) if f.suffix in ['.svg','.png']], 'D12':{'master':'D12_bottle_open_intact.svg','fragment_original_points':rim,'transform':'translate(100 35) scale(.5)','seam_original_x':286,'masks':'fragmentClip and complementary remainingMask; source uses same complete bottle','sealed_overlay':'cap and continuous paper strip; only pre-opening depiction','comparison_DEV':'Spoilers, developer-only. Never displayed during setup.'},'D03':{'fracture_source':'daram-evidence-art-20261020/geometry/D03_knife_source.svg','knife_transform':'translate(20 54)','holder_fragment_hotspot_logical':[224,220,240,230],'outer_latch_hotspot_logical':[268,158,294,180],'lantern_status':'Proposed render of existing holder/latch relationship; must fit existing scene background before release'},'verification_limit':'Exact 2D raster reconstruction and shared geometry only. Not forensic uniqueness, contact mechanics, scale realism, actual game readability, or scene integration.'},ensure_ascii=False,indent=2))
(P/'사용안내.txt').write_text('다람탐정 물증 공통 원본 제작 02\n\nD12: 같은 병 원본에서 봉인 상태, 개봉 뒤 온전한 상태(개발 검수), 파손 상태, 분리 파편을 만들었습니다. 파편과 병의 제조 이음선은 원본 좌표를 공유합니다. 봉인 그림은 범행 이전 관찰용이며 파손 병 그림에 봉인이 남은 것처럼 혼용하지 않습니다. 무늬 같은 라벨 선은 장식이며 글자·약명·추리 근거가 아닙니다. 필요한 약명은 승인된 대본의 게임 텍스트로 표시합니다.\n\nD03: 기존 칼끝 경계를 유지하고 손잡이를 덧붙였습니다. 온전한 칼은 실제 획득 증거가 아니므로 DEV 검수 전용입니다. 파편은 원본 위치의 투명 캔버스에 보관되어 있어 좌표를 그대로 겹치면 재결합됩니다. 확대 화면에서는 같은 배율로 확대하고, 파편을 독립적으로 찌그러뜨리지 않습니다.\n\n등 그림은 외부 걸쇠와 내부 돌받침의 위치를 보여 주는 제작 시안입니다. 원래 등 배경의 구조와 비교하여 채택해야 합니다. 이 그림을 새 증거로 추가하거나 물리적 거리의 독립 입증으로 사용하지 않습니다.\n\nDEV 이름이 붙은 비교·재결합 그림은 개발자용입니다. 반박 전에 정답 윤곽이나 조립 완료 상태를 보여 주지 않습니다. 모든 PNG는 투명 배경(비교판 제외), 2× 픽셀 격자입니다. SVG는 편집 원본입니다. 실제 화면에서의 파손면 읽힘·시야·접촉은 아직 플레이 검증하지 않았습니다.\n')
print(json.dumps(checks,indent=2))
# Deterministic discrete-grid partition: SVG fractional masks can produce alpha seams.
# Partition rendered native master pixels with ONE binary mask; both halves inherit the same source RGBA.
import numpy as np
maskdefs=f'<g id="fm" fill="white">{fragment}</g>'
svg('_D12_fragment_mask',maskdefs,use('fm'))
# Knife source fragment silhouette, not painted texture.
kpoly='260,70 340,130 260,160 272,146 260,132 280,120 264,108 276,94 260,84'
svg('_D03_fragment_mask','',f'<g transform="translate(20 54)"><polygon points="{kpoly}" fill="white"/></g>')
for prefix,master,main,frag in [('D12','D12_bottle_open_intact','D12_bottle_broken','D12_rim_fragment'),('D03','D03_knife_intact_DEV','D03_knife_broken','D03_knife_fragment')]:
 a=np.array(Image.open(P/(master+'.png')).convert('RGBA'));mask=np.array(Image.open(P/('_'+prefix+'_fragment_mask.png')).convert('RGBA'))[:,:,3]>0
 m=a.copy();f=a.copy();m[mask]=0;f[~mask]=0
 Image.fromarray(m).save(P/(main+'.png'));Image.fromarray(f).save(P/(frag+'.png'))
 merged=Image.alpha_composite(Image.fromarray(m),Image.fromarray(f));merged.save(P/(( 'D12_bottle_reassembled_DEV' if prefix=='D12' else 'D03_knife_reassembled_DEV')+'.png'))
 checks[prefix]['reconstruction_equal']=merged.tobytes()==Image.fromarray(a).tobytes()
 checks[prefix]['partition']='RGBA master split by native SVG mask threshold alpha>0, complementary grid sets, no rescaling of parts'
# Rebuild presentation proof sheets from these native vector exports only.
can=Image.new('RGBA',(1600,640),'#dfd2ac');can.alpha_composite(Image.open(P/'D12_bottle_broken.png'),(0,0));can.alpha_composite(Image.open(P/'D12_rim_fragment.png'),(270,280));can.alpha_composite(Image.open(P/'D12_bottle_reassembled_DEV.png'),(800,0));can.save(P/'D12_comparison_DEV.png')
can=Image.new('RGBA',(1600,640),'#dfd2ac');can.alpha_composite(Image.open(P/'D03_knife_broken.png'),(0,0));can.alpha_composite(Image.open(P/'D03_knife_fragment.png'),(740,0));can.save(P/'D03_knife_comparison_DEV.png')
for f in P.glob('*.png'):
 im=Image.open(f).convert('RGBA');checks['grid_2x'][f.name]=im.resize((im.width//2,im.height//2),Image.Resampling.NEAREST).resize(im.size,Image.Resampling.NEAREST).tobytes()==im.tobytes()
(P/'validation.json').write_text(json.dumps(checks,indent=2))
m=json.loads((P/'manifest.json').read_text());m['raster_partition']='Masks rasterized from native vector geometry and thresholded into disjoint pixel sets. PNG pairing is authoritative; live SVG renderer fractional clipping may produce alpha edge seams.';m['assets']=[{'file':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(P.glob('*')) if f.suffix in ['.svg','.png']];(P/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
with (P/'사용안내.txt').open('a') as w:w.write('\n정확 결합 기준은 PNG입니다. SVG 렌더러의 소수 좌표 마스크가 투명 경계를 만들 수 있어, 같은 원본을 1논리픽셀 격자의 상보 마스크로 나누어 PNG로 저장했습니다. 양쪽 PNG를 합치면 원본 RGBA가 완전히 복원됩니다. SVG를 게임에서 직접 다시 렌더링하는 대신 제공 PNG를 쓰세요. _로 시작하는 마스크 파일은 제작용이며 플레이어에게 표시하지 않습니다.\n')
print('FINAL',checks['D12'],checks['D03'])
