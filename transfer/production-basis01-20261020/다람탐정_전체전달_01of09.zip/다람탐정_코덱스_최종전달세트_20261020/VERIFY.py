#!/usr/bin/env python3
"""Verify the complete delivery set using only Python's standard library."""
from pathlib import Path
import hashlib, json, sys
ROOT = Path(__file__).resolve().parent
manifest = json.loads((ROOT / 'MASTER_MANIFEST.json').read_text(encoding='utf-8'))
errors = []
def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()
for item in manifest['files']:
    path = ROOT / item['path']
    if not path.is_file():
        errors.append('MISSING: ' + item['path'])
    elif path.stat().st_size != item['bytes'] or digest(path) != item['sha256']:
        errors.append('MISMATCH: ' + item['path'])
coverage = json.loads((ROOT / 'SOURCE_COVERAGE.json').read_text(encoding='utf-8'))
count = 0
for source in coverage['source_archives']:
    if source['source_file_count'] != source['retained_file_count']:
        errors.append('SOURCE COUNT: ' + source['source_archive'])
    for item in source['files']:
        count += 1
        path = ROOT / item['destination']
        if not path.is_file() or digest(path) != item['source_sha256']:
            errors.append('SOURCE RETENTION: ' + item['destination'])
for item in coverage['additional_source_files']:
    path = ROOT / item['destination']
    if not path.is_file() or digest(path) != item['source_sha256']:
        errors.append('ADDITIONAL SOURCE: ' + item['destination'])
expected = {item['path'] for item in manifest['files']} | {'MASTER_MANIFEST.json'}
actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
extras = sorted(actual - expected)
if errors:
    print('FAIL')
    for error in errors: print(error)
    sys.exit(1)
print('PASS: ' + str(len(manifest['files'])) + ' manifest file hashes match.')
print('PASS: ' + str(count) + ' files from 5 source ZIP archives are preserved byte-for-byte.')
print('PASS: cinematic reading edition is preserved byte-for-byte.')
print('PASS: all required files are present; no file contents changed.')
if extras:
    print('NOTE: additional files are not covered by this manifest:')
    for extra in extras: print(extra)
print('This verifies delivery integrity only, not game runtime, art approval, or playability.')
