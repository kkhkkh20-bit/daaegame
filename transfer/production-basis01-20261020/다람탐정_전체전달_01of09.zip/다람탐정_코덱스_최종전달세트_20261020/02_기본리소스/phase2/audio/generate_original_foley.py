"""Original procedural Foley candidates; no external recording or copyrighted samples.
Run with Python + numpy + scipy. Writes only this resource folder.
"""
from pathlib import Path
import numpy as np
from scipy.signal import butter,sosfilt
import wave,json,hashlib
P=Path(__file__).resolve().parent;SR=48000;rng=np.random.default_rng(20261020)
manifest=[]
def noise(n,lo,hi):
 x=rng.normal(size=n);sos=butter(3,[lo,hi],fs=SR,btype='band',output='sos');return sosfilt(sos,x)
def colored_periodic(n,lo,hi):
 freqs=np.fft.rfftfreq(n,1/SR);scale=np.zeros_like(freqs);q=(freqs>=lo)&(freqs<=hi);scale[q]=(freqs[q]/lo)**(-.65)*np.exp(-(freqs[q]/hi)**4)
 c=(rng.normal(size=len(freqs))+1j*rng.normal(size=len(freqs)))*scale;c[0]=0
 x=np.fft.irfft(c,n);return x/(np.std(x)+1e-12)
def hit(duration,freqs,decay=.09,air=.1):
 n=int(SR*duration);t=np.arange(n)/SR;x=np.zeros(n)
 for f,a in freqs:x+=a*np.sin(2*np.pi*f*t)*np.exp(-t/decay*(f/freqs[0][0])**.5)
 x+=air*noise(n,80,1800)*np.exp(-t/.035)
 return x*(1-np.exp(-t/.002))
def save(name,x,scenes,intent,loop=False):
 x=np.asarray(x,dtype=float);x-=np.mean(x)
 if not loop:
  k=min(480,len(x)//8);x[:k]*=np.linspace(0,1,k);x[-k:]*=np.linspace(1,0,k)
 x=x/(np.max(np.abs(x))+1e-12)*10**(-6/20)
 if loop:x=np.r_[x,x[0]]
 pcm=np.rint(x*32767).astype('<i2');path=P/(name+'.wav')
 with wave.open(str(path),'wb') as w:w.setnchannels(1);w.setsampwidth(2);w.setframerate(SR);w.writeframes(pcm.tobytes())
 d=np.diff(pcm.astype(np.int32));peak=np.max(np.abs(pcm.astype(np.int32)))/32768
 manifest.append({'file':path.name,'scenes':scenes,'intent':intent,'duration_s':len(pcm)/SR,'sample_rate':SR,'channels':1,'encoding':'PCM signed16 little endian','peak_dbfs':float(20*np.log10(peak)),'clipped_samples':int(np.sum(np.abs(pcm.astype(np.int32))>=32767)),'loop':loop,'first_last_sample_delta':int(abs(int(pcm[-1])-int(pcm[0]))),'maximum_adjacent_delta':int(np.max(np.abs(d))),'loop_note':'Periodic source with matching first/last sample; auditory repeat/gap not yet listened in engine.' if loop else '10ms edge fades; one shot.','subjective_listening':'not verified; synthesized candidate, not field recording','sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
# Rolling wooden wheels: circular low rumble, irregular periodic axle knocks, no tonal bleeps.
n=SR*8-1;t=np.arange(n)/SR
roll=.11*colored_periodic(n,35,650)*(1+.18*np.sin(2*np.pi*3*np.arange(n)/n))
for i in range(16):
 h=hit(.32,[(92,1),(163,.35),(281,.1)],.07,.12)*rng.uniform(.6,1)
 start=int((i/16*n+rng.uniform(-.025,.025)*SR)%n)
 np.add.at(roll,(start+np.arange(len(h)))%n,h)
save('SFX_cart_wood_roll_loop',roll,['MS14_D01_S01','MS14_D13_S03','MS14_D13_S04'],'마차/수레가 실제 움직일 때만. 대결 중 저음량.',True)
n=SR*2;t=np.arange(n)/SR
x=.15*noise(n,35,700)*(np.sin(np.pi*t/2)**2)
for at,amp in [(.18,1),(.62,.6),(1.08,.45),(1.54,.35)]:
 h=hit(.3,[(88,1),(174,.25)],.08,.15)*amp;k=int(at*SR);x[k:k+len(h)]+=h
save('SFX_cart_start',x,['MS14_D01_S01','MS14_D13_S03'],'수레가 움직이기 시작하는 실제 행동 전용')
x=.13*noise(n,40,1000)*np.maximum(0,1-t/1.5)
for at,amp in [(.08,.4),(.45,.6),(.92,1)]:
 h=hit(.45,[(79,1),(153,.4),(245,.1)],.11,.15)*amp;k=int(at*SR);x[k:k+len(h)]+=h
save('SFX_cart_stop',x,['MS14_D13_S04'],'바퀴가 실제 멎은 분기에만 사용. 정답 제출만으로 자동 재생하지 않음')
for i in range(2):
 n=int(SR*.8);t=np.arange(n)/SR;env=(1-np.exp(-t/.025))*np.exp(-t/.12)
 x=(noise(n,100,2200)*1.5+.28*np.sin(2*np.pi*(82+i*8)*t)*np.exp(-t/.07))*env
 save('SFX_snow_step_'+str(i+1),x,['MS14_D07_S04','MS14_D07_P02','MS14_D11_S01'],'눈길 실제 보행용 A/B 변주. 대사 클릭마다 재생 금지')
x=hit(1.4,[(236,1),(407,.48),(679,.16)],.14,.14)
save('SFX_tin_can_tap',x,['MS14_D06_S02','MS14_D06_S03'],'깡통을 건드리는 실제 장면용. 아이 피해를 알리는 시스템 경고음이 아님')
n=int(SR*1.3);t=np.arange(n)/SR;x=noise(n,65,1600)*.55*np.exp(-((t-.45)/.20)**4)
for at,amp in [(.10,.6),(.73,1)]:
 h=hit(.3,[(125,1),(213,.3)],.045,.18)*amp;k=int(at*SR);x[k:k+len(h)]+=h
save('SFX_door_bolt_slide',x,['MS14_D07_S03','MS14_D07_S04'],'빗장을 실제 움직이는 시점. 조용히 들려야 하는 분기는 음량 조절')
n=SR*2;t=np.arange(n)/SR;env=(np.sin(np.pi*t/2)**2)*(.7+.3*np.sin(2*np.pi*1.5*t)**2)
x=noise(n,90,1300)*env
save('SFX_tool_rub_quiet',x,['MS14_D14_S02'],'공구 작업 중단/재개에 맞춰 낮게 재생. 성공 여부를 암시하는 효과음 금지')
x=noise(n,80,1800)*((np.sin(np.pi*t/2)**2)*(.65+.35*np.sin(2*np.pi*2.2*t)**2))
save('SFX_cloth_rub_quiet',x,['MS14_D11_S02A','MS14_D11_S02B','MS14_D13_S01'],'양말/단추/담요를 실제 만질 때만. 장면ID는 최종 대사행과 연결 확인')
n=SR*10-1;a=np.arange(n)/n
x=colored_periodic(n,30,950)*(.6+.18*np.sin(2*np.pi*a)+.12*np.cos(2*np.pi*3*a))+.18*colored_periodic(n,150,1700)*(.5+.3*np.sin(2*np.pi*2*a)**2)
save('AMB_cold_wind_loop',x,['MS14_D11_S04','MS14_D13_S03','MS14_D14_S02'],'겨울 야외 바람. 실내와 따뜻한 생활 장면에서 과도하게 사용하지 않음',True)
(P/'audio_manifest.json').write_text(json.dumps({'version':'DT_ORIGINAL_FOLEY_CANDIDATES_01','source':'Original deterministic procedural synthesis. No external samples or melodies.','status':'Technical export checked; listening and mix not approved.','reuse_avoided':['Council_Desk_OneHit.ogg','Council_Soft-Air_Transition.ogg','Council_SmallRoom_Murmur_Loop.ogg'],'assets':manifest},ensure_ascii=False,indent=2))
(P/'사용안내.txt').write_text('다람탐정 추가 효과음 시안\n\n외부 녹음이나 음악 샘플을 쓰지 않고 저역 잡음과 짧게 감쇠하는 공명으로 직접 합성한 후보입니다. 실제 현장 녹음이라고 표기하지 않습니다.\n\n모두 48kHz, 모노, 16비트 PCM WAV, 최고 피크 약 -6dBFS입니다. 10파일: 수레 구름 반복/출발/정지, 눈 발걸음2종, 깡통, 빗장, 공구 마찰, 천 마찰, 찬바람 반복. 기존 회의 책상/작은방 웅성거림/전환음을 중복 제작하지 않았습니다.\n\n반복음은 주기 신호와 같은 시작·끝 샘플을 사용했습니다. 오디오 엔진이 파일 경계에 무음을 삽입하지 않도록 실제 기기에서 반복 청취를 확인해야 합니다. 경계 수치 검증은 청취 승인과 다릅니다.\n\n일반 효과음은 대사보다 낮게, 바람과 수레 반복은 더 낮게 섞어 시작하세요. -6dBFS는 파일 최대치이지 권장 게임 재생 음량이 아닙니다. 공구/천 마찰은 특히 작게 재생하세요. 자동으로 모든 관련 장면에 재생하지 말고 실제 행위가 있는 대사행에 연결하세요.\n\n음색과 리얼리티는 아직 직접 청취 검수하지 않았습니다. 고음 전자 알림음 대신 낮은 질감 중심으로 만들었지만, 실제 휴대폰에서 소리가 답답하거나 전자음처럼 들릴 수 있어 믹스 테스트가 필요합니다. 이 파일만으로 전체 배경음악/음향 자산이 완성된 것은 아닙니다.\n')
print(json.dumps(manifest,ensure_ascii=False,indent=2))
