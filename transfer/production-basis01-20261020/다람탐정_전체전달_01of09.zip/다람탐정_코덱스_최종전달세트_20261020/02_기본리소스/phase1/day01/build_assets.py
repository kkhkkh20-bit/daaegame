from pathlib import Path
import json,html,subprocess
from PIL import Image
D=Path(__file__).parent
INK='#493b30'; TEAL='#405d57'; FADE='#88734f'
def tx(x,y,s,size=22,color=INK,bold=False):
 return f'<text x="{x}" y="{y}" font-family="Noto Sans CJK KR" font-size="{size}" font-weight="{700 if bold else 400}" fill="{color}">{html.escape(s)}</text>'
def rect(x,y,w,h,c):return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{c}"/>'
def paper(title,theme):
 a=['<svg xmlns="http://www.w3.org/2000/svg" width="480" height="640" viewBox="0 0 480 640">',f'<title>{title}</title>',rect(12,16,460,616,'#3c2d24'),'<path d="M16 8 H448 V16 H464 V604 H456 V620 H16Z" fill="#ad895e"/>',rect(20,16,436,596,'#e7cea3'),rect(26,22,424,584,'#f0dfbd'),rect(26,22,424,4,'#fff0d0'),rect(26,600,424,6,'#c4a273'),rect(32,30,412,58,theme),tx(48,67,title,25,'#fff0d0',True),rect(48,104,384,2,'#c1ab81')]
 return a
assets=[]
def save(name,a,lines,ids,evidence,regions=None):
 a.append('</svg>');p=D/(name+'.svg');p.write_text(''.join(a))
 subprocess.run(['inkscape',str(p),'--export-type=png','--export-filename='+str(D/(name+'_base.png'))],capture_output=True,check=True)
 im=Image.open(D/(name+'_base.png'));im.resize((960,1280),Image.Resampling.NEAREST).save(D/(name+'.png'));(D/(name+'_base.png')).unlink()
 assets.append(dict(file=name+'.png',editable_svg=name+'.svg',dimensions=[960,1280],evidence=evidence,source_records=ids,visible_text=lines,regions_base480x640=regions or {},date_overlay_required=evidence in ['E02','E03']))
a=paper('초소 입장 명단','#77523a')
lines=['도착일','다돌','신청 2명','신규 일꾼 본인 1명','동행 아동 모집 제외','내일부터 장작 운반','처리  너울']
a += [tx(48,145,'도착일',18,FADE),rect(124,151,288,2,'#c1ab81')]
for y,s in [(201,lines[1]),(251,lines[2]),(321,lines[3]),(371,lines[4]),(465,lines[5]),(551,lines[6])]:a += [tx(48,y,s),rect(48,y+15,384,2,'#d5be94')]
save('D01_E02_gate_processing',a,lines,['MS14_D01_S02_L0019'],'E02',{'arrival_date':[124,117,288,36],'worker':[44,290,390,44],'excluded_child':[44,340,390,44]})
a=paper('訪問 신청서'.replace('訪問','방문'),TEAL)
lines=['도착일','신청자 다돌 외 1명','동행 아동 있음','총 2명','가족 방문','동행인 성명 다람','숙소 확인','여관 13호','방문 가족 2명 숙박 확인']
a += [tx(48,145,'도착일',18,FADE),rect(124,151,288,2,'#c1ab81')]
for y,s in [(201,lines[1]),(247,lines[2]),(293,lines[3]),(339,lines[4]),(385,lines[5])]:a += [tx(48,y,s),rect(48,y+13,384,2,'#d5be94')]
a += [rect(44,430,392,150,'#d9c6a2'),rect(48,434,384,142,'#f6e8c9'),tx(60,463,lines[6],18,FADE),tx(60,503,lines[7],24),tx(60,549,lines[8],21)]
save('D01_E03_visit_application',a,lines,['MS14_D01_S03_L0002'],'E03',{'arrival_date':[124,117,288,36],'family_visit':[44,308,390,44],'daram_name':[44,354,390,44],'lodging':[44,430,392,150]})
a=paper('겨울철 입장 규칙',TEAL)
lines=['가족 방문은 숙소가 확인된','동행 인원으로 등록한다.','초소는 실제 인원과 숙소를','확인해 현장 등록·정정할 수 있다.','신규 일꾼은 작업 명단의','본인만 등록한다.']
for y,st in [(163,0),(323,2),(483,4)]:
 a += [rect(48,y-24,4,66,'#a17b50'),tx(64,y,lines[st],21),tx(64,y+40,lines[st+1],21)]
save('D01_E04_winter_rules',a,lines,['MS14_D01_S03_L0007'],'E04',{'family_rule':[44,130,392,96],'correction_rule':[44,290,392,96],'worker_rule':[44,450,392,96]})
# Lodging detail is a crop of E03, not separate evidence or authored document.
im=Image.open(D/'D01_E03_visit_application.png');im.crop((88,860,872,1160)).save(D/'D01_E03_lodging_detail.png')
# Preview is a native SVG contact sheet, with documents embedded as images, no added clue labels.
import base64
pv=['<svg xmlns="http://www.w3.org/2000/svg" width="1500" height="720" viewBox="0 0 1500 720">',rect(0,0,1500,720,'#263735'),tx(24,702,'제작 시안 · 날짜 미확정 / 본편 출력 전 같은 도착일을 입력해야 합니다.',20,'#f0dfbd')]
for i,r in enumerate(assets):
 b64=base64.b64encode((D/r['file']).read_bytes()).decode();pv.append(f'<image x="{i*500+10}" y="20" width="480" height="640" href="data:image/png;base64,{b64}"/>')
pv.append('</svg>');(D/'D01_documents_preview.svg').write_text(''.join(pv));subprocess.run(['inkscape',str(D/'D01_documents_preview.svg'),'--export-filename='+str(D/'D01_documents_preview.png')],capture_output=True,check=True)
manifest={'version':'DAY01_RESOURCE_01','story_basis':'DT_STORY_1.1_PRODUCTION_BASIS_01_20261020','source_scene_ids':['MS14_D01_S02','MS14_D01_S03'],'status':'readable_art_with_required_date_overlay_not_final_game_integrated','style_reference':'daram-branch-record-design/05_notebook_thumbnail_flow.svg','assets':assets,'lodging_detail':{'file':'D01_E03_lodging_detail.png','derived_from':'D01_E03_visit_application.png','crop_pixels':[88,860,872,1160],'evidence':'E03','not_new_evidence':True},'blocking_ambiguity':'Source only says same arrival day, not the in-world calendar date. E02/E03 both have blank date overlay fields; fill identical authorized game date before shipping. Do not show blank-date assets as completed evidence.','font':'Noto Sans CJK KR. PNG embeds raster glyphs; SVG requires font or outline conversion.','pixel_grid':'Rendered 480x640 then nearest-neighbor 2x to 960x1280. All 2x2 output pixels identical. Glyph raster antialias retained inside base pixels for readable Korean.','no_changes':'No dialogue, clue, branch, engine code, or existing source art modified.'}
(D/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
(D/'README.txt').write_text('1일 초소 문서 리소스 01\n\nE02 입장 명단, E03 방문 신청서(숙소 확인 칸 포함), E04 겨울철 입장 규칙의 세 자료입니다. 숙소 확대 이미지는 E03의 실제 동일 영역을 잘라 만든 것으로, 새 문서나 네 번째 증거가 아닙니다.\n\n중요: 원고는 도착일이 같다고만 규정하고 구체적인 날짜를 정하지 않았습니다. 날짜를 임의 생성하지 않았으므로 E02와 E03의 도착일 칸은 개발 시 같은 실제 게임 날짜로 채워야 합니다. 현재 빈 날짜 상태로 최종 게임에 사용하지 마세요.\n\nPNG는 960×1280, 480×640 원본 렌더의 정확한 2배 확대입니다. 비교 화면에서 정답 표시, 밑줄, 범인 정보, 추론 해설은 포함하지 않았습니다. 지역 좌표는 manifest.json에 있습니다. 기존 본편과 코드에는 적용하지 않았습니다.\n')
print(json.dumps({'files':len(list(D.iterdir())),'assets':len(assets)},ensure_ascii=False))
