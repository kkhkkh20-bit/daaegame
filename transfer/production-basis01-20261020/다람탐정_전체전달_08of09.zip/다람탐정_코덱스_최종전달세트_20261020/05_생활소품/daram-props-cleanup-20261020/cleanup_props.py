#!/usr/bin/env python3
"""Conservative, reproducible cleanup of four approved Daram prop sources.

Native outputs: preserve every nonzero-alpha source pixel and every alpha value.
Only invisible RGB at alpha=0 is cleared. Components are partitioned, not painted.
Optional 2x2 outputs: technical candidates, NOT visually lossless replacements.
Run: python cleanup_props.py --root .
Requires: Python 3.10+, Pillow, numpy, scipy.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage as ndi

SOURCES = [
    ("phase2/daily_objects/D01_open_bundle_base.png", [
        ("D01_open_bundle", "열린 보따리", (650, 600))]),
    ("phase2/daily_objects/D02_exchange_box_open_empty.png", [
        ("D02_exchange_box_empty", "교환함 (원본 주머니 유지)", (700, 650))]),
    ("phase2/daily_objects/D11_family_supplies_sheet.png", [
        ("D11_blanket_ochre", "황토색 담요 1장", (300, 300)),
        ("D11_blanket_teal", "청록색 담요 1장", (800, 300)),
        ("D11_mittens_pair", "장갑 한 쌍", (1300, 300)),
        ("D11_sewing_pouch_group", "바느질 주머니 묶음", (500, 800)),
        ("D11_button", "단추", (1100, 750)),
        ("D11_short_thread", "짧은 실", (1345, 750))]),
    ("phase2/fire/D06_tincan_oilcloth.png", [
        ("D06_tincan_alarm", "깡통 경보기", (350, 600)),
        ("D06_oilcloth", "기름 묻은 천", (1400, 600))]),
]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def grid_check(a):
    h, w = a.shape[:2]
    if h % 2 or w % 2:
        return {"even_dimensions": False, "rgba_identical_2x2": False,
                "origin": [0, 0], "nonuniform_blocks": None}
    b = a.reshape(h // 2, 2, w // 2, 2, 4).transpose(0, 2, 1, 3, 4)
    bad = np.any(b != b[:, :, :1, :1, :], axis=(2, 3, 4))
    return {"even_dimensions": True, "rgba_identical_2x2": not bool(bad.any()),
            "origin": [0, 0], "nonuniform_blocks": int(bad.sum())}

def alpha_stats(a):
    z = a[:, :, 3]
    return {"min": int(z.min()), "max": int(z.max()),
            "fully_transparent_pixels": int((z == 0).sum()),
            "partially_transparent_pixels": int(((z > 0) & (z < 255)).sum()),
            "opaque_pixels": int((z == 255).sum()),
            "alpha_zero_nonzero_rgb_pixels": int(np.any(a[:, :, :3][z == 0] != 0, axis=1).sum())}

def save(a, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(a).save(path, optimize=True)

def strict_2x2_candidate(a):
    """Pick an existing foreground RGB per 2x2 cell, never invent a new color.

    The alpha>=128 majority rule is a silhouette approximation. A two-pixel tie
    is retained to conserve narrow strokes. All output alpha is 0 or 255.
    All actual source pixels remain available in assets_native/.
    """
    h, w = a.shape[:2]
    b = a.reshape(h // 2, 2, w // 2, 2, 4).transpose(0, 2, 1, 3, 4)
    b = b.reshape(h // 2, w // 2, 4, 4)
    fg = b[:, :, :, 3] >= 128
    keep = fg.sum(axis=2) >= 2
    # Medoid among existing visible RGB samples minimizes in-block alteration.
    rgb = b[:, :, :, :3].astype(np.int32)
    distance = np.abs(rgb[:, :, :, None, :] - rgb[:, :, None, :, :]).sum(axis=-1)
    score = (distance * fg[:, :, None, :]).sum(axis=-1)
    score[~fg] = 1000000
    pick = score.argmin(axis=-1)
    yy, xx = np.indices(pick.shape)
    q = b[yy, xx, pick].copy()
    q[:, :, 3] = np.where(keep, 255, 0)
    q[~keep] = 0
    return q.repeat(2, axis=0).repeat(2, axis=1)

def font(size):
    for p in ["/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc", 
              "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]:
        if Path(p).exists():
            return ImageFont.truetype(p, size)
    return ImageFont.load_default(size=size)

def composite_panel(im, size, color, nearest=False):
    im = im.copy()
    im.thumbnail(size, Image.Resampling.NEAREST if nearest else Image.Resampling.LANCZOS)
    bg = Image.new("RGBA", size, color + (255,))
    bg.alpha_composite(im, ((size[0] - im.width) // 2, (size[1] - im.height) // 2))
    return bg.convert("RGB")

def make_previews(root, sources, assets):
    # Real alpha compositions. These must not imply the hidden-RGB change was a
    # large visible halo repair: native BEFORE and AFTER are deliberately equal.
    colors = [(238, 237, 231), (26, 31, 40)]
    for i, (source, cleaned) in enumerate(sources, 1):
        before, after = Image.open(source).convert("RGBA"), Image.open(cleaned).convert("RGBA")
        sheet = Image.new("RGB", (1440, 1080), (247, 246, 242))
        d = ImageDraw.Draw(sheet)
        d.text((24, 12), f"{i:02d}  {source.stem}", font=font(27), fill=(28, 35, 43))
        d.text((24, 52), "원본 / 정상 알파 합성", font=font(22), fill=(28, 35, 43))
        d.text((744, 52), "정리본 / 보이는 픽셀·알파 그대로", font=font(22), fill=(28, 35, 43))
        for row, col in enumerate(colors):
            for column, im in enumerate([before, after]):
                sheet.paste(composite_panel(im, (696, 450), col), (24 + column * 720, 90 + row * 470))
        d.text((24, 1032), "밝은 배경 / 어두운 배경 · 두 열은 정상 합성 시 픽셀 단위 동일 · 원본의 숨은 RGB만 제거", font=font(20), fill=(46, 55, 65))
        sheet.save(root / "previews" / f"{i:02d}_{source.stem}_before_after.png")

    # Demonstrate why naive viewers show a misleading large halo.
    p = root / "originals/phase2/daily_objects/D11_family_supplies_sheet.png"
    raw = Image.open(p).convert("RGBA")
    cleaned = Image.open(root / "cleaned_sheets/D11_family_supplies_sheet.png").convert("RGBA")
    sheet = Image.new("RGB", (1440, 620), (247, 246, 242)); d = ImageDraw.Draw(sheet)
    d.text((24, 12), "넓은 빛의 정체: 투명도 없이 RGB만 표시한 비교", font=font(29), fill=(28, 35, 43))
    d.text((24, 58), "원본 RGB (알파 무시, 정상 게임 합성 아님)", font=font(21), fill=(28, 35, 43))
    d.text((744, 58), "정리본 RGB (알파 0의 색상값 제거)", font=font(21), fill=(28, 35, 43))
    for i, im in enumerate([raw, cleaned]):
        opaque = im.convert("RGB").convert("RGBA")
        sheet.paste(composite_panel(opaque, (696, 464), (0, 0, 0)), (24 + i * 720, 96))
    d.text((24, 578), "넓은 후광 대부분은 보이지 않는 RGB 데이터였다. 정상 합성의 외형은 바꾸지 않았다.", font=font(22), fill=(46, 55, 65))
    sheet.save(root / "previews/00_hidden_RGB_explanation.png")

    cell_w, cell_h = 700, 360
    sheet = Image.new("RGB", (1440, 60 + cell_h * 5 + 70), (247, 246, 242)); d = ImageDraw.Draw(sheet)
    d.text((24, 12), "개별 추출 10종 · 원본 외형 보존판", font=font(28), fill=(28, 35, 43))
    for i, entry in enumerate(assets):
        col, row = i % 2, i // 2; x, y = 20 + col * 720, 65 + row * cell_h
        im = Image.open(root / entry["native_file"]).convert("RGBA")
        d.text((x, y), f"{i+1:02d}. {entry['label_ko']}", font=font(22), fill=(28, 35, 43))
        d.text((x, y + 30), entry["id"], font=font(16), fill=(90, 96, 106))
        sheet.paste(composite_panel(im, (cell_w, 285), colors[i % 2]), (x, y + 60))
    d.text((24, sheet.height-50), "깡통 끈의 위쪽 잘림은 원본 상태 그대로. 바느질 도구와 장갑은 겹친 묶음을 임의로 분해하지 않음.", font=font(20), fill=(46, 55, 65))
    sheet.save(root / "previews/05_individual_assets.png")

    # Four exact source-pixel crops at nearest 4x, native vs optional 2x2.
    specs = [("D01_open_bundle", (820, 300, 916, 396)),
             ("D11_blanket_teal", (210, 120, 306, 216)),
             ("D11_sewing_pouch_group", (390, 170, 486, 266)),
             ("D11_short_thread", (36, 94, 132, 190))]
    sheet = Image.new("RGB", (1616, 1070), (247, 246, 242)); d = ImageDraw.Draw(sheet)
    d.text((24, 12), "선택용 2×2 격자판 · 외형 보존판과 차이 있음", font=font(28), fill=(28, 35, 43))
    for i, (aid, crop) in enumerate(specs):
        x, y = 16 + (i%2)*800, 80 + (i//2)*480
        d.text((x, y-20), aid+"   (최근접 4배 확대)", font=font(19), fill=(28, 35, 43))
        for j, directory in enumerate(["assets_native", "pixel2x_candidates"]):
            im = Image.open(root/directory/(aid+".png")).convert("RGBA").crop(crop)
            im = im.resize((384,384), Image.Resampling.NEAREST)
            bg=Image.new("RGBA",im.size,colors[1]+(255,));bg.alpha_composite(im)
            sheet.paste(bg.convert("RGB"),(x+j*396,y+20))
            d.text((x+j*396,y+412), "외형 보존" if j==0 else "2×2 정규화 후보",font=font(21),fill=(28,35,43))
    d.text((24, 1020), "격자판은 색면·외곽을 재표본화한다. 얇은 실·질감에 차이가 있어 원본과 동일하다고 주장하지 않음.", font=font(21), fill=(46,55,65))
    sheet.save(root/"previews/06_pixel2x_detail_comparison.png")

def run(root):
    for d in ["assets_native", "pixel2x_candidates", "cleaned_sheets", "previews"]:
        (root / d).mkdir(parents=True, exist_ok=True)
    report = {"version": 1, "date": "2026-10-20", "runtime_tested": False,
              "visual_scope": "Four source PNGs; real light/dark alpha composites; extraction and optional grid candidate detail comparisons.",
              "native_method": "Preserve all alpha and all RGB wherever alpha > 0. Set RGB to zero only at alpha=0. No threshold, recoloring, dilation, erosion, repainting or new generation.",
              "extraction_method": "Connected alpha>=128 cores, manually identified by interior seed; all nonzero-alpha pixels assigned to nearest core, exactly once. Crop with even origin/dimensions and transparent padding. Reassembly must reproduce the cleaned source exactly.",
              "pixel2x_method": "Optional lifestyle-only RGBA 2x2 normalization: majority alpha>=128, retain 2/2 ties, RGB medoid among in-cell foreground source colors, alpha 0/255. Not visually lossless. Fire evidence excluded from resampling.",
              "excluded": ["Crayon family drawing", "Portraits and faces", "All characters", "Evidence-shape redesign", "Game code and runtime bindings"],
              "sources": [], "assets": [], "limitations": [
                  "Normal alpha composites already hide most wide apparent glow. Clearing hidden RGB must not be described as a major visible halo removal.",
                  "Native outputs preserve all semi-transparency, including fine edge pixels. No legitimate translucent detail is hard-thresholded.",
                  "D06 tin rope reaches and is cut by the original top canvas edge; no missing rope is reconstructed.",
                  "Mittens, sewing pouch/needle/spool, scarf/pencils and exchange-box pouch overlap their bases and are not separated or reconstructed.",
                  "Native image grid is not strict 2x2. Only the eight optional lifestyle variants meet the strict RGBA grid check.",
                  "Strict 2x2 technical validity is not art approval. Texture and thin edges change in optional grid variants.",
                  "No game-engine, mobile display, branch count, collision, story or evidence proof verification."]}
    preview_pairs=[]
    for source_rel, entries in SOURCES:
        src = root / "originals" / source_rel
        old = np.array(Image.open(src).convert("RGBA"))
        a = old.copy(); a[a[:,:,3]==0,:3]=0
        cleaned = root / "cleaned_sheets" / src.name; save(a,cleaned)
        preview_pairs.append((src,cleaned))
        labels, n = ndi.label(a[:,:,3]>=128)
        assert n == len(entries), (src,n,len(entries))
        nearest=ndi.distance_transform_edt(labels==0,return_distances=False,return_indices=True)
        assignments=labels[nearest[0],nearest[1]]
        recon=np.zeros_like(a)
        record={"source": source_rel,"original_file":"originals/"+source_rel,
                "original_sha256":digest(src),"cleaned_file":str(cleaned.relative_to(root)),
                "cleaned_sha256":digest(cleaned),"size":[a.shape[1],a.shape[0]],
                "alpha_before":alpha_stats(old),"alpha_after":alpha_stats(a),
                "alpha_unchanged":bool(np.array_equal(old[:,:,3],a[:,:,3])),
                "visible_rgb_unchanged":bool(np.array_equal(old[old[:,:,3]>0],a[old[:,:,3]>0])),
                "only_alpha_zero_rgb_changed":bool(np.all(np.any(old!=a,axis=2)<= (old[:,:,3]==0))),
                "grid_original":grid_check(old),"grid_native_cleaned":grid_check(a),
                "component_count":n, "light_dark_composites_identical":True}
        # Exact alpha-compositing equality, not a thumbnail approximation.
        for color in [(238,237,231,255),(26,31,40,255)]:
            b1=Image.new("RGBA",Image.fromarray(old).size,color);b1.alpha_composite(Image.fromarray(old))
            b2=Image.new("RGBA",Image.fromarray(a).size,color);b2.alpha_composite(Image.fromarray(a))
            record["light_dark_composites_identical"] &= bool(np.array_equal(np.array(b1),np.array(b2)))
        used=set()
        for aid,label,seed in entries:
            k=int(labels[seed[1],seed[0]]);assert k and k not in used,(aid,k);used.add(k)
            mask=(assignments==k)&(a[:,:,3]>0)
            part=np.zeros_like(a);part[mask]=a[mask];recon[mask]=part[mask]
            yy,xx=np.where(mask); bx0,bx1=int(xx.min()),int(xx.max()+1);by0,by1=int(yy.min()),int(yy.max()+1)
            x0=(bx0//2)*2-8;y0=(by0//2)*2-8
            x1=((bx1+1)//2)*2+8;y1=((by1+1)//2)*2+8
            out=np.zeros((y1-y0,x1-x0,4),np.uint8)
            cx0,cx1=max(0,x0),min(a.shape[1],x1);cy0,cy1=max(0,y0),min(a.shape[0],y1)
            out[cy0-y0:cy1-y0,cx0-x0:cx1-x0]=part[cy0:cy1,cx0:cx1]
            target=root/"assets_native"/(aid+".png");save(out,target)
            e={"id":aid,"label_ko":label,"source":source_rel,"native_file":str(target.relative_to(root)),
               "native_sha256":digest(target),"canvas_size":[out.shape[1],out.shape[0]],
               "source_bbox_nonzero_alpha_xyxy":[bx0,by0,bx1,by1],
               "source_position_of_output_top_left_xy":[x0,y0],
               "nonzero_alpha_pixel_count":int(mask.sum()),"alpha":alpha_stats(out),"grid_native":grid_check(out),
               "source_canvas_touched_by_any_alpha_including_faint_noise":bool(bx0==0 or by0==0 or bx1==a.shape[1] or by1==a.shape[0]),
               "source_canvas_clips_visible_shape":bool(np.any(labels[0,:]==k) or np.any(labels[-1,:]==k) or np.any(labels[:,0]==k) or np.any(labels[:,-1]==k)),
               "runtime_auto_apply":False,"visual_approval":"review_candidate_preserving_source"}
            if "/daily_objects/" in source_rel:
                q=strict_2x2_candidate(out);qpath=root/"pixel2x_candidates"/(aid+".png");save(q,qpath)
                m=out[:,:,3]>=128;qm=q[:,:,3]>=128
                dd0=ndi.distance_transform_edt(~m);dd1=ndi.distance_transform_edt(~qm)
                changed_core=(out[:,:,3]>=250)&(q[:,:,3]>0)
                rgb_err=np.abs(q[:,:,:3].astype(int)-out[:,:,:3].astype(int))[changed_core]
                e["pixel2x"]={"file":str(qpath.relative_to(root)),"sha256":digest(qpath),"grid":grid_check(q),
                              "alpha":alpha_stats(q),"technical_candidate_only":True,
                              "alpha128_silhouette_added_pixels":int((qm&~m).sum()),
                              "alpha128_silhouette_removed_pixels":int((m&~qm).sum()),
                              "alpha128_silhouette_iou":float((m&qm).sum()/(m|qm).sum()),
                              "maximum_silhouette_displacement_pixels":float(max(dd0[qm].max(),dd1[m].max())),
                              "opaque_core_mean_rgb_abs_difference_0_255":float(rgb_err.mean()),
                              "opaque_core_rgb_unchanged_fraction":float(np.all(q[:,:,:3][changed_core]==out[:,:,:3][changed_core],axis=1).mean()),
                              "native_to_grid_not_lossless":True}
            else:
                e["pixel2x"]={"file":None,"status":"not_resampled_to_preserve_evidence_shape"}
            report["assets"].append(e)
        record["extraction_reassembles_exact_rgba"]=bool(np.array_equal(recon,a))
        assert record["extraction_reassembles_exact_rgba"]
        report["sources"].append(record)
    report["counts"]={"original_source_pngs":4,"native_cleaned_sheets":4,"native_individual_assets":10,"optional_strict_2x2_assets":8,"excluded_fire_resamples":2}
    make_previews(root,preview_pairs,report["assets"])
    (root/"QA.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    (root/"ASSET_MAP.json").write_text(json.dumps({"runtime_auto_apply":False,"assets":report["assets"]},ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    return report

if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("--root",type=Path,default=Path(__file__).resolve().parent)
    args=p.parse_args();r=run(args.root.resolve());print(json.dumps(r["counts"],ensure_ascii=False));print("All four native source reassemblies and real alpha composites are pixel-identical.")
