# First-batch centralized pixel comparison

Status: comparison only. Not final game integration. Existing runtime has 560/760/840 modes; render scaling and anchor configuration must be resolved separately. No game/repo/deployment edits were made.

## Improved normalization
The previous teacher test independently fit each pose to 560px. This central revision instead measures the default pose and applies ONE common scale to the entire character sheet. Thus hunched heads, raised hands and body acting do not cause the torso to shrink or expand just because the overall bbox changes. All poses are bottom-aligned to the same placement anchor with one shared canvas per character. Default is 560px only as a comparison benchmark; it does NOT mean all game characters have the same physical height. In particular Bori remains crouched.

Body ratios and source poses are preserved; exact integer output sizes require subpixel rounding of the common scale. Placement x is visual bounding-box center, not an anatomical foot point. Feet-bottom alignment can still move the anatomical position if a tail or prop extends below the boots; such cases need an explicit source ankle/ground anchor. Current reviewed sheets do not show major below-foot props, except Bori's wood bundle has a slightly lower extent; his bottom anchor is silhouette/prop-bottom rather than precise ankle ground. Runtime integration must resolve that anchor rather than claiming anatomical stability.

## Filter
Original smooth sheet, alpha128 component isolation, fringe alpha<8 discarded, default-derived common scale, LANCZOS normalization, BOX 1/2 reduction, alpha128 threshold, nearest2x expansion. No dithering, no noise, no palette reduction, no new image generation, no per-pose pixel painting. Every 2×2 RGBA block is verified exactly constant. manifest.json records original source bbox, common scale, actual visible bbox and output SHA.

## Visual review
- Teacher retains mature scholarly acting and costume. Glasses/eye intersections remain the finest features; readable at560 but not as crisp as carefully hand-placed pixels. Mane carries more small shading clusters than several other characters.
- Neoul: soft broad coat shadows and very fine glasses. Distinct upper body poses. Relatively thin contour line compared with Nubi.
- Nubi: thicker clean outlines and simpler high-contrast coat planes. Clothing silhouette and hair stay consistent. Raw master viewer shows colored background RGB, but alpha is transparent; central thresholded output has no backdrop.
- Bori: squat anatomy and wood bundle retained; joy/anger use very similar open-palm silhouettes, expressions differ. Face is more simplified cartoon rendering than teacher. Crouched default is not proof of correct runtime standing-relative height.
- Chorong: slender rabbit, scarf, satchel and lantern maintained. Simplified face and finer costume contours. Ears/head lean cause valid height variation.
- Kwaeksun: feather pink/black shapes, coat/skirt/scarf retained; strong facial read and distinct wing gestures. New smooth redraw is not identical to previous approved hand-pixel reference.
- Guard: face markings, scarf, coat, notebook, tail remain consistent; angry/anxious eyebrow differences legible, hand gesture changes present.
- Madam: cream cape, covered neckline, muted green sleeves and purple dress remain coherent; dress broad planes are simpler than teacher mane. Small lacing stays detailed, may alias at smaller displays.

Uniform filtering equalizes pixel grid but does NOT erase source lineweight/shading style differences. No claim of complete art-direction convergence. This comparison is adequate to review the batch direction before final runtime-size exports or any targeted corrections.

## Files
Each character directory has5 smooth normalized comparisons,5 pixel outputs, and native-scale 2-row comparison. all-characters-pixel-overview.png is a contact sheet at exactly50% nearest, so each 2px output cell becomes1px there. Do not infer actual game relative heights from the overview. Large image previews may be fitted again by the app.

## Last two additions
Guseul and Doto were generated as separate full-resolution pose files and then assembled without resizing into a sheet, unlike the first8 one-call sheets. The observed head/foot scale is very close across their poses, and the centralized transform remains one common scale; this does not guarantee that independent generations have mathematically identical anatomy. Their source per-figure resolution (~1500px) is materially higher than the other sheets (~550–700px); compare normalized outputs, not raw source detail.
- Guseul: slim orange long-eared fox identity, olive jacket, bow, trousers and boots persist. Default/angry/anxious poses have clear arm changes but lower-body stance is essentially fixed. Big eyes read clearly, suit folds are broad. Compared with teacher, rendering is less densely shaded.
- Doto: current deer identity, cloven hands, blue coat and rust scarf retained. Body acting is mostly arms/shoulders, lower body repeats. Large simple eyes read strongly. Not the obsolete squirrel design.
Investigative-action images from this worker are separate from the requested50 dialogue-image comparison and are not filtered or included here.
