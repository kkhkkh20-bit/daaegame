from pathlib import Path
import json,hashlib
from PIL import Image
P=Path(__file__).parent;root=Path('/workspace/shared/smooth-batch02-six');manifest=json.loads((root/'manifest.json').read_text());names=['neutral','joy','angry','anxious','surprise'];chars=list(dict.fromkeys(i['character'] for i in manifest['items']))
records=[];sources={}
for c in chars:
 items=[next(i for i in manifest['items'] if i['character']==c and i['emotion']==n) for n in names]
 paths=[root/i['file'] for i in items];ims=[Image.open(p).convert('RGBA') for p in paths]
 W=sum(im.width for im in ims)+80*6;H=max(im.height for im in ims)+80
 sheet=Image.new('RGBA',(W,H));x=80
 for im in ims:sheet.alpha_composite(im,(x,H-40-im.height));x+=im.width+80
 dst=P/'sources'/f'{c}-delivered-source-sheet.png';sheet.save(dst);sources[c]=str(dst)
 records.append({'character':c,'input_files':[str(p) for p in paths],'sha256':[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths],'assembly':'No resize or drawing. Delivered final manifest PNGs placed in a horizontal row,80px gutters,40px bottom margin. Existing24px source padding retained.','output':str(dst)})
(P/'sources.json').write_text(json.dumps(sources,indent=2));(P/'source-provenance.json').write_text(json.dumps(records,indent=2))
