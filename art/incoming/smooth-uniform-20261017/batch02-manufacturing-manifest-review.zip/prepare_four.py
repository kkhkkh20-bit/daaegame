from pathlib import Path
import json,hashlib,sys
from PIL import Image
P=Path(__file__).parent;root=Path('/workspace/shared/smooth-batch02-four');manifest=json.loads((root/'manifest.json').read_text());names=['neutral','joy','angry','anxious','surprise'];chars=['kalbaram','siluk','guldol']+(['solbang'] if '--include-solbang' in sys.argv else [])
sources={};records=[]
for c in chars:
 items=[next(i for i in manifest['assets'] if i['character']==c and i['expression']==n) for n in names];paths=[Path(i['path']) for i in items];ims=[Image.open(p).convert('RGBA') for p in paths]
 W=sum(im.width for im in ims)+80*6;H=max(im.height for im in ims)+80;sheet=Image.new('RGBA',(W,H));x=80
 for im in ims:sheet.alpha_composite(im,(x,H-40-im.height));x+=im.width+80
 dst=P/'sources'/f'{c}-delivered-source-sheet.png';sheet.save(dst);sources[c]=str(dst)
 records.append({'character':c,'input_files':[str(p) for p in paths],'sha256':[hashlib.sha256(p.read_bytes()).hexdigest() for p in paths],'assembly':'No resizing. Final manifest pose PNGs in horizontal row with80px gutters and40px bottom margin.','output':str(dst)})
(P/'additional-sources.json').write_text(json.dumps(sources,indent=2));(P/'source-provenance-four.json').write_text(json.dumps(records,indent=2))
