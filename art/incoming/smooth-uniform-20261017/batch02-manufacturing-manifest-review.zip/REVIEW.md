# Second batch: centralized uniform pixel comparison

Comparison only. Existing game modes560/760/840 require separate renderer and anchor integration; no repo/GitHub/deployment modifications were made. Default is560px as an inspection benchmark, not game-relative physical size. Each character uses ONE common scale across all5 poses; hunched or raised-limb poses retain differing visible heights. Output grid is2×2 logical pixels, BOX downsample + binary alpha128 + nearest2x. No dithering, no noise, no per-pose redraw or pixel painting.

Inputs use the producer's final manifest-listed PNGs only, with source padding retained. Rejected generations are excluded. Five PNGs are assembled with no resizing,80px gaps and40px bottom margin solely to reuse the approved component-isolation pipeline. Neutral is labeled default in centralized outputs. Source provenance records original files and SHA-256. Source component validation requires exactly5 major non-touching silhouettes; every output's2×2 RGBA repetition is tested exactly. New generation was not performed by central filtering.

First6 characters are based on source sheets with only about479–507px visible height per default. Thus560px comparison uses1.10–1.17x upscale. This is a genuine smooth source but not high-resolution production master art. Rendering at840 does not restore information. Runtime coordinator must decide final scale/pixel-grid design and avoid promising original detail beyond the sources.

## Visual findings
- Piko: orange hair/tail, dark wrap coat, red sash, boots and neutral/joy book retained. Joy lifts one leg and an arm; common scale preserves its size. Strong upper-body expression. Fine hair volume survives moderate filter.
- Mungchi: broad moose antlers, stocky torso, green jacket and cream sweater maintained. Arms and facial expression change; broad shading coherent.
- Mulgyeol: spotted yellow reptile, rust coat, green scarf and thick patterned tail retained. Eyes/teeth remain readable. Tail shape occupies significant bbox width; not a reason to squash the body.
- Dalgeurak: white bird, red coat, brown bag, beige trousers and talon feet maintained. Wing gestures remain legible; hand/wing overlap at anxious pose denser than neutral.
- Jongjong: white bird crest, bow, brown shoulder cape and purple dress retained. Broad dress planes remain clean. Feather hands and neck are fine features to review in actual camera.
- Hyeoni: cream large-eared fox, navy toggle coat, green trousers, bag and fluffy tail retained. Approved reference shown by producer includes a paper/scroll in hand, absent in new neutral. Treat prop-preservation as unresolved before final approval. Anxious pose lowers ears/head substantially; preserving common scale yields about514px visible height instead of forcing it to560.

All6 repeat fairly generic emotional gestures (joy hand up, anger crossed arms, anxiety clasped hands, surprise both hands up). Individual identity stays visible in species/costume, but acting individuality is weaker than a character-specific pose brief. Uniform filtering does not correct this automatically. Existing approved originals remain unchanged.

Overview is50% nearest:2px output blocks become1px in that contact sheet. Per-character comparisons show native output resolution with smooth source row and filtered row. App fit-to-window may further scale the preview.

## Remaining characters
- Kalbaram: grey/cream wolf, long green coat, orange knitwear, blue pouch, brown gloves and ochre boots preserved against the approved reference. Compass remains in neutral; emotional poses use both hands and do not show it. No assumption that prop disappearance is approved for every scene.
- Siluk: cream mane/dark face, yellow knitwear, blue jacket, patched trousers preserved. Coherent larger cel planes and sly default expression. Wide joy gesture is given sufficient canvas, not squeezed to neutral width.
- Guldol: elderly brows, burgundy shirt, brown apron, work trousers, boots and hammer preserved. Surprise raises both hands while hammer appears at waist; attachment loop is not clearly depicted, so hand/prop contact requires review before final production acceptance.
- Solbang: reviewed final repaired source only; the earlier clipped-basket rejection is excluded. Olive herb-worker coat, rust neckerchief, cream shirt, suspenders, patched trousers and herb basket preserved against approved original. All5 baskets are complete in the final sheet. Surprise has basket carried on wrist while palms are up, a plausible different contact from neutral. Anger mouth looks more like a forceful grin than a pure scowl; eyebrows and pointing gesture carry the emotion.

Final count:10 characters ×5 dialogue poses =50 outputs. Investigative work actions are outside this central comparison. All50 outputs use the same deterministic filter. Source quality/resolution is mixed: first6 lower-resolution sheets, final4 generally larger source figures. Differences remain visible in lineweight/shading and cannot be erased by equal pixel grids.
