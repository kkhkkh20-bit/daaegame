from pathlib import Path
import json,hashlib,math
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from scipy.ndimage import label,find_objects,distance_transform_edt
P=Path(__file__).parent
names=['default','joy','angry','anxious','surprise']
S={'teacher':'/workspace/shared/teacher-production-560/source-smooth-master-sheet.png','neoul':'/workspace/shared/smooth-batch01-neoul-nubi/neoul-smooth-master-sheet-v2.png','nubi':'/workspace/shared/smooth-batch01-neoul-nubi/nubi-smooth-master-sheet-v2.png','bori':'/workspace/shared/smooth-batch01-bori-chorong/bori-smooth-master-sheet.png','chorong':'/workspace/shared/smooth-batch01-bori-chorong/chorong-smooth-master-sheet.png'}
for n in ['kwaeksun','guard','resident_madam']:S[n]=f'/workspace/shared/smooth-batch01-kwak-guard-madam/{n}/smooth-master-sheet.png'
# Optional JSON adds final masters when generation finishes, never guessed candidates.
if (P/'additional-sources.json').exists():S.update(json.loads((P/'additional-sources.json').read_text()))
F='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
def f(n):return ImageFont.truetype(F,n)
def even(v):return int(math.ceil(v/2)*2)
records=[]
for char,path in S.items():
 dest=P/char;dest.mkdir(exist_ok=True);a=np.array(Image.open(path).convert('RGBA'))
 lab,_=label(a[:,:,3]>=128);obs=find_objects(lab)
 ids=[i+1 for i,s in enumerate(obs) if s and (s[0].stop-s[0].start)*(s[1].stop-s[1].start)>10000];ids.sort(key=lambda i:obs[i-1][1].start)
 assert len(ids)==5,(char,len(ids))
 _,near=distance_transform_edt(~np.isin(lab,ids),return_indices=True);assign=lab[tuple(near)];crops=[];boxes=[]
 for i in ids:
  b=a.copy();b[:,:,3]=np.where(assign==i,b[:,:,3],0);b[b[:,:,3]<8]=0
  box=Image.fromarray(np.where(b[:,:,3]>=128,255,0).astype('uint8')).getbbox();boxes.append(box);crops.append(Image.fromarray(b).crop(box))
 scale=560/crops[0].height
 sizes=[(round(c.width*scale),round(c.height*scale)) for c in crops]
 W=even(max(w for w,h in sizes)+48);H=even(max(h for w,h in sizes)+48);anchor=[W//2,H-24]
 poses=[];images=[]
 for n,c,size,box in zip(names,crops,sizes,boxes):
  smooth=Image.new('RGBA',(W,H)); x=round((W-size[0])/4)*2;y=anchor[1]-size[1]
  smooth.alpha_composite(c.resize(size,Image.Resampling.LANCZOS),(x,y));smooth.save(dest/f'{n}-smooth.png')
  low=smooth.resize((W//2,H//2),Image.Resampling.BOX);la=np.array(low);la[:,:,3]=np.where(la[:,:,3]>=128,255,0);la[la[:,:,3]==0]=0
  pix=Image.fromarray(la).resize((W,H),Image.Resampling.NEAREST);pix.save(dest/f'{n}-pixel-2px.png');pa=np.array(pix)
  exact=np.array_equal(pa,np.repeat(np.repeat(pa[::2,::2],2,0),2,1));assert exact
  bbox=pix.getbbox();poses.append({'pose':n,'source_bbox':box,'source_size':c.size,'normalized_size_before_grid':size,'visible_bbox':bbox,'visible_height_after_grid':bbox[3]-bbox[1],'foot_bottom_exclusive':bbox[3],'placement_anchor':anchor,'block_repeat_2px_verified':bool(exact),'sha256':hashlib.sha256((dest/f'{n}-pixel-2px.png').read_bytes()).hexdigest()});images.append((smooth,pix))
 rec={'character':char,'source':path,'source_sha256':hashlib.sha256(Path(path).read_bytes()).hexdigest(),'single_sheet_scale':scale,'scale_reference':'default alpha128 bbox ->560px; comparison only, NOT inter-character runtime size','canvas':[W,H],'poses':poses};records.append(rec)
 board=Image.new('RGB',(160+5*(W+8),140+2*(H+8)),'#e9e5dd');d=ImageDraw.Draw(board)
 d.text((20,15),char.upper()+' / SHARED SHEET SCALE / COMPARISON ONLY',font=f(26),fill='#20282e')
 d.text((20,55),'Default 560px; other pose heights preserved. Same 2px filter. Not final runtime sizing.',font=f(20),fill='#48545c')
 for j,(n,pair) in enumerate(zip(names,images)):
  x=160+j*(W+8);d.text((x,100),n.upper(),font=f(19),fill='#20282e')
  for r,img in enumerate(pair):
   y=132+r*(H+8);d.rectangle((x,y,x+W-1,y+H-1),fill='#f8f6f0');board.paste(img,(x,y),img);d.line((x,y+anchor[1],x+W-1,y+anchor[1]),fill='#b6b6ac')
 d.text((12,250),'SMOOTH',font=f(18),fill='#20282e');d.text((12,250+H+8),'2px PIXEL',font=f(18),fill='#20282e');board.save(dest/'comparison.png')
# Contact sheet uses exact 1/2 nearest: every 2px output block becomes 1px here.
CW=380;CH=400;overview=Image.new('RGB',(5*CW,100+len(records)*CH),'#e9e5dd');d=ImageDraw.Draw(overview)
d.text((20,15),'FIRST BATCH / SHARED-SCALE 2px FILTER / COMPARISON ONLY',font=f(25),fill='#20282e')
d.text((20,55),'50% nearest preview: output 2px cells become 1px. Character sizes here are NOT game-relative.',font=f(19),fill='#48545c')
for r,rec in enumerate(records):
 for c,n in enumerate(names):
  im=Image.open(P/rec['character']/f'{n}-pixel-2px.png');im=im.resize((im.width//2,im.height//2),Image.Resampling.NEAREST);x=c*CW+(CW-im.width)//2;y=100+r*CH
  d.text((c*CW+12,y),rec['character']+' / '+n,font=f(16),fill='#20282e');overview.paste(im,(x,y+35),im)
overview.save(P/'all-characters-pixel-overview.png')
(P/'manifest.json').write_text(json.dumps({'status':'comparison-only; runtime 560/760/840 sizing unresolved','policy':'one scale per character sheet based on default, never per-pose bbox matching; no generative changes','filter':'BOX / alpha128 / NEAREST2x / no dither / no palette quantization','characters':records},indent=2))
print('Processed',len(records),'characters',len(records)*5,'poses')
