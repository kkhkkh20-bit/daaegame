# 돌목·도토·구슬 제작 기록

8장 생성, 백 부인 1장 보류. built-in imagegen 사용. 승인 원본 네 종을 직접 확인하고 batch-01.json SHA-256과 일치 검증했다. 모든 생성 PNG는 RGBA, alpha 0–255. 새 디자인 선택이나 게임/보드 변경 없음.

## 근거
- https://github.com/kkhkkh20-bit/daaegame/blob/main/experiments/renpy-ch1/docs/art-coverage/BATCH_01.md
- https://github.com/kkhkkh20-bit/daaegame/blob/main/experiments/renpy-ch1/docs/art-coverage/batch-01.json
- https://github.com/kkhkkh20-bit/daaegame/blob/main/experiments/renpy-ch1/docs/ART_REQUEST_01867_LIFE_ACTIONS.md
- https://github.com/kkhkkh20-bit/daaegame/blob/main/experiments/renpy-ch1/game/assets/room13-world-layout.json

## 미해결
- 8장 모두 승인 대기 후보다. 전신/소품/감정 구분을 직접 확인했으나 원본과 캔버스 및 정확한 비율 일치는 미완료다. 최신 미세 도트 선호에 따라 원본 272×448로 강제 축소하지 않았다.
- pixel-style은 있으나 엄격한 2×2 격자 준수는 인증하지 않았다. 일부 가장자리 미세 반투명 픽셀을 포함한다. 임의 리샘플링/팔레트 변환 없음.
- 도토 action_1은 요청 프롬프트의 왼쪽 대신 오른쪽을 향한다. 자동 반전하지 않았다. 손/시선 및 표시 배율을 실제 장면에서 확인해야 한다.
- 백 부인: 현재 inn.objects에는 보관함/봉인부 좌표가 없다. 과거 문서는 발 좌표 (397,708), (5,682)만 제시한다. 여관 배경 바이너리를 GitHub fetch_file과 fetch_blob으로 읽으려 했으나 두 도구 모두 UTF-8 decode 오류로 실패했다. 임의 보관함·손끝 접점을 생성하지 않았다. 정확한 대상 위치 확인 뒤 제작 필요.
- manifest 접점은 이미지에서 사람이 추정한 픽셀 좌표이며 실제 화면 검수 증거가 아니다. 도토 좌상 높이 비율 0.700은 생성 선 자세 대비 알파 경계 비율이다.

## 생성 지시 요약
공통: 승인 외형·옷 유지, 한 장 한 전신, 투명 배경, 입체적이고 귀여운 정돈된 미세 픽셀, 잡음/텍스트/배경/다른 캐릭터 금지. 돌목은 승인 수정 입을 유지하며 명부 포함.
- joy: 밝게 웃고 한 주먹을 가슴 옆으로 들어 올림.
- flustered: 붉어진 뺨, 머리 뒤 긁기, 명부를 가슴에 품음.
- angry: 찌푸린 눈썹, 항의하는 열린 입, 한 손으로 앞을 가리킴.
- anxious: 걱정 입, 움츠린 어깨, 두 손으로 명부를 가슴에 쥠.
- surprise: 넓어진 눈과 둥근 입, 한 손을 뺨 옆에 들어 올림.
- doto/action_1: 서서 수첩에 연필로 쓰기, 수첩에 시선.
- doto/action_2: 바닥에 앉아 펼친 책 읽기, 위에 빈 투명 공간 유지, 앉은 키 늘리지 않음.
- guseul/living_stamp: 고개 숙여 나무 손잡이 도장의 밑면을 밝은 천으로 닦기. 소품은 두 손 안에서 끝나며 책상 없음.
