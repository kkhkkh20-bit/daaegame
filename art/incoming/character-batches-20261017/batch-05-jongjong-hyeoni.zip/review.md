# Jongjong and Hyeoni candidate asset review
9 transparent full-body PNG candidates: Jongjong 4 expressions + sealed-letter delivery; Hyeoni 4 expressions.
Canonical original SHA values match supplied canonical48 registry. All originals and outputs were visually inspected.
Jongjong: cream-white young duck, plum dress and bow, brown capelet and boots retained.
Hyeoni: large-eyed fennec, huge ears, navy winter coat, orange scarf, olive trousers, grey boots and cream tail retained.
Expressions have distinct facial and upper-body gestures. Delivery shows sealed bundle supported by both hands, hurried stepping and task-directed gaze, without opening or reading letters.
Hyeoni work asset remains held because no unambiguous original string instrument is visible. A golden hip accessory must not be reinterpreted into a new instrument without a verified reference.
Limitations: dialogue sprite margins are narrower than the requested 6%, with low-alpha edge speckling. Body parts are visually complete. Jongjong joy includes small yellow emphasis marks. Runtime registration/alignment and approval remain outstanding.
No code, deployment, or runtime assets changed. Review images are presentation layouts only.
