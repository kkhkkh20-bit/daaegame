다람탐정 대사 근거 소품 8종

masters/: 생성 원본 보존
pixel2x_candidates/: 균일 2×2 RGBA 블록 검증본
contact_sheet.png: 전체 검수 시트
manifest.json: 원문 라인·조건·크기·해시·검수 기록
generation_prompts.json: 생성 프롬프트

런타임 미연결, 게임 내 미검수. 증거 획득·생존·등장 조건을 변경하지 않습니다.
빨간 그릇은 흰 그릇보다 크게 배치해야 합니다. 이름표의 그림상 3장은 생존자 수가 아닙니다.
D14 학교 잠금함 열쇠는 기존 잠금함 형태 확인 전까지 보류합니다.
