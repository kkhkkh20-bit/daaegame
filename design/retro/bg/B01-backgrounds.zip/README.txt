압축을 모두 푼 다음 index.html 또는 bg/B01-preview.html을 브라우저로 열어 주세요. bg/의 PNG 세 장이 새 배경입니다. daram-matched.png는 기존 승인 그림의 미리보기용 사본입니다.
