압축을 모두 푼 뒤 index.html 또는 bg/B02-preview.html을 열어 주세요. bg/의 PNG 세 장이 새 배경이며 daram-matched.png는 기존 승인 그림의 미리보기용 사본입니다. B01 링크와 전체 묶음 다운로드는 온라인 페이지로 연결됩니다.
