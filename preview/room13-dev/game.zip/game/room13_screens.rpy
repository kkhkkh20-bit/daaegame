screen r13_hud():
    style_prefix "r13"
    zorder 20
    frame:
        xpos 848 ypos 16 xsize 407 ysize 72 padding (18,10)
        background R13PaperPanel()
        vbox:
            text r13_clock() size 19 color "#765426"
            text place size 21
    hbox:
        xpos 848 ypos 95 spacing 6
        textbutton "달력" action Show("r13_calendar") text_size 18 padding (14,8)
        textbutton "수첩" action Show("r13_book") text_size 18 padding (14,8)
        textbutton "저장" action ShowMenu("save") text_size 18 padding (14,8)
        textbutton "설정" action ShowMenu("pause_menu") text_size 18 padding (14,8)

screen r13_hub(entry=False):
    style_prefix "r13"
    modal True
    default ready=False
    timer .35 action SetScreenVariable("ready",True)
    button:
        area (0,155,1280,472)
        background None hover_background None insensitive_background None
        action Function(r13_empty_click) sensitive ready
    for key,spec in ROOM13["objects"].get(room13["location"],{}).items():
        if r13_object_visible(spec):
            button:
                area tuple(spec["rect"])
                background None hover_background None insensitive_background None padding (0,0)
                action Return(("object",key)) sensitive ready
    if room13["location"]=="room13":
        textbutton "‹ 복도에서 출입문 보기":
            xpos 24 ypos 155 padding (15,12)
            background R13PaperPanel()
            action Return(("menu","doorway")) sensitive ready text_size 21
    elif room13["location"]=="hall" and r13_has("lodging"):
        textbutton "13호실 안으로 ›":
            xpos 24 ypos 155 padding (15,12)
            background R13PaperPanel()
            action Return(("menu","room_inside")) sensitive ready text_size 21
    if not entry:
        $ present_people=r13_people()
        for i,person in enumerate(present_people[:3]):
            $ behind_counter=person=="granny" and room13["location"]=="inn"
            $ px=840 if behind_counter else 80+i*285
            $ py=200 if behind_counter else 280
            $ feet_y=535 if behind_counter else 610
            add Transform(r13_art(person,"inn_activity" if person=="granny" else "activity"),size=(190,330),fit="contain") xpos px xanchor 0 ypos feet_y yanchor 1.0
            button:
                area (px,py,190,280 if behind_counter else 330)
                background None hover_background None insensitive_background None padding (0,0)
                action Return(("person",person)) sensitive ready
            text R13_NAMES[person] xpos px ypos 610 size 18 color "#fff2cf" outlines [(2,"#182623",0,0)]
        if room13["location"]=="inn":
            add Crop((840,482,190,118),r13_background("front")) xpos 840 ypos 482
    for key,point in room13["checks"].items():
        if key.startswith(room13["location"]+":"):
            add TopicTick() xpos point[0]-13 ypos point[1]-13
    $ last_inspection=room13.get("last_inspection")
    if last_inspection and last_inspection["place"]==room13["location"]:
        add R13InvestigationRing() xpos last_inspection["x"]-28 ypos last_inspection["y"]-28
    frame:
        area (20,635,1240,78) padding (12,12) background R13PaperPanel()
        hbox:
            spacing 8
            if entry:
                textbutton "확인한 자료로 이야기한다" action Return(("entry","argue")) sensitive ready text_size 23
                textbutton "원본 대조를 요청하고 기다린다" action Return(("entry","wait")) sensitive ready text_size 23
            else:
                textbutton "이동하기" action Return(("menu","map")) sensitive ready text_size 20 padding (14,12)
                textbutton "해 볼 일" action Return(("menu","activities")) sensitive ready text_size 20 padding (14,12)
                textbutton "시간 보내기" action Return(("menu","wait")) sensitive ready and room13["period"]<3 text_size 20 padding (14,12)
                textbutton "여관에서 밤 보내기" action Return(("menu","rest")) sensitive ready text_size 20 padding (14,12)
                if len(r13_people())>3:
                    textbutton "주변 사람들" action Return(("menu","people")) sensitive ready text_size 20 padding (14,12)
                textbutton ("읽은 대사 빠르게 · 켬" if r13_fast_read else "읽은 대사 빠르게") action ToggleVariable("r13_fast_read") text_size 17 padding (12,12) sensitive ready

screen r13_interaction(person):
    style_prefix "r13"
    modal True
    default ready=False
    timer .35 action SetScreenVariable("ready",True)
    add Transform(r13_art(person,"interview_neutral"),size=(630,800),fit="contain") xalign .5 ypos 35
    text R13_NAMES[person] xpos 70 ypos 150 size 27 color "#fff2d5" outlines [(2,"#2a211c",0,0)]
    hbox:
        xalign .5 ypos 505 spacing 24
        for command,title,icon in (("talk","대화하기","talk"),("inspect","조사하기","inspect"),("present","제시하기","present"),("move","이동하기","move")):
            button:
                xsize 220 ysize 120 padding (12,10)
                background R13QuestionBar(False) hover_background R13QuestionBar(True)
                action Return(command) sensitive ready
                vbox:
                    xalign .5 spacing 7
                    add R13ActionGlyph(icon) xalign .5
                    text title size 24 color "#342a23" xalign .5
    textbutton "돌아가기" xpos 1070 ypos 665 action Return("back") sensitive ready text_size 22

screen r13_material_corner(key):
    style_prefix "r13"
    zorder 15
    frame:
        area (35,172,222,230) padding (13,12)
        background R13QuestionBar(False)
        vbox:
            spacing 8
            add Transform(r13_icon(key),size=(190,143),fit="contain") xalign .5
            text ROOM13["evidence"][key]["name"] size 19 color "#342a23" xsize 192 text_align .5

# Long translucent question bars retain the resident and room as the visual focus.
screen r13_topics(person):
    style_prefix "r13"
    modal True
    default ready=False
    timer .35 action SetScreenVariable("ready",True)
    add Transform(r13_art(person,"interview_neutral"),size=(630,800),fit="contain") xalign .5 ypos 35
    text R13_NAMES[person] xpos 165 ypos 140 size 25 color "#fff2d5" outlines [(2,"#2a211c",0,0)]
    viewport:
        area (160,190,975,365)
        mousewheel True draggable True scrollbars "vertical"
        vbox:
            spacing 20
            for key,spec in r13_topics(person):
                button:
                    xsize 945 yminimum 68 padding (25,15)
                    background R13QuestionBar(False)
                    hover_background R13QuestionBar(True)
                    insensitive_background R13QuestionBar(False)
                    action Return(key) sensitive ready
                    text ("{s}"+spec["title"]+"{/s}" if key in room13["read_topics"] else spec["title"]):
                        xsize 890 text_align .5 size 27
                        color ("#786e60" if key in room13["read_topics"] else "#342a23")
                        hover_color "#241b13" outlines []
            if not r13_topics(person):
                frame:
                    xsize 945 padding (25,20) background R13QuestionBar(False)
                    text "지금 더 물을 이야기는 없다. 가지고 온 자료를 보여줄 수도 있다." size 24 color "#342a23" xsize 890
    hbox:
        xpos 315 ypos 588 spacing 28
        textbutton "자료 제시하기":
            action Return("present") sensitive ready
            xsize 310 yminimum 60 background R13QuestionBar(False) hover_background R13QuestionBar(True)
            text_color "#342a23" text_hover_color "#241b13" text_size 24 text_xalign .5 padding (20,12)
        textbutton "돌아가기":
            action Return("back") sensitive ready
            xsize 310 yminimum 60 background R13QuestionBar(False) hover_background R13QuestionBar(True)
            text_color "#342a23" text_hover_color "#241b13" text_size 24 text_xalign .5 padding (20,12)

screen r13_confirm(message,yes="진행한다",no="돌아간다"):
    style_prefix "r13"
    modal True
    zorder 65
    default ready=False
    timer .35 action SetScreenVariable("ready",True)
    add Solid("#172a2aa6")
    frame:
        xpos 165 ypos 210 xsize 950 padding (32,28)
        vbox:
            spacing 25
            text message size 26 xsize 880
            hbox:
                spacing 25
                textbutton yes action Return(True) sensitive ready text_size 25
                textbutton no action Return(False) sensitive ready text_size 25

screen r13_map():
    style_prefix "r13"
    modal True
    zorder 45
    default ready=False
    default page=0
    timer .35 action SetScreenVariable("ready",True)
    add r13_background("village_overview")
    add Solid("#172a2aa6")
    text "마을과 여관" xpos 65 ypos 40 size 37 color "#f6ead3"
    text "가 본 곳과 찾아갈 수 있는 곳" xpos 65 ypos 95 size 21 color "#e7d8bd"
    for i,key in enumerate(r13_places()[page*9:(page+1)*9]):
        button:
            area (60+(i%3)*390,165+(i//3)*137,365,110)
            background R13PaperPanel() hover_background R13PaperPanel()
            action Return(key) sensitive ready
            vbox:
                spacing 13
                text R13_PLACES[key][0] size 25 color "#765426"
                text ("현재 위치" if key==room13["location"] else "이곳으로 이동") size 19
    textbutton "돌아가기" xpos 65 ypos 635 action Return(False) sensitive ready
    if page>0:
        textbutton "앞쪽 장소" xpos 595 ypos 635 action SetScreenVariable("page",page-1) sensitive ready
    if (page+1)*9<len(r13_places()):
        textbutton "다른 장소" xpos 875 ypos 635 action SetScreenVariable("page",page+1) sensitive ready

screen r13_activities():
    style_prefix "r13"
    modal True
    zorder 45
    default ready=False
    timer .35 action SetScreenVariable("ready",True)
    add Solid("#172a2aa6")
    frame:
        area (180,160,920,495) padding (26,25)
        vbox:
            spacing 20
            text "지금 해 볼 일" size 32 color "#765426"
            viewport:
                xsize 850 ysize 305 draggable True mousewheel True scrollbars "vertical"
                vbox:
                    spacing 16
                    for key,a in r13_actions():
                        textbutton (a["title"]+(" · "+r13_time_target() if a.get("cost",1) else "")):
                            action Return(key) sensitive ready and (room13["period"]<3 or not a.get("cost",1)) xsize 810 text_size 24
                    if not r13_actions():
                        text "주변을 살피거나 주민과 이야기하며 확인할 일을 찾아보자." size 24 xsize 780
            textbutton "돌아가기" action Return(False) sensitive ready

screen r13_book(target=None,present=False,hearing=False):
    style_prefix "r13"
    modal True
    zorder 50
    default detail=None
    default ready=False
    default archive=False
    timer .35 action SetScreenVariable("ready",True)
    add R13NotebookPaper()
    text ("자료 제시 · "+R13_NAMES.get(target,"재판") if present else "다람이의 수첩") xpos 55 ypos 28 size 32 color "#765426"
    if target:
        add Transform(r13_art(target,"avatar_neutral"),size=(75,80),fit="contain") xpos 1155 ypos 15
    if not present:
        hbox:
            xpos 55 ypos 82 spacing 18
            textbutton "이번 여정의 자료" action [SetScreenVariable("archive",False),SetScreenVariable("detail",None)] sensitive ready text_size 20
            textbutton "이전에 발견한 사실" action [SetScreenVariable("archive",True),SetScreenVariable("detail",None)] sensitive ready text_size 20
            textbutton "만난 사람들" action Show("r13_resident_notes") sensitive ready text_size 20
    $ entries=persistent.room13_knowledge if archive else room13["evidence"]
    viewport:
        area (45,150,535,465) mousewheel True draggable True scrollbars "vertical"
        vbox:
            spacing 10
            for key in entries:
                if key in ROOM13["evidence"]:
                    button:
                        xsize 505 yminimum 78 padding (10,6)
                        background R13PaperPanel(detail==key)
                        action SetScreenVariable("detail",key) sensitive ready
                        hbox:
                            spacing 16
                            add Transform(r13_icon(key),size=(62,66),fit="contain")
                            text ROOM13["evidence"][key]["name"] size 21 xsize 385 yalign .5
            if not entries:
                text "아직 기록한 자료가 없다." size 23
    if not detail:
        text ("보여 줄 자료를 골라 내용을 확인하세요." if present else "기록을 펼쳐 그때의 단서를 되짚어 보세요.") xpos 650 ypos 335 xsize 520 size 24 color "#85806e" text_align .5
    if detail:
        $ ev=ROOM13["evidence"][detail]
        text ev["name"] xpos 625 ypos 155 xsize 595 size 29 color "#765426"
        viewport:
            area (625,205,595,365) mousewheel True draggable True scrollbars "vertical"
            vbox:
                spacing 15
                hbox:
                    spacing 20
                    add Transform(r13_icon(detail),size=(155,110),fit="contain")
                    text ev["kind"] size 20 color "#69756a" yalign .5
                text ev["establishes"] size 24 xsize 555
                text ev["does_not_establish"] size 22 xsize 555 color "#68695f"
                if archive:
                    text "이전 여정에서 발견한 사실. 이번 여정의 증거로 제출할 수 없다." xsize 555 size 22 color "#975c32"
                elif detail in room13["records"]:
                    $ rec=room13["records"][detail]
                    text ("%d일째 · %s\n%s"%(rec["day"],R13_PLACES.get(rec["place"],(rec["place"],))[0],rec["source"])) xsize 555 size 20 color "#69756a"
        if present:
            textbutton ("이 주장에 근거로 낸다" if hearing else "이 사람에게 보여주기"):
                xpos 625 ypos 576 action Return(detail) sensitive ready text_size 24
    textbutton ("제시 취소" if present else "닫기"):
        xpos 55 ypos 650 action (Return(False) if present else Hide("r13_book")) sensitive ready

screen r13_calendar():
    style_prefix "r13"
    modal True
    zorder 55
    default week=(room13["day"]-1)//7
    add Solid("#243732b0")
    add R13PaperPanel() xpos 30 ypos 20 xsize 1220 ysize 685
    text "여행 수첩 · 달력" xpos 60 ypos 35 size 35 color "#765426"
    for i,dayname in enumerate(("월","화","수","목","금","토","일")):
        text dayname xpos 80+i*170 ypos 106 size 24
    for day in range(week*7+1,week*7+8):
        frame:
            area (55+((day-1)%7)*170,155,155,150)
            background R13PaperPanel(day==room13["day"]) padding (14,14)
            vbox:
                spacing 17
                text (str(day)+"일") size 25
                if day==room13["day"]:
                    text "오늘" size 20 color "#765426"
                elif day<room13["day"]:
                    text "지난 날" size 18
    text "확인한 약속" xpos 60 ypos 420 size 26 color "#765426"
    text ("내일 동틀 무렵 · 제단으로 호송한다는 통보를 받았다." if room13["day"]==13 and "day13_warning" in room13.get("events",[]) else "목요일 저녁 · 어르신과 만나기로 했다." if room13["day"]<=4 and r13_has("elder_appointment") else "일요일 · 다람이의 사건을 주민 앞에서 다룬다." if room13["day"]<=7 and r13_has("trial_notice") else "날짜가 정해진 새 약속은 아직 없다.") xpos 60 ypos 467 size 23 xsize 1110
    textbutton "닫기" xpos 60 ypos 650 action Hide("r13_calendar")
    if week>0:
        textbutton "지난 주" xpos 700 ypos 650 action SetScreenVariable("week",week-1)
    textbutton "다음 주" xpos 970 ypos 650 action SetScreenVariable("week",week+1)

screen r13_debate(claim):
    style_prefix "r13"
    modal True
    default ready=False
    timer .35 action SetScreenVariable("ready",True)
    frame:
        area (50,155,1180,425) padding (26,22) background R13PaperPanel()
        vbox:
            spacing 22
            text R13_CLAIMS[claim]["assertion"] size 32 color "#765426"
            text "내가 제시한 근거" size 23
            viewport:
                xsize 1110 ysize 180 draggable True mousewheel True scrollbars "vertical"
                vbox:
                    spacing 7
                    for key in room13["arguments"].get(claim,[]):
                        text ("· "+ROOM13["evidence"][key]["name"]) size 22
                    if not room13["arguments"].get(claim):
                        text "아직 제시하지 않았다." size 22 color "#817e70"
            hbox:
                spacing 18
                textbutton "근거 제시" action Return("present") sensitive ready
                textbutton "되묻기" action Return("press") sensitive ready
                textbutton "논리를 연결한다" action Return("argue") sensitive ready
                textbutton "이 논점은 남겨 둔다" action Return("leave") sensitive ready text_size 22

screen r13_handoff():
    style_prefix "r13"
    modal True
    zorder 40
    add Solid("#172a2aa6")
    frame:
        area (175,135,930,465) padding (35,30)
        vbox:
            spacing 25
            text "13호 사건 · 둘째 주 이어가기" size 35 color "#765426"
            text "이전 개발본의 끝에 도착했습니다.\n이번 판결과 구금 상태를 유지하며 계속합니다." size 27 xsize 840
            text ("다람이: "+("아빠와 동행" if room13["daram_state"]=="with_dad" else "보호시설에 구금")+"\n할머니: "+("구금" if room13["granny_state"]=="detained" else "자유 상태")) size 25
            text "이 화면은 이야기 속 엔딩이 아닙니다." size 22 color "#717367"
            hbox:
                spacing 18
                textbutton "저장하기" action ShowMenu("save")
                textbutton "이어서 진행" action [Hide("r13_handoff"),Jump("r13_week2_opening")]
                textbutton "제목으로" action MainMenu(confirm=False)
