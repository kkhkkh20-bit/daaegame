# Small, character-specific performance. Never deform the flat body drawing to
# imitate a tail: only independently authored tail layers may rotate separately.
default persistent.room13_motion = True
default r13_motion_person = None
image r13_visitor = Null()

init 58 python:
    import math as r13_motion_math

    # Native artwork pixels/degrees. An interview enlarges these by about 1.5x;
    # exploration reduces them. Distinct periods/phases avoid synchronized actors.
    R13_MOTION_PROFILES = {
        "daram": (4.5, 0.90, 0.45, 0.16),
        "dad": (5.6, 0.65, 0.30, 0.10),
        "mom": (5.4, 0.65, 0.25, 0.09),
        "granny": (6.2, 0.42, 0.18, 0.06),
        "seryeon": (5.8, 0.50, 0.24, 0.09),
        "nabi": (4.8, 0.65, 0.35, 0.13),
        "bami": (6.4, 0.22, 0.60, 0.20),
        "doto": (6.1, 0.40, 0.18, 0.06),
        "buri": (5.7, 0.55, 0.20, 0.06),
        "karo": (5.2, 0.55, 0.30, 0.10),
        "neoul": (6.0, 0.42, 0.20, 0.07),
        "guard": (6.4, 0.35, 0.12, 0.04),
    }

    def r13_motion_profile(person):
        seed=sum((i+1)*ord(c) for i,c in enumerate(person))
        profile=R13_MOTION_PROFILES.get(person,
            (5.0+(seed%17)/10.0,0.38+(seed%6)*0.05,0.18+(seed%5)*0.03,0.05+(seed%4)*0.02))
        return profile, (seed%628)/100.0

    class R13CharacterMotion:
        def __init__(self,person,pose,speaking=False,entrance=False):
            self.person=person
            self.pose=pose
            self.profile,self.phase=r13_motion_profile(person)
            self.speaking=speaking
            self.entrance=entrance

        def __call__(self,trans,st,at):
            if not persistent.room13_motion or renpy.is_skipping():
                trans.xoffset=0.0
                trans.yoffset=0.0
                trans.rotate=0.0
                trans.alpha=1.0
                return 0.20
            period,breath,shift,tilt=self.profile
            t=max(0.0,at)
            angle=t*2.0*r13_motion_math.pi/period+self.phase
            # Gentle rigid movement; no squash, stretch, body mesh or fake blink.
            trans.yoffset=-breath*r13_motion_math.sin(angle)
            trans.xoffset=shift*r13_motion_math.sin(angle*0.61+self.phase)
            trans.rotate=tilt*r13_motion_math.sin(angle*0.47+self.phase)
            if "distressed" in self.pose:
                # Quiet held tension, never a perpetual panic shake.
                trans.xoffset*=0.45
                trans.rotate*=0.40
            # A single small acknowledgement on arrival, not on every syllable.
            if self.speaking and self.entrance and st<0.55:
                trans.yoffset+=0.8*r13_motion_math.sin(st/0.55*r13_motion_math.pi)
            trans.alpha=min(1.0,st/0.16) if self.entrance else 1.0
            return 1.0/24.0

    class R13TailMotion:
        def __init__(self,pose):
            self.tense="distressed" in pose
        def __call__(self,trans,st,at):
            # Root movement is covered by the dress; only the separate tail turns.
            # Distress has a smaller held movement, not an incongruously happy wag.
            enabled=persistent.room13_motion and not renpy.is_skipping()
            amplitude=0.40 if self.tense else 1.45
            trans.rotate=amplitude*r13_motion_math.sin(at*2.0*r13_motion_math.pi/5.8) if enabled else 0.0
            return 1.0/24.0 if enabled else 0.20

    def r13_daram_layers(pose):
        index=next((i for i,key in enumerate(("neutral","thinking","distressed","expressive")) if key in pose),0)
        path="assets/room13-painted-daram-motion.png"
        body=Crop((index*384,0,384,560),path)
        # The generated sheet keeps the tail isolated below the full body row.
        # Crop metadata, size and placement are display-time operations only.
        tail_rects=((53,672,232,300),(436,672,233,300),(820,672,232,300),(1200,672,228,300))
        x,y,w,h=tail_rects[index]
        # Transparent breathing room prevents the rotated tip being clipped.
        tail=Transform(Crop((x-8,y-8,w+16,h+16),path),size=(186,250),nearest=False,
            subpixel=True,rotate_pad=False,function=R13TailMotion(pose))
        # Body position differs slightly with the hand pose. Match the hip while
        # keeping the seam behind clothing through the entire small rotation arc.
        tail_x=(42,33,20,20)[index]
        return Composite((384,560),(tail_x,217),tail,(0,0),body)

    def r13_motion_art(image_name,person,pose,speaking=False,entrance=False):
        art=r13_daram_layers(pose) if person=="daram" else image_name
        return Transform(art,subpixel=True,nearest=False,rotate_pad=False,
            function=R13CharacterMotion(person,pose,speaking,entrance))

screen r13_motion_settings():
    textbutton ("인물 움직임: 켜짐" if persistent.room13_motion else "인물 움직임: 정지"):
        action ToggleField(persistent,"room13_motion")
        xfill True
