# Shared rules for routines, discovery records and authored negotiation.
init 57 python:
    class R13QuestionBar(renpy.Displayable):
        def __init__(self,focused=False,**kwargs):
            super(R13QuestionBar,self).__init__(**kwargs)
            self.focused=focused
        def render(self,width,height,st,at):
            w=max(1,int(width));h=max(1,int(height))
            out=renpy.Render(w,h)
            canvas=out.canvas()
            canvas.rect("#fff3d5" if self.focused else "#f0e9db",(0,0,w,h))
            canvas.rect("#dfb854" if self.focused else "#918671",(1,1,max(1,w-2),max(1,h-2)),3 if self.focused else 1)
            return out

    class R13InvestigationRing(renpy.Displayable):
        def render(self,width,height,st,at):
            out=renpy.Render(56,56)
            out.canvas().circle("#f3ce81",(28,28),24,3)
            return out

    class R13ActionGlyph(renpy.Displayable):
        def __init__(self,kind,**kwargs):
            super(R13ActionGlyph,self).__init__(**kwargs)
            self.kind=kind
        def render(self,width,height,st,at):
            out=renpy.Render(58,58);c=out.canvas()
            if self.kind=="talk":
                c.circle("#687f99",(28,23),17)
                c.polygon("#687f99",[(14,32),(13,45),(29,34)])
                for x in (20,28,36):c.circle("#f8f1de",(x,23),2)
            elif self.kind=="inspect":
                c.circle("#b86550",(24,23),17,5)
                c.line("#b86550",(36,36),(49,49),7)
            elif self.kind=="present":
                c.rect("#bea057",(9,10,30,35),3)
                c.rect("#d4b665",(19,18,30,35))
                c.circle("#f7f0d8",(34,33),8)
                c.line("#f7f0d8",(27,46),(41,46),3)
            else:
                c.lines("#628966",False,[(10,41),(27,41),(27,19),(43,19)],5)
                c.lines("#628966",False,[(35,10),(45,19),(35,28)],5)
            return out

    R13_CORE_PEOPLE=set(R13_GREETING)
    R13_RESIDENTS=ROOM13["residents"]
    R13_DIRECTION={
        "entry:arrival":{"daram":"thinking","dad":"thinking"},
        "night1:knocking":{"daram":"thinking","nabi":"distressed"},
        "case:discovery:v3":{"daram":"distressed","dad":"distressed"},
        "case:sealing:v3":{"daram":"distressed","dad":"distressed"},
        "case:interview:opening:v3":{"daram":"distressed","dad":"thinking"},
        "trial:C2:done":{"daram":"distressed","dad":"thinking"},
        "trial:C4:done":{"dad":"thinking","granny":"distressed"},
        "reunion:held:question":{"mom":"distressed","dad":"distressed"},
        "reunion:free":{"mom":"distressed","daram":"distressed"},
        "rescue:child":{"daram":"distressed","dad":"thinking"},
        "finale:child_on_convoy":{"daram":"distressed","mom":"distressed"},
        "ending:E5:meal":{"daram":"expressive","mom":"neutral"},
        "ending:family":{"daram":"expressive"},
    }
    for person,spec in R13_RESIDENTS.items():
        R13_NAMES.setdefault(person,spec["name"])
        R13_GREETING.setdefault(person,"지금 하던 일을 마저 해야 해서요. 무슨 일입니까?")
        R13_CHARS.setdefault(person,Character(R13_NAMES[person],cb_who_id=person if person in CAST else None))

    def r13_daylight():
        # Period 3 is late evening, using the same authored evening art.
        return ("morning","afternoon","evening")[min(2,int((store.room13 or {}).get("period",0)))]

    def r13_scene_identity(bg,title,mood):
        state=store.room13 or {}
        return (bg,title,mood,r13_daylight(),state.get("case_state"))

    def r13_art_path(group,daylight=None):
        return "assets/room13-painted-%s-%s.png"%(group,daylight or r13_daylight())

    R13_PAINTED_LAYOUTS=json.load(renpy.file("assets/room13-painted-layouts.json"))

    def r13_atlas(path,index,columns=3,rows=2):
        spec=R13_PAINTED_LAYOUTS.get(path.rsplit("/",1)[-1])
        if spec:
            return Transform(Crop(tuple(spec["rects"][index]),path),size=(1280,720),nearest=False)
        if path=="assets/room13-inn.png":
            return Transform(Crop(tuple(ROOM13["background_atlases"]["inn"][index]),path),size=(1280,720),nearest=False)
        width,height=renpy.image_size(path)
        x=index%columns;y=index//columns
        left=width*x//columns;right=width*(x+1)//columns
        top=height*y//rows;bottom=height*(y+1)//rows
        return Transform(Crop((left,top,right-left,bottom-top),path),size=(1280,720),nearest=False)

    def r13_background(key):
        if key=="winter":
            return Transform(r13_art_path("gate"),size=(1280,720),nearest=False)
        if key=="winter_carriage":
            return Transform(r13_art_path("carriage","morning"),size=(1280,720),nearest=False)
        if key=="village_overview":
            return Transform(r13_art_path("overview"),size=(1280,720),nearest=False)
        if key=="r13_altar":
            return Transform(r13_art_path("altar"),size=(1280,720),nearest=False)
        if key=="hall":
            after=store.room13 and store.room13["case_state"]=="occurred"
            return Transform(r13_art_path("hall-after" if after else "hall-before"),size=(1280,720),nearest=False)
        if key in ("front","kitchen","winter_passage","council"):
            index={"front":0,"kitchen":1,"winter_passage":2,"council":3}[key]
            return r13_atlas(r13_art_path("inn"),index,2,2)
        if key in ("winter_square","winter_post","winter_workshop"):
            index=("winter_square","winter_post","winter_workshop").index(key)
            return r13_atlas(r13_art_path("village"),index,2,2)
        if key=="room":
            after=store.room13 and store.room13["case_state"]=="occurred"
            return Transform(r13_art_path("room-after" if after else "room-before"),size=(1280,720),nearest=False)
        if key.startswith("r13_"):
            index=("clinic","school","store","greenhouse","facility","altar").index(key[4:])
            return r13_atlas(r13_art_path("locations"),index)
        return winter_background(key)

    def r13_evidence_art(key):
        # Authored rectangles refer to the actual adopted artwork, never an old sheet.
        # Evidence illustrations stay fixed when the clock changes.
        for name,spec in R13_PAINTED_LAYOUTS.items():
            rect=spec.get("evidence",{}).get(key)
            if rect:
                return Crop(tuple(rect),"assets/"+name)
        return None

    def r13_resident_where(person):
        if person not in R13_RESIDENTS:return None
        s=store.room13
        if person=="resident_piko" and s["day"]>=8:return "clinic"
        if person=="resident_badook" and s["day"]>=8 and r13_has("patient_transport"):return "school"
        if s["day"]>=11 and r13_has("shelter_ready") and person in ("resident_tori","resident_yeoni","resident_kongi","resident_somi","resident_musoe"):
            return "school"
        where=R13_RESIDENTS[person]["weekly_locations"][(s["day"]-1)%7][min(s["period"],2)]
        return {"home":None,"library":"post","lowroad":"gate","tower":"square"}.get(where,where)

    def r13_activity_text(person):
        if person in R13_RESIDENTS:return R13_RESIDENTS[person]["activity"]
        return ""

    def r13_note_encounter(person):
        n=winter_copy.deepcopy(store.room13)
        entry=dict(person=person,day=n["day"],period=n["period"],place=n["location"])
        if entry not in n["encounters"]:n["encounters"].append(entry)
        store.room13=n

    def r13_met_people():
        return list(dict.fromkeys(e["person"] for e in store.room13["encounters"] if isinstance(e,dict)))

    def r13_note_topics(person):
        return [ROOM13["topics"][k]["title"] for k in store.room13["read_topics"] if k in ROOM13["topics"] and ROOM13["topics"][k]["npc"]==person]

    def r13_object_visible(spec):
        s=store.room13
        return (all(r13_has(k) for k in spec.get("need",[])) and
            (not spec.get("case") or spec["case"]==s["case_state"]))

label r13_topic_choice(key):
    if key=="w2_erased":
        call r13_lines([("resident_seori","그 줄은 제가 지웠습니다. 다시 나빠졌으니 회복이라고 쓰면 안 된다고 했죠."),("dad","잠깐 나아진 사실까지 없어진 건 아니잖습니까."),("resident_seori","압니다. 그렇지만 원본을 내놓으면 제 검사도 전부 다시 따질 겁니다.")],"negotiation:erased:start")
        menu:
            "정정에 어디까지 책임을 지겠습니까?"
            "당신 서명은 지우지 않겠습니다. 관찰한 사실과 지시받은 수정을 구분해 주세요":
                call r13_lines([("resident_seori","제 책임을 없애 주겠다는 말은 아니군요."),("dad","없던 일로 만들겠다고 하면 이 기록도 믿을 수 없어집니다."),("resident_seori","……가족에게는 제가 먼저 말하겠습니다. 정정 전 사본에는 할머니 확인도 남아 있습니다.")],"negotiation:erased:accepted")
                $ r13_flag("seori_responsibility_accepted")
                return True
            "서명 부분을 잘라 내면 당신도 우리도 곤란하지 않을 겁니다":
                call r13_lines([("resident_seori","누가 기록했는지도 모르는 사본을 제시하자는 겁니까?"),("dad","당신을 보호하려는 뜻입니다."),("resident_seori","그건 기록을 다시 지우는 일이에요. 다른 방법을 생각해 주십시오.")],"negotiation:erased:cut")
                return False
            "지금 여기에 서명하지 않으면 공범으로 알리겠습니다":
                call r13_lines([("resident_seori","제가 잘못한 부분은 남기겠습니다. 협박받고 한 말로 만들어 놓고 증언을 믿어 달라고 하실 겁니까?"),(None,"검사원이 서류를 접었다. 소리를 높여서 받을 수 있는 서명은 아니었다.")],"negotiation:erased:threat")
                $ r13_flag("seori_threatened")
                return False
            "원본을 더 확인한 뒤 이야기하겠습니다":
                return False
    if key=="w2_eunho":
        call r13_lines(ROOM13["topics"][key]["lines"],"negotiation:supplies:opening")
        menu:
            "창고를 열 조건을 어떻게 정할까?"
            "꺼낸 수량과 받을 집을 함께 적고, 사장님 가족 몫도 같은 기준으로 남긴다":
                call r13_lines([("resident_eunho","다른 집보다 더 빼놓으라는 뜻은 아니군요."),("dad","적어도 당신 집만 굶길 약속은 아닙니다. 갚을 몫도 공동 기록에 남기죠."),("resident_eunho","서리가 수량을 확인하면 내놓겠습니다. 빈 자루도 세어야 해요.")],"negotiation:supplies:agreement")
                return True
            "위기가 끝나면 사장님의 매입 가격으로 전부 갚겠다고 약속한다":
                call r13_lines([("resident_eunho","어느 돈으로요? 봄이 오면 가실 분이잖아요."),("dad","기록을 남기겠습니다."),("resident_eunho","빚진 사람 이름만 적힌 종이는 이미 많습니다. 오늘 누구 몫이 남는지부터 합시다.")],"negotiation:supplies:unfunded")
                return False
            "먼저 내놓으면 주민들도 사장님 편에 설 거라고 설득한다":
                call r13_lines([("resident_eunho","오늘은 편을 들어도 내일 물건 떨어지면 또 제 문을 두드리겠죠. 저한테 필요한 건 박수보다 약속의 범위입니다.")],"negotiation:supplies:popularity")
                return False
            "창고의 실제 수량부터 살펴보고 다시 온다":
                return False
    return False
