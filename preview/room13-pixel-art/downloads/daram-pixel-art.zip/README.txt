다람탐정 B안 도트 원화 모음

31 background sheets + 11 character sheets + 3 cinematic sheets + 1 motion sheet.
43 characters: 12 main with four expressions, 31 supporting with one neutral drawing.
12 cinematics: 5 story scenes and 7 endings.

PNG originals are copied unchanged. Rect/crop metadata selects panels at runtime. This archive contains spoiler scenes. Galmuri font license is in font/Galmuri-OFL.txt. This is an art source bundle, not a runnable game.
