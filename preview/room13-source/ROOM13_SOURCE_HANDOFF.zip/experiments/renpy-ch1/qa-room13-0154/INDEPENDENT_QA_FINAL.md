# Independent QA — 0.15.4

Final archive: `1da7d083ab69d910824f4e6a1fd44382bcd174d6f5db41d7d3959814ab0ad82f`.
Candidate URL: `http://127.0.0.1:8094/room13-release-0154-final/`.

The authoritative machine-readable disposition is in `RELEASE_STATUS.json`.

## Natural play and persistence

- `gate-a4cb-final/report.json`: fresh start, arrival card, visible waiting Daram click, Dad spoken/thought text without an avatar, Karo's framed portrait, read-question strike-through, resident conversation, original/copy inspection, evidence-based admission. Karo/Kkwak/Guard retain the exact same population, poses and positions before/after same-time permission. Guard remains talkable. Mobile actor and document taps select the correct targets. Right-click does not open options; the explicit Options button does.
- `navigation-a4cb-final/report.json`: independent natural wait route, mobile waiting-window tap, inn interior map default, locked room cancellation, explicit outside map, lodging, connected dining/hall/room travel, locked passage absent. Real camera arrow/drag changes 0→480→640 without accidental action or moving HUD. Actual slot save at nondefault 160, movement to 0, and load restores 160 and its camera dictionary. Dialogue retains the selected camera. Mobile drag/map controls work.
- `carriage-choice-1da7-checkpoint/report.json`: naturally reached opening with an explicitly injected old-art marker and magenta placeholder, then a **normal next dialogue checkpoint** before actual save/load. New carriage art replaces the old scene; text, read ID and story state are preserved. Subsequent natural document/proof clicks show the evidence card during Guard's response and hide it before the choice. Manual screenshot review confirms the face is clear.

## Explicit render/input fixtures

- `panorama-a4cb-visible/report.json`: maximum scheduled population scenes, not a 14-day playthrough. Inn 7, school 12, workshop 8, square 8. Eight left/right views manually reviewed for furniture contact, visibility and consistent art; 55 physical mouse/touch selections dispatched to the expected actors. The old edge-arrow overlap was recorded as a blocker, not accepted through a lower-face workaround.
- `panorama-1da7-final/report.json`: focused final school/inn regression; 59 real face/name selections, including mobile. Tori's original face center `(1230.5,403.5)` and name `(1230,335)` now select Tori with the arrow moved above the scene. Guseul's lower nameplate selects Guseul, matching the visible face. Viewport focus bounds remain clipped to the screen.
- These click fixtures keep the actual rendered sprites, alpha masks, viewport and input widgets. A `Return.__call__` observer records dispatch without advancing an artificially injected late-game story state. They do not claim to have naturally played every selected NPC conversation.
- `objects-1da7-final/report.json`: 24 exposed object samples across all four panoramas dispatch correctly at left/right offsets. Two initial door-center samples land on the visible Madam nameplate and correctly select Madam; these are explicitly classified as covered UI samples rather than incorrect object hits. Exposed door verification is recorded separately in `door-1da7-final/report.json`.
- `../qa-room13-0153/gate-continuity/source-report.json`: 224 host-side schedule conditions preserve all 37 preexisting residents' schedules and same-time permission continuity while adding Guard's duty. This is state regression, not browser play.

## Carry-forward evidence

The broad gate/navigation and separate records/puzzle QA use archive `a4cbad8b1616e92a1c6dc9339bd85db434c8e7d6d01c98b2acd422441199a27d`.
`archive-delta.json` independently compares both complete archives. Runtime source changes are only the evidence-card hide before Guard's choice and moving camera controls to the top; corresponding compiled files/build caches change. Assets and other source were independently verified byte-for-byte identical. Font table comparison confirms identical glyph order and all non-header tables; only header timestamp/checksum metadata differs. Focused final tests cover the changed behavior.

Separate-agent evidence: `records/report.json`, `inspection/report.json`, and `gallery/report.json` are passed. These are included as delegated verification, not represented as this agent's own runs.

## Fixed defects and limits

- Initial candidate `9f44…`: document popup close raised `KeyError: True`; fixed and passed naturally on `a4cb…`.
- Initial candidate `9f44…`: loading a nondefault camera reset it to the initial position; fixed and actual save/load passed on `a4cb…`.
- `a4cb…`: camera edge button covered Tori's face/name; fixed and original-target clicks passed on `1da7…`.
- The first carriage fixture called `retain_after_load()` directly from the external execution harness during a parametrized dialogue interaction and produced `entries` undefined after load. This is **not the accepted test**. Removing that artificial retention call and advancing one normal dialogue checkpoint before saving passed. The accepted report is `carriage-choice-1da7-checkpoint`, not `carriage-choice-1da7-final`.
- Guseul's name is below the face near the abdomen in a crowded inn view. It is readable/clickable and dispatches correctly, but the label layout could be refined later.
- No claim of a complete 14-day route/ending playthrough, every possible historical save, physical-device testing, or auditory quality assessment. Mobile coverage uses Chromium's 844×390 touch viewport. Source/screen sound callbacks were inspected; audio was not independently listened to.
