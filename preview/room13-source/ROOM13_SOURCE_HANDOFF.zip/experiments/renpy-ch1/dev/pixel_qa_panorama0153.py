"""Explicit crowded-scene fixtures; real camera controls and pixel hit dispatch."""
import argparse,asyncio,json,shutil,urllib.request
from playwright.async_api import async_playwright
from pixel_qa_navigation0153 import SpatialQA,ROOT
from pixel_qa_denseclick0152 import PATCH

META="""import renpy
s=renpy.store
actors=s.r13_stage_people()
result={'actors':actors,'people':s.r13_people(),'offset':s.r13_world_offset(),'width':s.r13_world_width(),
 'heads':[{'person':a['person'],'rect':s.r13_actor_face_target(a)} for a in actors],
 'names':s.r13_actor_nameplates(actors),'objects':{k:v['rect'] for k,v in s.ROOM13['objects'][s.room13['location']].items() if s.r13_object_visible(v)}}
"""

async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--objects-only',action='store_true');ap.add_argument('--locations',nargs='+',default=['inn','school','workshop','square']);ap.add_argument('--out',default='qa-room13-0153/panorama-final');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True);source=json.loads((ROOT/'qa-room13-0153/panorama-staging/report.json').read_text());report={'kind':'injected maximum population states, actual viewport clicks and Return observer, not natural story','shots':[],'clicks':[]}
 report['archive_sha256']=json.load(urllib.request.urlopen(a.url+'game-transport.json'))['archive_sha256']
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=SpatialQA(pg,out);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub');await q.py(PATCH)
   for loc in a.locations:
    row=max([v for k,v in source['maxima'].items()if k.startswith(loc+'-')],key=lambda r:len(r['people']))
    await q.py("import renpy\ns=renpy.store\ns.room13="+ascii(row['state'])+"\ns.place=s.R13_PLACES[s.room13['location']][0]\ns.r13_world_cameras=dict(s.r13_world_cameras,**{"+repr(loc)+":0})\nrenpy.exports.hide_screen('r13_hub')\nrenpy.exports.hide_screen('say')\nrenpy.exports.scene()\nrenpy.exports.show('qa_pan_bg',what=s.r13_background(s.R13_PLACES[s.room13['location']][1]))\nrenpy.exports.show_screen('r13_hub',entry=False)\nrenpy.exports.restart_interaction()\nresult=True")
    await q.wait('r13_hub');seen=set()
    for side in ('left','right'):
     if side=='right':
      await q.pan(1);await q.pan(1)
     await q.wait('r13_hub');meta=await q.py(META);assert set(meta['people'])==set(x['person']for x in meta['actors']);assert meta['offset']==(0 if side=='left'else meta['width']-1280);await q.shot(loc+'-'+side);report['shots'].append({'location':loc,'side':side,**meta})
     for head in ([] if a.objects_only else meta['heads']):
      if not head['rect']:continue
      x,y,w,h=head['rect'];sx=x+w/2-meta['offset'];sy=y+h/2
      if not 20<sx<1260 or not 100<sy<625:continue
      await q.py('import renpy;renpy.store.qa_hit=None;result=True');await q.input(sx,sy);actual=await q.py('import renpy;result=renpy.store.qa_hit');report['clicks'].append({'location':loc,'side':side,'coordinate':[sx,sy],'world_coordinate':[x+w/2,sy],'expected':['person',head['person']],'actual':actual});seen.add(head['person'])
     for name in ([] if a.objects_only else meta['names']):
      x,y,w,h=name['rect'];sx=x+w/2-meta['offset'];sy=y+h/2
      if not 5<sx<1275 or not 100<sy<640:continue
      await q.py('import renpy;renpy.store.qa_hit=None;result=True');await q.input(sx,sy);actual=await q.py('import renpy;result=renpy.store.qa_hit');report['clicks'].append({'location':loc,'side':side,'target':'visible nameplate','coordinate':[sx,sy],'expected':['person',name['person']],'actual':actual})
     if a.objects_only:
      for key,box in meta['objects'].items():
       x,y,w,h=box;wx=x+w/2;sy=y+h/2;sx=wx-meta['offset']
       if loc=='inn' and key=='door':sy=220  # visible upper wood/window, above the resident nameplate
       if not 20<sx<1260 or not 210<sy<630:continue
       if any(actor['x']<=wx<=actor['x']+actor['width'] and actor['y']<=sy<=actor['y']+actor['height'] for actor in meta['actors']):continue
       await q.py('import renpy;renpy.store.qa_hit=None;result=True');await q.input(sx,sy);actual=await q.py('import renpy;result=renpy.store.qa_hit');report['clicks'].append({'location':loc,'side':side,'target':'visible object center','offset':meta['offset'],'coordinate':[sx,sy],'world_coordinate':[wx,sy],'expected':['object',key],'actual':actual})
    assert a.objects_only or seen==set(meta['people']),(loc,'actor head never on-screen',set(meta['people'])-seen)
    # The viewport should clip focus positions as well as artwork.
    focus=(await q.state())['buttons'];assert all(b['rect'][0]>=-1 and b['rect'][0]+b['rect'][2]<=1281 for b in focus if b['value'].startswith("('person',")),(loc,'offscreen focus leak')
    if loc=='school' and not a.objects_only:
     await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.shot('school-right-mobile')
     for head in ([] if a.objects_only else meta['heads']):
      if not head['rect']:continue
      x,y,w,h=head['rect'];sx=x+w/2-meta['offset'];sy=y+h/2
      if not 20<sx<1260 or not 100<sy<625:continue
      await q.py('import renpy;renpy.store.qa_hit=None;result=True');await q.input(sx,sy);actual=await q.py('import renpy;result=renpy.store.qa_hit');report['clicks'].append({'location':loc,'side':'right','mode':'mobile','coordinate':[sx,sy],'expected':['person',head['person']],'actual':actual})
     await pg.set_viewport_size({'width':1280,'height':720});q.touch=False
   report['failures']=[x for x in report['clicks']if x['actual']!=x['expected']];assert not report['failures'],report['failures'];assert not errors,errors;report['status']='passed-pending-visual-review'
  except Exception as e:report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
  report.update(url=a.url,errors=errors);(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(report['status'],report.get('error'));await b.close()
  if report['status']=='failed':raise SystemExit(1)

if __name__=='__main__':asyncio.run(main())
