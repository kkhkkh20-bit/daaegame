"""Reuse verified unchanged assets for a local code-only browser candidate."""
from pathlib import Path
import zipfile,sys,json,re
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from build_web import prepare_game_transport
folder=Path(sys.argv[1] if len(sys.argv)>1 else '/workspace/room13-release-01510-final')
base=folder.with_name(folder.name+'-full-game.zip')
files={str(p.relative_to(ROOT)):p for p in (ROOT/'game').rglob('*') if p.is_file() and p.suffix in ('.rpy','.rpyc')}
files['game/room13-content.json']=ROOT/'game/room13-content.json'
for name in ('room13-pixel-karo-fullbody.png','room13-portraits.json','cast.json'):
 files['game/assets/'+name]=ROOT/'game/assets'/name
with zipfile.ZipFile(base) as old,zipfile.ZipFile(folder/'game.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=1) as new:
 for info in old.infolist():
  if info.filename not in files:new.writestr(info,old.read(info.filename))
 for name,path in files.items():new.write(path,name)
transport=prepare_game_transport(folder)
print(transport['archive_sha256'])

loader=folder/'renpy-pre.js'
script=loader.read_text()
script=re.sub(r'const parts = \[.*?\];','const parts = '+json.dumps(transport['parts'])+';',script)
script=re.sub(r"'Content-Length': '\d+'","'Content-Length': '"+str(transport['archive_bytes'])+"'",script)
loader.write_text(script)
