"""Natural gate interactions plus explicit daylight/crowd layout fixtures."""
import asyncio,json,shutil,urllib.request
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_ui0156 import UIQA
from pixel_qa_flow0150 import FLOW_PROBE
OUT=Path('/workspace/room13-review/gate0174');OUT.mkdir(exist_ok=True)
URL='http://127.0.0.1:8094/room13-dev/'
class Q(UIQA):
 async def state(self):
  probe=FLOW_PROBE.replace('names=[',"names=['r13_gate_document_inspection','r13_gate_document_read','r13_records',")
  s=await self.py('ns={};exec('+ascii(probe)+',ns);result=ns["result"]');assert '_exception' not in s['screens'],s;return s
 async def object(self,key):
  rect=await self.py('import renpy;s=renpy.store;result=s.ROOM13["objects"][s.room13["location"]]['+repr(key)+']["rect"]')
  offset=(await self.camera())['offset'];x,y,w,h=rect;assert 0<=x+w/2-offset<=1280,(key,rect,offset);await self.input(x+w/2-offset,y+h/2)
 async def pan(self,start,end):
  # Real drag on open snow, not a direct camera-state write.
  await self.p.mouse.move(start,650);await self.p.mouse.down();await self.p.mouse.move(end,650,steps=18);await self.p.mouse.up();await asyncio.sleep(.5)
async def main():
 report={'archive_sha256':json.load(urllib.request.urlopen(URL+'game-transport.json'))['archive_sha256'],'checks':[]}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True);pg=await c.new_page();q=Q(pg,OUT)
  try:
   await pg.goto(URL);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub')
   assert await q.py('import renpy;result=renpy.store.r13_world_width()')==1920;await q.shot('01-gate-natural-afternoon');before=await q.room();cam=await q.camera()
   await q.pan(1100,350);assert (await q.camera())['offset']>cam['offset'];await q.shot('02-right-pan');assert await q.room()==before
   await q.object('gate_documents');await q.wait('r13_gate_document_inspection');await q.shot('03-documents-popup')
   for title in ['예약 원본','옮겨 쓴 이름 목록']:
    await q.press(title);await q.wait('r13_gate_document_read');await q.press('확인');await q.wait('r13_gate_document_inspection')
   await q.press('현장으로 돌아가기');await q.wait('r13_hub');assert {'G1','G3'}<=set((await q.room())['evidence']);await q.shot('04-documents-check-world-position')
   await q.pan(250,1100);assert (await q.camera())['offset']==0;await q.shot('05-left-pan')
   for key in ['road','bundles','rules','shovel']:
    await q.object(key);await q.advance()
    if 'r13_object_context' in (await q.state())['screens']:await q.press('그만 살펴본다')
    await q.wait('r13_hub')
   assert 'G2' in (await q.room())['evidence'];await q.shot('06-known-object-checks');await q.value(('person','karo'));await q.advance();await q.wait('r13_topics');await q.shot('07-karo-player-facing');await q.press('돌아가기');await q.wait('r13_hub')
   saved_cam=await q.camera();await q.save(1);saved=await q.room();await q.load(1);assert await q.room()==saved and await q.camera()==saved_cam
   # Simulate old narrow-scene geometry metadata, without changing story facts.
   migration_before=await q.room()
   await q.py('import renpy,copy;s=renpy.store;n=copy.deepcopy(s.room13);n["world_art_revisions"].pop("gate",None);n["checks"]["gate:rules"]=[391,339];s.room13=n;s.r13_upgrade();renpy.exports.restart_interaction();result=True')
   migrated=await q.room();assert migrated['checks']['gate:rules']==[703,370]
   assert all(migrated[k]==migration_before[k] for k in ['day','period','evidence','flags','propositions'])
   report['checks'].append('Explicit old-world-revision fixture relocates saved rules checkmark without changing clock/evidence/flags/propositions')
   report['checks'].append('Natural afternoon: 1920 world, physical drag both directions no time/state change, docs G1/G3 and rules G2 reachable, road/bundles/shovel clicks, Karo dialogue, save/load camera/state preserved')
   # Explicit time fixtures for authored lighting/placement review; not a day-by-day playthrough.
   for period,label in [(0,'morning'),(2,'evening')]:
    await q.py('import renpy;s=renpy.store;s.r13_edit(period='+str(period)+');renpy.exports.restart_interaction();result=True');await q.shot('08-'+label+'-left');await q.pan(1100,350);await q.shot('09-'+label+'-right')
    await q.object('woodpile');await q.advance()
    if 'r13_object_context' in (await q.state())['screens']:await q.press('그만 살펴본다')
    await q.wait('r13_hub');await q.pan(250,1100)
   await q.py('import renpy;s=renpy.store;s.r13_edit(day=5,period=1,case_state="occurred",daram_state="held",victim_state="dead");renpy.exports.restart_interaction();result=True')
   await q.object('rules');await q.advance();await q.wait('r13_object_context');assert any("interview" in b['value'] for b in (await q.state())['buttons']);await q.shot('09b-day5-interview-on-notice');cancel=next(b for b in (await q.state())['buttons'] if '그만 살펴본다' in b['text']);assert cancel['rect'][3]>=44 and cancel['rect'][1]+cancel['rect'][3]<=660,cancel;await q.press('그만 살펴본다');await q.advance();await q.wait('r13_hub');report['checks'].append('Explicit day-5 occurred fixture: interview activity still reachable on the rules notice; cancelled without executing/time cost')
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.py('import renpy;renpy.store.persistent.room13_large_text=True;renpy.exports.restart_interaction();result=True');await q.shot('10-mobile-large-left')
   mobile_before=await q.room();mobile_offset=(await q.camera())['offset'];cdp=await c.new_cdp_session(pg)
   await cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':650,'y':340}]})
   for x in range(625,199,-25):
    await cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':x,'y':340}]});await asyncio.sleep(.025)
   await cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]});await asyncio.sleep(.6)
   assert (await q.camera())['offset']>mobile_offset;assert await q.room()==mobile_before;await q.shot('11-mobile-touch-pan-right');report['checks'].append('Real emulated touch swipe pans the gate viewport without changing story/time')
   report['checks'].append('Explicit morning/evening fixtures: inspect both world edges and woodpile reachability; mobile landscape large text capture')
   report['status']='passed-pending-visual-review'
  except Exception as e:
   report.update(status='failed',error=repr(e));await pg.screenshot(path=str(OUT/'failure.png'))
   try:(OUT/'failure-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
   except:pass
  (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']=='failed':raise SystemExit(1)
asyncio.run(main())
