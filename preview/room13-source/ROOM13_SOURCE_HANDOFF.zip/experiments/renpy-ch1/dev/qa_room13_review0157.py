"""Natural record viewing/save regression; explicit restored archive/calendar fixtures."""
import asyncio,json,shutil,argparse,urllib.request
from playwright.async_api import async_playwright
from pixel_qa_ui0156 import UIQA,ROOT
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);a=ap.parse_args();out=ROOT/'qa-room13-0157/browser';out.mkdir(parents=True,exist_ok=True)
 report={'archive_sha256':json.load(urllib.request.urlopen(a.url+'game-transport.json'))['archive_sha256'],'checks':[]}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);pg=await b.new_page(viewport={'width':1280,'height':720},has_touch=True);q=UIQA(pg,out)
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub')
   await q.docs();await q.value(('record','G1'));await q.wait('r13_gate_document_inspection');await q.value(('record','G3'));await q.wait('r13_gate_document_inspection');await q.press('닫기');await q.wait('r13_hub')
   before=await q.room();await q.press('기록');await q.wait('r13_records');await asyncio.sleep(1.2);r=await q.records();assert r['selected']=='G3' and 'G3'in r['ui']['seen'],r
   assert {k:v for k,v in(await q.room()).items()if k!='record_ui'}=={k:v for k,v in before.items()if k!='record_ui'};await q.shot('01-auto-visible-read');await q.press('관심 표시');await q.press('관심 자료만');assert(await q.records())['entries']==['G3']
   # Archive contains records from another run, deliberately seeded and restored.
   await q.py('import renpy;s=renpy.store;s._qa_old_knowledge=list(s.persistent.room13_knowledge);s.persistent.room13_knowledge=["E01","G1","G3","E02"];result=True')
   before=await q.room();await q.press('이전 발견');await asyncio.sleep(1);rec=await q.records();assert len(rec['entries'])==4,rec;await q.press('예약 원본');await asyncio.sleep(1);assert await q.room()==before;await q.shot('02-archive-filter-isolation')
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.shot('03-mobile-archive');await q.press('이번 여정');assert(await q.records())['entries']==['G3'];await q.press('닫기');await q.wait('r13_hub');await q.py('import renpy;s=renpy.store;s.persistent.room13_knowledge=s._qa_old_knowledge;result=True')
   report['checks'].append('Natural acquired detail read automatically, archive fixture retains all entries despite current favorites, archive click leaves run state intact, current filter restored, PC/mobile')
   await pg.set_viewport_size({'width':1280,'height':720});q.touch=False
   # Three actual spoken checkpoints, preserving exact line after timer/record edits and slot load.
   await q.press('까로');await q.wait('r13_entry_karo_topics');await q.value('road');await q.wait('say');assert(await q.line())['index']==0
   # G3 already favorite; remove it so shared regression can toggle it on.
   await q.press('기록');await q.wait('r13_records');await q.press('옮겨 쓴 명부');await q.press('관심 해제');await q.press('닫기');await q.wait('say')
   await q.input(810,610);await q.wait('say')
   for key,slot in [('G1',1),('G3',2),('E01',3)]:
    await q.favorite_during_line(key,slot,advance=slot<3)
   await q.advance();await q.wait('r13_entry_karo_topics');await q.press('돌아가기');await q.wait('r13_hub');report['checks'].append('Natural Karo line1/2/3 exact save-load, following line once, return to field')
   # Known-promise and completed-observation fixtures only; story untouched afterward.
   before=await q.room();await q.py('import renpy,copy;s=renpy.store;s._qa_saved=copy.deepcopy(s.room13);s.room13=copy.deepcopy(s.room13);s.room13["flags"]+= ["elder_appointment","trial_notice"];result=True')
   await q.press('기록');await q.wait('r13_records');await q.press('달력');await asyncio.sleep(.8);assert len(await q.py('import renpy;result=renpy.store.r13_calendar_promises()'))==2;await q.shot('04-both-appointments')
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.shot('05-mobile-appointments');await q.press('닫기');await q.press('닫기');await q.wait('r13_hub');await q.py('import renpy;s=renpy.store;s.room13=s._qa_saved;result=True');assert await q.room()==before
   report['checks'].append('Explicit known-appointment fixture shows both promises, desktop/mobile; original state restored')
   await q.py('import renpy,copy;s=renpy.store;s._qa_saved=copy.deepcopy(s.room13);s.room13=copy.deepcopy(s.room13);s.room13["tool_discoveries"]={"seam":{"day":1,"period":1,"place":"room13","evidence_id":"E03"}};s.room13["read_topics"].append("tool:seam");result=True')
   await q.press('기록');await q.wait('r13_records');await q.press('관찰 메모');await asyncio.sleep(.8);await q.shot('06-completed-observation-mobile');await q.press('닫기');await q.press('닫기');await q.wait('r13_hub');await q.py('import renpy;s=renpy.store;s.room13=s._qa_saved;result=True');assert await q.room()==before
   report['checks'].append('Explicit completed-tool-note fixture renders completion and history direction, state restored')

   report['status']='passed'
  except Exception as e:
   report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
   try:(out/'failure-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
   except Exception:pass
  finally:
   (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));await b.close()
 print(report,flush=True)
 if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
