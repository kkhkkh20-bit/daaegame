"""Explicit day7 hearing fixture: real cancel/Escape routes, no evidence submission."""
import asyncio,argparse,json,shutil,urllib.request
from playwright.async_api import async_playwright
from pixel_qa_ui0156 import UIQA,ROOT
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);a=ap.parse_args();out=ROOT/'qa-room13-0159/trial-fixture';out.mkdir(parents=True,exist_ok=True);report={'kind':'explicit day7 hearing fixture with real UI inputs','archive_sha256':json.load(urllib.request.urlopen(a.url+'game-transport.json'))['archive_sha256']}
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);pg=await b.new_page(viewport={'width':1280,'height':720},has_touch=True);q=UIQA(pg,out)
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;s=renpy.store;s.preferences.text_cps=0;s.persistent.room13_opening_seen=True;result=True');await q.press('처음부터');await q.wait('choice');await q.press('마을 입구부터');await q.advance();await q.wait('r13_hub')
   # A visible test button enters the real label; only fixture setup is injected.
   rect=await q.py('import renpy;s=renpy.store;s.r13_edit(day=7,period=0,case_state="occurred",victim_state="dead",daram_state="held");s.r13_claim="C1";s.r13_target="buri";s.r13_present_origin="topics";f=next(f for f in renpy.display.focus.focus_list if f.x is not None and f.w and f.h and hasattr(f.widget,"clicked"));f.widget.action=s.Jump("r13_argument_menu");f.widget.clicked=f.widget.action;f.widget.sensitive=True;result=[f.x,f.y,f.w,f.h]')
   x,y,w,h=rect;await q.input(x+w/2,y+h/2);await q.wait('r13_debate');before=await q.room();await q.press('근거 제시');await q.wait('r13_book');await q.press('제시 취소');await q.wait('r13_debate');assert {k:v for k,v in (await q.room()).items() if k!="record_ui"}=={k:v for k,v in before.items() if k!="record_ui"};assert await q.py('import renpy;result=renpy.store.r13_claim')=='C1';await q.shot('01-cancel-same-claim')
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.press('근거 제시');await q.wait('r13_book');await pg.keyboard.press('Escape');await q.wait('r13_debate');assert {k:v for k,v in (await q.room()).items() if k!="record_ui"}=={k:v for k,v in before.items() if k!="record_ui"};await q.shot('02-mobile-escape-same-claim');report['status']='passed'
  except Exception as e:report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
  finally:(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));await b.close()
 print(report,flush=True)
 if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
