#!/usr/bin/env python3
"""Browser-check only the gallery at the supplied URL; never drives game state."""
import argparse,asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
async def check(url,out):
 out.mkdir(parents=True,exist_ok=True)
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  page=await b.new_page(viewport={'width':1440,'height':1100});errors=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('response',lambda r:errors.append(str(r.status)+' '+r.url) if r.status>=400 else None)
  await page.goto(url,wait_until='networkidle')
  data=await(await page.request.get(url+'catalog.json')).json()
  assert data['portrait_coverage']['complete']
  assert len(data['people'])==43
  avatars=set();worlds=0;controls=0
  for group in ('main','support'):
   await page.locator('[data-kind='+group+']').click()
   for person in [x for x in data['people'] if x['kind']==group]:
    await page.locator('#person').select_option(person['id'])
    assert len(person['dialogue'])==4
    avatar=person['dedicated_avatar'];assert avatar and avatar['origin']=='dedicated'
    signature=(avatar['file'],tuple(avatar['rect']));assert signature not in avatars,(person['id'],'reused avatar');avatars.add(signature)
    assert avatar['file'] not in {s['file'] for s in person['dialogue'].values()}
    assert await page.locator('#front-strip .card').count()==4
    assert await page.locator('#front-strip .pending-card').count()==0
    assert '별도 프사 원화' in await page.locator('#front-comparison .card').last.inner_text()
    for button in await page.locator('#portrait-poses button').all():
     await button.click();controls+=1
     assert await page.locator('#front-comparison img').count()==3
    if person['id'] in ('daram','dad','mom'):
     world=person['after'][person['world_pose']];assert 'world-' in world['file'];worlds+=1
     await page.locator('#dialogue-comparison').scroll_into_view_if_needed();await page.wait_for_timeout(100)
     await page.screenshot(path=str(out/(person['id']+'-front-desktop.png')))
  for source in data['sources']:
   response=await page.request.head(url+source['file']);assert response.status==200,source
  for capture in data['front_runtime']:
   response=await page.request.head(url+capture['file']);assert response.status==200,capture
   assert 'portrait-framing' not in capture['file'],capture
  if data['front_runtime']:
   await page.locator('#front-runtime').scroll_into_view_if_needed();await page.wait_for_timeout(250)
   await page.screenshot(path=str(out/'natural-runtime-desktop.png'))
  # Browser-created review grid: untouched sources with the same CSS crop as gallery.
  await page.evaluate('''people=>{const grid=document.createElement('div');grid.id='qa-avatar-grid';grid.style.cssText='display:grid;grid-template-columns:repeat(9,1fr);gap:8px;padding:16px;background:#172a32;';people.forEach(p=>{const a=p.dedicated_avatar,c=document.createElement('div'),s=document.createElement('div');s.className='stage';s.style.height='145px';s.append(crop(a));c.append(s,el('div','',p.name));grid.append(c)});document.body.replaceChildren(grid)}''',data['people'])
  await page.set_viewport_size({'width':1800,'height':1080});await page.wait_for_timeout(600);await page.screenshot(path=str(out/'all-43-dedicated-avatars.png'),full_page=True)
  await page.goto(url,wait_until='networkidle');await page.set_viewport_size({'width':390,'height':844})
  for key in ('daram','dad','mom'):
   await page.locator('#person').select_option(key);await page.locator('#dialogue-comparison').scroll_into_view_if_needed()
   for button in await page.locator('#portrait-poses button').all():await button.click()
   await page.locator('#front-comparison .card').last.scroll_into_view_if_needed();await page.wait_for_timeout(150)
   await page.screenshot(path=str(out/(key+'-front-mobile.png')))
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth')
  if data['front_runtime']:
   await page.locator('#front-runtime').scroll_into_view_if_needed();await page.wait_for_timeout(250)
   await page.screenshot(path=str(out/'natural-runtime-mobile.png'))
  assert not errors,errors
  report=dict(characters=43,front_pose_controls=controls,unique_dedicated_avatars=len(avatars),family_world_overrides=worlds,source_urls=len(data['sources']),runtime_captures=len(data['front_runtime']),mobile_overflow=False,errors=errors)
  (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report))
  await b.close()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--url',default='http://127.0.0.1:8098/');p.add_argument('--output',type=Path,default=Path('/tmp/qa-front-gallery'));a=p.parse_args();asyncio.run(check(a.url,a.output))
