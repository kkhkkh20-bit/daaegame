"""Independent staging fixtures. Injected schedules are not narrative playthroughs.
Live-input routes and all state injection are named separately in the report.
"""
import argparse, asyncio, json, shutil
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_browser import PixelQA, ROOT

SCHEDULE = '''import renpy, copy
s=renpy.store
original=copy.deepcopy(s.room13)
rows=[];failures=[];seen=set();staged_seen=set()
has_stage=hasattr(s,'r13_stage_people')
variants=[('free','alive','trusted','with_dad','prevented'),('occurred','dead','trusted','with_dad','occurred'),('detained','dead','detained','held','occurred'),('rescued','alive','detained','rescued','prevented')]
try:
 for day in range(1,15):
  for period in range(4):
   for variant,victim,granny,daram,case in variants:
    for location in s.R13_PLACES:
     state=copy.deepcopy(original);state.update(day=day,period=period,location=location,victim_state=victim,granny_state=granny,daram_state=daram,case_state=case)
     state['flags']=[f for f in state['flags'] if f!='mom_reunited']
     if variant=='rescued' and day>=8:state['flags'].append('mom_reunited')
     s.room13=state
     people=list(s.r13_people());seen.update(people)
     staged=s.r13_stage_people() if has_stage else []
     identities=[r['person'] for r in staged];staged_seen.update(identities)
     errors=[]
     if has_stage and staged!=s.r13_stage_people():errors.append('same-clock staging is nondeterministic')
     if victim=='dead' and 'resident_owlgp' in people+identities:errors.append('dead victim visible')
     if granny=='detained' and 'granny' in people+identities:errors.append('detained granny visible')
     if daram not in ('with_dad','rescued') and 'daram' in identities:errors.append('held/lost child freely staged')
     if 'mom_reunited' not in state['flags'] and 'mom' in identities:errors.append('unrevealed mother staged')
     if len(identities)!=len(set(identities)):errors.append('duplicate physical actor')
     for actor in staged:
      if actor['person'] not in people and actor['person'] not in ('dad','daram'):errors.append('actor not scheduled: '+actor['person'])
      x,y,w,h=actor['rect']
      if w<=0 or h<=0 or not (0<=x+w/2<=1280 and 90<=y+h/2<625):errors.append('actor hitbox center inaccessible: '+actor['person'])
     item={'day':day,'period':period,'variant':variant,'location':location,'people':people,'stage':staged,'errors':errors}
     if errors:failures.append(item)
     if staged or people:rows.append(item)
finally:s.room13=original
face_checks=[]
if has_stage:
 for who,poses in s.R13_ACTING.items():
  for pose,spec in poses.items():
   if pose.startswith('avatar_'):continue
   actual=s.CAST.get(who,{}).get(pose)
   if not actual or actual['file']!=spec['file'] or actual['crop']!=spec['crop']:failures.append({'person':who,'pose':pose,'errors':['runtime CAST does not use authored acting crop']})
   front=hasattr(s,'r13_close_spec') and s.r13_close_spec(who,pose) is not None
   head=s.r13_close_head(who,pose) if front else s.r13_acting_head(who,pose)
   if not head:failures.append({'person':who,'pose':pose,'errors':['missing pose head anchor']});continue
   scale=s.r13_close_scale(who,pose,840);y=s.r13_close_y(who,pose=pose);w,h=s.r13_close_geometry(who,pose) if front else s.r13_actor_geometry(who,pose);x=640-w*scale/2
   face=[x+head[0]*scale,y+head[1]*scale,head[2]*scale,head[3]*scale]
   safe=face[0]>=0 and face[0]+face[2]<=1280 and 90<=face[1] and face[1]+face[3]<551
   if not safe:failures.append({'person':who,'pose':pose,'errors':['face extends outside safe dialogue area'],'face':face})
   face_checks.append({'person':who,'pose':pose,'face':face,'safe':safe})
result={'kind':'injected-14-day-schedule-matrix-not-natural-play','has_stage_api':has_stage,'face_geometry_checks':face_checks,'rows':rows,'failures':failures,'scheduled_identities':sorted(seen),'staged_identities':sorted(staged_seen),'never_staged':sorted(seen-staged_seen),'total_conditions':14*4*len(variants)*len(s.R13_PLACES),'state_restored':s.room13==original}
'''

async def render_stages(q,report,locations=None):
 import ast
 rows=report['rows'];chosen=[];keys=set();covered=set()
 # Cover each occupied location/time, then all scheduled identities.
 for row in rows:
  key=(row['location'],min(row['period'],2))
  if row['stage'] and key not in keys:
   chosen.append(row);keys.add(key);covered.update(a['person'] for a in row['stage'])
 while set(report['scheduled_identities'])-covered:
  row=max(rows,key=lambda r:len({a['person'] for a in r['stage']}-covered))
  new={a['person'] for a in row['stage']}-covered
  if not new:break
  chosen.append(row);covered.update(new)
 if locations:
  chosen=[row for row in chosen if row['location'] in locations]
  covered={actor['person'] for row in chosen for actor in row['stage']}
 variants={'free':('alive','trusted','with_dad','prevented'),'occurred':('dead','trusted','with_dad','occurred'),'detained':('dead','detained','held','occurred'),'rescued':('alive','detained','rescued','prevented')}
 base=(await q.state())['room'];shots=[]
 for i,row in enumerate(chosen):
  state=json.loads(json.dumps(base));victim,granny,daram,case=variants[row['variant']];state.update(day=row['day'],period=row['period'],location=row['location'],victim_state=victim,granny_state=granny,daram_state=daram,case_state=case);state['flags']=[f for f in state['flags'] if f!='mom_reunited']
  if row['variant']=='rescued' and row['day']>=8:state['flags'].append('mom_reunited')
  code="import renpy\ns=renpy.store\ns.room13="+ascii(state)+"\ns.r13_inspection_location=None\ns.place=s.R13_PLACES[s.room13['location']][0]\nrenpy.exports.hide_screen('r13_hub')\nrenpy.exports.hide_screen('say')\nrenpy.exports.scene()\nrenpy.exports.show('qa_stage_background',what=s.r13_background(s.R13_PLACES[s.room13['location']][1]))\nrenpy.exports.show_screen('r13_hub',entry=False)\nrenpy.exports.show_screen('r13_hud')\nrenpy.exports.restart_interaction()\nresult=s.r13_stage_people()"
  actors=await q.py(code);await q.wait('r13_hub');st=await q.state();focused={}
  for button in st['buttons']:
   try:value=ast.literal_eval(button['value'])
   except (ValueError,SyntaxError):continue
   if isinstance(value,tuple) and len(value)==2 and value[0]=='person':focused.setdefault(value[1],[]).append(button['rect'])
  for actor in actors:assert actor['rect'] in focused.get(actor['person'],[]),('focus vs stage mismatch',actor,focused)
  name='%02d-%s-d%d-p%d-%s'%(i,row['location'],row['day'],row['period'],row['variant']);await q.shot(name);shots.append({'file':name+'.png','actors':actors,'scenario':{k:row[k] for k in ('location','day','period','variant')}})
 return {'kind':'injected-world-staging-render-fixtures-not-natural-play','shots':shots,'covered_identities':sorted(covered),'focus_rectangles_match':True}

async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',default='http://127.0.0.1:8094/room13-release-0130/');ap.add_argument('--out',default='qa-room13-0140/schedule');ap.add_argument('--require-stage',action='store_true');ap.add_argument('--render',action='store_true');ap.add_argument('--render-locations',nargs='*');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True)
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);context=await browser.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');page=await context.new_page();errors=[];bad=[];external=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('response',lambda r:bad.append([r.status,r.url])if r.status>=400 and 'favicon'not in r.url else None)
  async def reject_art(route):
   external.append(route.request.url);await route.abort()
  await page.route('**/game/assets/room13-pixel-*.png',reject_art);q=PixelQA(page,out)
  try:
   await page.goto(a.url);await page.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy; renpy.store.preferences.text_cps=0; result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub');report=await q.py(SCHEDULE);assert not report['failures'],report['failures'][:3];assert report['state_restored'];assert not a.require_stage or report['has_stage_api'],'staging API unavailable';assert not a.require_stage or not report['never_staged'],('Scheduled actors never staged',report['never_staged']);assert not errors,errors;assert not bad,bad;assert not external,external;report['status']='passed'
   if a.render:report['render']=await render_stages(q,report,a.render_locations)
  except Exception as e:
   await page.screenshot(path=str(out/'failure.png'));report=locals().get('report',{});report.update(status='failed',error=repr(e))
  report.update(errors=errors,http_errors=bad,external_active_art_requests=external,url=a.url);(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ('rows','failures','render','face_geometry_checks')},ensure_ascii=False));await browser.close()
  if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
