"""Injected world fixtures and actual pixel input routing; no natural-story claims."""
import argparse,asyncio,json,shutil
from playwright.async_api import async_playwright
from pixel_qa_flow0150 import FlowQA,ROOT
# Chosen from actual 858 candidate screenshots; revise if final art placement changes.
POINTS={
 'school':[(140,304,'resident_seori'),(367,297,'resident_teacher'),(494,310,'nabi'),(684,310,'resident_owlgp'),(915,310,'resident_tok'),(116,487,'resident_kongi'),(337,496,'resident_yeoni'),(471,432,'resident_badook'),(673,425,'resident_somi'),(842,483,'resident_musoe'),(1064,510,'resident_tori'),(1216,500,'resident_nubi')],
 'post':[(172,380,'seryeon'),(341,475,'resident_momo'),(607,405,'resident_kongi'),(763,392,'resident_guseul'),(933,370,'resident_librarian'),(1169,321,'resident_ppul')],
 'workshop':[(124,456,'resident_tok'),(216,430,'resident_ttadak'),(294,479,'resident_musoe'),(398,409,'resident_yeoni'),(615,438,'buri'),(862,407,'resident_lamplighter'),(1030,408,'resident_ubak'),(1178,454,'resident_tori')],
}
PATCH='''import renpy
s=renpy.store;s.qa_hit=None
if not hasattr(s,'qa_original_return'):
 s.qa_original_return=s.Return.__call__
 s.Return.__call__=lambda self:setattr(__import__('renpy').store,'qa_hit',self.value)
result=True
'''
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--population',required=True);ap.add_argument('--out',default='qa-room13-0152/denseclick-final');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True);pop=json.loads((ROOT/a.population).read_text());report={'kind':'injected-world-state-and-action-observation-fixture-real-pixel-clicks','checks':[]}
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=FlowQA(pg,out)
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub')
   for loc,points in POINTS.items():
    row=max([r for r in pop['rows']if r['location']==loc],key=lambda r:len(r['actors']))
    await q.py("import renpy\ns=renpy.store\ns.room13="+ascii(row['state'])+"\ns.place=s.R13_PLACES[s.room13['location']][0]\nrenpy.exports.hide_screen('r13_hub')\nrenpy.exports.hide_screen('say')\nrenpy.exports.scene()\nrenpy.exports.show('qa_dense_background',what=s.r13_background(s.R13_PLACES[s.room13['location']][1]))\nrenpy.exports.show_screen('r13_hub',entry=False)\nrenpy.exports.restart_interaction()\nresult=True")
    await q.wait('r13_hub');await q.shot(loc)
    for x,y,who in points:
     await q.py(PATCH);await q.input(x,y);actual=await q.py('import renpy;result=renpy.store.qa_hit');check={'location':loc,'coordinate':[x,y],'expected':['person',who],'actual':actual};report['checks'].append(check)
    if loc=='school':
     await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await asyncio.sleep(.5);await q.shot('school-mobile')
     for x,y,who in points:
      await q.py(PATCH);await q.input(x,y);actual=await q.py('import renpy;result=renpy.store.qa_hit');report['checks'].append({'location':loc,'mode':'mobile','coordinate':[x,y],'expected':['person',who],'actual':actual})
     await pg.set_viewport_size({'width':1280,'height':720});q.touch=False;await asyncio.sleep(.5)
   report['failures']=[r for r in report['checks']if r['actual']!=r['expected']];assert not report['failures'],report['failures'];report['status']='passed'
  except Exception as e:report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
  report['url']=a.url;(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False));await b.close()
  if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
