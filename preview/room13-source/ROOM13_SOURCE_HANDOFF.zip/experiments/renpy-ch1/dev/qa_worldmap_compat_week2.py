"""Real old-build save through IndexedDB into candidate, plus full-runtime positives.
Run on a local server whose /room13-dev is a symlink. Only that symlink changes;
neither the baseline nor candidate game/save bytes are patched by this test.
"""
import argparse,asyncio,hashlib,json,os,shutil,sys,urllib.request
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from pixel_qa_ui0156 import UIQA
from playwright.async_api import async_playwright
ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--link',type=Path,required=True);ap.add_argument('--baseline',type=Path,required=True);ap.add_argument('--candidate',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True)
def select_build(path):
 temp=a.link.with_name(a.link.name+'.next');temp.unlink(missing_ok=True);temp.symlink_to(path.resolve(),target_is_directory=True);temp.replace(a.link)
def transport(path):return json.loads((path/'game-transport.json').read_text())['archive_sha256']
SAVES='''import renpy,os,hashlib
folder=renpy.config.savedir
result={n:hashlib.sha256(open(os.path.join(folder,n),'rb').read()).hexdigest() for n in os.listdir(folder) if n.endswith('.save')}
'''
async def main():
 report={'kind':'Full RenPy runtime; actual old-build UI save and same-origin IndexedDB reload, no candidate save/state injection before restore','baseline_archive':transport(a.baseline),'candidate_archive':transport(a.candidate),'checks':[]}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},service_workers='block');pg=await c.new_page();q=UIQA(pg,a.out);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  async def restart_field():
   await q.py('import renpy;s=renpy.store;w=renpy.exports.get_widget("r13_hub","r13_options_gear");w.action=s.Jump("r13_field");w.clicked=w.action;result=True');await q.input(1220,50);await q.wait('r13_hub')
  async def map_info():return await q.py('import renpy;s=renpy.store;sc=renpy.display.screen.get_screen("r13_map");result={"selected":sc.scope["selected"],"region":sc.scope["region"],"allowed":s.r13_places(),"mountain":[k for k,p in s.r13_map_nodes("mountain")],"day":s.room13["day"],"location":s.room13["location"],"finale_started":s.room13.get("finale_started")}')
  try:
   select_build(a.baseline);await pg.goto(a.url+'?baseline');await pg.wait_for_function("typeof renpy_exec==='function'",timeout=180000);await q.wait('main_menu')
   report['baseline_version']=await q.py('import renpy;result=renpy.store.config.version');assert not await q.py('import renpy;result=hasattr(renpy.store,"R13_WORLD_V5")')
   await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub')
   # Explicit baseline gameplay fixture, then the actual old engine/UI creates the save.
   await q.py('import renpy;s=renpy.store;s.r13_edit(day=2,period=0,location="inn");s.r13_flag("entry_corrected","lodging");s.r13_grant(["E03"],"호환 검증 fixture");s.r13_upgrade();result=True');await restart_field();await q.save(1);saved=await q.room();old_saves=await q.py(SAVES);assert old_saves
   (a.out/'old-saved-room.json').write_text(json.dumps(saved,ensure_ascii=False,indent=2));report['old_save_files']=old_saves;await q.shot('01-old-public-build-saved')
   await q.py('import renpy;renpy.savelocation.syncfs();result=True');await asyncio.sleep(2)
   # Same browser context, origin, URL path and real IndexedDB. Only served build changes.
   select_build(a.candidate);await pg.goto(a.url+'?candidate');await pg.wait_for_function("typeof renpy_exec==='function'",timeout=180000);await q.wait('main_menu');assert await q.py('import renpy;result=hasattr(renpy.store,"R13_WORLD_V5")')
   report['candidate_version']=await q.py('import renpy;result=renpy.store.config.version');new_saves=await q.py(SAVES)
   assert all(new_saves.get(k)==v for k,v in old_saves.items()),(old_saves,new_saves)
   report['save_files_after_candidate_boot']=new_saves
   await q.press('이어하기');await q.wait('r13_hub');await q.load(1);loaded=await q.room();assert loaded==saved,(loaded,saved)
   await q.shot('02-candidate-old-save-restored');await q.press('지도 · 이동');await q.wait('r13_map');await q.press('마을 보기');await q.press('수리점');await q.press('이곳으로 이동');await q.wait('r13_hub');assert (await q.room())['location']=='workshop';assert ((await q.room())['day'],(await q.room())['period'])==(2,0)
   report['checks'].append('Actual 0.17.25 public-package save files persist byte-for-byte through same-origin IndexedDB; candidate Load restores exact full room dict, then new-map travel works without time change')
   # No source extraction: inspect the installed callable/wrapper chain in the full runtime.
   report['runtime_place_functions']=await q.py('import renpy;s=renpy.store;result={n:{"file":getattr(s,n).__code__.co_filename,"line":getattr(s,n).__code__.co_firstlineno} for n in ("r13_places","_r13_firstday_places","_r13_route_places") if hasattr(s,n)}')
   await q.py('import renpy;s=renpy.store;s.r13_edit(day=8,period=0,location="facility",week2_started=True,trial_ended=True,evidence=[e for e in s.room13["evidence"] if e!="E19"]);result=True');await restart_field();await q.press('지도 · 이동');await q.wait('r13_map');before=await map_info();assert 'facility'in before['mountain'] and 'greenhouse'not in before['mountain'];report['day8_before_E19']=before
   await q.py('import renpy;s=renpy.store;s.r13_grant(["E19"],"초롱의 답장 — 긍정 분기 검증 fixture");renpy.exports.restart_interaction();result=True');after=await map_info();assert 'greenhouse'in after['allowed'] and 'greenhouse'in after['mountain'];report['day8_after_E19']=after;await q.shot('03-day8-E19-greenhouse-visible')
   await q.press('폐온실');await q.press('이곳으로 이동');await q.wait('r13_hub');room=await q.room();assert room['location']=='greenhouse' and room['day']==8 and room['period']==0;await q.shot('04-day8-greenhouse-arrival');report['checks'].append('Day8 full runtime: E19 absent hides greenhouse; real r13_grant adds E19, map shows it, actual selection/confirmation travels to greenhouse at unchanged time')
   await q.py('import renpy;s=renpy.store;s.r13_edit(day=14,period=0,location="facility",finale_started=False);result=True');await restart_field();await q.press('지도 · 이동');await q.wait('r13_map');assert 'altar'not in (await map_info())['mountain'];await q.press('현장으로 돌아가기');await q.wait('r13_hub')
   # Execute the real finale label to set day/location/finale_started, then inspect a map overlay.
   await q.py('import renpy;s=renpy.store;w=renpy.exports.get_widget("r13_hub","r13_options_gear");w.action=s.Jump("r13_finale");w.clicked=w.action;result=True');await q.input(1220,50);await q.wait('say');await q.py('import renpy;renpy.exports.show_screen("r13_map");renpy.exports.restart_interaction();result=True');await q.wait('r13_map');finale=await map_info();assert finale['day']==14 and finale['location']=='altar' and finale['finale_started'] and 'altar'in finale['mountain'] and finale['selected']=='altar';assert 'altar'not in finale['allowed'];report['day14_real_finale_map']=finale;await q.shot('05-day14-finale-current-altar')
   report['checks'].append('Real r13_finale label establishes day14/current altar/finale_started; explicitly opened map overlay displays current altar. It remains outside ordinary travel destinations; no new shrine route invented')
   assert not errors,errors;report['status']='passed'
  except Exception as e:
   report.update(status='failed',error=repr(e));await pg.screenshot(path=str(a.out/'failure.png'))
   try:(a.out/'failure-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
   except:pass
  report['errors']=errors;(a.out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']!='passed':raise SystemExit(1)
asyncio.run(main())
