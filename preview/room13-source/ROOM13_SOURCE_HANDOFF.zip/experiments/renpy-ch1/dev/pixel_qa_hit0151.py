"""Interactive independent visible-art hit QA; fixture jumps explicitly recorded."""
import asyncio,json,sys,shutil
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_flow0150 import FlowQA,ROOT
OUT=ROOT/'qa-room13-0151/hit-audit';OUT.mkdir(parents=True,exist_ok=True)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader'])
  c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=FlowQA(pg,OUT)
  await pg.goto('http://127.0.0.1:8094/room13-release-0151/');await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub');await q.shot('entry-desktop')
  print('READY',flush=True)
  while True:
   line=await asyncio.to_thread(sys.stdin.readline)
   if not line:break
   try:
    a=json.loads(line);op=a['op']
    if op=='click':await q.input(a['x'],a['y']);r=await q.state()
    elif op=='raw':await pg.mouse.click(a['x'],a['y']);await asyncio.sleep(.4);r=await q.state()
    elif op=='press':await q.press(a['text']);r=await q.state()
    elif op=='advance':r=await q.advance()
    elif op=='py':r=await q.py(a['code']);await asyncio.sleep(.5)
    elif op=='shot':await q.shot(a['name']);r=await q.state()
    elif op=='resize':await pg.set_viewport_size({'width':a['w'],'height':a['h']});q.touch=True;await asyncio.sleep(.7);r=await pg.locator('canvas').evaluate_all('(els)=>els.map(e=>({id:e.id,rect:e.getBoundingClientRect().toJSON(),w:e.width,h:e.height}))')
    elif op=='quit':break
    else:r=await q.state()
    (OUT/'last.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps(r,ensure_ascii=False),flush=True)
   except Exception as e:print('ERROR '+repr(e),flush=True)
  await b.close()
asyncio.run(main())
