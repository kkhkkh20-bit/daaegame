"""Fresh run, real UI: first-night deduction and day-two corroboration."""
import asyncio,json,shutil,urllib.request
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_ui0156 import UIQA
from pixel_qa_flow0150 import FLOW_PROBE
OUT=Path('/workspace/room13-review/intro0175');OUT.mkdir(exist_ok=True)
URL='http://127.0.0.1:8094/room13-dev/'
class IntroQA(UIQA):
 async def state(self):
  probe=FLOW_PROBE.replace('names=[',"names=['r13_entry_daram_topics','r13_gate_document_inspection','r13_gate_document_read','r13_resident_approach','r13_desk_inspection','r13_record_compare','r13_records','r13_book','r13_backlog',")
  st=await self.py('ns={};exec('+ascii(probe)+',ns);result=ns["result"]');assert '_exception' not in st['screens'],st;return st
 async def advance_to(self,name):
  for _ in range(150):
   st=await self.state()
   if name in st['screens']:await asyncio.sleep(.4);return st
   if 'say' in st['screens']:await self.input(810,610)
   elif 'r13_cinematic_view' in st['screens']:await self.press('계속')
   else:await asyncio.sleep(.2)
  raise AssertionError((name,st))
 async def talk(self,label):
  await self.press(label);await self.advance()
  if 'r13_resident_approach' in (await self.state())['screens']:
   await self.value(True)
  await self.advance_to('r13_topics')
 async def value(self,value):
  for attempt in range(10):
   try:return await super().value(value)
   except AssertionError:
    if attempt==9:raise
    await asyncio.sleep(.3)
 async def present(self,label):
  await self.press('보여주기');await self.wait('r13_book');await self.press('들은 말' if label=='초롱의 목격담' else '증거');await self.press(label);await self.press('보여주기');await self.wait('r13_confirm');await self.press('보여준다');await self.advance_to('r13_topics')
async def main():
 report={'archive_sha256':json.load(urllib.request.urlopen(URL+'game-transport.json'))['archive_sha256'],'checks':[]}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader'])
  context=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='allow');pg=await context.new_page();q=IntroQA(pg,OUT)
  try:
   await pg.goto(URL);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu')
   await q.py('import renpy;s=renpy.store;s.preferences.text_cps=0;s.preferences.afm_enable=False;result=True')
   await q.press('처음부터');await q.advance_to('r13_hub');assert (await q.room())['location']=='gate'
   assert 'entry_corrected' not in (await q.room())['flags'] and 'E02' not in (await q.room())['evidence']
   await q.value(('person','daram'));await q.advance_to('r13_entry_daram_topics');await q.value('look');await q.advance_to('r13_entry_daram_topics');await q.shot('00-daram-entry-questions');await q.press('돌아가기');await q.wait('r13_hub')
   rect=await q.py('import renpy;result=renpy.store.ROOM13["objects"]["gate"]["gate_documents"]["rect"]');cam=await q.camera();x,y,w,h=rect;await q.input(x+w/2-cam['offset'],y+h/2);await q.wait('r13_gate_document_inspection')
   for label in ('예약 원본','옮겨 쓴 이름 목록'):
    await q.press(label);await q.wait('r13_gate_document_read');await q.press('확인');await q.wait('r13_gate_document_inspection')
   await q.press('현장으로 돌아가기');await q.wait('r13_hub');await q.value(('person','daram'));await q.advance_to('r13_entry_daram_topics');await q.value('compare');await q.advance_to('r13_record_compare')
   await q.press('예약 원본');await q.press('옮겨 쓴 목록');await q.press('비교하기');assert 'gate_documents_compared' in (await q.room())['flags'];await q.shot('00b-family-entry-comparison');await q.press('기록으로 돌아가기');await q.wait('r13_entry_daram_topics');await q.press('돌아가기');await q.wait('r13_hub')
   await q.press('돌목');await q.wait('r13_entry_topics');await q.press('보여주기');await q.wait('r13_book');await q.press('예약 원본');await q.press('보여주기');await q.advance_to('r13_hub');assert 'entry_corrected' in (await q.room())['flags'];assert (await q.room())['location']=='gate'
   report['checks'].append('Entry deduction restored: Daram questions; read original/copied records; compare together; present original to guard; no automatic travel')
   await q.travel('광장');await q.travel('여관 접수대');before=await q.room();await q.press('할머니');await q.advance_to('r13_resident_approach');await q.shot('00c-granny-approach');await q.value(False);await q.wait('r13_hub');assert await q.room()==before
   await q.talk('할머니');assert 'lodging' not in (await q.room())['flags'];assert await q.py('import renpy;result=len(renpy.store.r13_topics("granny"))')>2
   await q.value('register');await q.advance_to('r13_topics');assert 'lodging' in (await q.room())['flags'];await q.press('돌아가기');await q.wait('r13_hub');assert (await q.room())['location']=='inn'
   report['checks'].append('Granny observation/companion remarks before approach; decline preserves state; accept opens greeting and original questions; room obtained only by question')
   await q.travel('2층 복도');await q.travel('13호실');assert 'M01' not in (await q.room())['evidence']
   await q.input(80,455);await q.wait('r13_desk_inspection');await q.shot('01-desk-closeup')
   rect=await q.py('import renpy;result=renpy.store.R13_INSPECTION_LAYOUT["desk"]["targets"]["letters"]');x,y,w,h=rect;await q.input(x+w/2,y+h/2);await q.wait('say')
   assert 'M01' not in (await q.room())['evidence'];await q.advance_to('r13_desk_inspection');assert 'M01' in (await q.room())['evidence']
   await q.press('방으로');await q.wait('r13_hub');await q.input(1020,360);await q.advance();await q.wait('r13_object_context');assert 'E03' in (await q.room())['evidence'];await q.press('그만 살펴본다');await q.wait('r13_hub')
   await q.value(('person','daram'));await q.advance_to('r13_topics');await q.value('home:records');await q.advance_to('r13_record_compare')
   before=await q.room();await q.press('초대 편지');await q.press('엄마의 메모');await q.press('비교하기');await q.shot('02-first-deduction')
   assert 'mother_expected_family' in (await q.room())['flags'];assert (await q.room())['period']==before['period']
   await q.press('기록으로 돌아가기');await q.wait('r13_topics');await q.press('돌아가기');await q.wait('r13_hub')
   report['checks'].append('Manual first-day travel; desk closeup; note acquired only after reading; owned-record comparison does not spend time')
   await q.travel('여관 접수대');await q.talk('할머니');await q.present('엄마의 메모');assert 'mother_lamplighter_lead' in (await q.room())['flags'];await q.press('돌아가기');await q.wait('r13_hub')
   await q.travel('13호실');await q.press('자기');await q.wait('r13_confirm');await q.press('자기');await q.advance_to('r13_hub');assert (await q.room())['day']==2
   report['checks'].append('Present note to granny identifies lamplighter; explicit sleep alone advances date')
   await q.travel('마을 입구',region='여관 밖으로');await q.press('까로');await q.advance_to('r13_topics');await q.value('life:karo');await q.advance_to('r13_topics');assert 'livelihood_open' in (await q.room())['flags'];assert (await q.room())['period']==0;await q.press('돌아가기');await q.wait('r13_hub')
   await q.travel('수리점');await q.talk('초롱')
   await q.present('엄마의 메모');assert 'J02' not in (await q.room())['evidence'];await q.value('intro:lamplighter_mother');await q.wait('say');assert 'J02' not in (await q.room())['evidence'];await q.advance_to('r13_topics');assert 'J02' in (await q.room())['evidence'];await q.shot('03-lamplighter-followup');await q.press('돌아가기');await q.wait('r13_hub')
   await q.travel('우체국');await q.talk('세련');await q.present('초롱의 목격담');assert 'J03' not in (await q.room())['evidence']
   await q.present('초대 편지');assert not await q.py('import renpy;result=any(k=="intro:post_visit" for k,s in renpy.store.r13_topics("seryeon"))')
   await q.present('엄마의 메모');assert await q.py('import renpy;result=any(k=="intro:post_visit" for k,s in renpy.store.r13_topics("seryeon"))')
   await q.value('intro:post_visit');await q.wait('say');assert 'J03' not in (await q.room())['evidence'];await q.advance_to('r13_topics');assert 'J03' in (await q.room())['evidence'];await q.shot('04-corroborated-visit');await q.press('돌아가기');await q.wait('r13_hub')
   report['checks'].append('Day-two Karo return question; note presentation opens testimony followup; postal followup requires both family records; testimonies acquired only after reading')
   assert (await q.room())['day']==2 and (await q.room())['period']==0
   await q.save(2);saved=await q.room();await q.load(2);assert await q.room()==saved
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.press('기록');await q.wait('r13_records');await q.shot('05-mobile-records');report['checks'].append('Investigation/presentation does not consume work slots; save/load preserves clues; mobile records render')
   report['status']='passed'
  except Exception as e:
   report.update(status='failed',error=repr(e));await pg.screenshot(path=str(OUT/'failure.png'))
   try:(OUT/'failure-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
   except:pass
   try:
    details=await q.py('import renpy;sc=renpy.display.screen.get_screen("r13_resident_approach");result={k:repr(sc.scope.get(k)) for k in ("ready","choices","person","target","_scope","_use_scope")} if sc else {}')
    (OUT/"failure-scope.json").write_text(json.dumps(details,ensure_ascii=False,indent=2))
   except:pass
  (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']=='failed':raise SystemExit(1)
asyncio.run(main())
