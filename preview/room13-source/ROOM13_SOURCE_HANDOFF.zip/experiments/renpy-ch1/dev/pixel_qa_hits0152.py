"""Visible-art-selected actual input regressions; no button-center oracle for Karo."""
import argparse,asyncio,json,shutil
from playwright.async_api import async_playwright
from pixel_qa_flow0150 import FlowQA,ROOT

async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--center-karo',action='store_true');ap.add_argument('--out',default='qa-room13-0152/hits');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True);report={'kind':'natural-entry-visible-picture-coordinate-clicks','checks':[]}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=FlowQA(pg,out);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub');await q.shot('00-entry')
   for mode in ('desktop','mobile'):
    if mode=='mobile':await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await asyncio.sleep(.7)
    await q.shot(mode+'-entry')
    points=([('eye',578,386),('coat',620,425),('right-head',620,377),('tail',714,465),('name',575,322)]if a.center_karo else [('eye',160,402),('coat',225,485),('right-head',210,390),('tail',342,533),('name',192,312)])
    for label,x,y in points:
     await q.wait('r13_hub');before=(await q.state())['room'];await q.input(x,y);st=await q.wait('r13_entry_karo_topics');assert st['room']==before,(mode,label,'changed room');await q.shot(mode+'-karo-'+label);report['checks'].append({'mode':mode,'target':'karo '+label,'game_coordinate':[x,y],'actual':'r13_entry_karo_topics'});await q.value('back');await q.wait('r13_hub')
    # Two questions in one continuing conversation; only explicit exit ends it.
    await q.input(points[0][1],points[0][2]);await q.wait('r13_entry_karo_topics')
    for text in ('짐 좀 부탁합니다','마차는 괜찮습니까?'):
     await q.press(text);await q.advance();st=await q.wait('r13_entry_karo_topics');report['checks'].append({'mode':mode,'question':text,'actual':'same topics after dialogue'})
    await q.shot(mode+'-two-questions-retained');await q.value('back');await q.wait('r13_hub')
    # The posted regulation is visibly at this coordinate, outside the actors.
    await q.input(390,321);await q.wait('say');thought=await q.py("import renpy;s=renpy.store;w=renpy.exports.get_widget('say','what');result={'active':s.r13_thought_active,'speaker':s.dialogue_speaker,'expression':s.dialogue_expression,'text':s.r13_packet[1],'color':str(w.style.color)}");assert thought['active'] and thought['speaker']=='dad' and thought['text'].startswith('('),thought;await q.shot(mode+'-dad-blue-thought');report['checks'].append({'mode':mode,'thought':thought});await q.advance();await q.wait('r13_hub');assert await q.py('import renpy;result=renpy.store.r13_thought_active')is False;st=await q.state();assert st['room']['last_inspection']['key']=='rules';assert 'G2'in st['room']['evidence'];report['checks'].append({'mode':mode,'game_coordinate':[390,321],'actual':'rules/G2'})
   assert not errors,errors;report['status']='passed'
  except Exception as e:report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
  report.update(errors=errors,url=a.url);(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False));await b.close()
  if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
