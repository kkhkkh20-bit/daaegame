import asyncio,json,sys,shutil
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path(__file__).resolve().parents[1]/'qa-room13-012'
PROBE='''import renpy
names=['main_menu','say','choice','r13_hub','r13_interaction','r13_topics','r13_book','r13_confirm','r13_calendar','r13_map','r13_activities','r13_debate','r13_completion','r13_cinematic_view','r13_crisis','r13_crisis_proof','r13_ending_screen','r13_handoff','save','load','pause_menu','confirm']
def txt(w,depth=0):
 if depth>8:return ''
 if isinstance(w,renpy.text.text.Text):return ''.join(str(x) for x in w.text)
 return ' '.join(txt(x,depth+1) for x in w.visit())
buttons=[]
for f in renpy.display.focus.focus_list:
 if f.x is not None and f.w and f.h:
  a=getattr(f.widget,'clicked',None)
  buttons.append({'text':txt(f.widget),'value':str(getattr(a,'value','')),'rect':[f.x,f.y,f.w,f.h]})
say=renpy.display.screen.get_screen('say')
result={'screens':[n for n in names if renpy.display.screen.get_screen(n)],'room':getattr(renpy.store,'room13',{}),'say':str(say.scope.get('what','')) if say else '', 'buttons':buttons}
'''
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader','--remote-debugging-port=9223'])
  ctx=await browser.new_context(viewport={'width':1280,'height':720},has_touch=True)
  page=await ctx.new_page();errors=[];bad=[]
  page.on('pageerror',lambda e:errors.append(str(e)))
  page.on('console',lambda m:(OUT/'console.log').open('a').write(m.type+': '+m.text+'\n'))
  page.on('response',lambda r:bad.append([r.status,r.url]) if r.status>=400 and 'favicon' not in r.url else None)
  page.set_default_timeout(20000)
  await page.goto('http://127.0.0.1:8093/preview/room13-candidate/')
  await page.wait_for_function("typeof renpy_exec==='function'",timeout=90000)
  await page.wait_for_timeout(1500)
  async def state(): return await asyncio.wait_for(page.evaluate('code=>renpy_exec(code)', 'ns={}; exec('+repr(PROBE)+',ns); result=ns["result"]'),15)
  async def click(x,y):
   await page.mouse.click(x,y);await page.wait_for_timeout(250)
  print('READY',flush=True)
  while True:
   line=await asyncio.to_thread(sys.stdin.readline)
   if not line:break
   try:
    c=json.loads(line);op=c['op']
    if op=='click':await click(c['x'],c['y']);r=await state()
    elif op=='text':
     s=await state();b=next(b for b in s['buttons'] if c['text'] in b['text'] and b['rect'][3]>15);x,y,w,h=b['rect'];await click(x+w/2,y+h/2);r=await state()
    elif op=='advance':
     for i in range(c.get('n',100)):
      s=await state()
      if 'say' not in s['screens'] or any(n in s['screens'] for n in ['choice','r13_hub','r13_book','r13_confirm','r13_interaction','r13_topics','r13_debate','r13_handoff']):break
      await click(810,640)
     r=await state()
    elif op=='shot':await page.screenshot(path=str(OUT/(c['name']+'.png')));r={'shot':c['name']}
    elif op=='py':r=await page.evaluate('code=>renpy_exec(code)',c['code']);await page.wait_for_timeout(800)
    elif op=='wheel':await page.mouse.move(c.get('x',450),c.get('y',470));await page.mouse.wheel(0,c['dy']);await page.wait_for_timeout(450);r=await state()
    elif op=='resize':await page.set_viewport_size({'width':c['w'],'height':c['h']});await page.wait_for_timeout(600);r=await state()
    elif op=='reload':await page.reload();await page.wait_for_function("typeof renpy_exec==='function'",timeout=90000);await page.wait_for_timeout(1200);r=await state()
    elif op=='driver':
     ns={'page':page,'state':state,'click':click,'OUT':OUT,'asyncio':asyncio,'json':json};exec(Path(c['file']).read_text(),ns);r=await ns['run']()
    elif op=='errors':r={'errors':errors,'bad':bad}
    else:r=await state()
    (OUT/'last-state.json').write_text(json.dumps(r,ensure_ascii=False,indent=2))
    if isinstance(r,dict) and 'room'in r:
     room=r['room'] or {};r['room']={k:v for k,v in room.items() if k not in ['records','checks','events','seen','observations','presented','read_topics']}
    print(json.dumps(r,ensure_ascii=False),flush=True)
   except Exception as e:
    await page.screenshot(path=str(OUT/'driver-error.png'));print(json.dumps({'error':str(e)}),flush=True)
  await browser.close()
asyncio.run(main())
