"""Independent UI acceptance: fresh browser, real buttons and touch; state reads only."""
import argparse, asyncio, ast, json, shutil
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
MOD=ast.parse((ROOT/'dev/qa_room13_live.py').read_text())
PROBE=next(ast.literal_eval(n.value) for n in MOD.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PROBE' for t in n.targets))
EXTRA="""import renpy
result={'version':renpy.store.config.version,'fast':renpy.store.r13_fast_read,'people':renpy.store.r13_people() if getattr(renpy.store,'room13_mode',False) else [],'speaker':getattr(renpy.store,'dialogue_speaker',None)}
"""
class QA:
 def __init__(self,page,out):self.p=page;self.out=out;self.touch=False;self.events=[];self.seen=set()
 async def py(self,code):return await self.p.evaluate('code=>renpy_exec(code)',code)
 async def state(self):return await self.py('ns={};exec('+repr(PROBE)+',ns);result=ns["result"]')
 async def info(self):return await self.py(EXTRA)
 async def input(self,x,y):
  vp=self.p.viewport_size;s=min(vp['width']/1280,vp['height']/720);x=(vp['width']-1280*s)/2+x*s;y=(vp['height']-720*s)/2+y*s
  if self.touch:await self.p.touchscreen.tap(x,y)
  else:await self.p.mouse.click(x,y)
  await asyncio.sleep(.30)
 async def wait(self,name):
  for _ in range(140):
   st=await self.state()
   if name in st['screens']:await asyncio.sleep(.55);return await self.state()
   await asyncio.sleep(.15)
  raise AssertionError((name,st))
 async def press(self,label):
  await asyncio.sleep(.55);st=await self.state()
  matches=[b for b in st['buttons'] if label in b['text'] and b['rect'][3]>15]
  assert matches,(label,st)
  b=min(matches,key=lambda b:b['rect'][2]*b['rect'][3]);x,y,w,h=b['rect']
  assert 0<=x+w/2<=1280 and 0<=y+h/2<=720,b
  await self.input(x+w/2,y+h/2)
 async def shot(self,name):
  await asyncio.sleep(.2);await self.p.screenshot(path=str(self.out/(name+'.png')))
  (self.out/(name+'.json')).write_text(json.dumps(await self.state(),ensure_ascii=False,indent=2));print('SHOT',name,flush=True)
 async def advance(self):
  for _ in range(230):
   st=await self.state()
   if 'r13_cinematic_view'in st['screens']:await self.press('계속');continue
   if any(x in st['screens'] for x in ['choice','r13_hub','r13_book','r13_confirm','r13_interaction','r13_topics']):
    await asyncio.sleep(.55);return await self.state()
   if 'say'in st['screens']:
    info=await self.info();who=info.get('speaker')
    if who and who not in self.seen:
     self.seen.add(who);await self.shot('speaker-'+str(who))
    await self.input(810,640)
   else:await asyncio.sleep(.2)
  raise AssertionError(st)
 async def cancel_unchanged(self,open_label,screen,close_label):
  before=(await self.state())['room'];await self.press(open_label);await self.wait(screen);await self.press(close_label);await self.wait('r13_hub')
  assert (await self.state())['room']==before,(open_label,'changed state')
  self.events.append(open_label+' cancel retains complete run state')
 async def npc(self,person):
  info=await self.info();assert person in info['people'],info
  i=info['people'].index(person);await self.input(175+285*i,430);await self.advance();await self.wait('r13_interaction')
 async def gate_only(self):
  await self.wait('main_menu');await self.press('처음부터');await self.advance();await self.wait('r13_hub');await self.press('원본 대조');await self.wait('r13_confirm');await self.press('진행한다')
  for _ in range(100):
   st=await self.state();info=await self.info()
   if 'say' in st['screens'] and info.get('speaker')=='karo':break
   if 'say' in st['screens']:await self.input(810,640)
   else:await asyncio.sleep(.2)
  assert info.get('speaker')=='karo',info
  scene=await self.py("import renpy; result={'clock':renpy.store.r13_clock(),'scene_key':renpy.store.r13_scene_key,'daylight':renpy.store.r13_daylight(),'gate_file':renpy.store.r13_art_path('gate'),'background':str(renpy.store.r13_background('winter').child)}")
  assert st['room']['period']==2 and scene['daylight']=='evening' and scene['scene_key'][3]=='evening',scene
  await self.shot('gate-wait-karo-evening')
  return {'status':'passed','checks':['Fresh start and gate wait: Karo first dialogue shows evening background and evening HUD'],'scene':scene}
 async def run(self):
  await self.wait('main_menu');await self.shot('01-title');self.events.append('fresh title')
  await self.press('설정');await self.wait('pause_menu');await self.shot('02-title-settings');await self.press('돌아가기');await self.wait('main_menu')
  await self.press('이어하기');await self.wait('load');await self.shot('03-title-load');await self.press('돌아가기');await self.wait('main_menu')
  await self.press('처음부터');await self.advance();await self.wait('r13_hub');await self.shot('04-entrance')
  await self.press('원본 대조');await self.wait('r13_confirm');await self.shot('05-wait-confirm');await self.press('진행한다');await self.advance();await self.wait('r13_hub')
  assert (await self.state())['room']['period']==2
  assert not any('빠르게'in b['text'] or '해 볼 일'in b['text'] for b in (await self.state())['buttons'])
  await self.shot('06-gate-hub');self.events.append('gate wait real consequence; no read-fast hub control')
  await self.press('설정');await self.wait('pause_menu');a=(await self.info())['fast'];await self.press('읽은 대사 빠르게');assert (await self.info())['fast']!=a
  await self.shot('07-game-settings');await self.press('읽은 대사 빠르게');assert (await self.info())['fast']==a;await self.press('돌아가기');await self.wait('r13_hub');self.events.append('settings read-fast toggle works both directions')
  await self.npc('karo');await self.shot('08-karo-interaction');await self.press('대화하기');await self.wait('r13_topics');await self.shot('09-karo-topics');await self.press('돌아가기');await self.wait('r13_interaction');await self.press('돌아가기');await self.advance()
  await self.cancel_unchanged('현장 활동','r13_activities','돌아가기');await self.cancel_unchanged('이동하기','r13_map','돌아가기')
  await self.press('이동하기');await self.wait('r13_map');await self.press('수리점');await self.advance();await self.wait('r13_hub');await self.shot('10-workshop-hub')
  await self.npc('buri');await self.shot('11-buri-interaction');await self.press('대화하기');await self.wait('r13_topics');await self.shot('12-buri-topics')
  await self.press('마차 수리를 부탁한다');await self.advance();await self.wait('r13_topics');await self.shot('12b-buri-read-topic');self.events.append('Buri selected question plays real dialogue and returns as read')
  before=(await self.state())['room'];await self.press('자료 제시하기');await self.wait('r13_book');await self.shot('13-buri-present');await self.press('제시 취소');await self.advance();assert (await self.state())['room']==before
  assert 'r13_topics' in (await self.state())['screens']
  self.events.append('Buri topics present cancel returns to topics without disclosure or time cost')
  st=await self.state()
  if 'r13_topics'in st['screens']:await self.press('돌아가기');await self.wait('r13_interaction')
  await self.p.set_viewport_size({'width':844,'height':390});self.touch=True;await asyncio.sleep(.7);await self.shot('14-mobile-interaction')
  await self.press('대화하기');await self.wait('r13_topics');await self.shot('15-mobile-topics');await self.press('돌아가기');await self.wait('r13_interaction')
  before=(await self.state())['room'];await self.press('제시하기');await self.wait('r13_book');await self.shot('16-mobile-present');await self.press('제시 취소');await self.advance();assert (await self.state())['room']==before
  assert 'r13_interaction' in (await self.state())['screens']
  self.events.append('Mobile interaction present cancel returns to interaction without disclosure or time cost')
  if 'r13_topics' in (await self.state())['screens']:await self.press('돌아가기');await self.wait('r13_interaction')
  await self.press('돌아가기');await self.advance();await self.wait('r13_hub');await self.shot('17-mobile-hub')
  await self.cancel_unchanged('현장 활동','r13_activities','돌아가기')
  await self.press('설정');await self.wait('pause_menu');await self.shot('18-mobile-settings');a=(await self.info())['fast'];await self.press('읽은 대사 빠르게');assert (await self.info())['fast']!=a;await self.press('읽은 대사 빠르게');await self.press('돌아가기');await self.wait('r13_hub')
  self.events.append('844x390 real touchscreen topics/present/cancel/settings working')
  return {'status':'passed','checks':self.events,'seen_speakers':sorted(self.seen),'info':await self.info()}
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',default='http://127.0.0.1:8093/preview/room13-candidate/');ap.add_argument('--out',default='qa-room13-0122/ui-browser');ap.add_argument('--gate-only',action='store_true');args=ap.parse_args();out=ROOT/args.out;out.mkdir(parents=True,exist_ok=True)
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True);pg=await c.new_page();errors=[];bad=[]
  pg.on('pageerror',lambda e:errors.append(str(e)));pg.on('response',lambda r:bad.append([r.status,r.url]) if r.status>=400 and 'favicon'not in r.url else None)
  q=QA(pg,out)
  try:
   await pg.goto(args.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);report=await (q.gate_only() if args.gate_only else q.run());assert not errors,errors;assert not bad,bad
  except Exception as e:
   await pg.screenshot(path=str(out/'failure.png'));report={'status':'failed','error':repr(e),'checks':q.events}
  report.update(errors=errors,http_errors=bad,url=args.url);(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
