"""Actual rendered world timelines in dense state fixtures; no source-art edits."""
import argparse,asyncio,json,shutil
import numpy as np
from PIL import Image
from playwright.async_api import async_playwright
from pixel_qa_flow0150 import FlowQA,ROOT
SELECT='''import renpy,copy
s=renpy.store;original=copy.deepcopy(s.room13);selected=[]
try:
 for location in ('gate','school','square'):
  best=None
  for day in range(1,14):
   for period in range(4):
    state=copy.deepcopy(original);state.update(day=day,period=period,location=location,victim_state='alive',granny_state='trusted',daram_state='rescued',case_state='prevented');state['flags']=list(set(state['flags']+['shelter_ready','patient_transport','nubi_protected','bami_protected','mom_reunited']))
    s.room13=state;actors=s.r13_stage_people()
    if best is None or len(actors)>len(best['actors']):best={'location':location,'state':state,'actors':actors}
  selected.append(best)
finally:s.room13=original
result=selected
'''
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',default='qa-room13-0152/motion/world');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True);report={'kind':'archive-engine-with-explicit-world-state-fixtures-original-global-clock-no-source-injection','scenes':[]};errors=[]
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},service_workers='block');pg=await c.new_page();pg.on('pageerror',lambda e:errors.append(str(e)));q=FlowQA(pg,out)
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub');selected=await q.py(SELECT)
   for row in selected:
    location=row['location'];await q.py("import renpy\ns=renpy.store\ns.room13="+ascii(row['state'])+"\ns.place=s.R13_PLACES[s.room13['location']][0]\ns.persistent.room13_motion=True\nrenpy.exports.hide_screen('r13_hub')\nrenpy.exports.hide_screen('say')\nrenpy.exports.scene()\nrenpy.exports.show('qa_motion_world',what=s.r13_background(s.R13_PLACES[s.room13['location']][1]))\nrenpy.exports.show_screen('r13_hub',entry=False)\nrenpy.exports.show_screen('r13_hud')\nrenpy.exports.restart_interaction()\nresult=True");await q.wait('r13_hub');await asyncio.sleep(.5)
    frames=[]
    for i in range(12):
     await asyncio.sleep(.4);path=out/(location+'-on-%02d.png'%i);await pg.screenshot(path=str(path));frames.append(np.asarray(Image.open(path).convert('RGB')))
    actors=[]
    for actor in row['actors']:
     x,y,w,h=actor['rect'];n=max(int(np.any(f[y:y+h,x:x+w]!=frames[0][y:y+h,x:x+w],axis=2).sum())for f in frames[1:]);actors.append({'person':actor['person'],'pose':actor['pose'],'changed_pixels':n,'rect':actor['rect']})
    assert any(r['changed_pixels']>10 for r in actors),(location,'no actual actor motion')
    await q.py('import renpy;s=renpy.store;s.persistent.room13_motion=False;renpy.exports.restart_interaction();result=True');await asyncio.sleep(.5);off0=out/(location+'-off-0.png');await pg.screenshot(path=str(off0));await asyncio.sleep(1.6);off1=out/(location+'-off-1.png');await pg.screenshot(path=str(off1));a0=np.asarray(Image.open(off0));a1=np.asarray(Image.open(off1));off=[]
    for actor in row['actors']:
     x,y,w,h=actor['rect'];n=int(np.any(a0[y:y+h,x:x+w]!=a1[y:y+h,x:x+w],axis=2).sum());off.append({'person':actor['person'],'changed_pixels':n});assert n==0,(location,actor['person'],'OFF moved',n)
    # ON resumes an already-visible cast, not only a newly replaced sprite.
    await q.py('import renpy;s=renpy.store;s.persistent.room13_motion=True;renpy.exports.restart_interaction();result=True');await asyncio.sleep(.5);r0=out/(location+'-resumed-0.png');await pg.screenshot(path=str(r0));await asyncio.sleep(2.5);r1=out/(location+'-resumed-1.png');await pg.screenshot(path=str(r1));ra=np.asarray(Image.open(r0));rb=np.asarray(Image.open(r1));resumed=sum(int(np.any(ra[y:y+h,x:x+w]!=rb[y:y+h,x:x+w],axis=2).sum())for x,y,w,h in [act['rect']for act in row['actors']]);assert resumed>10,(location,'ON did not resume')
    report['scenes'].append({'location':location,'day':row['state']['day'],'period':row['state']['period'],'actor_count':len(actors),'actors':actors,'off':off,'resumed_changed_pixels':resumed});print('WORLD',location,len(actors),'actors',sum(r['changed_pixels']for r in actors),'moving pixels',flush=True)
   assert not errors,errors;report['status']='passed'
  except Exception as e:report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
  report.update(url=a.url,errors=errors);(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
