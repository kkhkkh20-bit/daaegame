"""Browser contact sheets from untouched engine staging screenshots."""
import asyncio,json,argparse
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--source',default='qa-room13-0140/staging-final');args=ap.parse_args();base=ROOT/args.source
async def main():
 data=json.loads((base/'report.json').read_text())['render']['shots']
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',args=['--no-sandbox']);page=await b.new_page(viewport={'width':1600,'height':1000})
  for n in range(0,len(data),12):
   html='<style>body{margin:0;background:#15232a;color:white;font:16px sans-serif}main{display:grid;grid-template-columns:repeat(3,1fr)}figure{margin:3px}img{width:100%}</style><main>'
   for x in data[n:n+12]:html+='<figure><img src="'+x['file']+'"><figcaption>'+x['file']+'</figcaption></figure>'
   stem='contact-stage-'+str(n//12);path=base/(stem+'.html');path.write_text(html+'</main>');await page.goto('http://127.0.0.1:8094/'+str(path.relative_to('/workspace')));await page.wait_for_function('Array.from(document.images).every(i=>i.complete&&i.naturalWidth)');await page.screenshot(path=str(base/(stem+'.png')),full_page=True)
  await b.close()
asyncio.run(main())
