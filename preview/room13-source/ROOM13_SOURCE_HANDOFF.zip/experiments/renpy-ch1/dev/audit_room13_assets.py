"""Only prune excluded generated painted copies with byte-identical art originals."""
import argparse, hashlib, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--apply',action='store_true');args=ap.parse_args()
 rows=[]
 for p in sorted((ROOT/'game/assets').glob('room13-painted-*')):
  original=ROOT/'art'/p.name
  excluded=p.suffix=='.png' or p.name=='room13-painted-layouts.json'
  if excluded and original.is_file() and digest(p)==digest(original):
   rows.append(dict(path=str(p.relative_to(ROOT)),source=str(original.relative_to(ROOT)),bytes=p.stat().st_size,sha256=digest(p)))
   if args.apply:p.unlink()
 report=dict(applied=args.apply,bytes=sum(x['bytes'] for x in rows),files=rows,
   preserved='Source artwork, dynamic manifests, active pixel assets and historical QA are not deleted.')
 (ROOT/'dev/reports/asset-cleanup.json').write_text(json.dumps(report,indent=2))
 print(json.dumps({'applied':args.apply,'files':len(rows),'bytes':report['bytes']}))
if __name__=='__main__':main()
