"""Final wording smoke on the merged archive; earlier functional routes kept separately."""
import asyncio,json,shutil,urllib.request
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_ui0156 import UIQA
OUT=Path('qa-room13-learning');URL='http://127.0.0.1:8094/room13-release-0173/'
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},service_workers='block');pg=await c.new_page();q=UIQA(pg,OUT)
  await pg.goto(URL);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu')
  fixture=json.loads((OUT/'day2-fixture.json').read_text())['room'];fixture['evidence']=list(dict.fromkeys(fixture['evidence']+['J01']))
  await q.py('import renpy;s=renpy.store;s.room13='+repr(fixture)+';s.room13_mode=True;s.winter_mode=True;s.winter=s.winter_new();s.source_mode=False;s.typing_allowed=True;s.r13_scene_key=None;s.r13_world_cameras={};result=True')
  await q.py('import renpy\ns=renpy.store\nfor f in renpy.display.focus.focus_list:\n w=f.widget\n if isinstance(getattr(w,"action",None),s.Start):\n  w.action=s.Start("r13_roam");w.clicked=w.action\nresult=True')
  await q.press('처음부터');await q.wait('r13_hub');await q.press('기록');await q.wait('r13_records');await q.press('들은 말');await asyncio.sleep(1)
  state=await q.state();assert any('말한 사람: 나비' in r['text'] for r in state['buttons']),state
  await q.shot('10-final-testimony-source');await q.press('닫기');await q.wait('r13_hub')
  report=json.loads((OUT/'report.json').read_text());report.setdefault('functional_archive_sha256',report['archive_sha256']);report['archive_sha256']=json.load(urllib.request.urlopen(URL+'game-transport.json'))['archive_sha256'];report['checks'].append('Final merged wording smoke: testimony source is explicitly the speaker, found/heard tabs and archive visibility render correctly');report['status']='passed';report['visual_review']='Desktop roles/questions/work preview and mobile large-text notes/records reviewed; final testimony source viewed';(OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('FINAL SMOKE PASSED',flush=True);await b.close()
asyncio.run(main())
