"""Title acceptance through real clicks, keyboard and touch, with natural saves."""
import asyncio,json,shutil
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_ui0156 import UIQA
OUT=Path('/workspace/work/daram-title/qa');OUT.mkdir(exist_ok=True)
URL='http://127.0.0.1:8095/release/'
async def main():
 report={'checks':[]};errors=[]
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();pg.on('pageerror',lambda e:errors.append(str(e)));q=UIQA(pg,OUT)
  async def fit():
   for btn in (await q.state())['buttons']:
    x,y,w,h=btn['rect'];assert 0<=x and 0<=y and x+w<=1281 and y+h<=721,btn
  async def title():
   await asyncio.sleep(1);await q.press('옵션');await q.wait('pause_menu');await q.press('처음 화면');await q.wait('confirm');await q.press('예');await q.wait('main_menu')
  try:
   await pg.goto(URL);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=180000);await q.wait('main_menu');assert await q.py('import renpy;result=renpy.store.config.version')=='0.17.21-dev';await fit();await q.shot('01-title-desktop');st=await q.state();assert not any('이어하기' in x['text'] for x in st['buttons']);report['checks'].append('Fresh title: no active Continue/Load without a save; new art loads and every active button stays in bounds')
   # Default focus belongs to New Game; downward navigation skips unavailable Load.
   await pg.mouse.move(1270,10);await pg.keyboard.press('ArrowDown');await pg.keyboard.press('Enter');await q.wait('pause_menu');report['checks'].append('Keyboard ArrowDown/Enter opens settings from the fresh title')
   await q.press('화면');await q.press('켜짐');flag=await q.py('import renpy;result=renpy.store.persistent.room13_motion');assert flag==False;await q.press('돌아가기');await q.wait('main_menu');await q.shot('02-title-still');await pg.reload();await q.wait('main_menu');assert await q.py('import renpy;result=renpy.store.persistent.room13_motion')==False;report['checks'].append('Motion off persists across reload and disables title snowfall')
   for size,name in [({'width':844,'height':390},'03-title-mobile'),({'width':640,'height':360},'04-title-compact')]:
    await pg.set_viewport_size(size);q.touch=True;await asyncio.sleep(.5);await fit();await q.shot(name)
   await q.press('설정');await q.wait('pause_menu');await q.press('게임');await q.press('즉시');await q.press('돌아가기');await q.wait('main_menu');await q.press('처음부터');await q.advance();await q.wait('r13_hub');await q.shot('05-natural-game-entry');state=await q.room();await asyncio.sleep(1);await q.save(1);assert await q.room()==state;await title();await q.shot('06-title-saved-mobile');st=await q.state();assert any('이어하기' in x['text'] for x in st['buttons']);await q.press('이어하기');await q.wait('r13_hub');assert await q.room()==state;report['checks'].append('Real compact-screen touch: settings, New Game, natural save, return to title and Continue preserve the exact campaign state')
   await title();await pg.set_viewport_size({'width':1280,'height':720});q.touch=False;await q.shot('07-title-saved-desktop');await q.press('불러오기');await q.wait('load');await q.press('1쪽 1번');await q.wait('r13_hub');assert await q.room()==state;report['checks'].append('Load from the redesigned title restores the exact naturally saved campaign')
   assert not errors,errors;report['status']='passed'
  except Exception as e:
   report.update(status='failed',error=repr(e));await pg.screenshot(path=str(OUT/'failure.png'))
   try:(OUT/'failure-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
   except:pass
  report['errors']=errors;(OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']=='failed':raise SystemExit(1)
asyncio.run(main())
