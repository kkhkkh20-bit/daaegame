"""Fresh browser natural interactions, then explicitly injected meeting/save fixtures."""
import asyncio,json,shutil,sys
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_ui0156 import UIQA
from pixel_qa_flow0150 import FLOW_PROBE
OUT=Path('/workspace/room13-review/ui0171');OUT.mkdir(exist_ok=True)
URL='http://127.0.0.1:8094/room13-dev/'
class Q(UIQA):
 async def state(self):
  probe=FLOW_PROBE.replace('names=[',"names=['r13_records','r13_backlog','r13_debate_board','r13_save_cleanup','r13_save_review',")
  s=await self.py('ns={};exec('+ascii(probe)+',ns);result=ns["result"]');assert '_exception' not in s['screens'],s;return s
 async def advance(self):
  for _ in range(220):
   s=await self.state()
   if 'r13_arrival_card' in s['screens']:await self.input(800,400);continue
   if 'r13_cinematic_view' in s['screens']:await self.press('계속');continue
   if any(k in s['screens'] for k in ('r13_debate_board','choice','r13_hub','r13_book','r13_confirm','r13_topics','r13_entry_topics','r13_entry_karo_topics','r13_object_context','r13_map')):return s
   if 'say' in s['screens']:await self.input(810,610)
   else:await asyncio.sleep(.15)
  raise AssertionError(s)
async def main():
 report={'checks':[],'fixture_note':'Meeting and legacy-save cases below are injected; natural route is separate.'}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader'])
  c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=Q(pg,OUT)
  try:
   await pg.goto(URL);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu')
   assert await q.py('import renpy;result=renpy.store.r13_continue_slot()') is None
   await q.shot('01-title-no-save');await q.press('설정');await q.wait('pause_menu');await q.shot('02-options');await q.press('돌아가기');await q.wait('main_menu')
   await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.wait('say')
   first=await q.line();await q.press('읽은 대사만');await asyncio.sleep(1);assert (await q.line())['index']==first['index']
   await q.press('읽은 대사만');await q.shot('03-dialogue-profile');await q.advance();await q.wait('r13_hub');await q.shot('04-investigation')
   await q.value(('person','karo'));await q.advance();await q.wait('r13_topics');await q.shot('05-resident-topics')
   keys=await q.py('import renpy;result=[k for k,t in renpy.store.r13_topics("karo")]');assert 'life:karo:work' in keys,keys
   await q.value('life:karo:work');await q.advance();await q.wait('r13_topics')
   assert await q.py('import renpy;s=renpy.store;result=s.r13_calendar_topic_seen("life:karo:work",s.ROOM13["topics"]["life:karo:work"])')
   await q.shot('05b-read-question-retained');repeated=await q.room();await q.value('life:karo:work');await q.advance();await q.wait('r13_topics')
   for field in ('day','period','evidence','flags','propositions'):assert (await q.room())[field]==repeated[field]
   before=await q.room();report['checks'].append('Natural first-day Karo work question survives the guided-flow filter and remains checked/clickable after reading; replay spends no time or evidence')
   await q.press('보여주기');await q.wait('r13_book');await q.shot('06-presentation-unselected')
   # Click the disabled submit hit area; it must remain in the book.
   await q.input(1000,634);await q.wait('r13_book')
   await q.press('초대 편지');await q.shot('07-presentation-selected')
   await q.press('그만두기');await q.wait('r13_topics');after=await q.room()
   assert {k:v for k,v in before.items() if k!='record_ui'}=={k:v for k,v in after.items() if k!='record_ui'}
   await q.press('보여주기');await q.wait('r13_book');await q.press('초대 편지');await q.press('까로에게 보여주기');await q.advance()
   if 'r13_confirm' in (await q.state())['screens']:await q.press('보여준다');await q.advance()
   await q.wait('r13_topics');await q.press('돌아가기');await q.advance();await q.wait('r13_hub')
   report['checks'].append('Natural: no-save title, options, unread skip stops, profile dialogue, investigation, resident topic, explicit selection, disabled submit, cancel, actual presentation')
   await q.save(1);saved=await q.room();await q.load(1);assert await q.room()==saved
   meta=await q.py('import renpy;result=renpy.loadsave.slot_json("1-1")');report['save_metadata']=meta;assert meta['r13_contract']==1
   await q.press('옵션');await q.wait('pause_menu');await q.press('처음 화면');await q.wait('main_menu');await q.shot('08-title-compatible-save');await q.press('이어하기');await q.wait('r13_hub');assert await q.room()==saved
   report['checks'].append('Natural: save/load/Continue retains exact state; save metadata identifies campaign/story/visual contract')
   # Explicit render fixture: actual say screen and production text tokenizer.
   await q.py("""import renpy
s=renpy.store
s.r13_packet=("karo", "")
line="까로에게 초대 편지를 보여주자. " + s.R13_PLACES[s.room13["location"]][0] + "에서 살펴보자."
def show_line(renpy=renpy,line=line):
 renpy.exports.invoke_in_new_context(renpy.exports.say,"까로",line)
w=renpy.exports.get_widget("r13_hub","r13_options_gear")
w.action=s.Function(show_line)
w.clicked=w.action
result={"line":line,"markup":s.r13_semantic_text(line)}""")
   await q.input(1220,50);await q.wait('say');await q.shot('08b-semantic-render-fixture');await q.input(800,610);await q.wait('r13_hub')
   report['checks'].append('Explicit display fixture: production say screen renders known person/place/owned evidence with gold/teal/coral bold markup')
   # Inject owned evidence and a real call action solely in this fresh test browser.
   await q.py('import renpy;s=renpy.store;s.r13_edit(day=7,period=1,case_state="occurred",location="dining");s.r13_grant(["E06","E07","E09"],"QA fixture");renpy.exports.hide_screen("r13_evidence_found");result=True')
   await q.py("""import renpy
s=renpy.store
def enter(renpy=renpy):
 renpy.exports.call_in_new_context("r13_debate_run","C2")
w=renpy.exports.get_widget("r13_hub","r13_options_gear")
w.action=s.Function(enter)
w.clicked=w.action
result=True""")
   await q.input(1220,50);await q.wait('r13_debate_board');await q.shot('09-meeting-speaker')
   await q.press('자료로 반박');await q.wait('r13_book');await q.press('그만두기');await q.wait('r13_debate_board')
   assert await q.py('import renpy;result=renpy.store.r13_debate_selected')=='s1'
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True
   await q.py('import renpy;renpy.store.persistent.room13_large_text=True;renpy.exports.restart_interaction();result=True');await q.shot('10-meeting-mobile-large')
   await pg.set_viewport_size({'width':1280,'height':720});q.touch=False
   for st,key,tab in [('s1','E06','들은 말'),('s2','E07','증거'),('s3','E09','증거')]:
    await q.value(('select',st));await q.wait('r13_debate_board');await q.press('자료로 반박');await q.wait('r13_book')
    category=await q.py('import renpy;result=renpy.store.r13_record_category('+repr(key)+')');await q.press('들은 말' if category=='testimony' else '증거')
    await q.press(await q.py('import renpy;result=renpy.store.R13_RECORD_SHORT.get('+repr(key)+',renpy.store.ROOM13["evidence"]['+repr(key)+']["name"])'))
    await q.press('이 주장에 근거로');await q.advance();await q.wait('r13_debate_board')
   assert await q.py('import renpy;result=renpy.store.r13_debate_ready("C2")')
   await q.press('결론을 말한다');await q.wait('choice');await q.press('아이는 팔을');await q.advance()
   assert 'C2' in (await q.room())['propositions'];report['checks'].append('Injected meeting: C2 actual UI cancel returns same statement, three evidence rebuttals and correct conclusion still prove C2; large-text mobile speaker view')
   report['status']='passed'
  except Exception as e:
   report.update(status='failed',error=repr(e));await pg.screenshot(path=str(OUT/'failure.png'))
   try:(OUT/'failure-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
   except:pass
  (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']=='failed':raise SystemExit(1)
asyncio.run(main())
