"""Explicit source+art injection for context pose contacts before integration build."""
import asyncio,json,shutil,textwrap,base64,argparse
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_flow0150 import FlowQA,ROOT
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);a=ap.parse_args();out=ROOT/'qa-room13-0156/world-context/engine';out.mkdir(parents=True,exist_ok=True);report={'kind':'explicit-source-and-art-injection-not-final-archive','shots':[]}
 src=(ROOT/'game/room13_acting.rpy').read_text();stage=textwrap.dedent(src[src.index('    class R13FurnitureMask('):src.index('    def r13_staged_art(')])
 src=(ROOT/'game/room13_life.rpy').read_text();life=textwrap.dedent(src[src.index('    R13_WEEKLY_ROUTINES ='):src.index('    def r13_activity_text')]);layouts=json.loads((ROOT/'art/pixel-b/panorama/world-layout.json').read_text());poses=json.loads((ROOT/'art/pixel-b/acting/world-context.json').read_text())
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);pg=await b.new_page(viewport={'width':1280,'height':720});q=FlowQA(pg,out)
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;s=renpy.store;s.preferences.text_cps=0;s.persistent.room13_motion=False;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub')
   data=base64.b64encode((ROOT/'art/pixel-b/acting/room13-pixel-world-context0156.png').read_bytes()).decode();await q.py('import renpy,base64;p=renpy.store.config.gamedir+"/assets/qa-world-context0156.png";open(p,"wb").write(base64.b64decode('+repr(data)+'));result=True')
   for person,variants in poses.items():
    for spec in variants.values():spec['file']='assets/qa-world-context0156.png'
   await q.py('import renpy\ns=renpy.store\nexec('+ascii(stage+'\n'+life)+',s.__dict__)\ns.R13_WORLD_LAYOUTS='+ascii(layouts)+'\nfor p,variants in '+ascii(poses)+'.items():s.R13_ACTING[p].update(variants)\nresult=True')
   for loc,period,offset in [('square',0,0),('square',0,640),('inn',1,640),('inn',2,640)]:
    code='''import renpy
s=renpy.store
s.room13=dict(s.room13,location=%r,day=1,period=%d,flags=['lodging','entry_corrected'])
s.place=s.R13_PLACES[s.room13['location']][0]
s.r13_world_cameras={s.room13['location']:%d}
renpy.exports.scene()
renpy.exports.hide_screen('r13_hub')
renpy.exports.show_screen('r13_hub',entry=False)
renpy.exports.restart_interaction()
result={'actors':s.r13_stage_people(),'people':s.r13_people()}
'''%(loc,period,offset)
    row=await q.py(code);await asyncio.sleep(.7);name=f'{loc}-p{period}-x{offset}';await q.shot(name);report['shots'].append({'file':name+'.png',**row});print('POSE',name,flush=True)
   report['status']='captured-review-pending'
  except Exception as e:report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
  finally:await b.close();(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(report['status'],report.get('error'),flush=True)
asyncio.run(main())
