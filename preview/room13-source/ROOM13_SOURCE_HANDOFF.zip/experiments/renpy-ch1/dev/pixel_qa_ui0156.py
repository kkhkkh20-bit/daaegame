"""Natural 0.15.6 merge and compact UI regression, one browser and no story injection."""
import argparse,asyncio,json,shutil,urllib.request
from playwright.async_api import async_playwright
from pixel_qa_say_records0155 import SayQA,ROOT
from pixel_qa_flow0150 import FLOW_PROBE
class UIQA(SayQA):
 async def state(self):
  probe=FLOW_PROBE.replace('names=[',"names=['r13_resident_approach','r13_gate_document_inspection','r13_records',")
  st=await self.py('ns={};exec('+ascii(probe)+',ns);result=ns["result"]');assert '_exception'not in st['screens'],st;return st
 async def advance(self):
  for _ in range(350):
   st=await self.state()
   if 'r13_arrival_card'in st['screens']:await self.input(800,400);continue
   if 'r13_cinematic_view'in st['screens']:await self.press('계속');continue
   if any(n in st['screens']for n in ('r13_resident_approach','choice','r13_hub','r13_book','r13_confirm','r13_topics','r13_entry_topics','r13_entry_karo_topics','r13_object_context','r13_map')):await asyncio.sleep(.5);return await self.state()
   if 'say'in st['screens']:await self.input(810,610)
   else:await asyncio.sleep(.15)
  raise AssertionError(st)
 async def camera(self):return await self.py('import renpy;s=renpy.store;result={"offset":s.r13_world_offset(),"cameras":s.r13_world_cameras,"width":s.r13_world_width()}')
 async def options_cancel(self):
  before=await self.room();cam=await self.camera();await self.press('옵션');await self.wait('pause_menu');await self.press('돌아가기');assert await self.room()==before and await self.camera()==cam
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',default='qa-room13-0156/ui-natural');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True);report={'archive_sha256':json.load(urllib.request.urlopen(a.url+'game-transport.json'))['archive_sha256'],'kind':'natural-entry-merged-dialogue-save-and-resident-approach-PC-mobile','checks':[]}
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=UIQA(pg,out);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub');await q.shot('01-entry-three-cells-gear');await q.options_cancel();await q.wait('r13_hub');await q.docs();await q.value(('record','G1'));await q.wait('r13_gate_document_inspection');await q.value(('record','G3'));await q.wait('r13_gate_document_inspection');await q.press('닫기');await q.wait('r13_hub');assert 'gate_documents_compared'not in(await q.room())['flags'];await q.present();r=await q.room();assert 'gate_registration_acknowledged'in r['flags'] and 'entry_corrected'not in r['flags'] and 'G2'not in r['evidence'];await q.shot('02-partial-registration-after-merge');await q.press('다른 자료');await q.advance();await q.wait('r13_entry_topics');await q.press('돌아가기');await q.wait('r13_hub');report['checks'].append('Merged dialogue retains partial evidence recognition and no automatic comparison flag')
   await q.press('까로');await q.wait('r13_entry_karo_topics');await q.shot('03-explicit-topic-return');await q.options_cancel();await q.value('road');await q.wait('say');first=await q.line();assert first['index']==0 and first['speaker']=='dad';await q.input(810,610);await q.wait('say');assert(await q.line())['speaker']=='karo';report['checks'].append(await q.favorite_during_line('G1',1));assert(await q.line())['speaker']=='dad';await q.shot('04-dad-target-PC');await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await asyncio.sleep(.7);await q.shot('05-dad-target-mobile');await q.options_cancel();await q.wait('say');await pg.set_viewport_size({'width':1280,'height':720});q.touch=False;await asyncio.sleep(.7);report['checks'].append(await q.favorite_during_line('G3',2));assert(await q.line())['speaker']=='karo';report['checks'].append(await q.favorite_during_line('E01',3,advance=False));await q.advance();await q.wait('r13_entry_karo_topics');await q.press('돌아가기');await q.wait('r13_hub');report['checks'].append('New four-line road topic uses dad0/karo1/dad2/karo3; exact immediate save/load at1/2/3; final topic return works')
   await q.input(390,321);await q.advance();await q.wait('r13_hub');assert'G2'in(await q.room())['evidence'];await q.present();await q.press('원본에는 두 명');await q.advance();await q.wait('r13_hub');assert'entry_corrected'in(await q.room())['flags'];await q.travel('광장');await q.shot('06-square-no-panbar');people=await q.py('import renpy;result=renpy.store.r13_people()');report['square_people']=people;assert'resident_piko'in people,people
   # Piko's first notice is natural story text; cancel-state contract starts at the approach choice.
   await q.press('피코');await q.advance();await q.wait('r13_resident_approach');before=await q.room();cam=await q.camera();assert not any(e['person']=='resident_piko'for e in before['encounters']);await q.shot('07-piko-approach-PC');await q.options_cancel();await q.press('돌아가기');await q.wait('r13_hub');assert await q.room()==before and await q.camera()==cam;await q.press('피코');await q.advance();await q.wait('r13_resident_approach');await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await asyncio.sleep(.7);await q.shot('08-piko-approach-mobile');before=await q.room();cam=await q.camera();await q.press('지금은 말을');await q.wait('r13_hub');assert await q.room()==before and await q.camera()==cam
   await q.press('피코');await q.advance();await q.wait('r13_resident_approach');await q.value(True);await q.advance();await q.wait('r13_topics');assert any(e['person']=='resident_piko'for e in(await q.room())['encounters']);await q.shot('09-piko-topics-mobile');await q.options_cancel();before=await q.room();cam=await q.camera();await q.press('돌아가기');await q.wait('r13_hub');assert await q.room()==before and await q.camera()==cam;await q.shot('10-mobile-field-small-bar');report['checks'].append('Piko approach large actor; explicit return and decline both no encounter/state/camera change; accept records meeting; topics Return preserves camera; mobile gear works')
   assert not errors,errors;report['status']='passed-pending-visual-review'
  except Exception as e:report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'));(out/'failure-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
  report['errors']=errors;(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items()if k!='checks'},ensure_ascii=False));await b.close()
  if report['status']=='failed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
