"""Hold the engine request to inspect the first paint without racing startup."""
import asyncio,json,shutil
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path('/workspace/work/daram-type/qa');OUT.mkdir(exist_ok=True)
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox']);c=await b.new_context(viewport={'width':1280,'height':720},service_workers='block');pg=await c.new_page();await pg.route('**/renpy.js',lambda route:route.abort())
  await pg.goto('http://127.0.0.1:8096/release/',wait_until='domcontentloaded');await pg.evaluate('document.fonts.ready');await pg.wait_for_timeout(300)
  for size,name in [({'width':1280,'height':720},'00-loading-desktop'),({'width':844,'height':390},'00-loading-mobile')]:
   await pg.set_viewport_size(size);await pg.wait_for_timeout(200)
   r=await pg.locator('#loading-brand').bounding_box();assert r['x']>=0 and r['y']>=0 and r['x']+r['width']<=size['width'] and r['y']+r['height']<=size['height'],r
   assert await pg.locator('#presplash').evaluate('(e)=>e.complete&&e.naturalWidth>0')
   assert await pg.evaluate('document.fonts.check("20px Galmuri")')
   await pg.screenshot(path=str(OUT/(name+'.png')))
  (OUT/'loader-report.json').write_text(json.dumps({'status':'passed','checks':['First paint uses the new lossless title image and matching title font','Desktop and mobile loading brand stay in viewport'],'note':'The engine request is deliberately aborted only in this visual loading fixture.'},ensure_ascii=False,indent=2));print('Loading art/font/bounds: PASS');await b.close()
asyncio.run(main())
