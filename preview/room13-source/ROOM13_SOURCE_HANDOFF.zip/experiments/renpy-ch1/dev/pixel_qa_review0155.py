"""Fresh first-run acceptance for explicit gate comparison and record UI; no story injection."""
import argparse,asyncio,json,shutil,urllib.request
from playwright.async_api import async_playwright
from pixel_qa_gate0153 import GateQA,ROOT
class ReviewQA(GateQA):
 async def room(self):return (await self.state())['room']
 async def save(self,slot):
  await self.press('옵션');await self.wait('pause_menu');await self.press('저장');await self.wait('save');await self.press('1쪽 '+str(slot)+'번');await self.press('돌아가기')
  if 'pause_menu'in(await self.state())['screens']:await self.press('돌아가기')
  await self.wait('r13_hub')
 async def load(self,slot):
  await self.press('옵션');await self.wait('pause_menu');await self.press('불러오기');await self.wait('load');await self.press('1쪽 '+str(slot)+'번');await self.press('예');await self.wait('r13_hub')
 async def docs(self):await self.input(1128,410);await self.wait('r13_gate_document_inspection')
 async def present(self,key='G1'):
  await self.press('돌목');await self.wait('r13_entry_topics');await self.press('제시');await self.wait('r13_book');label=await self.py("import renpy;result=renpy.store.R13_RECORD_SHORT["+repr(key)+"]");await self.press(label);await self.press('돌목에게 보여주기');await self.advance();await self.wait('choice')
 async def records(self):
  return await self.py("import renpy;s=renpy.store;sc=renpy.display.screen.get_screen('r13_records');result={'order':sc.scope['order'],'entries':sc.scope['entries'],'selected':sc.scope['selected_record'],'page_size':s.r13_record_page_size(),'ui':s.room13.get('record_ui',{}),'large':s.persistent.room13_large_text}")
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',default='qa-room13-0155/review-natural');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True)
 report={'kind':'fresh-natural-first-run-gate-and-records-real-PC-mobile-input','archive_sha256':json.load(urllib.request.urlopen(a.url+'game-transport.json'))['archive_sha256'],'checks':[]}
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=ReviewQA(pg,out);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub');await q.shot('01-fresh-entry')
   await q.docs();await q.value(('record','G1'));await q.wait('r13_gate_document_inspection');await q.press('닫기');await q.wait('r13_hub');r=await q.room();assert 'G1'in r['evidence'] and 'G2'not in r['evidence'] and 'G3'not in r['evidence'];assert 'gate_documents_compared'not in r['flags']
   await q.present();r=await q.room();assert 'gate_registration_acknowledged'in r['flags'];assert 'entry_corrected'not in r['flags'];await q.shot('02-G1-only-partial-recognition');assert not any('원본에는 두 명'in x['text']for x in(await q.state())['buttons']);await q.press('다른 자료');await q.advance();await q.wait('r13_entry_topics');await q.press('조사');await q.wait('r13_hub');report['checks'].append('G1 alone receives partial registration acknowledgement and bulletin hint, no entry success')
   await q.docs();await q.value(('record','G3'));await q.wait('r13_gate_document_inspection');await q.press('닫기');await q.wait('r13_hub');assert 'gate_documents_compared'not in(await q.room())['flags'];await q.save(1)
   await q.present();assert 'G2'not in(await q.room())['evidence'];await q.shot('03-two-records-no-rules-partial');await q.press('다른 자료');await q.advance();await q.wait('r13_entry_topics');await q.press('조사');await q.wait('r13_hub');assert 'gate_documents_compared'not in(await q.room())['flags'];report['checks'].append('G1+G3 ownership and presentation do not auto-mark explicit comparison')
   await q.docs();await q.input(310,287);await q.input(875,357);before=await q.room();await q.press('선택한 항목');assert await q.room()==before;await q.shot('04-mismatched-fields-no-progress');await q.input(875,287);await q.press('선택한 항목');assert await q.room()==before;await q.shot('05-equal-adults-no-false-discrepancy')
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.input(310,357);await q.input(875,357);await q.press('선택한 항목');await q.wait('r13_gate_document_inspection');assert 'gate_documents_compared'in(await q.room())['flags'];await q.shot('06-mobile-explicit-child-comparison');await q.press('닫기');await q.wait('r13_hub');await pg.set_viewport_size({'width':1280,'height':720});q.touch=False;compared=await q.room();await q.save(2);await q.load(1);assert 'gate_documents_compared'not in(await q.room())['flags'];await q.load(2);assert (await q.room())==compared;report['checks'].append('Mobile child comparison flags only on explicit matched comparison; immediate save/load preserves it')
   # Same-period acquisition ordering and UI-only favorite changes on naturally obtained evidence.
   before=await q.room();await q.press('기록');await q.wait('r13_records');rec=await q.records();assert rec['order']=='recent' and rec['entries']==list(reversed(before['evidence'])),rec;assert rec['page_size']==12;await q.press('예약 원본');await q.press('관심 표시');favorite=await q.room();assert set(favorite)^set(before)<= {'record_ui'};assert {k:v for k,v in favorite.items()if k!='record_ui'}=={k:v for k,v in before.items()if k!='record_ui'};assert favorite['record_ui']['favorites']==['G1'];await q.press('관심 자료만');rec=await q.records();assert rec['entries']==['G1'];await q.shot('07-favorites-filter-read-mark');await q.press('닫기');await q.wait('r13_hub');await q.save(3)
   await q.press('기록');await q.wait('r13_records');await q.press('예약 원본');await q.press('관심 해제');await q.press('닫기');await q.wait('r13_hub');assert 'G1'not in(await q.room())['record_ui']['favorites'];await q.load(3);assert await q.room()==favorite;report['checks'].append({'same_period_recent_entries':list(reversed(before['evidence'])),'favorite_immediate_save_load':True,'only_record_ui_mutated':True})
   await q.input(390,321);await q.advance();await q.wait('r13_hub');assert 'G2'in(await q.room())['evidence'];await q.present();await q.shot('08-rules-enable-correct-reason');await q.press('원본에는 두 명');await q.advance();await q.wait('r13_hub');r=await q.room();assert 'entry_corrected'in r['flags'] and r['period']==1;report['checks'].append('Reading G2 after partial feedback unlocks correct argument without time advance')
   await q.press('옵션');await q.wait('pause_menu');await q.press('큰 글씨');await q.press('돌아가기');await q.wait('r13_hub');await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.shot('09-mobile-large-hud');before=await q.room();await q.press('기록');await q.wait('r13_records');rec=await q.records();assert rec['large'] and rec['page_size']==8;await q.shot('10-mobile-large-records');await q.press('예약 원본');await q.shot('11-mobile-large-record-detail');assert {k:v for k,v in(await q.room()).items()if k!='record_ui'}=={k:v for k,v in before.items()if k!='record_ui'};report['checks'].append({'large_mobile':rec,'first_run_story_injection':False})
   assert not errors,errors;report['status']='passed-pending-visual-review'
  except Exception as e:report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'));(out/'failure-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
  report.update(url=a.url,errors=errors);(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']=='failed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
