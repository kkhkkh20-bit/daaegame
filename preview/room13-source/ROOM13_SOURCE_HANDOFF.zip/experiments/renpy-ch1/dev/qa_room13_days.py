async def waitscreen(name):
 for _ in range(120):
  s=await state()
  if name in s['screens']:
   await asyncio.sleep(.45);return await state()
  await asyncio.sleep(.15)
 raise AssertionError(('screen',name,s))
async def press(label):
 await asyncio.sleep(.45);s=await state()
 matches=[b for b in s['buttons'] if label in b['text'] and b['rect'][3]>15]; b=min(matches,key=lambda b:b['rect'][2]*b['rect'][3]) if matches else None
 assert b,(label,s)
 x,y,w,h=b['rect'];await click(x+w/2,y+h/2)
async def advance():
 for _ in range(250):
  s=await state()
  if any(x in s['screens'] for x in ['choice','r13_hub','r13_book','r13_confirm','r13_interaction','r13_topics','r13_debate','r13_handoff']):
   await asyncio.sleep(.45);return await state()
  if 'say'in s['screens']:await click(810,640)
  else:await asyncio.sleep(.2)
 raise AssertionError(s)
async def shot(n):await page.screenshot(path=str(OUT/(n+'.png')))
async def move(label):
 await press('이동하기');await waitscreen('r13_map');await press(label);return await advance()
async def run():
 await press('1쪽 1번');await press('돌아가기');await advance()
 for day in range(1,4):
  await press('여관에서 밤 보내기');await waitscreen('r13_confirm');await press('진행한다');s=await advance()
  if 'choice'in s['screens']:
   await press('현관을 살핀다');s=await advance()
  assert s['room']['day']==day+1
  await shot('day%d-morning'%(day+1))
 await press('여관에서 밤 보내기');await waitscreen('r13_confirm');await press('진행한다');await advance()
 await press('까로와 반송품');await advance();await shot('10-rescue-choice')
 await press('아이를 안고 너울');await advance();await shot('11-case-after')
 for day in (4,5,6):
  await press('여관에서 밤 보내기');await waitscreen('r13_confirm');await press('진행한다');await advance()
 await shot('12-trial');return await state()
