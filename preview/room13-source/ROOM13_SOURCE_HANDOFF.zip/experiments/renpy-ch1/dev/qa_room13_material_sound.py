"""Focused Ren'Py engine fixture for the presentation-card sound lifecycle.

Runs on an already built candidate. This is not a fresh story walkthrough;
show/replace/hide and preference changes deliberately exercise actual screen
events while WebAudio output is sampled without modifying its audio path.
"""
import argparse
import asyncio
import json
from pathlib import Path
import shutil
import sys
import wave

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from qa_web import AUDIO_PROBE


async def main(args):
    from playwright.async_api import async_playwright

    output = Path(args.output)
    output.mkdir(parents=True, exist_ok=True)
    report = {"kind": "targeted-engine-fixture-not-story-walkthrough", "url": args.url}
    with wave.open(str(ROOT / "game/assets/source-page.wav")) as source:
        report["asset"] = {"path": "assets/source-page.wav", "seconds": source.getnframes() / source.getframerate()}
    with wave.open(str(ROOT / "game/assets/source-found.wav")) as found:
        report["acquisition_seconds"] = found.getnframes() / found.getframerate()
    assert report["asset"]["seconds"] < .25
    assert (ROOT / "game/assets/source-page.wav").read_bytes() != (ROOT / "game/assets/source-found.wav").read_bytes()
    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(executable_path=shutil.which("chromium"), args=["--no-sandbox", "--enable-unsafe-swiftshader"])
        context = await browser.new_context(viewport={"width": 1280, "height": 720}, service_workers="block")
        await context.add_init_script(AUDIO_PROBE)
        page = await context.new_page()
        errors, bad = [], []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.on("response", lambda r: bad.append([r.status, r.url]) if r.status >= 400 and "favicon" not in r.url else None)

        async def py(code):
            # Engine modules and the game's exported `renpy` facade differ.
            # Isolate imports so a fixture cannot replace that game facade.
            code = code.replace("renpy.music.", "renpy.audio.music.")
            code = code.replace("renpy.get_screen(", "renpy.display.screen.get_screen(")
            for name in ("predict_screen", "hide_screen", "show_screen", "restart_interaction"):
                code = code.replace("renpy." + name + "(", "renpy.exports." + name + "(")
            isolated = "qa_material_ns={};exec(" + repr(code) + ",qa_material_ns);result=qa_material_ns['result']"
            return await page.evaluate("code=>renpy_exec(code)", isolated)

        async def state():
            return await py('''import renpy
s=renpy.store
c=renpy.audio.audio.get_channel("scene_fx")
result={"effects":list(s.source_effect_log),"screen":bool(renpy.get_screen("r13_material_corner")),"playing":renpy.music.get_playing("scene_fx"),"mixer":c.mixer,"actual_volume":c.actual_volume,"mute":s._preferences.get_mute("sfx"),"volume":s._preferences.get_volume("sfx")}
''')

        async def capture(command):
            await page.evaluate('''window.__cardAudioSamples=[];window.__cardAudioTimer=setInterval(()=>__cardAudioSamples.push(...__probeAudio()),20)''')
            await py(command)
            await page.wait_for_timeout(750)
            signals = await page.evaluate("clearInterval(__cardAudioTimer);__cardAudioSamples")
            return max([s["rms"] for s in signals] or [0])

        try:
            await page.goto(args.url)
            await page.wait_for_function("typeof renpy_exec==='function'", timeout=120000)
            await py("import renpy;result=bool(hasattr(renpy.store,'r13_new'))")
            await page.mouse.click(12, 12)  # Real gesture unlocks browser audio.
            await py('''import renpy
s=renpy.store
s.room13=s.r13_new()
s.room13_mode=True
s.typing_allowed=False
renpy.music.stop(channel="typing")
s._preferences.set_mute("music",True)
s._preferences.set_mute("sfx",False)
s._preferences.set_volume("sfx",.8)
s.source_effect_log=[]
renpy.hide_screen("r13_material_corner")
renpy.restart_interaction()
result=True
''')
            await page.wait_for_timeout(650)

            # Prediction must never play an effect before its card appears.
            await py('import renpy;renpy.predict_screen("r13_material_corner",key="E01");result=True')
            await page.wait_for_timeout(300)
            assert (await state())["effects"] == [], await state()
            loud = await capture('import renpy;renpy.show_screen("r13_material_corner",key="E01");renpy.restart_interaction();result=True')
            first = await state()
            assert first["effects"] == ["page"] and first["screen"], first
            assert first["mixer"] == "sfx" and first["playing"] is None, first
            assert loud > 1e-6, ("No actual whoosh output", loud, first)
            await page.screenshot(path=str(output / "card-reveal.png"))

            # Duplicate callbacks/replace and repeated redraw keep this same
            # screen lifetime silent; they cannot replay the one-shot sound.
            for _ in range(4):
                await py('import renpy;renpy.restart_interaction();result=True')
                await page.wait_for_timeout(80)
            await py('import renpy;renpy.show_screen("r13_material_corner",key="E01");renpy.restart_interaction();result=True')
            await page.wait_for_timeout(450)
            assert (await state())["effects"] == ["page"], await state()

            await py('import renpy;renpy.hide_screen("r13_material_corner");renpy.store._preferences.set_volume("sfx",.2);renpy.restart_interaction();result=True')
            await page.wait_for_timeout(300)
            quiet = await capture('import renpy;renpy.show_screen("r13_material_corner",key="G1");renpy.restart_interaction();result=True')
            second = await state()
            assert second["effects"] == ["page", "page"], second
            assert 0 < quiet < loud * .65, ("Effects volume not reflected in real output", loud, quiet, second)

            await py('import renpy;renpy.hide_screen("r13_material_corner");renpy.store._preferences.set_mute("sfx",True);renpy.restart_interaction();result=True')
            await page.wait_for_timeout(300)
            muted = await capture('import renpy;renpy.show_screen("r13_material_corner",key="E01");renpy.restart_interaction();result=True')
            last = await state()
            assert last["effects"] == ["page", "page", "page"] and last["screen"], last
            assert last["mute"] and last["actual_volume"] == 0 and muted < 1e-7, (muted, last)
            assert not errors, errors
            assert not bad, bad
            report.update(status="passed", checks=["Prediction silent", "One page whoosh on actual show", "Same-screen redraw and duplicate show silent", "Hide/new presentation emits one new whoosh", "One-shot finishes", "sfx volume changes actual WebAudio output", "sfx mute silences actual output"], loud_rms=loud, quiet_rms=quiet, muted_rms=muted, effects=last["effects"], errors=errors, http_errors=bad)
        except Exception as e:
            report.update(status="failed", error=repr(e), errors=errors, http_errors=bad)
            await page.screenshot(path=str(output / "failure.png"))
            raise
        finally:
            (output / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
            print(json.dumps(report, ensure_ascii=False), flush=True)
            await browser.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", required=True)
    parser.add_argument("--output", default="/tmp/room13-material-sound-qa")
    asyncio.run(main(parser.parse_args()))
