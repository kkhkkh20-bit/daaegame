#!/usr/bin/env python3
"""Build authored-pose comparison gallery. Copy originals; never edit pixels."""
import argparse,json,shutil
from pathlib import Path
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
ART=ROOT/'art/pixel-b'
ACT=ART/'acting'
BASE=ACT/'baseline'
OUT=ROOT.parents[1]/'preview/room13-acting'
PORTRAITS=ART/'portraits'
FRONT_POSES=('neutral','thinking','distressed','expressive')
POSES=['neutral','thinking','distressed','expressive','activity','action_1','action_2','sad','left']

def portrait_inputs():
    combined=PORTRAITS/'portraits.json'
    files=[combined] if combined.exists() else sorted(PORTRAITS.glob('*-dialogue.json'))
    portraits,avatars={},{}
    for source in files:
        for person,poses in json.loads(source.read_text()).items():
            if person in portraits:raise ValueError('Duplicate front portrait '+person)
            portraits[person]={k:v for k,v in poses.items() if not k.startswith('avatar_')}
            avatars[person]={k:v for k,v in poses.items() if k.startswith('avatar_')}
    for source in sorted(PORTRAITS.glob('*-avatars.json')):
        for person,poses in json.loads(source.read_text()).items():
            avatars.setdefault(person,{}).update(poses)
    return portraits,avatars

def build(partial=False,destination=OUT,allow_pending=False):
    destination=Path(destination)
    if allow_pending and destination.resolve()==OUT.resolve():
        raise ValueError('Pending portraits may only be inspected in a separate draft destination')
    output=destination
    portraits,portrait_avatars=portrait_inputs()
    if not allow_pending:
        expected=set()
        for name in ('cast-main.json','cast-support.json'):
            expected.update(json.loads((BASE/name).read_text()))
        assert set(portraits)==expected, ('Front portrait inputs incomplete; published gallery unchanged',expected-set(portraits))
        for person,poses in portraits.items():
            assert all(p in poses for p in FRONT_POSES),(person,'Missing front pose')
            assert len({(poses[p]['file'],tuple(poses[p]['crop'])) for p in FRONT_POSES})==4,(person,'Duplicate front drawing')
            avatar=portrait_avatars.get(person,{}).get('avatar_neutral')
            assert avatar and avatar['file'] not in {poses[p]['file'] for p in FRONT_POSES},(person,'Separate avatar source required')
            assert (PORTRAITS/Path(avatar['file']).name).is_file(),avatar['file']
            for pose in FRONT_POSES:
                spec=poses[pose]
                assert (PORTRAITS/Path(spec['file']).name).is_file(),spec['file']
                assert spec.get('nearest') is True and spec.get('head'),(person,pose,'Missing pixel/front geometry')
    (output/'assets').mkdir(parents=True,exist_ok=True)
    old={}
    main=set()
    for f in ['cast-main.json','cast-support.json']:
        entries=json.loads((BASE/f).read_text())
        old.update(entries)
        if f=='cast-main.json':main.update(entries)
    names={p:d['name'] for p,d in json.loads((ROOT/'game/room13-content.json').read_text())['residents'].items()}
    village_path=ROOT/'game/village-residents.json'
    if village_path.exists():
        village=json.loads(village_path.read_text())
        for key,profile in village.get('profiles',{}).items():
            if isinstance(profile,dict) and profile.get('name'): names[key]=profile['name']
    names.update(daram='다람이',dad='아빠',mom='엄마',granny='할머니',seryeon='세련',nabi='나비',bami='밤이',doto='도토',buri='부리',karo='까로',neoul='너울',guard='돌목')
    entries={}
    for f in sorted(ACT.glob('*-acting.json')):
        data=json.loads(f.read_text())
        if 'characters' in data:data=data['characters']
        if 'cast' in data:data=data['cast']
        for key,spec in data.items():
            if key in old and isinstance(spec,dict):
                if key in entries:raise ValueError('Duplicate acting character '+key)
                poses=spec.get('poses',spec)
                if all(value.get('reviewed',True) for value in poses.values()):entries[key]=poses
    family_world=PORTRAITS/'family-world.json'
    if family_world.exists():
        for person,poses in json.loads(family_world.read_text()).items():
            assert person in entries and set(poses)<=set(entries[person]),('World override mismatch',person)
            entries[person].update(poses)
    world_context=ACT/'world-context.json'
    if world_context.exists():
        for person,poses in json.loads(world_context.read_text()).items():
            assert person in entries and not set(poses)&set(entries[person]),('Context pose collision',person)
            assert all(spec.get('reviewed') and key.startswith('world_') for key,spec in poses.items()),person
            entries[person].update(poses)
    sources={}
    missing=[]
    def art(spec,before=False,portrait=False):
        if not isinstance(spec,dict) or 'file'not in spec:return None
        name=Path(spec['file']).name
        candidates=[BASE/name] if before else ([PORTRAITS/name] if portrait else [PORTRAITS/name,ACT/name,ART/name,ART/'panorama'/name,ROOT/'game/assets'/name])
        src=next((p for p in candidates if p.exists()),None)
        if src is None:
            missing.append(name);return None
        public=('before-' if before else '')+name
        if public not in sources:
            shutil.copyfile(src,output/'assets'/public)
            with Image.open(src) as im:size=list(im.size)
            sources[public]={'file':'assets/'+public,'size':size}
        size=sources[public]['size']
        rect=spec.get('crop',spec.get('rect',[0,0,*size]))
        x,y,w,h=rect
        assert min(x,y)>=0 and min(w,h)>0 and x+w<=size[0] and y+h<=size[1],(src,rect,size)
        return dict(file='assets/'+public,size=size,rect=rect)
    labels={}
    for path in ACT.glob('*-acting-labels.json'):
        labels.update(json.loads(path.read_text()))
    if world_context.exists():
        for person,poses in json.loads(world_context.read_text()).items():
            labels.setdefault(person,{}).update({key:spec['activity_label'] for key,spec in poses.items()})
    for key,spec in labels.items():
        if isinstance(spec,dict) and spec.get('name'): names[key]=spec['name']
    # Match the campaign's public names after optional art-label metadata.
    names.update(resident_owlgp='부엉이 할아버지',resident_lamplighter='초롱',resident_tok='톡',resident_piko='피코',resident_seori='서리 검사원',resident_ppul='뿔이 촌장')
    people=[]
    for key,spec in entries.items():
        newposes={p:art(value) for p,value in spec.items() if not p.startswith(('avatar_','interview_')) and isinstance(value,dict) and 'file'in value}
        newposes={p:v for p,v in newposes.items()if v}
        oldposes={p:art(old[key][p],True)for p in POSES if p in old[key]}
        oldposes={p:v for p,v in oldposes.items()if v}
        # Existing support facial labels are aliases. Display one source drawing.
        seen=set();uniqueold={}
        for p,v in oldposes.items():
            token=(v['file'],tuple(v['rect']))
            if token not in seen:uniqueold[p]=v;seen.add(token)
        distinct=len({(v['file'],tuple(v['rect']))for v in newposes.values()})
        if newposes:people.append(dict(id=key,name=names.get(key,key),kind='main'if key in main else 'support',before=uniqueold,after=newposes,labels=labels.get(key,{}),authored=distinct,alias_count=len(newposes)-distinct))
    front_missing=[]
    for person in people:
        key=person['id']; fronts={}; avatars={}
        for pose in FRONT_POSES:
            spec=portraits.get(key,{}).get(pose)
            if not spec:
                front_missing.append(key+':'+pose);continue
            x,y,w,h=spec['crop'];head=spec.get('head')
            if not head or spec.get('nearest') is not True:
                front_missing.append(key+':'+pose+':geometry');continue
            hx,hy,hw,hh=head
            assert min(hx,hy)>=0 and min(hw,hh)>0 and hx+hw<=w and hy+hh<=h,(key,pose,'Head bounds')
            front=art(spec,portrait=True)
            avatar_spec=portrait_avatars.get(key,{}).get('avatar_'+pose) or dict(file=spec['file'],crop=[x+hx,y+hy,hw,hh],nearest=True)
            avatar=art(avatar_spec,portrait=True)
            if front and avatar:
                fronts[pose]=front
                avatar['origin']='dedicated' if 'avatar_'+pose in portrait_avatars.get(key,{}) and avatar_spec['file'] not in {value['file'] for value in portraits.get(key,{}).values()} else 'dialogue_crop'
                avatars[pose]=avatar
        person['dialogue']=fronts
        person['front_avatars']=avatars
        person['dedicated_avatar']=next((a for a in avatars.values() if a['origin']=='dedicated'),None)
        person['portrait_status']='source_ready' if len(fronts)==4 else 'pending'
        person['world_pose']=next((p for p in person['after'] if p.startswith('living_')), 'activity' if 'activity' in person['after'] else 'neutral')
    front_coverage=dict(people=sum(len(p['dialogue'])==4 for p in people),drawings=sum(len(p['dialogue']) for p in people),avatars=sum(len(p['front_avatars']) for p in people),missing=front_missing)
    front_coverage['dedicated_avatars']=sum(p['dedicated_avatar'] is not None for p in people)
    front_coverage['dialogue_complete']=front_coverage['people']==43 and not front_missing and not missing
    front_coverage['complete']=front_coverage['dialogue_complete'] and front_coverage['dedicated_avatars']==43
    # Source availability is not a visual review or a runtime verification claim.
    front_coverage['verification']='source-metadata-only'
    people.sort(key=lambda p:(p['kind']!='main',list(old).index(p['id'])))
    coverage=dict(people=len(people),main=sum(p['kind']=='main'for p in people),support=sum(p['kind']=='support'for p in people),authored=sum(p['authored']for p in people),aliases=sum(p['alias_count']for p in people),missing=sorted(set(missing)))
    coverage['complete']=len(people)==43 and not missing and all(p['authored']>=5 for p in people)
    continuity=[]
    if (ACT/'continuity.json').exists():
        current_cinematics=json.loads((ART/'cinematics.json').read_text())
        current_by_id={item['id']:item for item in current_cinematics['items']}
        for spec in json.loads((ACT/'continuity.json').read_text())['items']:
            current=dict(spec)
            if spec['id']=='carriage':
                current['file']=current_cinematics.get('carriage_file',spec['file'])
            elif spec['id'] in current_by_id:
                current=current_by_id[spec['id']]
            before,after=art(spec,True),art(current)
            if before and after:continuity.append(dict(id=spec['id'],title=spec['title'],before=before,after=after))
    runtime=[]
    runtime_manifest=ACT/'runtime-gallery.json'
    if runtime_manifest.exists():
        (output/'screenshots').mkdir(exist_ok=True)
        for screen in json.loads(runtime_manifest.read_text())['items']:
            source=Path(screen['source'])
            assert source.is_file(),source
            shutil.copyfile(source,output/'screenshots'/source.name)
            runtime.append(dict(title=screen['title'],caption=screen['caption'],file='screenshots/'+source.name))
    front_runtime=[]
    front_runtime_manifest=PORTRAITS/'runtime-gallery.json'
    if front_runtime_manifest.exists():
        (output/'screenshots').mkdir(exist_ok=True)
        for screen in json.loads(front_runtime_manifest.read_text())['items']:
            source=Path(screen['source'])
            assert source.is_file(),source
            public='front-'+source.name
            shutil.copyfile(source,output/'screenshots'/public)
            front_runtime.append(dict(title=screen['title'],caption=screen['caption'],file='screenshots/'+public))
    latest_screens = [
        ("입구 · 주민과 대기소", "01-natural-entry-three-residents.png"),
        ("질문 · 읽은 대화 표시", "06-question-struck-through.png"),
        ("초소 서류 · 확대 조사", "07-original-copy-recorded.png"),
        ("증거 제시 · 좌측 아이콘", "09-guard-evidence-card.png"),
        ("아빠 시점 · 속마음", "08-dad-blue-thought-no-avatar.png"),
        ("대화 프로필 · 프레임 안 확대", "05-karo-profile-in-frame.png"),
        ("모바일 · 확대 조사", "12-mobile-recorded-document-popup.png"),
    ]
    latest_runtime=[]
    for title,name in latest_screens:
        source=ROOT/"qa-room13-0154/gate-a4cb-final"/name
        if source.is_file():
            (output/"screenshots").mkdir(exist_ok=True)
            public="0154-"+name
            shutil.copyfile(source,output/"screenshots"/public)
            latest_runtime.append(dict(title=title,caption="이전 0.15.4 통합 후보 · 실제 입력으로 실행한 화면. 현재 대화 배치와 다릅니다.",file="screenshots/"+public))
    for side,label in [("left","왼쪽"),("right","오른쪽")]:
        source=ROOT/"qa-room13-0154/panorama-1da7-final"/("inn-"+side+".png")
        if source.is_file():
            public="0154-inn-"+side+".png"
            shutil.copyfile(source,output/"screenshots"/public)
            latest_runtime.append(dict(title="여관 · "+label+" 시야",caption="이전 0.15.4 검수본 · 최대 인원 배치를 설정한 클릭 검수 화면",file="screenshots/"+public))
    review_runtime=[]
    review_screens=[
        ('초소 서류 · 항목과 값 비교','final-say-records-accepted','01-PC-separated-label-value.png','문서 표기 수정 후보 · PC에서 원본과 사본의 항목을 직접 선택한 화면'),
        ('모바일 · 인원 칸 직접 선택','final-say-records-accepted','02-mobile-count-selected.png','문서 표기 수정 후보 · 모바일에서 인원 칸을 실제로 누른 화면'),
        ('기록 · 관심 자료 모아 보기','review-natural','07-favorites-filter-read-mark.png','기록 검수 후보 · 새 게임에서 얻은 자료에 관심 표시를 붙이고 필터를 켠 화면'),
        ('모바일 · 증거 수첩','review-natural','10-mobile-large-records.png','기록 검수 후보 · 입구 추리를 마친 뒤 실제로 모은 증거와 큰 글씨 설정'),
        ('모바일 · 자료의 내용과 입수 경로','review-natural','11-mobile-large-record-detail.png','기록 검수 후보 · 수첩에서 예약 원본을 직접 선택한 화면'),
        ('서랍 조사 · 접이식 돋보기 획득','tool-discovery-final','01-natural-magnifier-reward.png','도구 연계 검수 후보 · 책상과 서랍을 실제로 조사해 돋보기를 얻은 화면'),
        ('붉은 바느질 · 다람이에게 새 질문','tool-discovery-final','02-seam-memo.png','도구 연계 검수 후보 · 침대의 단서를 돋보기로 살펴보고 관찰 메모를 남긴 화면'),
        ('다람이에게 확인한 관찰 메모','tool-discovery-final','02b-child-read.png','도구 연계 검수 후보 · 새 질문을 실제로 물어본 뒤 읽음 표시가 남은 화면'),
        ('수리점 · 도면을 얻은 뒤','tool-discovery-final','07-existing-map-earned-E04.png','도구 연계 검수 후보 · 원래의 도면 조사 활동을 수행해 자료를 얻은 화면. 하단 메뉴 개편 전'),
        ('모바일 · 돋보기 관찰 기록','tool-discovery-final','08-mobile-observation-notes.png','도구 연계 검수 후보 · 실제 플레이에서 남긴 두 관찰 메모를 모바일 수첩에서 연 화면'),
    ]
    for title,folder,name,caption in review_screens:
        source=ROOT/'qa-room13-0155'/folder/name
        if source.is_file():
            (output/'screenshots').mkdir(exist_ok=True)
            public='0155-'+folder+'-'+name
            shutil.copyfile(source,output/'screenshots'/public)
            review_runtime.append(dict(title=title,caption='0.15.5 '+caption,file='screenshots/'+public))
    # Newly captured final-toolbar viewpoints are supplied separately by QA.
    viewpoint_manifest=PORTRAITS/'runtime-viewpoint0156.json'
    if not viewpoint_manifest.exists():viewpoint_manifest=PORTRAITS/'runtime-viewpoint0155.json'
    viewpoint_runtime=[]
    if viewpoint_manifest.exists():
        for screen in json.loads(viewpoint_manifest.read_text())['items']:
            source=Path(screen['source'])
            assert source.is_file(),source
            public=('0156-viewpoint-' if '0156' in viewpoint_manifest.name else '0155-viewpoint-')+source.name
            shutil.copyfile(source,output/'screenshots'/public)
            viewpoint_runtime.append(dict(title=screen['title'],caption=screen['caption'],file='screenshots/'+public))
    for screen in front_runtime:
        screen['caption']='이전 대화 배치 기록 · '+screen['caption']
    staging_runtime=[]
    for title,name in [
        ('여관 · 접수대 앞에서 일하는 할머니','inn-p1-x640.png'),
        ('광장 · 게시판을 읽는 도토','square-p0-x0.png'),
        ('광장 · 벤치에 앉은 토리','square-p0-x640.png'),
    ]:
        source=ROOT/'qa-room13-0156/world-context/engine'/name
        if source.is_file():
            public='0156-staging-'+name
            shutil.copyfile(source,output/'screenshots'/public)
            staging_runtime.append(dict(title=title,caption='0.15.6 배치 검수 후보 · 새 원화와 인물·시간·시야를 직접 설정한 엔진 검수 화면입니다. 자연 플레이 캡처와 구분합니다.',file='screenshots/'+public))
    front_runtime=viewpoint_runtime+staging_runtime+review_runtime+latest_runtime+front_runtime
    exploration=[]
    for key,title in [('desk','책상 확대 조사'),('drawer','열린 필기함 서랍'),('items','조사 아이템')]:
        value=art({'file':'room13-pixel-inspect-'+key+'.png'})
        if value: exploration.append(dict(title=title,art=value))
    world_file=ART/'panorama/world-layout.json'
    if world_file.exists():
        for location,world in json.loads(world_file.read_text()).items():
            for period,path in world['files'].items():
                value=art({'file':path})
                if value: exploration.append(dict(title=world.get('title',location)+' · '+{'morning':'오전','afternoon':'오후','evening':'저녁'}[period],art=value))
    evidence_icons=[]
    evidence_atlas=None
    evidence_manifest=ART/'evidence-icons0155.json'
    if evidence_manifest.exists():
        evidence_specs=json.loads(evidence_manifest.read_text())
        evidence_titles=[('E01','초대 봉투'),('G1','예약 원본'),('G3','사본 명부'),('G2','보호 규정'),
            ('E02','정정본'),('E04','건물 도면'),('E05','서비스 통로'),('E08','진료 기록'),
            ('E13','핀 수리 쪽지'),('E14','촛대 금속핀'),('E16','가족 분리 요청'),('E18','미전달 봉투')]
        for key,title in evidence_titles:
            assert key in evidence_specs,('Missing evidence icon',key)
            value=art(evidence_specs[key])
            assert value,('Missing evidence icon source',key)
            evidence_icons.append(dict(id=key,title=title,art=value))
        evidence_atlas=art({'file':evidence_specs['E01']['file']})
    family_palette=None
    palette_report=ART/'family-chestnut0156-report.json'
    if palette_report.exists():
        palette=json.loads(palette_report.read_text())
        palette_assets=[]
        for item in palette['assets']:
            source_art=art({'file':Path(item['source']).name})
            assert source_art,('Missing recolored family source',item['source'])
            palette_assets.append(dict(file=source_art['file'],size=source_art['size'],sha256=item['sha256']))
        family_palette=dict(revision=palette['revision'],colors=palette['family_palette'],assets=palette_assets)
        (output/'family-palette.json').write_text(json.dumps(family_palette,ensure_ascii=False,indent=2)+'\n')
    result=dict(revision='acting-front-review-v3',coverage=coverage,portrait_coverage=front_coverage,front_runtime=front_runtime,people=people,continuity=continuity,runtime=runtime,exploration=exploration,evidence_icons=evidence_icons,evidence_atlas=evidence_atlas,family_palette=family_palette,sources=list(sources.values()))
    # Only remove obsolete copied gallery PNGs; source art/baselines stay untouched.
    for file in (output/'assets').glob('*.png'):
        if file.name not in sources: file.unlink()
    assert len(list((output/'assets').glob('*.png')))==len(sources)
    (output/'index.html').write_text((ROOT/'dev/acting_gallery_template.html').read_text())
    for font in ('Galmuri11.woff2','Galmuri-OFL.txt'):
        src=OUT/'assets'/font
        if src.exists() and src.resolve()!=(output/'assets'/font).resolve():shutil.copyfile(src,output/'assets'/font)
    (output/'catalog.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(dict(acting=coverage,portraits=front_coverage),ensure_ascii=False))
    if not partial:assert coverage['complete'],coverage
    if not allow_pending:assert front_coverage['complete'],front_coverage

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--partial',action='store_true');parser.add_argument('--destination',type=Path,default=OUT);parser.add_argument('--allow-pending-portraits',action='store_true');args=parser.parse_args();build(args.partial,args.destination,args.allow_pending_portraits)
