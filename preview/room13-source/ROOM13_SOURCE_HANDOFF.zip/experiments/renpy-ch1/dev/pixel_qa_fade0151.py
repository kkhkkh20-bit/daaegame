"""Independent 0.15.1 appearance QA. Video frames are actual browser output.
All explicit presentation injections below are fixtures, never natural play.
"""
import argparse,asyncio,base64,json,shutil,time
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_flow0150 import FlowQA,ROOT

class Recorder:
 def __init__(self,page,out):self.p=page;self.out=out;self.frames=[];self.pending=[]
 async def start(self,name):
  self.name=name;self.frames=[];self.folder=self.out/name;self.folder.mkdir(parents=True,exist_ok=True);self.start_time=time.monotonic();self.cdp=await self.p.context.new_cdp_session(self.p)
  def frame(event):
   i=len(self.frames);path=self.folder/('%03d.png'%i);path.write_bytes(base64.b64decode(event['data']));self.frames.append({'file':str(path.relative_to(self.out)),'received_ms':round((time.monotonic()-self.start_time)*1000,2),'browser_timestamp':event['metadata'].get('timestamp')});self.pending.append(asyncio.create_task(self.cdp.send('Page.screencastFrameAck',{'sessionId':event['sessionId']})))
  self.cdp.on('Page.screencastFrame',frame);await self.cdp.send('Page.startScreencast',{'format':'png','everyNthFrame':1,'maxWidth':1280,'maxHeight':720});await asyncio.sleep(.12)
 async def stop(self):
  await self.cdp.send('Page.stopScreencast');await asyncio.gather(*self.pending,return_exceptions=True);await self.cdp.detach();return {'name':self.name,'frames':self.frames}

ALPHA_PROBE="""import renpy
s=renpy.store
seen=set();nodes=[];stack=[]
for entry in renpy.game.context().scene_lists.layers.get('master',[]):
 if entry.tag=='r13_visitor':stack.append((entry.displayable,'central'))
for screen,ident in [('r13_entry_karo_topics','r13_topics_karo'),('say','r13_dialogue_portrait_'+str(s.dialogue_speaker)+'_'+str(s.dialogue_expression)),('r13_hub','r13_world_karo'),('r13_hub','r13_world_guard'),('r13_hub','r13_waiting_daram')]:
 widget=renpy.exports.get_widget(screen,ident)
 if widget is not None:stack.append((widget,ident))
while stack:
 node,path=stack.pop()
 if id(node) in seen:continue
 seen.add(id(node))
 state=getattr(node,'state',None)
 if state is not None and hasattr(state,'alpha'):nodes.append({'path':path,'type':type(node).__name__,'alpha':state.alpha})
 for i,child in enumerate(node.visit()):stack.append((child,path+'/'+str(i)))
result=nodes
"""
async def sample(q,duration=.75):
 rows=[];start=time.monotonic()
 while time.monotonic()-start<duration:
  rows.append({'ms':round((time.monotonic()-start)*1000,2),'alpha':await q.py(ALPHA_PROBE)});await asyncio.sleep(.025)
 return rows

async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',default='qa-room13-0151/fade-independent');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True)
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();errors=[];pg.on('pageerror',lambda e:errors.append(str(e)));q=FlowQA(pg,out);r=Recorder(pg,out);report={'captures':[],'kind':'actual-input-topics-plus-presentation-fixture-timing'}
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub')
   await r.start('natural-karo-topics');st=await q.state();button=next(x for x in st['buttons']if '까로'in x['text']);x,y,w,h=button['rect'];await pg.mouse.click(x+w/2,y+h/2);samples=await sample(q);cap=await r.stop();cap['samples']=samples;report['captures'].append(cap);await q.wait('r13_entry_karo_topics')
   await r.start('natural-karo-dialogue');st=await q.state();button=next(x for x in st['buttons']if '짐 좀 부탁합니다'in x['text']);x,y,w,h=button['rect'];await pg.mouse.click(x+w/2,y+h/2);samples=await sample(q);cap=await r.stop();cap['samples']=samples;report['captures'].append(cap);await q.wait('say');await q.shot('natural-karo-dialogue-settled')
   # Identity-stable presentation update: no new story lines/flags are executed.
   for name,code in [
    ('same-speaker-repeated',"s.r13_speaker('karo','neutral');s.dialogue_speaker='karo'"),
    ('same-speaker-expression',"s.r13_speaker('karo','thinking');s.dialogue_speaker='karo'"),
    ('different-speaker',"s.r13_speaker('buri','neutral');s.dialogue_speaker='buri'"),
    ('screen-restart',"pass")]:
    await r.start(name);await q.py("import renpy\ns=renpy.store\n"+code+"\nrenpy.exports.restart_interaction()\nresult=True");samples=await sample(q);cap=await r.stop();cap['samples']=samples;report['captures'].append(cap)
   # Return to real entry hub after the one-line Karo topic.
   await q.advance();await q.wait('r13_hub')
   await r.start('world-screen-restart');await q.py('import renpy;renpy.exports.restart_interaction();result=True');samples=await sample(q);cap=await r.stop();cap['samples']=samples;report['captures'].append(cap)
   await r.start('world-appearance-fixture');await q.py("import renpy;renpy.exports.hide_screen('r13_hub');renpy.exports.restart_interaction();result=True");await asyncio.sleep(.12);await q.py("import renpy;renpy.exports.show_screen('r13_hub',entry=True);renpy.exports.restart_interaction();result=True");samples=await sample(q);cap=await r.stop();cap['samples']=samples;report['captures'].append(cap)
   await r.start('motion-off-immediate');await q.py("import renpy;s=renpy.store;s.persistent.room13_motion=False;renpy.exports.hide_screen('r13_hub');s.r13_speaker('neoul','neutral');renpy.exports.restart_interaction();result=s.r13_appearance_duration()");samples=await sample(q,.4);cap=await r.stop();cap['samples']=samples;report['captures'].append(cap);await q.py('import renpy;renpy.store.persistent.room13_motion=True;result=True')
   assert not errors,errors;report['status']='captured-awaiting-independent-analysis'
  except Exception as e:
   report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
   try:await r.stop()
   except Exception:pass
  report.update(errors=errors,url=a.url);(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items()if k!='captures'},ensure_ascii=False),flush=True);await b.close()
  if report['status']=='failed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
