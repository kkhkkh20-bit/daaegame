"""Natural gate->inn->tool->diagram->working door->granny chain; no story injection."""
import asyncio,argparse,json,shutil,urllib.request,traceback
from playwright.async_api import async_playwright
from pixel_qa_ui0156 import UIQA,ROOT
from qa_room13_inspection import InspectionQA
from pixel_qa_flow0150 import FLOW_PROBE
class MysteryQA(UIQA):
 target=InspectionQA.target
 isp=InspectionQA.isp
 async def state(self):
  probe=FLOW_PROBE.replace("getattr(a,'value','')", "next((getattr(v,'value') for v in (a if isinstance(a,(list,tuple)) else [a]) if hasattr(v,'value')),'')").replace('names=[',"names=['r13_resident_approach','r13_gate_document_inspection','r13_records','r13_plan_comparison','r13_mystery_notebook','r13_desk_inspection','r13_tool_closeup',")
  st=await self.py('ns={};exec('+ascii(probe)+',ns);result=ns["result"]');assert '_exception'not in st['screens'],st;return st
 async def talk(self,who):
  await self.value(('person',who));await self.advance()
  if 'r13_resident_approach'in(await self.state())['screens']:await self.value(True);await self.advance()
  await self.wait('r13_topics')
 async def exit_talk(self):await self.press('돌아가기');await self.advance();await self.wait('r13_hub')
 async def world(self,label):
  await self.press('지도 · 이동');await self.wait('r13_map');st=await self.state()
  if any('여관 밖으로'in b['text']for b in st['buttons']):await self.press('여관 밖으로')
  await self.press(label);await self.press('이곳으로 이동');await self.advance();await self.wait('r13_hub')
 async def show_material(self,key,who):
  await self.value('present');await self.wait('r13_book');short=await self.py('import renpy;result=renpy.store.R13_RECORD_SHORT.get('+repr(key)+','+repr(key)+')');await self.press(short);await self.press(who+'에게 보여주기');await self.wait('r13_confirm');await self.press('보여준다');await self.wait('say')
 async def plan(self):return await self.py("import renpy;s=renpy.display.screen.get_screen('r13_plan_comparison');result={k:s.scope[k] for k in ['stage','gap','endpoints','reason','feedback','lens']}")
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',default='qa-room13-0158/natural');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True);report={'kind':'natural full first-mystery loop with PC/mobile actions and actual slot saves','archive_sha256':json.load(urllib.request.urlopen(a.url+'game-transport.json'))['archive_sha256'],'checks':[]}
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);pg=await b.new_page(viewport={'width':1280,'height':720},has_touch=True);q=MysteryQA(pg,out)
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub')
   await q.docs();await q.input(310,357);await q.input(875,357);await q.press('선택한 항목');await q.wait('r13_gate_document_inspection');await q.press('닫기');await q.wait('r13_hub');await q.input(390,321);await q.advance();await q.wait('r13_hub');await q.present();await q.press('원본에는 두 명');await q.advance();await q.wait('r13_hub');assert(await q.room())['period']==1
   await q.travel('여관 접수대');await q.talk('granny');await q.value('register');await q.advance();await q.wait('r13_topics');assert'inn_front_door_claim'in(await q.room())['flags'];await q.exit_talk();await q.travel('13호실');await q.value(('object','bed'));await q.advance();await q.wait('r13_object_context');await q.press('그만 살펴본다');await q.wait('r13_hub');assert'E03'in(await q.room())['evidence']
   await q.value(('object','books'));await q.advance();await q.wait('choice');await q.press('다른 곳을');await q.advance();await q.wait('r13_hub');assert not(await q.room())['passage_open'];await q.press('기록');await q.wait('r13_records');await q.press('추리 메모');await q.wait('r13_mystery_notebook');await q.shot('01-question-from-actual-claim');await q.press('닫기');await q.press('닫기');await q.wait('r13_hub');report['checks'].append('Natural gate correction; lodging statement; E03 and stuck bookshelf; notes show known facts only')
   # Existing item puzzle earns the optional magnifier naturally.
   await q.value(('object','desk'));await q.wait('r13_desk_inspection')
   for key in ('pencil','paper','ruler'):await q.target(key)
   await q.target('drawer');await q.press('얇은 종이');await q.target('tag');await q.press('짧은 연필');await q.target('tag');await q.press('납작한 자');await q.target('divider');await q.target('compartment');assert 'magnifier'in(await q.isp())['inventory'];await q.press('책상으로');await q.press('방으로');await q.wait('r13_hub')
   await q.world('수리점');await q.value(('object','plans'));await q.advance();await q.wait('r13_object_context');before=await q.room();await q.value(('activity','map'));await q.wait('r13_plan_comparison');await q.press('창문 쪽');await q.press('선택한 부분');assert(await q.plan())['stage']==0 and await q.room()==before;await q.shot('02-wrong-gap-feedback');await q.press('돌아가기');await q.wait('r13_hub');assert await q.room()==before
   await q.value(('object','plans'));await q.advance();await q.wait('r13_object_context');await q.value(('activity','map'));await q.wait('r13_plan_comparison');await q.press('책장 뒤');await q.press('선택한 부분');assert(await q.plan())['stage']==1;await q.press('굴뚝 관');await q.press('화덕');await q.press('선택한 부분');assert(await q.plan())['stage']==1;await q.press('생각이 막혔다면');await q.shot('03-wrong-line-optional-hint');await q.press('돋보기로');assert(await q.plan())['lens'];await q.shot('04-earned-magnifier-line-detail');await q.press('책장 아래');await q.press('선반 아래');await q.press('선택한 부분');assert(await q.plan())['stage']==2
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.press('열을 가두는');await q.press('이 가설로');assert(await q.plan())['stage']==2 and await q.room()==before;await q.shot('05-mobile-reason-feedback');await q.press('아래층에서');await q.shot('06-mobile-correct-hypothesis');await q.press('이 가설로');await q.advance();await q.wait('r13_hub');after=await q.room();assert 'E04'in after['evidence'] and after['period']==before['period']+1 and after['done'].count('map')==1;assert not after['passage_open'] and not after['kitchen_switch'];report['checks'].append('Real wrong spatial/line/hypothesis attempts, no time/reward; cancel preserves state; earned magnifier helps diagram; touch completion grants E04 once and costs one period, door remains closed')
   await pg.set_viewport_size({'width':1280,'height':720});q.touch=False;await q.save(2);await q.load(2);assert await q.room()==after;await q.talk('buri');await q.show_material('E04','부리');await q.shot('07-buri-reacts-to-found-space');await q.advance();await q.wait('r13_topics');assert'plan_reviewed_with_buri'in(await q.room())['flags'];await q.exit_talk()
   await q.travel('여관 접수대');await q.talk('granny');await q.show_material('E04','할머니');await q.advance();await q.wait('r13_topics');assert'inn_claim_retracted'not in(await q.room())['flags'];await q.exit_talk();await q.value(('travel','kitchen'));await q.advance();await q.wait('r13_hub');await q.value(('object','shelf'));await q.advance();await q.wait('choice');await q.press('레버를 올려');await q.advance();await q.wait('r13_hub');assert(await q.room())['kitchen_switch']
   await q.travel('13호실');await q.value(('object','books'));await q.advance();await q.wait('choice');await q.press('책의 아래쪽');await q.advance();await q.wait('choice');assert'E37'in(await q.room())['evidence'];await q.press('지금은 방에');await q.advance();await q.wait('r13_hub');assert(await q.room())['passage_open'];await q.shot('08-working-door-confirmed');await q.travel('여관 접수대');await q.talk('granny');await q.show_material('E37','할머니');await q.input(810,610);await q.wait('say');await q.shot('09-granny-reaction');await q.advance();await q.wait('r13_topics');assert'inn_claim_retracted'in(await q.room())['flags'];await q.exit_talk();await q.save(3);await q.load(3);assert'inn_claim_retracted'in(await q.room())['flags']
   await q.press('기록');await q.wait('r13_records');await q.press('추리 메모');await q.wait('r13_mystery_notebook');await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.shot('10-mobile-question-resolved');report['checks'].append('Actual save/load preserves diagram completion; presenting paper changes Buri but does not prove working door; physical lever/book operations grant E37; Granny retracts only after actual evidence; result survives real save/load')
   report.update(status='passed',final_day=(await q.room())['day'],final_period=(await q.room())['period'])
  except Exception as e:
   report.update(status='failed',error=repr(e),traceback=traceback.format_exc());await pg.screenshot(path=str(out/'failure.png'))
   try:(out/'failure-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
   except Exception:pass
  finally:(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));await b.close()
 print(report,flush=True)
 if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
