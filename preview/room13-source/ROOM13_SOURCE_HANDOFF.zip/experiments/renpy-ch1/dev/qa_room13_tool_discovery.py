"""Natural puzzle reward -> optional observation -> real save/load -> existing map cost."""
import argparse,asyncio,json,shutil,traceback
from playwright.async_api import async_playwright
from qa_room13_inspection import InspectionQA,ROOT
class ToolQA(InspectionQA):
 async def press(self,label):
  if label=='마을':
   st=await self.state()
   if any('여관 밖으로'in row['text']for row in st['buttons']):label='여관 밖으로'
  return await super().press(label)
 async def state(self):
  st=await super().state();st['screens']+=await self.py("import renpy;result=[n for n in ['r13_tool_closeup','r13_tool_notebook','r13_records'] if renpy.display.screen.get_screen(n)]");return st
 async def advance_tool(self):
  for _ in range(100):
   st=await self.state()
   if 'r13_tool_closeup'in st['screens']:return st
   if 'say'in st['screens']:await self.input(810,640)
   else:await asyncio.sleep(.15)
  raise AssertionError(st)
 async def save_load(self):
  await self.press('옵션');await self.wait('pause_menu');await self.press('저장');await self.wait('save');await self.press('슬롯 2');await asyncio.sleep(.5);await self.press('돌아가기')
  if 'pause_menu'in(await self.state())['screens']:await self.press('돌아가기')
  await self.wait('r13_hub');await self.press('옵션');await self.wait('pause_menu');await self.press('불러오기');await self.wait('load');await self.press('슬롯 2');await self.wait('r13_hub')
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--legacy-no-child',action='store_true');ap.add_argument('--out',default='qa-room13-0155/tool-discovery');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True);report={'kind':'natural input; no inventory/evidence/state injection','checks':[],'url':a.url}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=ToolQA(pg,out)
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.natural_entry('wait')
   await q.travel('여관 접수대');await q.press('할머니');await q.advance();await q.wait('r13_topics');await q.value('register');await q.advance();await q.press('돌아가기');await q.advance();await q.travel('13호실','여관 안');baseline=(await q.state())['room']
   await q.value(('object','desk'));await q.wait('r13_desk_inspection')
   for key in ['pencil','paper','ruler']:await q.target(key)
   await q.target('drawer');await q.press('얇은 종이');await q.target('tag');await q.press('짧은 연필');await q.target('tag');await q.press('납작한 자');await q.target('divider');await q.target('compartment');assert 'magnifier'in(await q.isp())['inventory'];await q.shot('01-natural-magnifier-reward');await q.press('책상으로');await q.press('방으로');await q.wait('r13_hub')
   now=(await q.state())['room'];assert all(now[k]==baseline[k]for k in ['day','period','evidence','flags']);report['checks'].append('Original desk/drawer puzzle solved by real clicks; reusable reward acquired with no evidence/time change')
   if not a.legacy_no_child:
    # Existing bed examination grants E03 as before; tool itself only records a memo.
    await q.value(('object','bed'));await q.advance();await q.wait('r13_object_context');before_seam=(await q.state())['room'];assert 'E03'in before_seam['evidence'];await q.value(('tool','bed'));await q.wait('r13_tool_closeup');await q.press('관찰 메모 남기기');await q.wait('r13_tool_closeup');await q.shot('02-seam-memo');assert 'seam'in(await q.state())['room']['tool_discoveries'];await q.press('다람이에게 물어보기');await q.advance_tool();await q.wait('r13_tool_closeup');child_done=(await q.state())['room'];assert 'tool:seam'in child_done['read_topics'];assert all(child_done[k]==before_seam[k]for k in ['evidence','day','period','passage_open','kitchen_switch']);await q.shot('02b-child-read');await q.press('현장으로 돌아가기');await q.advance();await q.wait('r13_hub');report['checks'].append('Existing E03 bed observation -> optional enlarged seam memo -> Daram follow-up, no new evidence')
   await q.travel('수리점','마을');await q.value(('object','plans'));await q.advance();await q.wait('r13_object_context');before=(await q.state())['room'];assert 'E04'not in before['evidence'];await q.value(('tool','plans'));await q.wait('r13_tool_closeup');assert (await q.state())['room'].get('tool_discoveries',{})==before.get('tool_discoveries',{});await q.shot('03-plans-before-note')
   await q.press('관찰 메모 남기기');await q.wait('r13_tool_closeup');recorded=(await q.state())['room'];assert 'E04'not in recorded['evidence'];assert all(recorded[k]==before[k]for k in ['evidence','day','period','flags','passage_open','kitchen_switch']);assert 'plans'in recorded['tool_discoveries'];await q.shot('04-new-plans-question');await q.press('현장으로 돌아가기');await q.advance();await q.wait('r13_hub')
   # Save immediately after leaving the memo screen, before any other story action.
   expected=(await q.state())['room'];await q.save_load();loaded=(await q.state())['room'];assert loaded['tool_discoveries']==expected['tool_discoveries'];assert loaded['inspection_items']==expected['inspection_items'];assert all(loaded[k]==expected[k]for k in ['day','period','evidence','read_topics','flags']);report['checks'].append('Diagram tool works before E04; memo leaves evidence/time/gates unchanged and survives immediate real save/load')
   await q.value(('object','plans'));await q.advance();await q.wait('r13_object_context');await q.value(('tool','plans'));await q.wait('r13_tool_closeup');assert (await q.state())['room']['tool_discoveries']==expected['tool_discoveries'];await q.shot('05-loaded-no-duplicate');await q.press('현장으로 돌아가기');await q.advance();await q.wait('r13_hub')
   await q.press('부리');await q.advance();await q.wait('r13_topics');await q.value('tool:plans');await q.advance();await q.wait('r13_topics');after_question=(await q.state())['room'];assert 'tool:plans'in after_question['read_topics'] and 'E04'not in after_question['evidence'];await q.shot('06-buri-new-question-read');await q.press('돌아가기');await q.advance();await q.wait('r13_hub')
   await q.value(('object','plans'));await q.advance();await q.wait('r13_object_context');before_map=(await q.state())['room'];await q.value(('activity','map'));await q.wait('r13_confirm');await q.press('진행한다');await q.advance();await q.wait('r13_hub');after_map=(await q.state())['room'];assert after_map['evidence'].count('E04')==1;assert 'map'in after_map['done'];assert (after_map['day']-before_map['day'])*4+after_map['period']-before_map['period']==1;await q.shot('07-existing-map-earned-E04');report['checks'].append('Buri follow-up does not award E04; original map activity alone spends one time segment and grants exactly one E04')
   await q.press('부리');await q.advance();await q.wait('r13_topics');await q.value('present');await q.wait('r13_book');await q.press('옛 도면');await q.press('보여주기');await q.wait('r13_confirm');await q.press('보여준다');await q.advance();await q.wait('r13_topics');history=await q.py('import renpy;result=renpy.store.r13_history_rows()');assert any('돋보기로 봤던 선'in row['what']for row in history[:8]);await q.press('돌아가기');await q.advance();report['checks'].append('Owned E04 presentation to Buri acknowledges the optional observation through normal confirmation flow')
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.press('기록');await q.wait('r13_records');await q.press('관찰 메모');await q.wait('r13_tool_notebook');await q.shot('08-mobile-observation-notes');assert len((await q.state())['room']['tool_discoveries'])==(1 if a.legacy_no_child else 2);await q.press('닫기');report['checks'].append('Mobile records hub opens actual tool notes; repeat observation keeps original timestamps')
   report['status']='passed';report['final']=after_map
  except Exception as e:
   report.update(status='failed',error=repr(e),traceback=traceback.format_exc());await pg.screenshot(path=str(out/'failure.png'))
  (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
