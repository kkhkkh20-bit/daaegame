"""Records UI acceptance; natural history followed by clearly labelled acquired-data fixtures."""
import argparse,asyncio,copy,json,shutil
from playwright.async_api import async_playwright
from qa_room13_0153_helpers import FlowQA,ROOT
class RecordsQA(FlowQA):
 async def state(self):
  st=await super().state();st['screens']+=await self.py("import renpy;result=[n for n in ['r13_records','r13_item_bag','r13_calendar'] if renpy.display.screen.get_screen(n)]");return st
 async def record_scope(self,name='r13_records'):
  return await self.py("import renpy;s=renpy.display.screen.get_screen(%r);result={k:s.scope.get(k) for k in ['tab','category','detail','page','archive','selected_record','selected_person']}"%name)
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',default='qa-room13-0153/records');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True);report={'checks':[],'fixtures':[]}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=RecordsQA(pg,out)
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.natural_entry('wait')
   before=(await q.state())['room'];await q.press('기록');await q.wait('r13_records');await q.shot('01-natural-evidence')
   await q.press('증언');await q.shot('02-natural-testimony');await q.press('인물');people=await q.py('import renpy;result=renpy.store.r13_met_people()');assert 'karo'in people and 'guard'in people,people;await q.shot('03-natural-people')
   await q.press('대화');rows=await q.py('import renpy;result=renpy.store.r13_history_rows()');assert rows and any(r['who']=='까로'for r in rows);await q.shot('04-real-history')
   await q.press('달력');await q.wait('r13_calendar');await q.press('닫기');await q.wait('r13_records');await q.press('아이템');await q.wait('r13_item_bag');await q.press('닫기');await q.wait('r13_records');await q.press('닫기');await q.wait('r13_hub');assert (await q.state())['room']==before
   report['checks']+=['Natural entry people include actual Karo and guard','Real dialogue history retained','Records/calendar/items navigation and close preserve complete run state']
   # This deliberately grants all records only to exercise 34/6 pagination, not story progress.
   fixture=copy.deepcopy(before);fixture['evidence']=await q.py("import renpy;result=list(renpy.store.ROOM13['evidence'])")
   await q.py('import renpy;s=renpy.store;s.room13='+ascii(fixture)+';renpy.exports.restart_interaction();result=True');await q.press('기록');await q.wait('r13_records');await q.shot('05-fixture-evidence-page1');await q.press('다음');assert (await q.record_scope())['page']==1;await q.shot('06-fixture-evidence-page2');await q.press('다음');assert (await q.record_scope())['page']==2;await q.shot('07-fixture-evidence-page3')
   await q.press('증언');assert (await q.record_scope())['page']==0;await q.press('밤이의 목격');assert (await q.record_scope())['selected_record']=='E10';await q.shot('08-fixture-testimony')
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await asyncio.sleep(.5);await q.shot('09-mobile-testimony');await q.press('증거');await q.press('다음');await q.shot('10-mobile-evidence-page2');await q.press('닫기');await q.wait('r13_hub');assert (await q.state())['room']==fixture
   report['fixtures'].append('All40 acquired records injected only for 34 evidence /6 testimony layout and 3-page click/touch coverage')
   # Use normal NPC presentation call so cancel must return to that exact target.
   await pg.set_viewport_size({'width':1280,'height':720});q.touch=False
   await q.value(('person','karo'));await q.advance();await q.wait('r13_topics');before_present=(await q.state())['room'];await q.value('present');await q.wait('r13_book');await q.press('증언');await q.press('밤이의 목격');await q.shot('11-karo-present-testimony');st=await q.state();assert any('까로에게 보여주기'in x['text'] for x in st['buttons']);assert not any('이전 발견'in x['text'] for x in st['buttons']);await q.press('제시 취소');await q.wait('r13_topics');assert (await q.state())['room']==before_present
   report['checks']+=['12-card 6x2 pagination covers 34 evidence and6 actual testimony','844x390 touch tabs, selection and page controls','Presentation recipient explicit, no archive toggle, cancel returns to same NPC without mutations']
   report['status']='passed'
  except Exception as e:
   report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
  report['url']=a.url;(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
