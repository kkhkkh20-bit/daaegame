#!/usr/bin/env python3
"""Copy untouched pixel originals and create a browsable source-art catalog."""
import argparse
import json
import shutil
import zipfile
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT.parents[1]
ART = ROOT / 'art/pixel-b'
OUT = REPO / 'preview/room13-pixel-art'
NAMES = dict(daram='다람이', dad='아빠', mom='엄마', granny='할머니', seryeon='세련', nabi='나비', bami='밤이', doto='도토', buri='부리', karo='까로', neoul='너울', guard='돌목')
GROUPS = {'gate':['마을 입구'], 'overview':['마을 전경'], 'room-before':['13호실 · 사건 전'], 'room-after':['13호실 · 사건 후'], 'hall-before':['2층 복도 · 사건 전'], 'hall-after':['2층 복도 · 사건 후'], 'inn':['여관 접수대','주방','비밀 통로','식당'], 'village':['광장','우체국','수리점','마을 골목'], 'locations':['진료소','학교 대피소','창고','온실','수용 시설','산 제단 · 보조 구도'], 'altar':['산 제단'], 'carriage':['마차 안']}
TIMES = {'morning':'오전','afternoon':'오후','evening':'저녁'}

def build(partial=False):
    assets = OUT/'assets'
    assets.mkdir(parents=True, exist_ok=True)
    missing=[]
    sources={}
    def item(spec):
        name=Path(spec['file']).name
        src=ART/name
        if not src.exists():
            missing.append(name)
            return None
        if name not in sources:
            shutil.copyfile(src, assets/name)
            with Image.open(src) as im: size=list(im.size)
            sources[name]={'file':'assets/'+name,'size':size}
        size=sources[name]['size']
        rect=spec.get('crop',spec.get('rect',[0,0,*size]))
        x,y,w,h=rect
        assert 0<=x and 0<=y and w>0 and h>0 and x+w<=size[0] and y+h<=size[1],(name,rect,size)
        return dict(file='assets/'+name,size=size,rect=rect)
    layout_path=ART/'layouts.json'
    layouts=json.loads(layout_path.read_text()) if layout_path.exists() else {k.replace('painted','pixel'):v for k,v in json.loads((ROOT/'art/room13-painted-layouts.json').read_text()).items()}
    if 'layouts' in layouts: layouts=layouts['layouts']
    bg=[]
    for filename, layout in layouts.items():
        key=Path(filename).stem.removeprefix('room13-pixel-')
        group,time=key.rsplit('-',1)
        if group not in GROUPS: continue
        panels=[]
        for n,rect in enumerate(layout['rects']):
            art=item(dict(file=filename,rect=rect))
            if art: panels.append(dict(title=GROUPS[group][n],**art))
        if panels: bg.append(dict(id=key,group=group,time=time,label=TIMES[time],panels=panels))
    content=json.loads((ROOT/'game/room13-content.json').read_text())
    for key,value in content['residents'].items(): NAMES[key]=value['name']
    NAMES.update(resident_owlgp='부엉이 할아버지',resident_lamplighter='초롱',resident_tok='톡',resident_piko='피코',resident_seori='서리 검사원',resident_ppul='뿔이 촌장')
    cast=[]
    for filename,kind in [('cast-main.json','main'),('cast-support.json','support')]:
        path=ART/filename
        if not path.exists():
            missing.append(filename)
            continue
        data=json.loads(path.read_text())
        for key,specs in data.items():
            poses={}
            for pose in (['neutral','thinking','distressed','expressive'] if kind=='main' else ['neutral']):
                if pose not in specs: missing.append(key+':'+pose); continue
                art=item(specs[pose])
                if art: poses[pose]=art
            if poses: cast.append(dict(id=key,name=NAMES.get(key,key),kind=kind,poses=poses))
    cg=[]
    for spec in json.loads((ART/'cinematics.json').read_text())['items']:
        art=item(spec)
        if art: cg.append(dict(id=spec['id'],title=spec['title'],kind=spec['kind'],**art))
    extras=[]
    motion=ART/'room13-pixel-daram-motion.png'
    if motion.exists():
        extra=item({'file':motion.name})
        extras.append(dict(title='다람이 움직임 분리 원화',**extra))
    coverage={'background_files':len(bg),'people':len(cast),'main_people':sum(x['kind']=='main' for x in cast),'support_people':sum(x['kind']=='support' for x in cast),'cinematics':len(cg),'missing':sorted(set(missing))}
    coverage['complete']=(len(bg)==31 and len(cast)==43 and len(cg)==12 and not missing and layout_path.exists())
    data={'revision':'pixel-b-gallery-v1','coverage':coverage,'backgrounds':bg,'cast':cast,'cinematics':cg,'extras':extras,'sources':list(sources.values())}
    (OUT/'catalog.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(coverage,ensure_ascii=False))
    if not partial: assert coverage['complete'],coverage
    if coverage['complete']:
        downloads=OUT/'downloads'
        downloads.mkdir(exist_ok=True)
        target=downloads/'daram-pixel-art.zip'
        with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
            for name in sorted(sources): z.write(ART/name,'art/'+name)
            for name in ['layouts.json','cast-main.json','cast-support.json','cinematics.json','motion.json']:
                z.write(ART/name,'manifests/'+name)
            z.write(OUT/'catalog.json','catalog.json')
            for name in ['Galmuri11.woff2','Galmuri-OFL.txt']: z.write(assets/name,'font/'+name)
            z.writestr('README.txt','다람탐정 B안 도트 원화 모음\n\n31 background sheets + 11 character sheets + 3 cinematic sheets + 1 motion sheet.\n43 characters: 12 main with four expressions, 31 supporting with one neutral drawing.\n12 cinematics: 5 story scenes and 7 endings.\n\nPNG originals are copied unchanged. Rect/crop metadata selects panels at runtime. This archive contains spoiler scenes. Galmuri font license is in font/Galmuri-OFL.txt. This is an art source bundle, not a runnable game.\n')
        assert target.stat().st_size < 100*1024*1024, 'Split archive before publishing: exceeds GitHub file limit'
        with zipfile.ZipFile(target) as z: assert z.testzip() is None
        print(json.dumps({'archive':str(target),'bytes':target.stat().st_size,'source_pngs':len(sources)}))

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--partial',action='store_true')
    build(parser.parse_args().partial)
