"""Actual timeline motion scope and panorama drag checks on an integrated archive."""
import argparse,asyncio,json,shutil
from pathlib import Path
import numpy as np
from PIL import Image
from playwright.async_api import async_playwright
from pixel_qa_flow0150 import FlowQA,ROOT
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',required=True);a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True);report={'kind':'natural-field-and-topics-real-clock-plus-explicit-panorama-fixture'}
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);page=await browser.new_page(viewport={'width':1280,'height':720},has_touch=True);q=FlowQA(page,out)
  async def frames(prefix,rect):
   shots=[]
   for i in range(5):
    await asyncio.sleep(1);path=out/(prefix+'-'+str(i)+'.png');await page.screenshot(path=str(path));im=np.asarray(Image.open(path));x,y,w,h=rect;shots.append(im[y:y+h,x:x+w])
   return max(int(np.any(im!=shots[0],axis=2).sum()) for im in shots[1:])
  try:
   await page.goto(a.url);await page.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;s=renpy.store;s.preferences.text_cps=0;s.persistent.room13_motion=True;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub');await page.mouse.move(1250,10)
   report['field_on_changed_pixels']=await frames('field-on',(40,325,390,300));assert report['field_on_changed_pixels']==0,report
   await q.press('까로');await q.advance();await q.wait('r13_entry_karo_topics');await page.mouse.move(1250,10)
   report['dialogue_on_changed_pixels']=await frames('dialogue-on',(0,145,400,480));assert report['dialogue_on_changed_pixels']>0,report
   await q.py('import renpy;renpy.store.persistent.room13_motion=False;renpy.exports.restart_interaction();result=True');await asyncio.sleep(.3)
   report['dialogue_off_changed_pixels']=await frames('dialogue-off',(0,145,400,480));assert report['dialogue_off_changed_pixels']==0,report
   await q.press('조사');await q.wait('r13_hub')
   await q.py('import renpy\ns=renpy.store\ns.room13=dict(s.room13,location="inn",flags=["lodging","entry_corrected"])\ns.place=s.R13_PLACES["inn"][0]\ns.r13_world_cameras={"inn":0}\nrenpy.exports.scene()\nrenpy.exports.hide_screen("r13_hub")\nrenpy.exports.show_screen("r13_hub",entry=False)\nrenpy.exports.restart_interaction()\nresult=True');await q.wait('r13_hub');await asyncio.sleep(.4)
   st=await q.state();assert not any(b['text'].strip()in('‹','›','둘러보기')for b in st['buttons']);before=st['room']
   await page.mouse.move(900,235);await page.mouse.down();await page.mouse.move(400,235,steps=20);await page.mouse.up();await asyncio.sleep(.3)
   report['drag_offset']=await q.py('import renpy;result=renpy.store.r13_world_offset()');assert report['drag_offset']>0;assert (await q.state())['room']==before;await q.shot('panorama-no-controls-after-drag')
   await page.set_viewport_size({'width':844,'height':390});await q.shot('mobile-panorama-no-controls');report['status']='passed'
  except Exception as e:report.update(status='failed',error=repr(e));await page.screenshot(path=str(out/'failure.png'))
  finally:await browser.close();(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(report,flush=True)
 if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
