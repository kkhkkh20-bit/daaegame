"""Copy immutable generated originals and derive runtime crop metadata.

This script never paints, recolors, resizes or rewrites image pixels.
"""
from pathlib import Path
import json
import shutil
from PIL import Image
import numpy as np
from scipy.ndimage import label, find_objects
from room13_cast_faces import face_crop

ROOT=Path(__file__).resolve().parents[1]
ART=ROOT/'art'
source=json.loads((ART/'room13-film-sources.json').read_text())
layouts={}
for group,times in source['backgrounds'].items():
    for time,path in times.items():
        name=f'room13-painted-{group}-{time}.png'
        shutil.copy2(path,ART/name)
        w,h=Image.open(ART/name).size
        cols,rows=(2,2) if group in ('inn','village') else (3,2) if group=='locations' else (1,1)
        rects=[]
        for row in range(rows):
            for col in range(cols):
                x,y=w*col//cols,h*row//rows
                right,bottom=w*(col+1)//cols,h*(row+1)//rows
                rects.append([x,y,right-x,bottom-y])
        spec=dict(size=[w,h],rects=rects)
        if time=='afternoon':
            details={}
            # Source rectangles are authored in the 1280x720 playable view.
            # Only direct physical details use scene thumbnails. A letter or a
            # written order must not be illustrated as a bed, blanket or food sack.
            crops={'room-before':{'E03':(0,[936,405,95,71])},
                'room-after':{'E07':(0,[595,522,172,78]),'E09':(0,[643,539,110,65])}}
            for key,(index,rect) in crops.get(group,{}).items():
                px,py,pw,ph=rects[index];x,y,rw,rh=rect
                details[key]=[px+round(x*pw/1280),py+round(y*ph/720),round(rw*pw/1280),round(rh*ph/720)]
            if details:spec['evidence']=details
        layouts[name]=spec
(ART/'room13-painted-layouts.json').write_text(json.dumps(layouts,indent=2)+'\n')

def occupied_runs(values):
    runs=[];start=None
    for i,v in enumerate(values+[False]):
        if v and start is None:start=i
        elif not v and start is not None:runs.append((start,i));start=None
    return runs

cast={};review=[]
states=('neutral','thinking','distressed','expressive')
for sheet in source['cast']:
    name='room13-painted-cast-'+sheet['group']+'.png'
    shutil.copy2(sheet['path'],ART/name)
    im=Image.open(ART/name)
    assert im.mode=='RGBA',name
    alpha=im.getchannel('A');w,h=im.size
    assert alpha.getpixel((0,0))<=3,(name,'opaque corner')
    # Whole connected silhouettes avoid cutting a short row at a neighbour's
    # feet/hat. A single horizontal split clipped close-set source sheets.
    row_counts=[4,4] if sheet['expressions'] else ([3,3] if sheet['group']=='recurring' else [4,3])
    labels,count=label(np.asarray(alpha)>80)
    sizes=np.bincount(labels.ravel());sizes[0]=0
    slices=find_objects(labels)
    selected=np.argsort(sizes)[-sum(row_counts):]
    bounds=[]
    for component in selected:
        ys,xs=slices[component-1]
        bounds.append((xs.start,ys.start,xs.stop,ys.stop,int(component)))
    bounds.sort(key=lambda b:b[1])
    bodies=[];offset=0
    for row,count in enumerate(row_counts):
        row_bodies=[]
        for x,y,right,bottom,component in sorted(bounds[offset:offset+count]):
            rect=[max(0,x-2),max(0,y-2),min(w,right+2)-max(0,x-2),min(h,bottom+2)-max(0,y-2)]
            row_bodies.append(rect)
            rx,ry,rw,rh=rect
            others=[int(v) for v in np.unique(labels[ry:ry+rh,rx:rx+rw]) if v!=component and v in selected]
            assert not others,(name,row,'neighbour silhouette in crop',rect,others)
            review.append(dict(sheet=name,row=row,rect=rect,edge_contact=x<=1 or y<=1 or right>=w-1 or bottom>=h-1,neighbour_fragments=others))
        bodies.append(row_bodies);offset+=count
    for i,person in enumerate(sheet['ids']):
        if sheet['expressions']:
            variants=dict(zip(states,bodies[i]))
        elif sheet['group']=='recurring':
            variants={state:bodies[0][i] for state in states}
        else:
            row=0 if i<4 else 1;col=i if i<4 else i-4
            variants={state:bodies[row][col] for state in states}
        entry={}
        for state,rect in variants.items():
            entry[state]=entry['interview_'+state]=dict(file='assets/'+name,crop=rect,nearest=False)
            x,y,bw,bh=rect
            face=face_crop(person,state)
            fx,fy,fw,fh=face
            assert 0<=fx<fx+fw<=w and 0<=fy<fy+fh<=h,(person,state,face)
            entry['avatar_'+state]=dict(file='assets/'+name,crop=face,nearest=False)
        entry['world']=entry['activity']=entry['inn_activity']=entry['neutral']
        # Recurring sheet lower row contains DIFFERENT residents, not work poses.
        # Keep the same identity in world, activity and interview views.
        cast[person]=entry
assert len(cast)==43,len(cast)
(ART/'room13-painted-cast.json').write_text(json.dumps(cast,ensure_ascii=False,indent=2)+'\n')
(ART/'room13-painted-crop-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(f'Installed {len(layouts)} background images and {len(cast)} character identities; originals copied unchanged.')
print('Source sprite edge contacts:',[v for v in review if v['edge_contact']])
