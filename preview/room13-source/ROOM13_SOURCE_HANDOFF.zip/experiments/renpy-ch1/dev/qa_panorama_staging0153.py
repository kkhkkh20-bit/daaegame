"""Explicit source-injected staging census/render fixtures, not story playthroughs."""
import asyncio,json,shutil,textwrap,base64
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_browser import PixelQA,ROOT
OUT=ROOT/'qa-room13-0153/panorama-staging';OUT.mkdir(parents=True,exist_ok=True)
s=(ROOT/'game/room13_acting.rpy').read_text();SRC=textwrap.dedent(s[s.index('    class R13FurnitureMask('):s.index('    def r13_staged_art(')])
CENSUS='''import renpy,copy
s=renpy.store
s.qa_crowd_original=copy.deepcopy(s.room13)
maxima={};conditions=0
for day in range(1,15):
 for period in range(3):
  for victim,granny,case,flags in [('alive','trusted','prevented',[]),('dead','trusted','occurred',['bami_protected']),('alive','detained','prevented',['mom_reunited','shelter_ready','patient_transport','nubi_protected','bami_protected']),('dead','detained','occurred',['mom_reunited','shelter_ready','patient_transport','nubi_protected','bami_protected'])]:
   for loc in ['inn','school','workshop','square']:
    state=copy.deepcopy(s.qa_crowd_original);state.update(day=day,period=period,location=loc,victim_state=victim,granny_state=granny,case_state=case,daram_state='rescued' if day>=8 else 'with_dad');state['flags']+=flags;s.room13=state
    people=list(s.r13_people());actors=s.r13_stage_people();conditions+=1
    assert set(people)==set(a['person'] for a in actors),(day,period,loc,'missing resident')
    assert max([a['rect'][0]+a['rect'][2] for a in actors] or [0])<=s.R13_WORLD_LAYOUTS[loc]['width'],(loc,'world overflow')
    if len(people)>len(maxima.get(loc+'-p'+str(period),{}).get('people',[])):maxima[loc+'-p'+str(period)]={'state':copy.deepcopy(state),'people':people}
result={'maxima':maxima,'conditions':conditions}
'''
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},service_workers='block');pg=await c.new_page();q=PixelQA(pg,OUT);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)));report={'kind':'source-injected-0152-layout-fixtures-not-natural-play','shots':[]}
  try:
   await pg.goto('http://127.0.0.1:8094/room13-release-0152/');await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub');await q.py('import renpy;exec('+repr(SRC)+',renpy.store.__dict__);result=True')
   layouts=json.loads((ROOT/'art/pixel-b/panorama/world-layout.json').read_text())
   await q.py('import renpy;renpy.store.R13_WORLD_LAYOUTS='+ascii(layouts)+';result=True')
   for place,layout in layouts.items():
    for fpath in layout['files'].values():
     f=Path(fpath).name
     data=base64.b64encode((ROOT/'art/pixel-b/panorama'/f).read_bytes()).decode()
     await q.py('import renpy,base64,os;p=renpy.store.config.gamedir+"/assets/qa-"+'+repr(f)+';open(p,"wb").write(base64.b64decode('+repr(data)+'));result=True')
   census=await q.py(CENSUS);report.update(census)
   for loc,row in census['maxima'].items():
    for offset in [0,layouts[row['state']['location']]['width']-1280]:
     data=await q.py("""import renpy
s=renpy.store
s.room13="""+ascii(row['state'])+"""
s.place=s.R13_PLACES[s.room13['location']][0]
for n in ['r13_hub','r13_hud','say']:renpy.exports.hide_screen(n)
renpy.exports.scene()
layout=s.R13_WORLD_LAYOUTS[s.room13['location']]
period=['morning','afternoon','evening'][s.room13['period']]
path='assets/qa-'+layout['files'][period].split('/')[-1]
background=s.Crop(tuple(layout['crops'][period]),path)
renpy.exports.show('qa_crowd_bg',what=s.Transform(background,size=(layout['width'],720),nearest=True),at_list=[s.Transform(xpos=-"""+str(offset)+""")])
actors=s.r13_stage_people()
for i,a in enumerate(actors):
 art=s.r13_staged_art(a)
 if a['occlusion']:art=s.AlphaMask(art,s.R13FurnitureMask(a['occlusion'],size=(a['width'],a['height']),origin=(a['x'],a['y'])),invert=True)
 renpy.exports.show('qa_crowd_'+str(i),what=art,at_list=[s.Transform(xpos=a['x']-"""+str(offset)+""",ypos=a['y'])])
renpy.exports.show_screen('r13_hud')
renpy.exports.restart_interaction()
result={'actors':actors,'people':s.r13_people()}
""")
     assert set(a['person'] for a in data['actors'])==set(data['people']),(loc,data)
     await asyncio.sleep(.5);await pg.screenshot(path=str(OUT/(loc+'-'+str(offset)+'.png')));report['shots'].append({'location':loc,'offset':offset,**data});print('SHOT',loc,offset,len(data['actors']),flush=True)
   await q.py('import renpy;renpy.store.room13=renpy.store.qa_crowd_original;result=True');report['status']='rendered-needs-visual-review'
  except Exception as e:report['status']='failed';report['error']=repr(e);await pg.screenshot(path=str(OUT/'failure.png'))
  report['page_errors']=errors;(OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(report['status'],report.get('error'),flush=True);await b.close()
asyncio.run(main())
