"""Natural playback/investigation path on the exact release archive."""
import asyncio,json,shutil,urllib.request
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_ui0156 import UIQA
from pixel_qa_flow0150 import FLOW_PROBE
OUT=Path('qa-room13-0160');OUT.mkdir(exist_ok=True)
URL='http://127.0.0.1:8094/room13-release-0160/'
class ReleaseQA(UIQA):
 async def state(self):
  probe=FLOW_PROBE.replace('names=[',"names=['r13_records','r13_book','r13_backlog','r13_work_board',")
  st=await self.py('ns={};exec('+ascii(probe)+',ns);result=ns["result"]')
  assert '_exception' not in st['screens'],st
  return st
async def main():
 report={'archive_sha256':json.load(urllib.request.urlopen(URL+'game-transport.json'))['archive_sha256'],'checks':[]}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader'])
  context=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block')
  pg=await context.new_page();q=ReleaseQA(pg,OUT)
  try:
   await pg.goto(URL);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu')
   await q.py('import renpy;s=renpy.store;s.preferences.text_cps=0;s.preferences.afm_time=5;s.preferences.afm_enable=False;s.preferences.afm_after_click=True;result=True')
   await q.press('처음부터');await q.wait('say');await q.shot('01-carriage-playback')
   before=await q.line();await q.press('자동');await asyncio.sleep(3.5);after=await q.line()
   assert after['index']>before['index'],(before['index'],after['index'])
   await q.press('백로그');await q.wait('r13_backlog');held=await q.line();await q.shot('02-backlog')
   assert not await q.py('import renpy;result=renpy.store.r13_auto_can_advance()')
   await asyncio.sleep(3.5);assert (await q.line())['index']==held['index']
   await q.press('대화로 돌아가기');await q.wait('say')
   if await q.py('import renpy;result=renpy.store.preferences.afm_enable'):await q.press('자동')
   report['checks'].append('Real auto button advances dialogue; backlog pauses auto and preserves current line')
   await q.advance();await q.wait('r13_hub');assert (await q.room())['location']=='room13'
   await q.input(195,400);await q.advance()
   if 'r13_object_context' in (await q.state())['screens']:await q.press('그만 살펴본다')
   await q.wait('r13_hub');assert 'M01' in (await q.room())['evidence']
   await q.press('기록');await q.wait('r13_records');await q.shot('03-compact-evidence')
   await q.press('엄마의 메모');await q.shot('04-evidence-detail');await q.press('닫기');await q.wait('r13_hub')
   await q.input(700,360);await q.advance()
   if 'r13_object_context' in (await q.state())['screens']:await q.press('그만 살펴본다')
   await q.wait('r13_hub');await q.press('자기');await q.wait('r13_confirm');await q.press('자기');await q.advance();await q.wait('r13_hub')
   await q.press('지도 · 이동');await q.wait('r13_map');await q.shot('05-inn-map');await q.press('여관 밖으로');await q.shot('06-world-map')
   await q.press('입구');await q.press('이곳으로 이동');await q.advance();await q.wait('r13_hub')
   await q.value(('person','karo'));await q.advance();await q.wait('r13_topics');await q.shot('07-central-choice')
   await q.press('마차는 언제');await q.wait('say');await q.press('자동');await q.advance();await q.wait('r13_topics')
   snapshot=await q.room();await asyncio.sleep(3);assert await q.room()==snapshot
   assert not await q.py('import renpy;result=renpy.store.r13_auto_can_advance()')
   report['checks'].append('Auto ends on topic selection and never chooses a question')
   await q.press('제시');await q.wait('r13_book');await q.shot('08-presentation')
   await q.press('엄마의 메모');await q.press('까로에게 보여주기');await q.advance()
   if 'r13_confirm' in (await q.state())['screens']:
    await q.press('보여준다');await q.advance()
   await q.wait('r13_topics')
   await q.press('백로그');await q.wait('r13_backlog');await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.shot('09-mobile-backlog');await q.press('대화로 돌아가기');await q.wait('r13_topics')
   await q.press('돌아가기');await q.advance();await q.wait('r13_hub');await q.press('기록');await q.wait('r13_records');await q.shot('10-mobile-evidence');await q.press('닫기');await q.wait('r13_hub')
   await q.save(1);saved=await q.room();await q.load(1);assert (await q.room())==saved
   report['checks'].append('Map travel, owned evidence selection/presentation, desktop/mobile compact panels and actual save/load')
   report['status']='passed'
  except Exception as e:
   report.update(status='failed',error=repr(e));await pg.screenshot(path=str(OUT/'failure.png'))
   try:(OUT/'failure-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
   except:pass
  (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']=='failed':raise SystemExit(1)
asyncio.run(main())
