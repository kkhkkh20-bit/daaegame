"""Natural proof route: population continuity and revised field interactions."""
import argparse,asyncio,json,shutil,urllib.request
from playwright.async_api import async_playwright
from pixel_qa_flow0150 import FlowQA,ROOT,FLOW_PROBE

class GateQA(FlowQA):
 async def state(self):
  probe=FLOW_PROBE.replace('names=[',"names=['r13_gate_document_inspection','r13_records',")
  st=await self.py('ns={};exec('+ascii(probe)+',ns);result=ns["result"]')
  assert '_exception' not in st['screens'],st
  return st
 async def population(self):
  return await self.py("import renpy;s=renpy.store;sc=renpy.display.screen.get_screen('r13_hub');result={'entry':sc.scope['entry'],'scheduled':s.r13_people(),'actors':s.r13_stage_people(sc.scope['entry']),'clock':[s.room13['day'],s.room13['period']]}")
 async def portrait(self):
  return await self.py("import renpy;s=renpy.store;w=renpy.exports.get_widget('say','what');result={'speaker':s.dialogue_speaker,'thought':s.r13_thought_active,'portrait':renpy.exports.get_widget('say','r13_dialogue_portrait') is not None,'frame':renpy.exports.get_widget('say','dialogue_portrait_frame') is not None,'text':w.text if w else None}")

async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',default='qa-room13-0153/gate-final');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True);report={'kind':'natural-first-entry-proof-route-real-mouse-and-touch','checks':[]}
 report['archive_sha256']=json.load(urllib.request.urlopen(a.url+'game-transport.json'))['archive_sha256']
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=GateQA(pg,out);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub')
   before=await q.population();assert set(before['scheduled'])=={'karo','resident_kkwak','guard'},before;assert set(x['person']for x in before['actors'])==set(before['scheduled']);await q.shot('01-natural-entry-three-residents')
   await pg.mouse.click(680,275,button='right');await asyncio.sleep(.4);assert 'pause_menu'not in(await q.state())['screens'];await q.press('옵션');await q.wait('pause_menu');await q.press('돌아가기');await q.wait('r13_hub');report['checks'].append('Right click stays field; explicit Options opens and closes')
   await q.input(1069,384);await q.wait('say');daram=await q.portrait();assert daram['speaker']=='daram' and daram['portrait'];await q.shot('02-window-daram-real-dialogue');await q.input(810,640);await q.wait('say');dad=await q.portrait();assert dad['speaker']=='dad' and not dad['portrait'];await q.shot('03-dad-spoken-no-avatar');await q.advance();await q.wait('r13_hub')
   await q.press('꽥순');await q.advance();await q.wait('r13_topics');assert await q.py("import renpy;result=renpy.display.screen.get_screen('r13_topics').scope['person']")=='resident_kkwak';await q.shot('04-initial-resident-talkable');await q.press('조사');await q.wait('r13_hub')
   await q.input(160,402);await q.wait('r13_entry_karo_topics');await q.value('bags');await q.wait('say');assert(await q.portrait())['speaker']=='karo';await q.shot('05-karo-profile-in-frame');await q.advance();await q.wait('r13_entry_karo_topics');assert'question_read:entry:karo:bags'in(await q.state())['room']['flags'];await q.shot('06-question-struck-through');await q.press('조사');await q.wait('r13_hub')
   await q.input(1128,410);await q.wait('r13_gate_document_inspection');await q.press('기록하기');await q.wait('r13_gate_document_inspection');await q.press('옮겨 쓴 명부');await q.press('기록하기');await q.wait('r13_gate_document_inspection');await q.shot('07-original-copy-recorded');await q.press('닫기');await q.wait('r13_hub');assert{'G1','G3'}<=set((await q.state())['room']['evidence'])
   await q.input(390,321);await q.wait('say');thought=await q.portrait();assert thought['speaker']=='dad' and thought['thought'] and not thought['portrait'];await q.shot('08-dad-blue-thought-no-avatar');await q.advance();await q.wait('r13_hub');assert'G2'in(await q.state())['room']['evidence']
   await q.press('돌목');await q.wait('r13_entry_topics');await q.press('제시');await q.wait('r13_book');short=await q.py("import renpy;result=renpy.store.R13_RECORD_SHORT.get('G1',renpy.store.ROOM13['evidence']['G1']['name'])");await q.press(short);await q.press('돌목에게 보여주기');await q.wait('say');await q.shot('09-guard-evidence-card');await q.advance();await q.wait('choice');await q.press('원본에는 두 명');await q.advance();await q.wait('r13_hub');after=await q.population();assert before['clock']==after['clock'] and before['scheduled']==after['scheduled'];assert before['actors']==after['actors'],(before,after);assert not after['entry'];await q.shot('10-permission-same-residents');report['checks'].append({'same_time_population_and_placement':True,'before':before,'after':after})
   await q.press('돌목');await q.advance();await q.wait('r13_topics');await q.value('gate_guard_duty');await q.advance();await q.wait('r13_topics');await q.press('조사');await q.wait('r13_hub');report['checks'].append('Guard stays and work question returns to same topic screen')
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.input(160,402);await q.advance();await q.wait('r13_topics');assert await q.py("import renpy;result=renpy.display.screen.get_screen('r13_topics').scope['person']")=='karo';await q.shot('11-mobile-visible-karo-click');await q.press('조사');await q.wait('r13_hub');await q.input(1128,410);await q.wait('r13_gate_document_inspection');await q.shot('12-mobile-recorded-document-popup');report['checks'].append('Mobile letterboxed visible actor and shelf tap select correct targets')
   assert not errors,errors;report.update(status='passed',portrait_checks=[daram,dad,thought])
  except Exception as e:report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
  report.update(url=a.url,errors=errors);(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items()if k!='checks'},ensure_ascii=False));await b.close()
  if report['status']!='passed':raise SystemExit(1)

if __name__=='__main__':asyncio.run(main())
