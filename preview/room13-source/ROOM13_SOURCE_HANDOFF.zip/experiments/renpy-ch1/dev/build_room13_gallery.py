#!/usr/bin/env python3
"""Publish original Room13 artwork with browser-only atlas crops. No pixel rewriting."""
import argparse
import json
import shutil
from pathlib import Path
from PIL import Image

PROJECT = Path(__file__).resolve().parents[1]
ART = PROJECT / 'art'
DEFAULT = PROJECT.parents[1] / 'preview' / 'room13-art'
GROUPS = {
    'overview': ['눈 속의 마을'], 'gate': ['마을 입구'],
    'room-before': ['13호실 · 사건 전'], 'room-after': ['13호실 · 사건 후'],
    'hall-before': ['2층 끝 복도 · 사건 전'], 'hall-after': ['2층 끝 복도 · 사건 후'],
    'inn': ['여관 식당', '여관 주방', '세탁실 통로', '주민 회의실'],
    'village': ['마을 광장', '우편실', '수리점', '마을 골목'],
    'locations': ['진료소', '학교', '물자 창고', '온실', '돌 관리 시설', '시설 안쪽'],
    'altar': ['북쪽 산길 · 숲속 제단'], 'carriage': ['마을로 향하는 마차'],
}
CORE = dict(daram='다람', dad='아빠', mom='엄마', granny='할머니', seryeon='세련', nabi='나비', bami='밤이', doto='도토', buri='부리', karo='까로', neoul='너울', guard='경비')
EXPRESSIONS = dict(neutral='평소', thinking='생각', distressed='불안', expressive='감정', activity='일하는 모습')

def build(destination):
    destination.mkdir(parents=True, exist_ok=True)
    (destination/'images').mkdir(exist_ok=True)
    copied = {}
    def asset(file):
        name = Path(file).name
        source = ART/name
        if not source.is_file():
            raise FileNotFoundError(source)
        if name not in copied:
            shutil.copy2(source, destination/'images'/name)
            with Image.open(source) as im:
                size = list(im.size)
            copied[name] = {'file':'images/'+name,'size':size}
        return copied[name]
    layouts = json.loads((ART/'room13-painted-layouts.json').read_text())
    backgrounds=[]
    for group,titles in GROUPS.items():
        for i,title in enumerate(titles):
            variants={}
            for time in ('morning','afternoon','evening'):
                name=f'room13-painted-{group}-{time}.png'
                if name in layouts:
                    variants[time]={**asset(name),'crop':layouts[name]['rects'][i]}
            if variants:
                backgrounds.append({'id':f'{group}-{i}','title':title,'variants':variants,'spoiler':group.endswith('after')})
    residents=json.loads((PROJECT/'game/room13-content.json').read_text()).get('residents',{})
    profiles=json.loads((PROJECT/'game/village-residents.json').read_text()).get('profiles',{})
    cast=[]
    for person,states in json.loads((ART/'room13-painted-cast.json').read_text()).items():
        variants={}; seen=set()
        for state,title in EXPRESSIONS.items():
            if state not in states: continue
            spec=states[state]; signature=(spec['file'],tuple(spec['crop']))
            if signature in seen: continue
            seen.add(signature)
            variants[state]={**asset(spec['file']),'crop':spec['crop'],'title':title}
        cast.append({'id':person,'title':CORE.get(person,residents.get(person,profiles.get(person,{})).get('name',person)), 'variants':variants})
    cinematics=[]
    # Optional exported cinematic manifest; no source paths or private metadata go public.
    for manifest in (ART/'room13-cinematics.json', ART/'room13-cinematic-gallery.json'):
        if not manifest.exists(): continue
        raw=json.loads(manifest.read_text())
        items=raw.get('items',[]) if isinstance(raw,dict) else raw
        for item in items:
            if not isinstance(item,dict) or not item.get('file'): continue
            spec=asset(item['file']); w,h=spec['size']
            cinematics.append({'id':item.get('id',Path(item['file']).stem),'title':item.get('title','장면 시안'),'spoiler':item.get('spoiler',True), 'variants':{'scene':{**spec,'crop':item.get('crop',item.get('rect',[0,0,w,h])),'title':'장면'}}})
    data={'backgrounds':backgrounds,'cast':cast,'cinematics':cinematics,'originals':len(copied)}
    (destination/'gallery.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    (destination/'index.html').write_text(HTML,encoding='utf-8')
    print(json.dumps({'destination':str(destination),'backgrounds':len(backgrounds),'cast':len(cast),'cinematics':len(cinematics),'originals':len(copied)},ensure_ascii=False))

HTML = r'''<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="theme-color" content="#283c36"><title>다람탐정 — 그림 수첩</title>
<style>
:root{--paper:#f5f0e6;--ink:#2c3933;--muted:#72786a;--line:#dcd5c7;--green:#314c40;--gold:#b89858}*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font-family:system-ui,-apple-system,"Noto Sans KR",sans-serif}a{color:inherit}button,select{font:inherit}button,a,select{ -webkit-tap-highlight-color:transparent}button{cursor:pointer}button:focus-visible,a:focus-visible,select:focus-visible{outline:3px solid #bf8c39;outline-offset:4px}header{background:#293e36;color:#f5efdd;padding:30px max(24px,calc((100vw - 1280px)/2));display:flex;align-items:center;justify-content:space-between;gap:16px}header a{text-decoration:none;font-size:13px;border:1px solid #8b9786;padding:10px 16px;border-radius:30px}.brand{letter-spacing:.15em;font-size:12px}.hero{max-width:1280px;margin:auto;padding:54px 24px 30px;display:flex;justify-content:space-between;align-items:flex-end;gap:24px}.eyebrow{font-size:11px;letter-spacing:.22em;color:var(--muted)}h1{font-family:Georgia,"Nanum Myeongjo",serif;font-weight:500;font-size:clamp(34px,5vw,58px);margin:12px 0 16px;letter-spacing:-.06em}.hero p{line-height:1.9;font-size:14px;max-width:640px;margin:0;color:#626a5f}.seal{border:1px solid #b3a984;border-radius:50%;width:90px;height:90px;display:grid;place-content:center;text-align:center;font-family:Georgia,serif;color:#8b7951;font-size:12px;flex-shrink:0;transform:rotate(-7deg)}.seal b{font-size:25px;font-weight:400}main{max-width:1280px;padding:0 24px 60px;margin:auto}.toolbar{position:sticky;top:0;z-index:3;background:#f5f0e6f5;border-top:1px solid var(--line);border-bottom:1px solid var(--line);padding:14px 0;display:flex;gap:18px;flex-wrap:wrap;align-items:center;justify-content:space-between;backdrop-filter:blur(10px)}.tabs,.times,.controls{display:flex;gap:6px;align-items:center;flex-wrap:wrap}.tabs button,.times button,.lightbutton{border:0;padding:9px 15px;border-radius:30px;background:transparent;color:#72786a}.tabs button[aria-selected=true]{background:var(--green);color:#fff7e7}.times{border:1px solid var(--line);border-radius:30px;padding:3px}.times button{padding:6px 12px;font-size:13px}.times button[aria-pressed=true]{background:#e3dbca;color:#293e36}.check{font-size:12px;display:flex;align-items:center;gap:5px}.check input{accent-color:var(--green);width:16px;height:16px}#summary{margin:20px 0;color:var(--muted);font-size:12px;line-height:1.8}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:28px 24px}.card{min-width:0;margin:0}.artbutton{padding:0;border:0;display:block;width:100%;background:transparent;text-align:inherit;color:inherit}.picture{overflow:hidden;position:relative;display:block;background:#dfdfd2;isolation:isolate}.picture img{position:absolute;max-width:none;display:block;height:auto}.card .picture{border-radius:4px;box-shadow:0 6px 18px #3836260d;transition:box-shadow .2s}.artbutton:hover .picture{box-shadow:0 8px 25px #38362625}.caption{display:flex;align-items:baseline;justify-content:space-between;gap:12px;padding:13px 1px}.caption h2{font-size:15px;font-weight:500;margin:0}.caption span{font-size:11px;color:var(--muted)}.compare{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px}.compare figure{margin:0}.compare small{display:block;text-align:center;margin-top:7px;color:#757866;font-size:11px}.cast-grid{grid-template-columns:repeat(5,minmax(0,1fr));gap:24px 18px}.cast-stage{height:265px;display:flex;justify-content:center;align-items:flex-end;background:#e9e5d8;border-radius:4px;padding:20px 14px 0}.cast-stage .picture{background:transparent;box-shadow:none;border-radius:0;max-width:100%;height:100%;width:auto;max-height:100%}.cast-stage .picture img{height:auto}.cast-grid .caption{justify-content:center;flex-wrap:wrap;gap:6px}.cast-grid .caption span{width:100%;text-align:center}.empty{padding:80px 25px;border:1px dashed var(--line);text-align:center;color:var(--muted);grid-column:1/-1}.spoiler-note{background:#ebe4d6;border-left:3px solid var(--gold);padding:20px;font-size:13px;line-height:1.8;grid-column:1/-1}.spoiler-note button{background:var(--green);border:0;border-radius:25px;color:#fff;padding:10px 18px;margin:12px 0 0}.foot{border-top:1px solid var(--line);padding:24px 0;margin-top:45px;color:var(--muted);font-size:12px;line-height:1.9}.foot a{text-underline-offset:4px}dialog{border:0;padding:0;background:#eee8dc;color:var(--ink);max-width:min(1180px,94vw);width:1180px;max-height:94dvh;border-radius:8px;box-shadow:0 20px 80px #0005}dialog::backdrop{background:#12241ae0}.dialogbar{padding:14px 20px;display:flex;justify-content:space-between;align-items:center;gap:12px;position:sticky;top:0;background:#eee8dc;z-index:2}.dialogbar h2{font-size:17px;font-weight:500;margin:0}.close{border:1px solid #cec5b4;border-radius:50%;width:36px;height:36px;font-size:23px;background:transparent}.dialogbody{padding:0 20px 20px}.dialogbody .picture{max-height:70vh;margin:auto}.dialogbody .cast-stage{height:62vh;background:#e1dfd3;padding:18px}.dialogfooter{display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between;margin-top:15px}.dialogfooter select{border:1px solid var(--line);background:var(--paper);border-radius:20px;padding:8px 14px}.download{font-size:12px;border-bottom:1px solid #aaa18e;text-decoration:none;padding:8px 0}.dialoghint{font-size:11px;color:var(--muted);margin:12px 0 0;line-height:1.6}[hidden]{display:none!important}@media(max-width:900px){.cast-grid{grid-template-columns:repeat(3,minmax(0,1fr))}.cast-stage{height:245px}.seal{display:none}.controls{width:100%;justify-content:space-between}.toolbar{gap:10px}.hero{padding-top:35px}}@media(max-width:560px){header{padding:20px}header a{font-size:11px;padding:8px 12px}.hero{padding:30px 20px 25px}.hero p{font-size:12px}main{padding:0 16px 35px}.grid{grid-template-columns:1fr;gap:22px}.cast-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:20px 12px}.cast-stage{height:235px}.tabs button{font-size:12px;padding:8px 12px}.times button{font-size:11px;padding:6px 9px}.check{font-size:11px}.caption h2{font-size:14px}.dialogbar{padding:12px}.dialogbody{padding:0 12px 15px}.dialogbody .cast-stage{height:58vh}.dialogfooter{align-items:flex-start}.controls{gap:10px}.toolbar{position:relative}.compare{gap:4px}}
@media(prefers-reduced-motion:reduce){*{transition:none!important;scroll-behavior:auto!important}}
</style></head><body>
<header><div class="brand">DARAM DETECTIVE · ART BOOK</div><a href="../room13-dev/">게임으로 돌아가기 ↗</a></header>
<section class="hero"><div><div class="eyebrow">WINTER VILLAGE / VISUAL STUDIES</div><h1>마을을 그린 수첩</h1><p>눈이 쌓인 골목, 불이 켜진 창문, 저마다의 표정을 가진 주민들.<br>다람탐정의 배경과 인물, 이야기 속 장면을 한 장씩 살펴보세요.</p></div><div class="seal">THIRTEENTH<br><b>13</b>ROOM</div></section>
<main><div class="toolbar"><nav class="tabs" role="tablist" aria-label="그림 종류"><button role="tab" data-tab="backgrounds" aria-selected="true">배경</button><button role="tab" data-tab="cast" aria-selected="false">등장인물</button><button role="tab" data-tab="cinematics" aria-selected="false">컷씬·엔딩</button></nav><div class="controls"><div class="times" aria-label="시간대"><button data-time="morning" aria-pressed="false">오전</button><button data-time="afternoon" aria-pressed="true">오후</button><button data-time="evening" aria-pressed="false">저녁</button></div><label class="check" id="compare-label"><input id="compare" type="checkbox">나란히 비교</label><label class="check"><input id="spoilers" type="checkbox">사건·결말 보기</label></div></div>
<p id="summary" role="status">그림 수첩을 펼치는 중입니다.</p><section class="grid" id="gallery" aria-label="그림 목록"></section>
<footer class="foot">그림을 누르면 크게 볼 수 있습니다. 시간대 비교와 표정 선택은 이 수첩 안에서 자유롭게 할 수 있어요.<br>원본 다운로드는 배경·캐릭터·컷씬 원화 시트 전체를 저장합니다. <a href="../room13-dev/">다람탐정 플레이하기</a></footer></main>
<dialog id="viewer" aria-labelledby="viewer-title"><div class="dialogbar"><h2 id="viewer-title"></h2><button class="close" aria-label="확대 보기 닫기">×</button></div><div class="dialogbody"><div id="viewer-art"></div><div class="dialogfooter"><select id="variant" aria-label="시간대 또는 표정 선택"></select><a id="download" class="download" download>원본 PNG 다운로드 ↓</a></div><p class="dialoghint">여러 그림이 함께 있는 원화는 전체 시트로 다운로드됩니다.</p></div></dialog>
<script>
'use strict';
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const names={morning:'오전',afternoon:'오후',evening:'저녁',scene:'장면'};
let data,tab='backgrounds',time='afternoon',active,activeVariant;
function picture(spec,title,eager=false){const frame=document.createElement('span');frame.className='picture';const [x,y,w,h]=spec.crop,[W,H]=spec.size;frame.style.aspectRatio=`${w}/${h}`;const img=document.createElement('img');img.alt=title;img.loading=eager?'eager':'lazy';img.decoding='async';img.src=spec.file;img.style.width=`${W/w*100}%`;img.style.left=`${-x/w*100}%`;img.style.top=`${-y/h*100}%`;frame.append(img);return frame}
function choose(item){return item.variants[time]?time:Object.keys(item.variants)[0]}
function open(item,key){active=item;activeVariant=key;$('#viewer-title').textContent=item.title;const select=$('#variant');select.replaceChildren();Object.entries(item.variants).forEach(([k,v])=>{const o=document.createElement('option');o.value=k;o.textContent=v.title||names[k]||k;select.append(o)});select.value=key;showVariant();$('#viewer').showModal()}
function showVariant(){const spec=active.variants[activeVariant];const art=$('#viewer-art');art.replaceChildren();const p=picture(spec,active.title,true);if(tab==='cast'){const stage=document.createElement('div');stage.className='cast-stage';stage.append(p);art.append(stage)}else art.append(p);$('#download').href=spec.file;$('#download').download=spec.file.split('/').pop()}
function render(){const container=$('#gallery');container.replaceChildren();container.className='grid'+(tab==='cast'?' cast-grid':'');$('.times').hidden=tab!=='backgrounds';$('#compare-label').hidden=tab!=='backgrounds';const items=data[tab],spoilers=$('#spoilers').checked;const visible=items.filter(item=>!item.spoiler||spoilers);$('#summary').textContent=tab==='backgrounds'?`${visible.length}개의 공간 · 같은 장소의 빛을 비교해 보세요.`:tab==='cast'?`${visible.length}명의 주민 · 인물을 누르면 표정을 살펴볼 수 있어요.`:`${visible.length}개의 장면 · 사건과 결말 그림은 별도로 펼쳐 봅니다.`;
if(items.some(i=>i.spoiler)&&!spoilers){const note=document.createElement('div');note.className='spoiler-note';note.textContent='사건 이후의 흔적과 이야기의 결말이 담긴 그림은 접어 두었어요.';const b=document.createElement('button');b.textContent='사건·결말 그림도 펼치기';b.onclick=()=>{$('#spoilers').checked=true;render()};note.append(document.createElement('br'),b);container.append(note)}
if(!visible.length){const p=document.createElement('div');p.className='empty';p.textContent=items.length?'위의 버튼으로 장면을 펼쳐 볼 수 있습니다.':'새 장면이 수첩에 추가되면 여기에서 볼 수 있습니다.';container.append(p)}
visible.forEach(item=>{const card=document.createElement('article');card.className='card';let key=choose(item);if(tab==='backgrounds'&&$('#compare').checked){const group=document.createElement('div');group.className='compare';Object.entries(item.variants).forEach(([k,spec])=>{const fig=document.createElement('figure'),button=document.createElement('button');button.className='artbutton';button.setAttribute('aria-label',`${item.title} ${names[k]} 크게 보기`);button.append(picture(spec,`${item.title} ${names[k]}`));button.onclick=()=>open(item,k);const label=document.createElement('small');label.textContent=names[k];fig.append(button,label);group.append(fig)});card.append(group)}else{const button=document.createElement('button');button.className='artbutton';button.setAttribute('aria-label',`${item.title} 크게 보기`);const p=picture(item.variants[key],item.title);if(tab==='cast'){const stage=document.createElement('div');stage.className='cast-stage';stage.append(p);button.append(stage)}else button.append(p);button.onclick=()=>open(item,key);card.append(button)}const caption=document.createElement('div');caption.className='caption';const h=document.createElement('h2');h.textContent=item.title;const tag=document.createElement('span');tag.textContent=tab==='cast'?`${Object.keys(item.variants).length}가지 모습`:tab==='backgrounds'?(item.spoiler?'사건 이후':names[key]):'이야기 장면';caption.append(h,tag);card.append(caption);container.append(card)})}
$$('[data-tab]').forEach(b=>b.onclick=()=>{tab=b.dataset.tab;$$('[data-tab]').forEach(n=>n.setAttribute('aria-selected',String(n===b)));render()});
$$('[data-time]').forEach(b=>b.onclick=()=>{time=b.dataset.time;$$('[data-time]').forEach(n=>n.setAttribute('aria-pressed',String(n===b)));render()});
$('#compare').onchange=render;$('#spoilers').onchange=render;$('#variant').onchange=e=>{activeVariant=e.target.value;showVariant()};$('.close').onclick=()=>$('#viewer').close();$('#viewer').onclick=e=>{if(e.target===$('#viewer')){const r=e.target.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)e.target.close()}};
fetch('gallery.json').then(r=>{if(!r.ok)throw Error(r.status);return r.json()}).then(d=>{data=d;render()}).catch(()=>{$('#summary').textContent='그림 목록을 불러오지 못했습니다. 잠시 뒤 새로고침해 주세요.'});
</script></body></html>'''

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--destination',type=Path,default=DEFAULT)
    args=parser.parse_args();build(args.destination)
