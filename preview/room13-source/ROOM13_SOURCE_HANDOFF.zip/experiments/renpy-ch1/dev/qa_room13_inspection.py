"""Natural-entry, actual click/touch and save/load acceptance for desk puzzle."""
import argparse,asyncio,json,shutil,traceback
from playwright.async_api import async_playwright
from qa_room13_0153_helpers import FlowQA,ROOT
class InspectionQA(FlowQA):
 async def state(self):
  st=await super().state();st['screens']+=await self.py("import renpy;result=[n for n in ['r13_desk_inspection','r13_item_bag'] if renpy.display.screen.get_screen(n)]");return st
 async def isp(self):return await self.py("import renpy;result=renpy.store.r13_inspection_state()")
 async def scope(self):return await self.py("import renpy;s=renpy.display.screen.get_screen('r13_desk_inspection');result={k:s.scope[k] for k in ['view','selected','lens','message']} if s else None")
 async def target(self,name):
  r=await self.py("import renpy;s=renpy.store;v=renpy.display.screen.get_screen('r13_desk_inspection').scope['view'];result=s.R13_INSPECTION_LAYOUT[v]['targets'][%r]"%name);x,y,w,h=r;await self.input(x+w/2,y+h/2)
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',default='qa-room13-0153/inspection');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True);report={'kind':'natural entry and lodging, actual item puzzle clicks/touch/save-load','checks':[]}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=InspectionQA(pg,out)
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.natural_entry('wait')
   await q.travel('여관 접수대');await q.press('할머니');await q.advance();await q.wait('r13_topics');await q.value('register');await q.advance();await q.press('돌아가기');await q.advance();await q.wait('r13_hub');await q.travel('13호실','여관 안')
   before=(await q.state())['room'];await q.value(('object','desk'));await q.wait('r13_desk_inspection');await q.shot('01-desk')
   for key in ['pencil','paper','ruler']:await q.target(key)
   assert set((await q.isp())['inventory'])=={'pencil','paper','ruler'};await q.shot('02-items-collected')
   await q.target('drawer');assert (await q.scope())['view']=='drawer';await q.shot('03-drawer')
   await q.press('납작한 자');await q.target('divider');assert not (await q.isp())['compartment_open'];await q.press('선택 해제')
   await q.press('짧은 연필');await q.target('tag');assert not (await q.isp())['rubbing'];await q.press('선택 해제')
   report['checks'].append('Wrong-order item use rejected without consuming tools')
   await q.press('얇은 종이');await q.target('tag');assert (await q.isp())['paper_placed'];assert 'paper'not in (await q.isp())['inventory'];await q.shot('04-paper-placed')
   await q.press('책상으로');await q.press('방으로');await q.wait('r13_hub')
   expected=await q.isp();await q.press('옵션');await q.wait('pause_menu');await q.press('저장');await q.wait('save');await q.press('슬롯 2');await asyncio.sleep(.5);await q.press('돌아가기')
   if 'pause_menu'in(await q.state())['screens']:await q.press('돌아가기')
   await q.wait('r13_hub');await q.press('옵션');await q.wait('pause_menu');await q.press('불러오기');await q.wait('load');await q.press('슬롯 2');await q.wait('r13_hub');assert await q.isp()==expected
   report['checks'].append('Real save/load in middle of puzzle preserves placed paper and tools')
   await q.value(('object','desk'));await q.wait('r13_desk_inspection');await q.target('drawer')
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await asyncio.sleep(.6)
   await q.press('짧은 연필');await q.target('tag');assert (await q.isp())['rubbing'];await q.shot('05-mobile-rubbing')
   await q.press('납작한 자');await q.target('divider');assert (await q.isp())['compartment_open'];await q.shot('06-mobile-compartment')
   await q.target('compartment');await q.target('compartment');assert (await q.isp())['inventory'].count('magnifier')==1
   await q.press('접이식 돋보기');await q.target('buttons');assert (await q.scope())['lens']==['drawer','buttons'] or tuple((await q.scope())['lens'])==('drawer','buttons');await q.shot('07-mobile-magnifier')
   prior=await q.isp();await q.input(450,655);assert await q.isp()==prior and (await q.scope())['lens']
   await pg.keyboard.press('Escape');await asyncio.sleep(.3);assert not (await q.scope())['lens'];await pg.keyboard.press('Escape');await asyncio.sleep(.3);assert not (await q.scope())['selected'];await pg.keyboard.press('Escape');await asyncio.sleep(.3);assert (await q.scope())['view']=='desk'
   await q.press('접이식 돋보기');await q.target('letters');assert (await q.scope())['lens'];await q.shot('08-mobile-letter-enlarged');await q.press('돋보기 내려놓기');await q.press('선택 해제');await q.press('방으로');await q.wait('r13_hub')
   after=(await q.state())['room']
   for key in ['day','period','location','evidence','flags','daram_state','case_state','records']:assert after[key]==before[key],key
   report['checks']+=['844x390 touch solves rubbing, divider and one-time magnifier reward','Magnifier really enlarges drawer buttons and desk letter; outside clicks blocked','Escape dismisses lens, then item selection, then drawer in order','Puzzle leaves time, evidence, flags, case and location unchanged']
   report['items']=await q.isp();report['status']='passed'
  except Exception as e:
   report.update(status='failed',error=repr(e),traceback=traceback.format_exc());await pg.screenshot(path=str(out/'failure.png'))
  report['url']=a.url;(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
