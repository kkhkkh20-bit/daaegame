"""B-direction acceptance. Real input routes are separate from injected visual fixtures.
Does not mutate shipped game files; uses engine scripting only for the explicitly
labelled visual matrix. Natural runs mutate preferences only (instant text), never
inventory, flags, evidence, time, or choices.
"""
import argparse, asyncio, html, json, shutil
from pathlib import Path
from playwright.async_api import async_playwright
from qa_room13_ui0122 import QA, ROOT, PROBE
PIXEL_PROBE=PROBE.replace("names=[", "names=['_exception','r13_entry_topics',")

class PixelQA(QA):
 async def py(self,code):
  return await asyncio.wait_for(self.p.evaluate('code=>renpy_exec(code)',code),30)
 async def state(self):
  st=await self.py('ns={};exec('+repr(PIXEL_PROBE)+',ns);result=ns["result"]')
  assert '_exception' not in st['screens'],('RenPy exception screen',st)
  return st
 async def press(self,label):
  if label in ('확인한 자료','원본 대조'):
   st=await self.state()
   if not any(label in b['text'] for b in st['buttons']):
    await super().press('대화');await self.wait('r13_entry_topics');await self.shot('entry-topics')
  return await super().press(label)
 async def npc(self,person):
  # Click the live engine focus rectangle, never a presumed row/grid position.
  import ast
  st=await self.state();matches=[]
  for b in st['buttons']:
   try:value=ast.literal_eval(b.get('value',''))
   except (ValueError,SyntaxError):continue
   if value==('person',person):matches.append(b)
  assert matches,('No live resident hitbox',person,st)
  b=min(matches,key=lambda b:b['rect'][2]*b['rect'][3]);x,y,w,h=b['rect'];assert w>0 and h>0 and 0<=x+w/2<=1280 and 0<=y+h/2<625,b
  await self.input(x+w/2,y+h/2);await self.advance();await self.wait('r13_interaction')
 async def display_info(self):
  return await self.py("import renpy; result={'version':renpy.store.config.version,'showing':sorted(renpy.exports.get_showing_tags()),'entry':bool(renpy.display.screen.get_screen('r13_hub') and renpy.display.screen.get_screen('r13_hub').scope.get('entry'))}")
 async def proof_route(self):
  await self.wait('main_menu');await self.shot('01-title');await self.press('처음부터');await self.advance();await self.wait('r13_hub');await self.shot('02-entry-characters')
  assert (await self.display_info())['entry']
  self.events.append('Fresh entry reached with real inputs; screenshot records guard/Daram positioning')
  before=(await self.state())['room'];await self.press('대화');await self.wait('r13_entry_topics');await self.shot('02b-entry-topics');await self.press('주변을 더');await self.wait('r13_hub');assert (await self.state())['room']==before
  await self.press('자료 제시');await self.wait('r13_book');await self.press('제시 취소');await self.wait('r13_hub');assert (await self.state())['room']==before
  self.events.append('Entry topics and evidence cancel return safely without spending time or disclosing information')
  await self.press('조사');await self.wait('r13_hub')
  objects=await self.py("import renpy; result=renpy.store.ROOM13['objects']['gate']")
  for key in ('booth','rules'):
   x,y,w,h=objects[key]['rect'];await self.input(x+w/2,y+h/2);await self.advance();await self.wait('r13_hub')
  st=await self.state();assert {'G1','G2'}<=set(st['room']['evidence']),st['room']['evidence'];assert st['room']['period']==1
  await self.shot('03-entry-inspected');await self.press('조사 마치기');await self.wait('r13_hub');await self.press('확인한 자료');await self.wait('r13_book');await self.shot('04-entry-proof-book')
  # Evidence details are selected by their actual label, never programmatically submitted.
  title=await self.py("import renpy; result=renpy.store.ROOM13['evidence']['G1']['name']")
  await self.press(title);await self.press('보여주기');await self.advance();await self.wait('choice');await self.shot('05-reason-choice');await self.press('원본에는 두 명');await self.advance();await self.wait('r13_hub')
  st=await self.state();assert 'entry_corrected' in st['room']['flags'];assert st['room']['period']==1;assert 'E02' in st['room']['evidence'];await self.shot('06-proof-entry-complete')
  self.events.append('G1/G2 physically inspected, G1 manually presented, correct reasoning selected, joint entry succeeds without time cost')
  saved=(await self.state())['room'];await self.press('저장');await self.wait('save');await self.press('슬롯 1');await asyncio.sleep(.8);await self.shot('07-real-save');await self.press('돌아가기');await self.wait('r13_hub')
  await self.press('기다리기');await self.wait('r13_confirm');await self.press('진행한다');await self.advance();await self.wait('r13_hub');assert (await self.state())['room']['period']==2
  await self.press('설정');await self.wait('pause_menu');await self.press('불러오기');await self.wait('load');await self.press('슬롯 1');await self.wait('r13_hub');assert (await self.state())['room']==saved;await self.shot('08-real-load-restores')
  self.events.append('Actual save slot, wait activity, settings/load slot restores complete evidence/flags/time state')
  return {'status':'passed','kind':'fresh-natural-proof-route','checks':self.events,'seen_speakers':sorted(self.seen)}
 async def inspection(self):
  await self.wait('main_menu');await self.press('처음부터');await self.advance();await self.wait('r13_hub')
  entry_before=(await self.state())['room'];await self.press('조사');await self.wait('r13_hub');assert await self.py("import renpy; result=renpy.store.r13_inspection_location")=='gate';assert (await self.state())['room']==entry_before;await self.shot('00-entry-inspection')
  await self.press('조사 마치기');await self.wait('r13_hub');assert not await self.py("import renpy; result=renpy.store.r13_inspection_location");assert (await self.state())['room']==entry_before;await self.shot('00b-entry-restored')
  await self.press('원본 대조');await self.wait('r13_confirm');await self.press('진행한다');await self.advance();await self.wait('r13_hub')
  # Fixture: put the otherwise freshly played run in the clinic at a crowded time.
  await self.py("import renpy; s=renpy.store; s.r13_edit(location='clinic',period=1); s.r13_scene_key=None; renpy.exports.restart_interaction(); result=True")
  await asyncio.sleep(.6);st=await self.state();button=min([b for b in st['buttons'] if '이동하기' in b['text']],key=lambda b:b['rect'][2]*b['rect'][3]);x,y,w,h=button['rect']
  await self.py("import renpy\ns=renpy.store\nfor f in renpy.display.focus.focus_list:\n if f.x==%r and f.y==%r and f.w==%r and f.h==%r:\n  f.widget.action=s.Jump('r13_roam');f.widget.clicked=f.widget.action\nresult=True"%(x,y,w,h))
  await self.input(x+w/2,y+h/2);await self.advance();await self.wait('r13_hub');await self.shot('01-clinic-residents');info=await self.info();assert len(info['people'])>=2,info
  await self.npc('resident_seori');before=(await self.state())['room'];await self.press('조사하기');await self.advance();await self.wait('r13_hub');assert (await self.state())['room']==before
  active=await self.py("import renpy; result=renpy.store.r13_inspection_location");assert active=='clinic';assert not any("'person'" in b['value'] for b in (await self.state())['buttons']);await self.shot('02-clinic-inspect-clear')
  # Click the notebook itself, previously covered by the second resident.
  await self.input(488,550);await self.wait('say');st=await self.state();assert '진료 메모' in st['say'],st['say'];await self.shot('03-notes-response');await self.advance();await self.wait('r13_hub');assert 'clinic:notes' in (await self.state())['room']['checks'];assert (await self.state())['room']['period']==before['period']
  await self.p.set_viewport_size({'width':844,'height':390});self.touch=True;await self.press('조사 마치기');await self.wait('r13_hub');assert not await self.py("import renpy; result=renpy.store.r13_inspection_location");assert any("'person'" in b['value'] for b in (await self.state())['buttons']);await self.shot('04-mobile-residents-restored')
  await self.npc('resident_seori');await self.press('조사하기');await self.advance();await self.wait('r13_hub');await self.press('이동하기');await self.wait('r13_map');await self.press('수리점');await self.advance();await self.wait('r13_hub');assert not await self.py("import renpy; result=renpy.store.r13_inspection_location");assert (await self.state())['room']['location']=='workshop';await self.shot('05-mobile-move-clears-mode')
  # Second injected fixture: crowded supply store, then real ledger click.
  await self.p.set_viewport_size({'width':1280,'height':720});self.touch=False
  await self.py("import renpy; s=renpy.store; s.r13_edit(location='store',period=1); s.r13_scene_key=None; renpy.exports.restart_interaction(); result=True")
  await asyncio.sleep(.6);st=await self.state();button=min([b for b in st['buttons'] if '이동하기' in b['text']],key=lambda b:b['rect'][2]*b['rect'][3]);x,y,w,h=button['rect']
  await self.py("import renpy\ns=renpy.store\nfor f in renpy.display.focus.focus_list:\n if f.x==%r and f.y==%r and f.w==%r and f.h==%r:\n  f.widget.action=s.Jump('r13_roam');f.widget.clicked=f.widget.action\nresult=True"%(x,y,w,h))
  await self.input(x+w/2,y+h/2);await self.advance();await self.wait('r13_hub');info=await self.info();assert info['people'];await self.shot('06-store-residents');await self.npc(info['people'][0]);await self.press('조사하기');await self.advance();await self.wait('r13_hub');assert not any("'person'" in b['value'] for b in (await self.state())['buttons']);await self.shot('07-store-inspection');await self.input(270,500);await self.wait('say');await self.shot('08-store-ledger-response');await self.advance();await self.wait('r13_hub');assert 'store:ledger' in (await self.state())['room']['checks']
  return {'status':'passed','kind':'injected-location-fixture-with-real-inputs','checks':['Entry inspection toggle preserves state and restores actors','Store ledger physically accessible in inspection','Crowded clinic has 2+ residents before inspection','Real resident action opens inspection without time/state cost','Resident drawing/hitboxes removed while inspecting','Visible medical notebook center yields correct observation and checkmark','Mobile finish restores resident hitboxes','Mobile map move clears inspection mode']}
 async def fixtures(self):
  await self.wait('main_menu');await self.press('처음부터');await self.advance();await self.wait('r13_hub')
  await self.press('대화');await self.wait('r13_entry_topics');await self.press('아이와 따로');await self.wait('say')
  migration_before=await self.py("import renpy; s=renpy.store; result={'room':s.room13,'speaker':s.dialogue_speaker,'expression':s.dialogue_expression,'scene':s.r13_scene_key,'tags':sorted(renpy.exports.get_showing_tags())}")
  assert migration_before['speaker']=='guard',migration_before
  await self.py("import renpy; s=renpy.store; s.r13_edit(visual_revision='painted-daylight-v1'); s.r13_upgrade(); renpy.exports.restart_interaction(); result=True")
  migration_after=await self.py("import renpy; s=renpy.store; result={'room':s.room13,'speaker':s.dialogue_speaker,'expression':s.dialogue_expression,'scene':s.r13_scene_key,'tags':sorted(renpy.exports.get_showing_tags())}")
  for field in ('day','period','location','evidence','flags','records','resident_knowledge','daram_state','case_state'):
   assert migration_before['room'][field]==migration_after['room'][field],('migration changed '+field,migration_after)
  assert migration_after['speaker']==migration_before['speaker'] and migration_after['expression']==migration_before['expression'],migration_after
  assert migration_after['room']['visual_revision']=='pixel-b-v1' and 'r13_restored_background' in migration_after['tags'] and 'r13_visitor' in migration_after['tags'],migration_after
  await self.shot('migration-live-guard');await self.advance();await self.wait('r13_hub')
  before=(await self.state())['room'];shots=[]
  setup="""import renpy
s=renpy.store
for name in ['r13_hub','r13_hud','say']:
 renpy.exports.hide_screen(name)
renpy.exports.scene()
result=True
"""
  await self.py(setup)
  bgkeys=['winter','winter_carriage','village_overview','r13_altar','hall','front','kitchen','winter_passage','council','winter_square','winter_post','winter_workshop','room','r13_clinic','r13_school','r13_store','r13_greenhouse','r13_facility']
  for key in bgkeys:
   for period in ([0] if key=='winter_carriage' else range(3)):
    for case in (['pending','occurred'] if key in ('hall','room') else ['pending']):
     code="import renpy\ns=renpy.store\ns.r13_edit(period=%d,case_state=%r)\nrenpy.exports.scene()\nrenpy.exports.show('pixel_qa_bg',what=s.r13_background(%r))\nrenpy.exports.restart_interaction()\nresult=True"%(period,case,key)
     await self.py(code);await asyncio.sleep(.22);await self.state();name='bg-%s-%s-%s'%(key,period,case);await self.p.screenshot(path=str(self.out/(name+'.png')));shots.append({'file':name+'.png','type':'background','key':key,'period':period,'case':case})
  cast=await self.py("import renpy; result=sorted(renpy.store.CAST)")
  for person in cast:
   await self.py("import renpy\ns=renpy.store\nrenpy.exports.scene()\nrenpy.exports.show('pixel_qa_bg',what=s.r13_background('front'))\nrenpy.exports.show('pixel_qa_actor',what=(s.r13_close_art(%r,'interview_neutral') if hasattr(s,'r13_close_art') else s.r13_art(%r,'interview_neutral')),at_list=[s.r13_portrait_close(s.r13_close_y(%r))])\nrenpy.exports.restart_interaction()\nresult=True"%(person,person,person))
   await asyncio.sleep(.22);await self.state();name='cast-'+person;await self.p.screenshot(path=str(self.out/(name+'.png')));shots.append({'file':name+'.png','type':'portrait','key':person})
  cinema=await self.py("import renpy; result=sorted(renpy.store.R13_CINEMATICS)")
  for key in cinema:
   await self.py("import renpy\ns=renpy.store\nrenpy.exports.scene()\nrenpy.exports.show('pixel_qa_cg',what=s.r13_cinematic_art(%r))\nrenpy.exports.restart_interaction()\nresult=True"%key)
   await asyncio.sleep(.22);await self.state();name='cg-'+key;await self.p.screenshot(path=str(self.out/(name+'.png')));shots.append({'file':name+'.png','type':'cinematic','key':key})
  cards=''.join('<figure><a href="%s"><img loading="lazy" src="%s"></a><figcaption>%s</figcaption></figure>'%(x['file'],x['file'],html.escape(x['file'])) for x in shots)
  (self.out/'index.html').write_text('<!doctype html><meta charset="utf-8"><title>Pixel B render fixtures</title><style>body{background:#12252b;color:#fff;font-family:sans-serif}main{display:grid;grid-template-columns:repeat(3,1fr)}figure{margin:8px}img{width:100%}figcaption{font-size:12px}</style><h1>Injected render fixtures — not natural playthroughs</h1><p>Every active background/time/state view, all character identities, all cinematic panels. Runtime drawing only; image pixels were not edited.</p><main>'+cards+'</main>')
  return {'status':'passed','kind':'injected-render-fixture-matrix-not-natural-play','shots':shots,'counts':{t:sum(x['type']==t for x in shots) for t in ('background','portrait','cinematic')},'base_room':before,'migration':{'before':migration_before,'after':migration_after}}

async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',default='http://127.0.0.1:8094/room13-release-0130/');ap.add_argument('--out',default='qa-room13-0130/pixel');ap.add_argument('--mode',choices=['proof','wait-ui','fixtures','inspection'],default='proof');args=ap.parse_args();out=ROOT/args.out;out.mkdir(parents=True,exist_ok=True)
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();errors=[];bad=[];cast_requests=[]
  pg.on('console',lambda m:(out/'console.log').open('a').write(m.type+': '+m.text+'\n'));pg.on('pageerror',lambda e:errors.append(str(e)));pg.on('response',lambda r:bad.append([r.status,r.url]) if r.status>=400 and 'favicon'not in r.url else None)
  # Active pixel artwork must never need external fetches, even in a cold context.
  async def reject_cast(route):
   cast_requests.append(route.request.url);await route.abort()
  await pg.route('**/game/assets/room13-pixel-*.png',reject_cast)
  q=PixelQA(pg,out)
  try:
   await pg.goto(args.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy; renpy.store.preferences.text_cps=0; result=True')
   report=await (q.proof_route() if args.mode=='proof' else q.run() if args.mode=='wait-ui' else q.inspection() if args.mode=='inspection' else q.fixtures());assert not errors,errors;assert not bad,bad;assert not cast_requests,cast_requests
  except Exception as e:
   await pg.screenshot(path=str(out/'failure.png'));report={'status':'failed','kind':args.mode,'error':repr(e),'checks':q.events}
   try:report['last_state']=await q.state()
   except Exception:pass
  report.update(errors=errors,http_errors=bad,external_active_art_requests=cast_requests,url=args.url);(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ('shots','last_state','base_room')},ensure_ascii=False),flush=True);await b.close()
  if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
