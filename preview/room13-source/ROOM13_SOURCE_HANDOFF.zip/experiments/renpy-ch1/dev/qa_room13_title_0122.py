import asyncio,json,shutil,ast,sys
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'qa-room13-0122'/('title-audio-strict' if '--strict' in sys.argv else 'title-audio');OUT.mkdir(parents=True,exist_ok=True)
module=ast.parse((ROOT/'dev/qa_room13_live.py').read_text());PROBE=next(ast.literal_eval(n.value) for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PROBE' for t in n.targets))
AUDIO_HOOK="""(()=>{window.__audioMonitors=[];const original=AudioNode.prototype.connect;const seen=new WeakSet();AudioNode.prototype.connect=function(...args){let result=original.apply(this,args);if(args[0] instanceof AudioDestinationNode && !seen.has(this)){seen.add(this);let c=this.context,a=c.createAnalyser(),g=c.createGain();a.fftSize=2048;g.gain.value=0;original.call(this,a);original.call(a,g);original.call(g,c.destination);window.__audioMonitors.push({context:c,analyser:a});}return result;};})()"""
AUDIO="""()=>window.__audioMonitors.map(({context:c,analyser:a})=>{let d=new Float32Array(a.fftSize);a.getFloatTimeDomainData(d);let peak=0,sum=0;for(let v of d){peak=Math.max(peak,Math.abs(v));sum+=v*v;}return {state:c.state,peak,rms:Math.sqrt(sum/d.length),samples:d.length,time:c.currentTime};})"""

async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']+(['--autoplay-policy=document-user-activation-required'] if '--strict' in sys.argv else []));ctx=await b.new_context(viewport={'width':1280,'height':720},has_touch=True);pg=await ctx.new_page();errors=[];bad=[]
  pg.on('pageerror',lambda e:errors.append(str(e)));pg.on('response',lambda r:bad.append([r.status,r.url]) if r.status>=400 and 'favicon'not in r.url else None)
  await pg.add_init_script(AUDIO_HOOK)
  await pg.goto('http://127.0.0.1:8094/room13-release-0122/');await pg.wait_for_function("typeof renpy_exec==='function'",timeout=90000)
  async def state():return await pg.evaluate('code=>renpy_exec(code)','ns={};exec('+repr(PROBE)+',ns);result=ns["result"]')
  async def press(label,mobile=False):
   await pg.wait_for_timeout(400);s=await state();buttons=[x for x in s['buttons'] if x['text'].strip()==label];a=min(buttons,key=lambda x:x['rect'][2]*x['rect'][3]);x,y,w,h=a['rect'];scale=390/720 if mobile else 1;offset=(844-1280*scale)/2 if mobile else 0;await pg.mouse.click(offset+(x+w/2)*scale,(y+h/2)*scale);await pg.wait_for_timeout(700)
  for _ in range(100):
   s=await state()
   if 'main_menu'in s['screens']:break
   await asyncio.sleep(.2)
  await asyncio.sleep(2);await pg.screenshot(path=str(OUT/'title-desktop.png'))
  report={'version':await pg.evaluate('code=>renpy_exec(code)',"import renpy;result=renpy.store.config.version"),'before_gesture':await pg.evaluate(AUDIO),'before_menu':s}
  await pg.mouse.click(1120,300);await pg.wait_for_timeout(1800)
  report['after_background_gesture']=await pg.evaluate(AUDIO)
  report['music']=await pg.evaluate('code=>renpy_exec(code)',"import renpy;import renpy.audio.music as music;result={'file':music.get_playing(),'volume':renpy.store._preferences.get_volume('music'),'muted':renpy.store._preferences.get_mute('music')}" )
  await press('음악 듣기');await pg.wait_for_timeout(1800);report['after_listen']=await pg.evaluate(AUDIO)
  await press('설정');await pg.screenshot(path=str(OUT/'settings-desktop.png'));report['settings']=await state()
  await press('돌아가기');await press('이어하기');await pg.screenshot(path=str(OUT/'load-desktop.png'));report['load']=await state();await press('돌아가기')
  await pg.set_viewport_size({'width':844,'height':390});await pg.wait_for_timeout(1000);await pg.screenshot(path=str(OUT/'title-mobile.png'));await press('설정',True);await pg.screenshot(path=str(OUT/'settings-mobile.png'));await press('돌아가기',True)
  report['errors']=errors;report['http_errors']=bad
  (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['before_menu','settings','load']},ensure_ascii=False),flush=True)
  await b.close()
asyncio.run(main())
