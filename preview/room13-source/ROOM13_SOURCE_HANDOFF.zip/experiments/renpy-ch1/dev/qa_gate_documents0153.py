"""Real popup clicks after explicitly injecting the new module into release0152.
The production gate interception and acquired-card animation need final-build QA.
"""
import asyncio,json,shutil
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_browser import PixelQA,ROOT
OUT=ROOT/'qa-room13-0153/gate-documents';OUT.mkdir(parents=True,exist_ok=True)
SRC=(ROOT/'game/room13_gate_inspection.rpy').read_text()+'''\nscreen qa_gate_open():
    zorder 99
    textbutton "QA open":
        xpos 600 ypos 610 xsize 180 ysize 65
        action [Hide("qa_gate_open"), Function(renpy.call_in_new_context,"r13_inspect_gate_documents","booth")]
'''
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},service_workers='block');pg=await c.new_page();q=PixelQA(pg,OUT);report={'kind':'source-injected-popup-with-real-clicks-not-final-production-interception','checks':[]};errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  async def info():return await q.py("import renpy;result={'shown':bool(renpy.exports.get_screen('r13_gate_document_inspection')),'evidence':renpy.store.room13['evidence'],'records':renpy.store.room13['records'],'point':renpy.store.r13_gate_bundle_check_point(),'day':renpy.store.room13['day'],'period':renpy.store.room13['period']}")
  async def wait_popup():
   for _ in range(50):
    if (await info())['shown']:return
    await asyncio.sleep(.1)
   raise AssertionError('popup not shown')
  try:
   await pg.goto('http://127.0.0.1:8094/room13-release-0152/');await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub')
   await q.py('import renpy;renpy.exports.load_string('+ascii(SRC)+',filename="qa_gate_documents.rpy");renpy.exports.show_screen("qa_gate_open");renpy.exports.restart_interaction();result=True')
   before=await info();await q.input(680,640);await wait_popup();await pg.screenshot(path=str(OUT/'01-original-unrecorded.png'))
   assert (await info())['evidence']==before['evidence']
   await q.input(995,230);await pg.screenshot(path=str(OUT/'02-copy-unrecorded.png'));assert (await info())['evidence']==before['evidence']
   await q.input(1125,140);await asyncio.sleep(.2);assert not (await info())['shown'];assert (await info())['evidence']==before['evidence'];report['checks'].append('Open, switch tabs and close do not grant evidence')
   await q.py('import renpy;renpy.exports.show_screen("qa_gate_open");renpy.exports.restart_interaction();result=True');await q.input(680,640);await wait_popup();await q.input(750,565);await wait_popup();one=await info();assert 'G1'in one['evidence'] and 'G3'not in one['evidence'] and one['point'] is None;await pg.screenshot(path=str(OUT/'03-one-recorded.png'))
   await q.input(995,230);await q.input(750,565);await wait_popup();two=await info();assert {'G1','G3'}<=set(two['evidence']) and two['point'];await pg.screenshot(path=str(OUT/'04-both-recorded.png'));report['checks'].append('Explicit record grants only selected G1/G3; one document has no field tick; both produce one bundle point')
   await q.input(750,565);assert (await info())==two;report['checks'].append('Recorded button cannot duplicate or rewrite evidence')
   assert (two['day'],two['period'])==(before['day'],before['period']);assert 'G2'not in two['evidence'];report['checks'].append('Reading does not advance time, acquire G2 or resolve registration')
   await q.input(1125,140);await asyncio.sleep(.2);assert not (await info())['shown'];await pg.screenshot(path=str(OUT/'05-return-to-field.png'));report['checks'].append('Close returns to the existing field context')
   report['status']='passed';report['final']=await info()
  except Exception as e:report['status']='failed';report['error']=repr(e);await pg.screenshot(path=str(OUT/'failure.png'))
  report['page_errors']=errors;(OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(report['status'],report.get('error'),flush=True);await b.close()
asyncio.run(main())
