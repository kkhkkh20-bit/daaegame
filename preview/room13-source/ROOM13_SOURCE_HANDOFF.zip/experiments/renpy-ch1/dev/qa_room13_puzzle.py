async def waitscreen(name):
 for _ in range(120):
  s=await state()
  if name in s['screens']:
   await asyncio.sleep(.45);return await state()
  await asyncio.sleep(.15)
 raise AssertionError(('screen',name,s))
async def press(label):
 await asyncio.sleep(.45);s=await state()
 matches=[b for b in s['buttons'] if label in b['text'] and b['rect'][3]>15]; b=min(matches,key=lambda b:b['rect'][2]*b['rect'][3]) if matches else None
 assert b,(label,s)
 x,y,w,h=b['rect'];await click(x+w/2,y+h/2)
async def advance():
 for _ in range(250):
  s=await state()
  if 'r13_cinematic_view' in s['screens']:
   await shot('cg-'+str(s['room']['day'])+'-'+s['room']['location']);await press('계속');continue
  if any(x in s['screens'] for x in ['choice','r13_hub','r13_book','r13_confirm','r13_interaction','r13_topics','r13_debate','r13_handoff','r13_crisis','r13_crisis_proof','r13_ending_screen']):
   await asyncio.sleep(.45);return await state()
  if 'say'in s['screens']:await click(810,640)
  else:await asyncio.sleep(.2)
 raise AssertionError(s)
async def shot(n):
 print('QA '+n,flush=True);await page.screenshot(path=str(OUT/(n+'.png')))
 (OUT/(n+'.json')).write_text(json.dumps(await state(),ensure_ascii=False,indent=2))
async def move(label):
 await press('이동하기');await waitscreen('r13_map');await press(label);return await advance()
async def rest():
 await press('여관에서 밤 보내기');await waitscreen('r13_confirm');await press('진행한다');return await advance()
async def run():
 await press('새 여정 시작');s=await advance();await press('마을 입구부터');s=await advance()
 assert s['room']['day']==1 and s['room']['evidence']==['E01'] and s['room']['case_state']=='pending'
 assert await page.evaluate("code=>renpy_exec(code)", "import renpy; result='E03' in renpy.store.persistent.room13_knowledge")
 await shot('final-15-restart')
 await press('설정');await waitscreen('pause_menu');await press('불러오기');await waitscreen('load');await press('슬롯 1');await advance()
 await move('여관 1층');await shot('final-16-kitchen');await click(410,460);await advance();await press('레버를 올려');await advance()
 assert (await state())['room']['kitchen_switch']
 await move('13호실');await click(1220,300);await advance();await press('책의 아래쪽');await advance();await press('통로로 들어간다');s=await advance()
 assert s['room']['passage_open'] and 'E37'in s['room']['evidence'] and s['room']['location']=='passage'
 await shot('final-17-passage')
 await move('여관 접수대');await press('시간 보내기');await waitscreen('r13_confirm');await press('진행한다');await advance();await shot('final-18-evening')
 assert (await state())['room']['period']==2
 return await state()
