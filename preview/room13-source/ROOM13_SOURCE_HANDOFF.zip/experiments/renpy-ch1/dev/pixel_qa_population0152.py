"""All scheduled residents present; explicit state fixtures, not natural route claims."""
import argparse,asyncio,json,shutil
from playwright.async_api import async_playwright
from pixel_qa_flow0150 import FlowQA,ROOT
POPULATION='''import renpy,copy
s=renpy.store;original=copy.deepcopy(s.room13);rows=[];failures=[];seen=set()
try:
 for day in range(1,15):
  for period in range(4):
   for variant,victim,granny,daram,case in [('free','alive','trusted','with_dad','prevented'),('occurred','dead','trusted','with_dad','occurred'),('held','dead','detained','held','occurred'),('rescued','alive','detained','rescued','prevented'),('shelter','alive','trusted','rescued','prevented')]:
    for location in s.R13_PLACES:
     state=copy.deepcopy(original);state.update(day=day,period=period,location=location,victim_state=victim,granny_state=granny,daram_state=daram,case_state=case)
     state['flags']=[f for f in state['flags']if f!='mom_reunited']
     if variant in ('rescued','shelter')and day>=8:state['flags'].append('mom_reunited')
     if variant=='shelter':state['flags']+=['shelter_ready','patient_transport','nubi_protected','bami_protected']
     s.room13=state;people=list(s.r13_people());actors=s.r13_stage_people();ids=[a['person']for a in actors];seen.update(ids);errors=[]
     if set(people)!=set(ids):errors.append({'missing':sorted(set(people)-set(ids)),'extra':sorted(set(ids)-set(people))})
     if len(ids)!=len(set(ids)):errors.append('duplicate')
     if actors!=s.r13_stage_people():errors.append('nondeterministic')
     if victim=='dead'and 'resident_owlgp'in ids:errors.append('dead victim')
     if granny=='detained'and 'granny'in ids:errors.append('detained granny')
     if daram not in ('with_dad','rescued')and 'daram'in ids:errors.append('absent child')
     if 'mom_reunited'not in state['flags']and 'mom'in ids:errors.append('unrevealed mom')
     row={'day':day,'period':period,'location':location,'variant':variant,'people':people,'actors':actors,'state':state,'errors':errors}
     rows.append(row)
     if errors:failures.append(row)
finally:s.room13=original
result={'kind':'injected-population-equality-fixtures','rows':rows,'failures':failures,'identities':sorted(seen),'total_conditions':len(rows),'state_restored':s.room13==original}
'''
class PopulationQA(FlowQA):
 async def py(self,code):return await asyncio.wait_for(self.p.evaluate('code=>renpy_exec(code)','exec('+ascii(code)+')'),180)

async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',default='qa-room13-0152/population');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True)
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=PopulationQA(pg,out);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)));report={}
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub');report=await q.py(POPULATION)
   selected=[]
   for location in sorted({r['location']for r in report['rows']}):
    row=max([r for r in report['rows']if r['location']==location],key=lambda r:len(r['actors']))
    if not row['actors']:continue
    selected.append(row)
   report['screenshots']=[]
   for row in selected:
    await q.py("import renpy\ns=renpy.store\ns.room13="+ascii(row['state'])+"\ns.place=s.R13_PLACES[s.room13['location']][0]\nrenpy.exports.hide_screen('r13_hub')\nrenpy.exports.hide_screen('say')\nrenpy.exports.scene()\nrenpy.exports.show('qa_population_background',what=s.r13_background(s.R13_PLACES[s.room13['location']][1]))\nrenpy.exports.show_screen('r13_hub',entry=False)\nrenpy.exports.show_screen('r13_hud')\nrenpy.exports.restart_interaction()\nresult=True")
    await q.wait('r13_hub');name='max-'+row['location'];await q.shot(name);report['screenshots'].append({'file':name+'.png','day':row['day'],'period':row['period'],'variant':row['variant'],'actors':row['actors']});assert not any('이곳의 주민'in x['text']for x in(await q.state())['buttons'])
   assert not report['failures'],report['failures'][:1];assert not errors,errors;report['status']='passed-pending-visible-art-review'
  except Exception as e:report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
  report.update(url=a.url,errors=errors);(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items()if k not in('rows','screenshots','failures')},ensure_ascii=False));await b.close()
  if report['status']=='failed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
