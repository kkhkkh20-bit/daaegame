"""Archive engine checks with state/clock fixtures; no implementation injection."""
import argparse,asyncio,json,shutil
from pathlib import Path
import numpy as np
from PIL import Image
from playwright.async_api import async_playwright
from pixel_qa_flow0150 import FlowQA,ROOT

FIXTURE='''import renpy
s=renpy.store
person=%r;pose=%r;close=%r
for name in ('r13_hub','r13_entry_topics','r13_entry_karo_topics','r13_topics','say'):renpy.exports.hide_screen(name)
renpy.exports.scene()
renpy.exports.show('qa_motion_background',what=s.Solid('#263b45'))
spec=s.r13_close_spec(person,pose) if close else s.r13_acting_spec(person,pose)
w,h=spec['crop'][2:];height=480 if close else 370;width=int(round(w*height/h))
art=s.r13_pixel_scale(s.Crop(tuple(spec['crop']),spec['file']),width,height,2)
s.qa_idle=s.r13_idle_art(art,person,pose,spec,width,height,contact='dialogue_bust' if close else spec.get('contact'),speaking=close)
s.qa_idle_static=art
s.persistent.room13_motion=True
s.qa_idle_clock_original=s.r13_idle_clock
s.qa_idle_t=0.0
s.r13_idle_clock=lambda state=s:state.qa_idle_t
renpy.exports.show('qa_idle',what=s.qa_idle,at_list=[s.Transform(xpos=440,ypos=130)])
renpy.exports.restart_interaction()
values={}
for i in range(160):
 t=i/8.0;v=s.r13_idle_values(person,pose,s.qa_idle.kind,t)
 if v not in values:values[v]=t
result={'person':person,'pose':pose,'close':close,'width':width,'height':height,'kind':s.qa_idle.kind,'lock':s.qa_idle.lock,'sample_times':list(values.values())[:6]}
'''

def pixels(path,info):
 a=np.asarray(Image.open(path).convert('RGB'));return a[130:130+info['height'],440:440+info['width']]

async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',default='qa-room13-0152/motion/engine');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True)
 report={'kind':'archive-engine-with-explicit-state-and-clock-fixtures-no-source-injection','cases':[]};errors=[]
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},service_workers='block');pg=await c.new_page();pg.on('pageerror',lambda e:errors.append(str(e)));q=FlowQA(pg,out)
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub')
   for person,pose,close in [('resident_tori','neutral',False),('granny','action_1',False),('buri','action_1',False),('seryeon','chair_read',False),('resident_momo','living_read',False),('dad','neutral',True)]:
    info=await q.py(FIXTURE%(person,pose,close));frames=[]
    for i,t in enumerate(info['sample_times']):
     await q.py('import renpy;s=renpy.store;s.qa_idle_t='+repr(t)+';renpy.display.render.redraw(s.qa_idle,0);renpy.exports.restart_interaction();result=True');await asyncio.sleep(.18);path=out/(person+'-'+pose+'-on-'+str(i)+'.png');await pg.screenshot(path=str(path));frames.append(pixels(path,info))
    differences=[np.any(x!=frames[0],axis=2) for x in frames[1:]];moving=max(int(x.sum())for x in differences);locked=max(int(x[info['lock']:].sum())for x in differences);assert moving>20,(info,'no visible motion',moving);assert locked==0,(info,'contact area changed',locked)
    # OFF renders the actual unmodified child and stays exactly fixed over time.
    await q.py('import renpy;s=renpy.store;s.persistent.room13_motion=False;renpy.display.render.redraw(s.qa_idle,0);renpy.exports.restart_interaction();result=True');await asyncio.sleep(.2);off0=out/(person+'-'+pose+'-off-0.png');await pg.screenshot(path=str(off0));await q.py('import renpy;s=renpy.store;s.qa_idle_t=123.0;renpy.display.render.redraw(s.qa_idle,0);renpy.exports.restart_interaction();result=True');await asyncio.sleep(.2);off1=out/(person+'-'+pose+'-off-1.png');await pg.screenshot(path=str(off1));assert np.array_equal(pixels(off0,info),pixels(off1,info)),(person,'OFF moved')
    await q.py("import renpy;s=renpy.store;renpy.exports.show('qa_idle',what=s.qa_idle_static,at_list=[s.Transform(xpos=440,ypos=130)]);renpy.exports.restart_interaction();result=True");await asyncio.sleep(.2);static=out/(person+'-'+pose+'-static.png');await pg.screenshot(path=str(static));assert np.array_equal(pixels(off0,info),pixels(static,info)),(person,'OFF differs from original art')
    await q.py('import renpy;s=renpy.store;s.r13_idle_clock=s.qa_idle_clock_original;result=True');info.update(max_changed_pixels=moving,changed_contact_pixels=locked,motion_off_exactly_static=True);report['cases'].append(info);print('MOTION',person,info['kind'],moving,'pixels',flush=True)
   # Real unmodified clock/redraw timeline, not a fixture time switch.
   info=await q.py(FIXTURE%('resident_tori','neutral',False));await q.py('import renpy;s=renpy.store;s.r13_idle_clock=s.qa_idle_clock_original;renpy.display.render.redraw(s.qa_idle,0);result=True');live=[]
   for i in range(10):
    await asyncio.sleep(.5);path=out/('live-tori-%02d.png'%i);await pg.screenshot(path=str(path));live.append(pixels(path,info))
   report['live_redraw_changed_pixels']=max(int(np.any(x!=live[0],axis=2).sum()) for x in live[1:]);assert report['live_redraw_changed_pixels']>20
   # Actual GPU output of draw/mask at one shared frame time. Direct bulk
   # is_pixel_opaque readbacks in renpy_exec block the WebGL renderer, so compare
   # rendered mask crops instead. This is a clock fixture, not source injection.
   (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
   rows=await q.py("import renpy;s=renpy.store;original=s.room13['location'];rows=[]\nfor location in ('gate','inn','workshop','post','square','school'):\n s.room13['location']=location\n for actor in s.r13_stage_people():rows.append(dict(actor,qa_location=location))\ns.room13['location']=original;result=rows")
   report['mask_checks']=[]
   for index,actor in enumerate(rows):
    code="import renpy\ns=renpy.store\ns.qa_actor="+ascii(actor)+"\ns.persistent.room13_motion=True\ns.qa_idle_t="+repr(index*1.75)+"\ns.r13_idle_clock=lambda state=s:state.qa_idle_t\nrenpy.exports.hide_screen('r13_hud')\nrenpy.exports.hide('qa_idle')\nrenpy.exports.show('qa_mask',what=s.r13_staged_visible_art(s.qa_actor),at_list=[s.Transform(xpos=100,ypos=150)])\nrenpy.exports.restart_interaction()\nresult=True"
    await q.py(code);await asyncio.sleep(.16);shown=out/('mask-%02d-draw.png'%index);await pg.screenshot(path=str(shown))
    x,y,w,h=actor['rect'];ox=x-actor['x'];oy=y-actor['y']
    await q.py("import renpy;s=renpy.store;renpy.exports.show('qa_mask',what=s.r13_actor_hit_mask(s.qa_actor),at_list=[s.Transform(xpos="+repr(100+ox)+",ypos="+repr(150+oy)+")]);renpy.exports.restart_interaction();result=True");await asyncio.sleep(.16);hit=out/('mask-%02d-hit.png'%index);await pg.screenshot(path=str(hit))
    aa=np.asarray(Image.open(shown));bb=np.asarray(Image.open(hit));rx=100+ox;ry=150+oy;bad=int(np.any(aa[ry:ry+h,rx:rx+w]!=bb[ry:ry+h,rx:rx+w],axis=2).sum())
    check={'person':actor['person'],'location':actor['qa_location'],'fixture_time':index*1.75,'compared_pixels':w*h,'mismatched_pixels':bad};report['mask_checks'].append(check);assert bad==0,check
   await q.py('import renpy;s=renpy.store;s.r13_idle_clock=s.qa_idle_clock_original;result=True')
   assert report['mask_checks'];assert not errors,errors;report['status']='passed' 
  except Exception as e:
   report.update(status='failed',error=repr(e))
   try:await pg.screenshot(path=str(out/'failure.png'),timeout=5000)
   except Exception:pass
  report.update(url=a.url,errors=errors);(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
