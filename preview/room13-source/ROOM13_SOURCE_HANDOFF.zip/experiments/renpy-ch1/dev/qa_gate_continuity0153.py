"""Host-side schedule regression. Actual rendering/clicks require final browser QA."""
import ast
import copy
import json
import textwrap
from qa_room13_rules import ROOT, load_rules


def main():
    ns = load_rules()
    source = (ROOT / 'game/room13_life.rpy').read_text().split(' python:\n', 1)[1].split('\nlabel ', 1)[0]
    tree = ast.parse(textwrap.dedent(source))
    selected = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'r13_resident_where']
    ns['R13_RESIDENTS'] = ns['ROOM13']['residents']
    for person in ns['R13_RESIDENTS']:
        ns['R13_GREETING'].setdefault(person, 'QA greeting')
    exec(compile(ast.Module(body=selected, type_ignores=[]), '<actual resident schedule>', 'exec'), ns)
    original = ns['r13_where']
    original_people = list(ns['R13_GREETING'])
    patch = (ROOT / 'game/room13_gate_continuity.rpy').read_text().split(' python:\n', 1)[1]
    exec(compile(textwrap.dedent(patch), 'room13_gate_continuity.rpy', 'exec'), ns)
    base = copy.deepcopy(ns['store'].room13)
    conditions = 0
    maxima = None
    for day in range(1, 15):
        for period in range(4):
            for victim, granny, case, child, flags in [
                ('alive','trusted','prevented','with_dad',[]),
                ('dead','trusted','occurred','with_dad',['bami_protected']),
                ('dead','detained','occurred','held',['shelter_ready','patient_transport']),
                ('alive','trusted','prevented','rescued',['mom_reunited','shelter_ready','nubi_protected']),
            ]:
                state=copy.deepcopy(base)
                state.update(day=day,period=period,location='gate',victim_state=victim,
                    granny_state=granny,case_state=case,daram_state=child)
                state['flags'] += flags
                ns['store'].room13=state
                assert all(ns['r13_where'](p)==original(p) for p in original_people)
                before=ns['r13_people']()
                before_state=copy.deepcopy(state)
                assert 'guard' in before and len(before)==len(set(before))
                assert not ns['r13_topics']('guard')
                ns['r13_flag']('entry_corrected')
                after=ns['r13_people']()
                assert before==after, (day,period,before,after)
                assert {k for k,_ in ns['r13_topics']('guard')}=={'gate_guard_duty','gate_guard_record'}
                assert state==before_state, 'read helpers mutated input'
                conditions += 1
                if maxima is None or len(before)>len(maxima['people']):
                    maxima={'state':before_state,'people':before}
    ns['store'].room13=copy.deepcopy(base)
    ns['store'].room13.update(location='gate',period=1)
    first=ns['r13_people']()
    assert 'karo' in first and 'guard' in first
    # Entry/normal staging must use the same authoritative ordered population.
    acting=ast.parse(textwrap.dedent((ROOT/'game/room13_acting.rpy').read_text().split(' python:\n',1)[1]))
    stage=next(n for n in acting.body if isinstance(n,ast.FunctionDef) and n.name=='r13_stage_people')
    people_assignment=next(n for n in stage.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='people' for t in n.targets))
    assert ast.unparse(people_assignment.value)=='r13_visible_people()'
    result={'status':'passed','kind':'host-side actual source schedule tests, not browser play',
        'conditions':conditions,'original_resident_ids':len(original_people),'first_entry_people':first,'maximum_gate':maxima,
        'checks':['all preexisting schedules unchanged','same-time permission population equality',
            'guard available through all periods','guard work topics gated on permission','entry and field use identical people source']}
    out=ROOT/'qa-room13-0153/gate-continuity';out.mkdir(parents=True,exist_ok=True)
    (out/'source-report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':
    main()
