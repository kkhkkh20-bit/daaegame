"""Authored line performance. Exact text guards prevent stale scene-index acting."""
import ast
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
# One code per line, including '-' for narration. These are editorial choices,
# not random or keyword-based emotion inference.
# Quiet listening is the default for a whole exchange. Large gestures are
# reserved for named emotional turns: the rescue, a direct accusation, and loss.
# Ordinary questions do not trigger a new physical pose on every reply.
SCENES = {
    'entry:karo:arrival': 'nnn',
    'entry:arrival': 'nnnnn-dn',
    'entry:explain': 'nnn',
    'entry:corrected': 'nnn',
    'entry:insufficient': 'n',
    'entry:letter': 'n',
    'entry:wait': 'ndn',
    'entry:departure': 'nn',
    'entry:daram:waiting': 'dnd',
    'entry:karo:road': 'nnn',
    'entry:karo:witness': 'nnnn',
    'entry:karo:bags': 'n',
    'opening:carriage:v1': 'nnnnn-nnnnnn-',
    'day4:appointment:v3': 'nnnnnnn',
    'day5:notice': 'nnn-',
    'night1:meal': 'nnn',
    'night1:knocking': '-nnnd',
    'night1:stay': 'dn',
    'case:appointment:v3': 'nnn-',
    'case:separate:v3': 'nn',
    'case:father:parcel:v3': 'n-nn',
    'case:father:return:v3': '-ndndpn-',
    'case:discovery:v3': '-n-dnd-',
    'case:preserve:v3': 'nn',
    'case:unpreserved:v3': 'dd-',
    'case:sealing:v3': 'n-dnnnnn',
    'case:displaced:v3': 'd-',
    'case:prevented:watch': '-d',
    'case:prevented:accompany': 'nnn-d',
    'case:prevented:result': 'nn-',
    'trial:opening': 'nnnnn',
    'trial:C1:start': 'nn',
    'trial:C2:start': 'nn',
    'trial:C3:start': 'n',
    'trial:C4:prepared': 'n',
    'trial:C4:prepared_pin': 'n',
    'trial:C4:start': 'n',
    'trial:C1:counter': 'nn',
    'trial:C1:done': 'n',
    'trial:C1:wrong': 'n',
    'trial:C1:overreach': 'n',
    'trial:C2:done': 'nnndn',
    'trial:C2:wrong': 'd',
    'trial:C3:done': 'nnn',
    'trial:C3:wrong': 'e',
    'trial:C4:done': 'nnendn',
    'trial:C4:wrong': 'n',
    'buri:consent:repair': 'nn',
    'buri:consent:needs_record': 'n',
    'buri:consent:accepted': 'nn',
    'buri:consent:refused': 'e',
    'reunion:after_intervention:v3': 'ndn',
    'reunion:held:question': 'dnd',
    'reunion:held:visited': 'nn',
    'reunion:held:unvisited': 'dn',
    'reunion:free': 'd-d',
    'reunion:prevented': 'nn',
    'reunion:injured': 'dn',
    'reunion:lure': 'nn-nnn',
    'reunion:research': 'nnn',
    'finale:arrival': '-en',
    'finale:granny_detained': '-nn',
    'finale:granny_free': 'n-',
    'finale:mother_arrives': '-ndn-',
    'finale:child_on_convoy': 'pe',
    'finale:child_with_family': 'nn',
    'finale:escape_blocked': 'd',
    'finale:emergency_rescue': 'ne-dn',
    'finale:last_rescue_failed': '-b-',
    'ending:E0': 'nnd',
    'ending:E2': 'dnn-',
    'ending:E1': 'dn-',
    'ending:E3': '-n-',
    'ending:E4': 'dnn-',
    'ending:E5:meal': '-nnnnn',
    'ending:elder_dead': '-d',
    'ending:elder_survived': 'n',
    'ending:family': 'nnnj',
    'ending:E6': 'nnnn-nn-',
    'negotiation:erased:start': 'dnn',
    'negotiation:erased:accepted': 'nnd',
    'negotiation:erased:cut': 'nnn',
    'negotiation:erased:threat': 'e-',
    'negotiation:supplies:agreement': 'nnn',
    'negotiation:supplies:unfunded': 'nnn',
    'negotiation:supplies:popularity': 'n',
}
POSE = dict(n='neutral', t='thinking', d='distressed', e='expressive',
            j='joy', p='panic', b='breakdown')

TOPIC_CUES = {
    'register': 'nnnnnnn',
    'granny_letter': 'nnnnnn',
    'granny_rules': 'nnnn',
    'karo_road': 'nnnnn',
    'karo_parcel': 'nnn',
    'owl_glove': 'nnnnnnn',
    'owl_mother': 'nnnn',
    'buri_work': 'nnn',
    'buri_consent': 'dndnn',
    'buri_records': 'dnnnn',
    'nabi_food': 'nnnn',
    'nabi_alibi': 'nnnnn',
    'nabi_gap': 'nnnn',
    'doto_corridor': 'nnnnnn',
    'bami_boundary': 'nnnn',
    'bami_saw': 'nnnnnnn',
    'tok_pin': 'nnnnn',
    'tok_repair': 'nnnnn',
    'lamplighter_guarded': 'nnnnn',
    'lamplighter_warning': 'nnnnn',
    'neoul_custody': 'nnn',
    'seryeon_mail': 'nnnnn',
    'w2_contact': 'dnnnnnn',
    'w2_lamps': 'nnn',
    'w2_doctor': 'nnn',
    'w2_erased': 'dnnnd',
    'w2_school': 'nnn',
    'w2_eunho': 'nnn',
    'w2_supply_receipt': 'nnn',
    'w2_buri_ops': 'nnn',
    'w2_bori': 'nnn',
    'w2_nubi': 'nnn',
    'w2_laundry': 'nnn',
    'w2_stay_order': 'nnn',
    'w2_maintenance': 'nnn',
    'w2_route': 'nnn',
    'w2_prevented_plan': 'nnnnn',
    'w2_mom_past': 'nnnnn',
    'w2_mom_stone': 'nnnnn',
    'w2_mom_plan': 'nnnnn',
    'seori_case': 'nnn',
    'seori_previous': 'nnnnnn',
    'life:nabi:changed': 'nnnn',
    'life:resident_bori:changed': 'nnn',
    'life:resident_teacher:changed': 'nnn',
    'life:resident_tori:changed': 'nnn',
    'life:resident_tori:repair': 'nnn',
    'life:resident_librarian:dated': 'nnn',
    'life:resident_ubak:measurement': 'nnn',
    'life:resident_guseul:receipt': 'nnn',
    'life:resident_nero:privacy': 'nne',
}
# Work conversation (four lines), post-incident response, crisis response pair.
# Daily conversations hold a listening pose; personality lives in the wording.
# Situation-specific performances above carry the exceptional emotional turns.
LIFE_CUES = {
    'resident_tori': ('nnnn', 'n', 'nn'),
    'resident_bori': ('nnnn', 'n', 'nn'),
    'resident_yeoni': ('nnnn', 'n', 'nn'),
    'nabi': ('nnnn', 'n', 'nn'),
    'buri': ('nnnn', 'n', 'nn'),
    'resident_kongi': ('nnnn', 'n', 'nn'),
    'doto': ('nnnn', 'n', 'nn'),
    'resident_kkwak': ('nnnn', 'n', 'nn'),
    'granny': ('nnnn', 'n', 'nn'),
    'resident_librarian': ('nnnn', 'n', 'nn'),
    'resident_owlgp': ('nnnn', 'n', 'nn'),
    'resident_teacher': ('nnnn', 'n', 'nn'),
    'karo': ('nnnn', 'n', 'nn'),
    'resident_nero': ('nnnn', 'n', 'nn'),
    'resident_seol': ('nnnn', 'n', 'nn'),
    'resident_ppul': ('nnnn', 'n', 'nn'),
    'resident_tok': ('nnnn', 'n', 'nn'),
    'bami': ('nnnn', 'n', 'nn'),
    'resident_sling': ('nnnn', 'n', 'nn'),
    'resident_momo': ('nnnn', 'n', 'nn'),
    'resident_ttadak': ('nnnn', 'n', 'nn'),
    'resident_piko': ('nnnn', 'n', 'nn'),
    'resident_mungchi': ('nnnn', 'n', 'nn'),
    'resident_madam': ('nnnn', 'n', 'nn'),
    'resident_siluk': ('nnnn', 'n', 'nn'),
    'neoul': ('nnnn', 'n', 'nn'),
    'resident_musoe': ('nnnn', 'n', 'nn'),
    'resident_somi': ('nnnn', 'n', 'nn'),
    'resident_seori': ('nnnn', 'n', 'nn'),
    'resident_ubak': ('nnnn', 'n', 'nn'),
    'resident_nubi': ('nnnn', 'n', 'nn'),
    'resident_eunho': ('nnnn', 'n', 'nn'),
    'resident_guseul': ('nnnn', 'n', 'nn'),
    'resident_badook': ('nnnn', 'n', 'nn'),
    'resident_lamplighter': ('nnnn', 'n', 'nn'),
}


def build():
    codes_by_scene = dict(SCENES)
    found = {}
    for path in (ROOT / 'game').glob('room13*.rpy'):
        for line in path.read_text().splitlines():
            line = line.strip()
            if not line.startswith('call r13_lines('):
                continue
            try:
                call = ast.parse(line[5:], mode='eval').body
                entries, identity = [ast.literal_eval(arg) for arg in call.args]
            except (SyntaxError, ValueError, TypeError):
                continue
            if identity in SCENES:
                assert identity not in found, identity
                found[identity] = entries
    assert set(found) == set(SCENES), set(SCENES) - set(found)
    topics = json.loads((ROOT/'game/room13-content.json').read_text())['topics']
    topic_cues = dict(TOPIC_CUES)
    for person, (work, after, crisis) in LIFE_CUES.items():
        topic_cues['life:'+person+':work'] = work
        topic_cues['life:'+person+':after'] = after+'n'
        topic_cues['life:'+person+':crisis'] = crisis[0]+'n'+crisis[1]
    for key, codes in topic_cues.items():
        assert key in topics, key
        for prefix in ('topic:', 'topic:review:'):
            identity = prefix+key
            found[identity] = topics[key]['lines']
            codes_by_scene[identity] = codes
    output = {}
    for identity, codes in codes_by_scene.items():
        entries = found[identity]
        assert len(entries) == len(codes), (identity, len(entries), len(codes))
        output[identity] = {}
        for index, (entry, code) in enumerate(zip(entries, codes)):
            person, text = entry[:2]
            assert (person is None) == (code == '-'), (identity, index, person, code)
            if code == '-':
                continue
            pose = POSE[code]
            # Named high-intensity gestures exist only on the relevant family sheet.
            if code in ('j', 'p'):
                assert person == 'daram', (identity, index, person, code)
            if code == 'b':
                assert person == 'dad'
            expression = pose if code in 'ntde' else {'j':'neutral','p':'distressed','b':'distressed'}[code]
            output[identity][str(index)] = dict(person=person, pose=pose, expression=expression, text=text)
    path = ROOT / 'art/pixel-b/acting/line-direction.json'
    path.write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n')
    print(f'{len(output)} scenes, {sum(len(x) for x in output.values())} exact-text guarded acting cues: {path}')


if __name__ == '__main__':
    build()
