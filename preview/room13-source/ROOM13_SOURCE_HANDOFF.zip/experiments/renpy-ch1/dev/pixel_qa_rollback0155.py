"""Natural dialogue rollback without record/menu interactions as checkpoint confounds."""
import asyncio,argparse,json,shutil,urllib.request
from playwright.async_api import async_playwright
from pixel_qa_say_records0155 import SayQA,ROOT
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',default='qa-room13-0155/viewpoint-rollback-clean');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True);report={'archive_sha256':json.load(urllib.request.urlopen(a.url+'game-transport.json'))['archive_sha256'],'kind':'natural-dialogue-rollback-without-record-UI-or-save-actions'}
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},service_workers='block');pg=await c.new_page();q=SayQA(pg,out)
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub');await q.press('까로');await q.wait('r13_entry_karo_topics');await q.value('road');await q.wait('say');report['initial']=await q.line();await q.input(810,625);await q.wait('say');report['second']=await q.line();await q.input(810,625);await q.wait('say');report['third']=await q.line();assert report['third']['index']==2;report['rollback_steps']=[]
   for i in range(4):
    await pg.keyboard.press('PageUp');await asyncio.sleep(.8);line=await q.line();report['rollback_steps'].append(line);await q.shot('rollback-'+str(i+1))
    if line['index']==1:break
   assert report['rollback_steps'][-1]['index']==1;report['status']='passed' if len(report['rollback_steps'])==1 else 'extra-rollback-stop';await q.advance();await q.wait('r13_entry_karo_topics');report['conversation_completes']=True
  except Exception as e:report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
  (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({'status':report['status'],'steps':[(x['index'],x['speaker'])for x in report.get('rollback_steps',[])]}));await b.close()
if __name__=='__main__':asyncio.run(main())
