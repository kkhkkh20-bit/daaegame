"""Natural portrait/narrow UI regression. Preferences only; no story injection."""
import asyncio,json,shutil
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_ui0156 import UIQA
OUT=Path('/workspace/room13-review/portrait0172');OUT.mkdir(exist_ok=True)
URL='http://127.0.0.1:8094/room13-dev/'
async def main():
 report={'base':'bc0359b16935feb77712b791ca5335ab06f61480','conditions':['Chromium touch emulation','390x844 portrait','320x568 narrow portrait','568x320 narrow landscape','large text enabled','fresh browser; natural day 1; no story injection'],'checks':[]}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':390,'height':844},has_touch=True);pg=await c.new_page();q=UIQA(pg,OUT);q.touch=True
  try:
   await pg.goto(URL);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.shot('01-title-portrait')
   await q.py('import renpy;s=renpy.store;s.preferences.text_cps=0;s.persistent.room13_large_text=True;result=True');await q.press('처음부터');await q.wait('say');await q.shot('02-dialogue-portrait');await q.advance();await q.wait('r13_hub')
   await q.value(('person','karo'));await q.advance();await q.wait('r13_topics');await q.shot('03-topic-unread-portrait');key='life:karo:work'
   await q.value(key);await q.advance();await q.wait('r13_topics');await q.shot('04-topic-read-portrait')
   for i,size in enumerate([{'width':320,'height':568},{'width':568,'height':320},{'width':390,'height':844}]):
    await pg.set_viewport_size(size);await asyncio.sleep(.5);before=await q.room();await q.value(key);await q.advance();await q.wait('r13_topics');after=await q.room()
    assert all(before[k]==after[k] for k in ['day','period','evidence','flags','propositions'])
    assert await q.py('import renpy;s=renpy.store;result=s.r13_calendar_topic_seen("life:karo:work",s.ROOM13["topics"]["life:karo:work"])')
    assert any('✓' in b['text'] for b in (await q.state())['buttons'])
    await q.shot('05-repeat-%d-%dx%d'%(i,size['width'],size['height']))
   await q.press('보여주기');await q.wait('r13_book');await q.press('초대 편지');await q.shot('06-evidence-portrait');await q.press('그만두기');await q.wait('r13_topics');assert any('✓' in b['text'] for b in (await q.state())['buttons']);await q.press('돌아가기');await q.advance();await q.wait('r13_hub')
   report['checks'].append('Read question remains checked/clickable across three repeated selections and evidence cancel; no clock/evidence/flag/proposition change')
   await q.travel('여관 접수대');assert (await q.room())['location']=='inn';await q.press('지도 · 이동');await q.wait('r13_map');assert await q.py('import renpy;result=renpy.exports.get_screen("r13_map").scope["region"]')=='inn';await q.shot('07-inn-before-checkin-portrait');await q.press('현장으로 돌아가기');await q.wait('r13_hub')
   await q.press('할머니');await q.advance();await q.wait('r13_hub');await q.press('지도 · 이동');await q.wait('r13_map');await q.press('2층 복도');before=await q.room();await q.shot('08-inn-select-hall-portrait');assert (await q.room())['location']=='inn';await q.press('이곳으로 이동');await q.advance();await q.wait('r13_hub');assert (await q.room())['location']=='hall'
   await q.press('지도 · 이동');await q.wait('r13_map');await q.press('13호실');await pg.set_viewport_size({'width':320,'height':568});await q.shot('09-room-selection-narrow');await q.press('이곳으로 이동');await q.advance();await q.wait('r13_hub');assert (await q.room())['location']=='room13'
   await q.press('기록');await q.wait('r13_records');await q.shot('10-records-narrow');await pg.set_viewport_size({'width':568,'height':320});await q.shot('11-records-narrow-landscape');await q.press('닫기');await q.wait('r13_hub')
   report['checks'].append('After actual inn entry map opens interior; selecting hallway does not move until explicit Move; actual hallway and room navigation work in portrait/narrow touch view')
   report['status']='passed-pending-visual-review'
  except Exception as e:
   report.update(status='failed',error=repr(e));await pg.screenshot(path=str(OUT/'failure.png'))
   try:(OUT/'failure-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
   except:pass
  (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']=='failed':raise SystemExit(1)
asyncio.run(main())
