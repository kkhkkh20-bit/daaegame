"""Targeted browser ENGINE FIXTURES, not ordinary end-to-end player routes.

Injects authored branch state, then clicks an injected Jump action on a real
Ren'Py button and advances the actual labels/screens with mouse input.
Run only against the final candidate build after its producer signals ready.
"""
import argparse
import asyncio
import json
from pathlib import Path
import shutil
from playwright.async_api import async_playwright

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'qa-room13-012'/'fixtures'
PROBE='''import renpy
names=['main_menu','say','choice','r13_hub','r13_interaction','r13_topics','r13_book','r13_confirm','r13_calendar','r13_map','r13_activities','r13_debate','r13_handoff','r13_crisis','r13_crisis_proof','r13_ending_screen','r13_cinematic_view','save','load','pause_menu','confirm']
def txt(w,depth=0):
 if depth>8:return ''
 if isinstance(w,renpy.text.text.Text):return ''.join(str(x) for x in w.text)
 return ' '.join(txt(x,depth+1) for x in w.visit())
buttons=[]
for i,f in enumerate(renpy.display.focus.focus_list):
 if f.x is not None and f.w and f.h:
  a=getattr(f.widget,'clicked',None)
  buttons.append({'index':i,'button':isinstance(f.widget,renpy.display.behavior.Button),'text':txt(f.widget),'value':str(getattr(a,'value','')),'rect':[f.x,f.y,f.w,f.h]})
say=renpy.display.screen.get_screen('say')
cg=renpy.display.screen.get_screen('r13_cinematic_view')
result={'version':renpy.store.config.version,'screens':[n for n in names if renpy.display.screen.get_screen(n)],'room':getattr(renpy.store,'room13',{}),'say':str(say.scope.get('what','')) if say else '', 'buttons':buttons,'cinematic':str(cg.scope.get('key','')) if cg else None,'knowledge':list(renpy.store.persistent.room13_knowledge),'read_count':len(renpy.store.persistent.room13_read),'endings':list(renpy.store.persistent.room13_endings),'cinematics_seen':list(renpy.store.persistent.room13_cinematics_seen)}
'''

async def main(url,scenario="all"):
 OUT.mkdir(parents=True,exist_ok=True)
 report={'kind':'injected-engine-fixtures-not-normal-play','url':url,'checks':[], 'errors':[], 'http_errors':[]}
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader'])
  context=await browser.new_context(viewport={'width':1280,'height':720})
  page=await context.new_page()
  page.on('pageerror',lambda e:report['errors'].append(str(e)))
  page.on('response',lambda r:report['http_errors'].append([r.status,r.url]) if r.status>=400 and 'favicon' not in r.url else None)
  async def py(code):return await page.evaluate('code=>renpy_exec(code)',code)
  async def state():return await py('ns={}; exec('+repr(PROBE)+',ns); result=ns["result"]')
  async def click(x,y):
   await page.mouse.click(x,y);await page.wait_for_timeout(550)
  async def button(text):
   await page.wait_for_timeout(650)
   s=await state();b=next(b for b in s['buttons'] if b['button'] and text in b['text'] and b['rect'][3]>15)
   x,y,w,h=b['rect'];await click(x+w/2,y+h/2)
  async def shot(name):await page.screenshot(path=str(OUT/(name+'.png')))
  async def advance_until(screen,limit=180,capture_cg=False):
   for i in range(limit):
    s=await state()
    if screen in s['screens']:return s
    if 'r13_cinematic_view' in s['screens']:
     if capture_cg:await shot('cg-'+s['cinematic'])
     await button('계속')
    elif 'say' in s['screens'] and not any(v in s['screens'] for v in ('choice','r13_hub','r13_confirm','r13_book','r13_ending_screen')):
     await click(850,630)
    elif not s['screens']:
     await page.wait_for_timeout(500)
    else:raise AssertionError(('Unexpected screen waiting '+screen,s['screens'],s['say']))
   raise AssertionError('Too many lines waiting '+screen)
  async def jump(label,setup=''):
   await py('import renpy\ns=renpy.store\n'+setup+'\ns.r13_scene_key=None\nrenpy.exports.restart_interaction()\nresult=True')
   await page.wait_for_timeout(1000)
   s=await state()
   b=next(b for b in s['buttons'] if b['button'] and b['text'] and b['rect'][3]>15)
   await py('import renpy\ns=renpy.store\nw=renpy.display.focus.focus_list['+str(b['index'])+'].widget\nw.action=s.Jump('+repr(label)+')\nw.clicked=w.action\nw.sensitive=True\nresult=True')
   x,y,w,h=b['rect'];await click(x+w/2,y+h/2)
  def check(name,condition,details=None):
   report['checks'].append({'name':name,'passed':bool(condition),'details':details})
   (OUT/('report-finale.json' if scenario=='finale' else 'report.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2))
   assert condition,(name,details)
  try:
   await page.goto(url)
   await page.wait_for_function("typeof renpy_exec==='function'",timeout=120000)
   await page.wait_for_timeout(1800)
   await page.wait_for_function("renpy_exec('import renpy; result=hasattr(renpy.store, \"R13_CINEMATICS\")')",timeout=60000)
   s=await state();report['version']=s['version']
   await py('import renpy; renpy.store.preferences.text_cps=0; result=True')
   await button('처음부터')
   await advance_until('r13_hub',capture_cg=True)
   base='s.room13=s.r13_new()\ns.r13_upgrade()\ns.r13_flag("lodging","entry_corrected")\ns.r13_grant(["E01","E02"],"fixture setup")\n'
   if scenario=='finale':
    await jump('r13_finale',base+'s.r13_edit(day=14,period=0,case_state="occurred",victim_state="dead",daram_state="with_dad",granny_state="detained",propositions=["C2","C3","C4"])\ns.r13_flag("mom_reunited")\ns.r13_grant(["E20","E31"],"fixture evidence")')
    await advance_until('r13_crisis',capture_cg=True)
    await page.wait_for_timeout(600);await button('야생화한 주민')
    await advance_until('r13_crisis_proof')
    await page.wait_for_timeout(600);await button('논리를 연결한다')
    s=await advance_until('r13_crisis_proof')
    check('Owning evidence does not auto-submit or prove F1','F1' not in s['room']['propositions'] and not s['room']['arguments'].get('F1'))
    for key in ('E20','E31'):
     await page.wait_for_timeout(600);await button('근거를 제시한다')
     await page.wait_for_timeout(600)
     for attempt in range(8):
      ss=await state();matching=[b for b in ss['buttons'] if b['button'] and b['value']==key]
      if matching:
       b=matching[0];x,y,w,h=b['rect'];await click(x+w/2,y+h/2);break
      await page.mouse.move(380,430);await page.mouse.wheel(0,300);await page.wait_for_timeout(400)
     else:raise AssertionError('Evidence not reachable '+key)
     await button('이 주장에 근거로 낸다')
     await advance_until('r13_crisis_proof')
    await page.wait_for_timeout(600);await button('논리를 연결한다')
    await advance_until('choice');await page.wait_for_timeout(600);await button('나중에 다시 악화')
    s=await advance_until('r13_crisis_proof');await shot('F1-wrong-reason')
    check('Wrong reasoning preserves submitted evidence but does not prove F1','F1' not in s['room']['propositions'] and set(s['room']['arguments']['F1'])=={'E20','E31'})
    await page.wait_for_timeout(600);await button('논리를 연결한다')
    await advance_until('choice');await page.wait_for_timeout(600);await button('모두 낫는다는 뜻은 아니다')
    s=await advance_until('r13_crisis');await shot('F1-proved')
    check('Correct reasoning proves F1 via actual evidence UI','F1' in s['room']['propositions'])
    check('No JavaScript or HTTP asset errors',not report['errors'] and not report['http_errors'])
    report['status']='passed';return
   await jump('r13_verdict',base+'s.r13_edit(day=7,period=0,case_state="occurred",victim_state="dead",daram_state="held",propositions=["C2","C3","C4"])')
   s=await advance_until('r13_hub',capture_cg=True);await shot('cleared-day8')
   check('Day 7 acquittal and culprit proof preserved into Day 8',s['room']['day']==8 and s['room']['daram_state']=='with_dad' and s['room']['granny_state']=='detained' and s['room']['trial_result']=='culprit_proven',s['room'])
   await jump('r13_prevention_hearing',base+'s.r13_edit(day=7,period=0,case_state="prevented",victim_state="protected",daram_state="with_dad")')
   await advance_until('choice');await button('어르신과 함께')
   s=await advance_until('r13_hub',capture_cg=True);await shot('prevented-day8')
   check('Prevented case keeps elder alive and daughter with father in Week 2',s['room']['day']==8 and s['room']['case_state']=='prevented' and s['room']['victim_state']=='protected' and s['room']['daram_state']=='with_dad',s['room'])
   for key in [f'E{i}' for i in range(7)]:
    setup=base+'s.r13_edit(day=14,period=0,case_state="occurred",victim_state="dead",daram_state='+repr('lost' if key=='E1' else 'rescued')+',granny_state="detained")\ns.r13_ending_id='+repr(key)
    if key in ('E2','E3','E4','E5','E6'):setup+='\ns.r13_flag("mom_reunited")\ns.r13_edit(mom_state="reunited")'
    if key in ('E4','E5','E6'):setup+='\ns.r13_prove("F2")'
    if key in ('E5','E6'):setup+='\ns.r13_flag("shelter_ready","supplies_ready","operators_ready","patient_transport")'
    if key=='E6':setup+='\ns.r13_prove("F4")'
    await jump('r13_ending',setup)
    s=await advance_until('r13_ending_screen',capture_cg=True);await shot('ending-'+key)
    check('Ending '+key+' renders narrative, cutscene, and ending screen',s['room']['ending']==key and key in s['endings'] and key in s['cinematics_seen'],{'screens':s['screens'],'ending':s['room']['ending'],'cinematics_seen':s['cinematics_seen']})
   # Real restart button performs full_restart. This is not a manual state clear.
   before=await state();await button('새 여정 시작')
   await advance_until('choice');await button('마을 입구부터')
   s=await advance_until('r13_hub',capture_cg=True);await shot('restarted-day1')
   check('Real restart clears current case and preserves earned history',s['room']['day']==1 and s['room']['daram_state']=='with_dad' and s['room']['case_state']=='pending' and s['room']['evidence']==['E01'] and not s['room']['resident_knowledge'] and set(before['knowledge'])<=set(s['knowledge']) and s['read_count']>=before['read_count'] and len(s['endings'])==7,{'room':s['room'],'knowledge':s['knowledge'],'read_count':s['read_count'],'endings':s['endings']})
   check('No JavaScript or HTTP asset errors',not report['errors'] and not report['http_errors'])
   report['status']='passed'
  except Exception as exc:
   report['status']='failed';report['failure']=repr(exc)
   try:
    report['last_state']=await state();await shot('failure')
   except Exception:pass
   raise
  finally:
   (OUT/('report-finale.json' if scenario=='finale' else 'report.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2))
   print(json.dumps({'status':report.get('status'),'checks':len(report['checks']),'report':str(OUT/('report-finale.json' if scenario=='finale' else 'report.json')),'failure':report.get('failure')},ensure_ascii=False),flush=True)
   await browser.close()

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--url',default='http://127.0.0.1:8093/preview/room13-candidate/')
 parser.add_argument('--scenario',choices=['all','finale'],default='all')
 args=parser.parse_args();asyncio.run(main(args.url,args.scenario))
