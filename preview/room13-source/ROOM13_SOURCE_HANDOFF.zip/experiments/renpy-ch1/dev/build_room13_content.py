"""Compile the reviewed first-week slice into explicit, authored runtime content.
No generated dialogue at runtime. Story bible is not executable game state.
"""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
bible=json.loads((ROOT/'story-room13/narrative.json').read_text())
D={'schema':1,'campaign':'room13_v1','scope':'day1-through-day8-opening','evidence':{e['id']:e for e in bible['evidence'] if int(e['id'][1:])<=18 or e['id'] in ('E20','E33','E34')},'topics':{},'activities':{},'objects':{},'claims':bible['claims'][:4]}
for i,name,desc in [('G1','예약 원본','보호자와 동행 아동, 두 사람이 적혀 있다.'),('G2','동반 보호 규정','동행 아동의 인계에는 보호자의 확인과 서명이 필요하다.'),('G3','초소의 옮겨 쓴 명부','예약 원본에서 옮긴 사본에는 어른 한 명만 적혀 있다.')]:
 D['evidence'][i]=dict(id=i,name=name,kind='기록',establishes=desc,does_not_establish='입구 등록에 관한 자료다. 이후 사건의 유무죄와는 별개다.')
def topic(id,npc,title,lines,**kw):
 D['topics'][id]=dict(npc=npc,title=title,lines=lines,day=[1,7],need=[],flags=[],give=[],**{})
 D['topics'][id].update(kw)
def activity(id,place,title,lines,**kw):
 D['activities'][id]=dict(place=place,title=title,lines=lines,day=[1,6],need=[],flags=[],give=[],cost=1)
 D['activities'][id].update(kw)
def obj(place,id,rect,text,**kw):
 D['objects'].setdefault(place,{})[id]=dict(rect=rect,text=text,give=[],need=[],flags=[],**{})
 D['objects'][place][id].update(kw)
topic('register','granny','방을 부탁한다',[
 ['granny','편지는 받으셨죠.'],['dad','네. 아내가 여기 있었다고 하셨습니다.'],['granny','물건도 그대로 두었어요. 우선 아이부터 앉혀요. 신발까지 젖었네.'],['daram','눈이 위로 들어왔어요.'],['granny','털기만 하면 안 돼. 양말도 갈아야지.'],['dad','남긴 것부터 보겠습니다.'],['granny','복도 끝 방에 두었어요. 열쇠는 가져가요. 문이 뻑뻑하니 밀면서 돌리고.']],flags=['lodging'])
topic('granny_letter','granny','편지를 보내신 이유',[
 ['dad','아내가 직접 연락해 달라고 했습니까?'],['granny','가족에게 돌려줘야 할 물건이 남았잖아요.'],['dad','언제 떠났는지도 알고 싶습니다.'],['granny','나간 날짜는 장부에 있어요. 어디로 갔는지는 본 사람이 없고.'],['daram','인사도 안 했어요?'],['granny','나도 기다렸어요.']],need=['lodging'])
topic('granny_rules','granny','밤에 잠그는 문',[
 ['dad','안쪽에도 빗장을 두 개나 달았군요.'],['granny','길을 잃은 분이 남의 집 문을 여는 일이 있어요.'],['daram','집을 못 찾으면 여기서 기다리면 되잖아요.'],['granny','그분들한테는 따로 쉬는 곳이 있어. 너는 아빠와 같이 다니고.']])
topic('karo_road','karo','돌아가는 마차',[
 ['karo','축이 갈라졌어요. 여기 내려오는 동안 버텨 준 게 다행이지.'],['dad','수리하면 바로 나갈 수 있습니까?'],['karo','바퀴가 굴러도 고개가 막혔어요. 눈이 내려앉을 때까진 못 갑니다.'],['daram','그러면 내일도 여기 있어요?'],['karo','당분간은요. 돌아갈 때 먼저 알려 드릴게요.']],flags=['road_known'])
topic('karo_parcel','karo','반송된 물건',[
 ['karo','성함이 적힌 반송표가 왔어요. 목요일 저녁에 외곽 초소에서 확인하기로 했습니다.'],['dad','아내 물건일 수도 있겠군요.'],['karo','그건 열어 봐야 알죠. 꼭 그날 못 오시면 맡아 둘게요.']],day=[2,4],flags=['parcel_known'])
topic('owl_glove','resident_owlgp','난간을 붙들고 있는 어르신',[
 ['resident_owlgp','발밑.'],['daram','네?'],['resident_owlgp','장갑. 밟고 있다.'],['daram','아. 고맙습니다.'],['resident_owlgp','한 짝만 잃으면 남은 것도 못 쓰지. 주머니 깊이 넣어.'],['daram','아빠 것도 제가 갖고 있어요.'],['resident_owlgp','그럼 더 깊이.']])
topic('owl_mother','resident_owlgp','찾고 있는 사람',[
 ['dad','이 편지에 적힌 손님을 아십니까?'],['resident_owlgp','누굴 아느냐고 묻는 사람은 많소. 왜 찾는지가 다를 뿐이지.'],['dad','제 아내입니다. 아이 엄마고요.'],['resident_owlgp','여기서 남의 이름을 크게 부르지는 마시오. 확인할 게 있으면 내가 이야기하지.']],need=['E01'],flags=['elder_contact'])
topic('buri_work','buri','마차 수리를 부탁한다',[
 ['buri','축부터 봐야죠. 못 하나 박고 끝날 일은 아니에요.'],['dad','까로에게 들었습니다. 필요한 일이 있으면 돕겠습니다.'],['buri','약속은 나중에 해요. 할 일 생기면 부를 테니까.']])
topic('buri_consent','buri','할아버지에 관한 소문',[
 ['buri','밖에서는 할아버지가 아이를 잡아먹으려 했대요.'],['dad','그렇게 말한 적 없습니다.'],['buri','누군가는 했어요. 다람이를 구하려고.'],['dad','확인하지 않은 말은 쓰지 않겠습니다. 병에 관해서도 먼저 가족에게 묻겠습니다.'],['buri','그 말, 사람들 앞에서도 해요.']],case='occurred',flags=['medical_consent'])
topic('buri_records','buri','새로 열린 이야기 · 할아버지가 남긴 일',[
 ['buri','며칠 전부터 단어가 잘 안 떠오른다고 했어요. 일을 쉬라니까 이번 건은 끝내야 한대요.'],['dad','이번 건이 뭡니까?'],['buri','나도 몰라요. 내가 안 물었으니까.'],['buri','보관함 사본이에요. 돌려줘야 합니다. 이걸 준다고 당신을 믿는 건 아니에요.']],need=['topic:buri_records'],give=['E17'])
topic('nabi_food','nabi','도울 일이 있나',[
 ['nabi','그릇 두 개만 옮겨 줘. 뜨거우니까 밑으로 잡고.'],['daram','아빠 것까지 한 번에 가져갈게요.'],['nabi','두 번 오면 되잖아. 한 번에 다 들지 말고.'],['dad','이쪽은 내가 들게.']])
topic('nabi_alibi','nabi','그날 식당에서 본 것',[
 ['nabi','할머니는 나랑 있었어. 내가 봤다니까.'],['dad','첫 비명이 났을 때 말이지?'],['nabi','응. 식탁 끝에서 나한테 컵을 달라고 했어. 목도리 브로치도 여며 줬고.'],['dad','그 뒤에는?'],['nabi','물 가지러 갔지. 돌아왔을 때도 물을 들고 있었어.']],case='occurred',give=['E15'])
topic('nabi_gap','nabi','새로 열린 이야기 · 물을 데우던 동안',[
 ['dad','복도에서는 그 뒤에 큰 소리를 들었다고 해. 주방에서도 계속 얼굴을 봤어?'],['nabi','……그건 아니지. 그런데 물을 들고 왔어.'],['dad','네가 본 것과 우리가 짐작한 걸 나누려는 거야.'],['nabi','그럼 그렇게 적어. 같이 있던 것도 빼지 말고.']],need=['topic:nabi_gap'],give=['E12'])
topic('doto_corridor','doto','복도에서 들은 소리',[
 ['doto','처음 비명에 복도로 나왔어요. 앞문으로 드나드는 사람은 없었고요.'],['dad','그 뒤에 들은 말도 있습니까?'],['doto','그 애부터 내보내라고 했어요. 그다음은 작아서 잘 안 들렸고. 한참 있다가 더 둔한 소리가 났어요.'],['dad','말소리는 처음 비명보다 나중입니까?'],['doto','네. 그건 분명해요. 문 뒤를 봤다는 뜻은 아니고요.']],case='occurred',give=['E11'])
topic('bami_boundary','bami','처마에서 보이는 곳',[
 ['bami','문 쪽은 안 보여. 자꾸 거길 물어도 몰라.'],['dad','어디까지 보였니?'],['bami','침대 밑. 쇠살 사이로 거기만. 방 안 얼굴은 안 보여.'],['bami','내 이름 적으면 또 검사하러 와. 날개 떠는 것도 병이라고 했어.']],case='occurred',flags=['bami_warning'])
topic('bami_saw','bami','새로 열린 이야기 · 두 번째 소리',[
 ['dad','다람이는 침대 밑에 있었다고 했어.'],['bami','응. 무릎이랑 손. 계속 거기 있었어.'],['dad','큰 소리가 났을 때도?'],['bami','그때 더 작게 웅크렸어.'],['dad','이름을 알리지 않고 우선 관찰한 내용부터 적을게.'],['bami','사람들 앞에 나가서 말하라는 건 싫어.']],need=['topic:bami_saw'],give=['E10'],flags=['bami_warning'])
topic('tok_pin','resident_tok','새로 열린 이야기 · 핀의 이음매',[
 ['resident_tok','이렇게 덧댄 핀은 내가 만들었어요. 목요일에요.'],['dad','이 조각과 맞습니까?'],['resident_tok','남은 부품과 맞춰 볼게요. ……같은 이음이에요. 수리 쪽지도 가져가세요.'],['dad','그때 누가 달고 갔죠?'],['resident_tok','할머니가요. 이걸로 누가 뭘 했는지는 나도 몰라요.']],need=['topic:tok_pin'],give=['E13'])
topic('tok_repair','resident_tok','수리 중인 브로치',[
 ['resident_tok','손은 그쪽 말고. 금속 아직 뜨거워요.'],['daram','이제 안 풀려요?'],['resident_tok','억지로 잡아당기지만 않으면요. 할머니 목도리 핀인데 오늘 새것으로 바꿨어요.'],['dad','이음이 특이하군요.'],['resident_tok','맞는 부품이 없어서 덧댔어요. 납품 기록은 남겨 둬야죠.']],day=[4,4],period=[0,1],give=['E13'])
topic('lamplighter_guarded','resident_lamplighter','등을 고치는 사람',[
 ['resident_lamplighter','조금 떨어져 있어요. 선이 끊어졌는지 보고 있으니까.'],['daram','이것도 돌로 켜요?'],['resident_lamplighter','여기 등은 그래. 너무 밝아지면 가까이 가지 마.'],['dad','고장입니까?'],['resident_lamplighter','그렇게 말하면 내가 고쳐야 하거든요. 아직은 보고 있어요.']])
topic('lamplighter_warning','resident_lamplighter','새로 열린 이야기 · 전달되지 않은 봉투',[
 ['resident_lamplighter','그 매듭, 안쪽으로 한 번 더 돌려 묶죠. 가족이 맞군요.'],['dad','아내를 만났습니까?'],['resident_lamplighter','편지를 맡았어요. 전달할 사람을 못 찾았다고 해 뒀습니다. 누가 읽을지 몰라서.'],['dad','왜 여관에는 맡기지 않았습니까?'],['resident_lamplighter','그래서는 안 되는 편지니까요. 등 밑 점검함을 여세요. 다른 데서 읽고요.']],need=['topic:lamplighter_warning'],day=[3,6],flags=['warning_location'])
topic('neoul_custody','neoul','아이를 언제 만날 수 있습니까',[
 ['neoul','들어가서 확인할 때 제가 같이 있겠습니다. 유리한 말을 시키지는 마십시오.'],['dad','아이가 겪은 순서를 듣겠습니다.'],['neoul','면회가 끝나면 원문 그대로 남깁니다. 고칠 말이 있으면 고쳤다는 기록도 같이요.']],case='occurred')
topic('seryeon_mail','seryeon','아내 앞으로 온 편지',[
 ['seryeon','수취인이 직접 와야 합니다.'],['dad','가족입니다.'],['seryeon','그러면 가족이라는 자료를 가져오셔야죠. 찾는 분이라는 말씀만으로는 안 됩니다.'],['dad','마을 밖으로 보낸 기록은요?'],['seryeon','그건 보낸 분의 기록입니다. 다른 질문으로 바뀌었군요.']])
activity('map','workshop','외벽과 보수 도면을 비교한다',[
 ['buri','도면은 빌려줄게요. 지금 벽이 이대로라는 보장은 못 해요.'],[None,'외벽 창 사이의 길이를 재고 옛 도면 옆에 적었다. 복도 끝 방 뒤에 설명되지 않는 폭이 남는다.']],give=['E04'],day=[2,6],need=['observed:workshop:plans'])
activity('passage','room13','벽 뒤 공간을 실제로 확인한다',[
 [None,'창틀에서 옮겨 잰 길이와 안쪽 벽 길이가 다르다. 장식판 아래 손잡이는 벽에 고정돼 있지 않았다.'],[None,'판넬 뒤에는 식기와 접은 천, 낮은 잠자리가 있었다. 계단은 아래층 물품 창고로 이어졌다.'],['dad','정문을 거치지 않아도 들어올 수 있겠군.'],[None,'동선을 직접 오가며 길이와 걸리는 시간을 적었다. 어느 사람이 썼는지는 아직 모른다.']],give=['E05'],need=['E04','observed:room13:under'],flags=['passage_known'],day=[2,6])
activity('interview','gate','다람이와 면회한다',[
 ['daram','아빠가 안 죽였다고 하면, 안 죽인 거야?'],['dad','내가 말한다고 바뀌진 않아.'],['daram','그럼 왜 다들한테 아니라고 해?'],['dad','아직 모르는 일이 있어서.'],['daram','나는 알아. 내가 때렸어.'],['dad','어디를?'],['daram','팔. 여기 잡은 손을 놓게 하려고. 그다음엔 침대 밑에 있었어.'],['dad','그 뒤에 들은 건?'],['daram','처음엔 쨍 했어. 나중에는…… 더 컸어.'],['dad','다른 사람이 본 것도 확인할게.']],give=['E06'],case='occurred',day=[5,6])
activity('wax','room13','봉인한 바닥 흔적을 대조한다',[
 [None,'처음 남긴 그림과 바닥을 대조했다. 신발 자국은 쏟아진 촛농을 밟고 안으로 향한다. 그 일부를 나중의 피가 덮고 있다.'],['dad','낙하 뒤, 마지막 부상 전의 출입이다. 신발 주인까지 알 수 있는 건 아니지만.']],give=['E09'],need=['E33','E07','observed:room13:floor'],case='occurred',day=[5,6])
activity('protect_bami','inn','밤이가 머물 방을 함께 마련한다',[
 ['nabi','다락은 춥고, 식당 옆방이면 내가 드나들 수 있어.'],['bami','경비가 이름 물으면?'],['dad','서리 검사원에게 관찰 범위만 확인받자. 방 위치는 공개하지 않을게.'],['bami','……그러면 내가 본 건 말할게. 못 본 걸 봤다고 하지는 않을 거야.']],need=['E10','lodging'],flags=['bami_protected','bami_consent'],day=[5,6])
activity('custody_draft','post','등록 원본과 분리 지시를 대조한다',[
 ['seryeon','등록 정정은 이미 처리했습니다.'],['dad','그런데 아이만 옮기라는 전달문에 사건 전 날짜가 있군요. 원본과 함께 확인해 주십시오.'],['seryeon','숙소에서 보낸 초안입니다. 실행된 명령이라고 적지는 마십시오.'],[None,'할머니가 보낸 별도 구금 초안을 원본 장부와 대조해 기록했다. 살인을 증명하는 물건은 아니지만, 아이를 떼어 놓으려던 계획은 먼저 있었다.']],give=['E16'],need=['E02'],case='occurred',day=[5,6])
activity('recovery','square','등에서 떨어져 피코와 기다린다',[
 ['resident_piko','소리가…… 너무 가까워.'],['daram','물 가져올까?'],['resident_owlgp','천천히. 물어보고 줘.'],[None,'조용한 처마 아래에서 기다렸다. 한참 뒤 피코가 떨어뜨린 붓을 찾았다.'],['resident_piko','내 그림은 어디 있죠?'],['daram','여기. 물은 안 쏟았어요.'],[None,'피코는 자기 이름을 다시 말했다. 완전히 나았는지는 더 보아야 한다.']],give=['E20'],day=[3,3])
activity('warning','square','점검함에서 편지를 받아 온다',[
 [None,'봉투 안쪽에는 가족끼리 쓰던 매듭이 묶여 있었다.'],[None,'「편지를 보내라고 부탁한 적 없어. 여관에 내 행선지를 말하지 마. 등불을 고치는 사람을 통해 답해 줘. 혼자 누구를 만나러 가지 말고.」'],['daram','엄마 글씨야.'],['dad','전달되지 않은 이유부터 확인하자.']],give=['E18'],need=['warning_location'],day=[3,6])
for place,key,rect,text,give in [
 ('gate','booth',[25,180,235,220],'초소 선반에는 원본 예약표가 있다. 동행 아동 칸에도 이름이 적혀 있다.',['G1']),
 ('gate','rules',[875,160,265,190],'초소에 붙은 규정. 동행 아동의 인계에는 보호자의 확인과 서명이 필요하다.',['G2']),
 ('gate','ledger',[270,420,240,120],'옮겨 쓴 명부에는 어른 한 명만 적혀 있다. 원본과 글씨도 다르다.',['G3']),
 ('gate','road',[440,320,230,250],'마차 축이 갈라졌다. 고갯길의 바퀴 자국은 눈보라 속으로 끊긴다.',[]),
 ('inn','desk',[380,375,540,160],'나무 열쇠패는 열두 개다. 할머니 손 아래 명부에는 접힌 종이가 끼어 있다.',[]),
 ('inn','door',[20,170,210,390],'안쪽 빗장은 두 겹이다. 문 바깥 손잡이와 연결돼 있지 않다.',[]),
 ('square','stone',[440,70,225,290],'돌에서 나온 관이 집들로 이어진다. 가까운 난간만 눈이 녹아 있다.',[]),
 ('square','offerings',[470,350,210,85],'장갑 한 짝, 낡은 열쇠, 이름 대신 번호가 달린 보따리. 장식이라기엔 너무 닳았다.',[]),
 ('square','lamp',[935,150,230,300],'등 받침에 작은 점검함이 있다. 함 안에 남의 봉투가 보이지만 주인부터 확인해야겠다.',[]),
 ('post','notice',[420,180,330,250],'닫힌 문에 영업 공고가 붙어 있다. 마을 밖 우편은 고갯길이 열려야 출발한다.',[]),
 ('workshop','plans',[290,208,250,130],'덧칠한 배관 선 아래로 옛 구조가 남아 있다. 지금 외벽의 길이와 비교해 볼 수 있겠다.',[]),
 ('workshop','wood',[0,440,195,180],'마른 장작과 젖은 조각을 나눠 두었다. 태울 수 있는 양은 보기보다 적다.',[]),
 ('room13','bed',[830,260,450,175],'이불 안쪽을 붉은 실로 기웠다. 다람이가 엄마의 바느질과 닮았다고 말한다. 지금 여기 있다는 뜻은 아니다.',['E03']),
 ('room13','window',[600,85,205,220],'창문은 안에서 잠겼고 겨울 봉인은 끊어지지 않았다. 아래 환기 틈에는 쇠살이 박혀 있다.',[]),
 ('room13','boxes',[15,210,235,135],'상자는 비어 있다. 오래된 천 냄새만 남았다.',[]),
 ('room13','under',[890,380,310,75],'침대 밑을 통해 찬바람이 들어온다. 벽 장식판 아래에는 닳은 손잡이가 있다.',[]),
 ('room13','floor',[785,485,400,140],'바닥 이음새를 따라 작은 틈이 나 있다. 밟으면 낮은 소리가 난다.',[]),
 ('hall','rail',[405,165,125,125],'복도에서는 방 앞문이 보인다. 방 안쪽 벽까지 볼 수는 없다.',[]),
 ('dining','table',[210,320,710,230],'수프 그릇이 제각각이다. 오래 쓰다가 모서리가 닳은 자리도 있다.',[]),
 ('passage','steps',[500,180,245,290],'열 계단 아래는 물품 창고다. 방과 창고 사이를 직접 걸어 시간을 확인할 수 있다.',[])
]: obj(place,key,rect,text,give=give)
D['evidence_sources']={'E06':'daram','E10':'bami','E11':'doto','E12':'nabi','E15':'nabi','E34':'karo'}
from room13_week2_content import extend
extend(D,bible)
from room13_residents import extend as extend_residents
extend_residents(D,bible,json.loads((ROOT/'game/legacy-resident-roster.json').read_text()))
from room13_revision_content import extend as extend_revision
extend_revision(D)
from room13_lived_spaces import extend as extend_lived_spaces
extend_lived_spaces(D)
from room13_art_geometry import extend as extend_art_geometry
extend_art_geometry(D)
from room13_dialogue_revision import apply_content as r13_apply_dialogue_revision
D = r13_apply_dialogue_revision(D)
(ROOT/'game/room13-content.json').write_text(json.dumps(D,ensure_ascii=False,indent=2)+'\n')
