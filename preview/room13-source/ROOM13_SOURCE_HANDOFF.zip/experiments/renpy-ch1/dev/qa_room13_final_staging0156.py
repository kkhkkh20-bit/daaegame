"""Final archive staging fixtures: no source or image injection."""
import asyncio,argparse,json,shutil,urllib.request
from playwright.async_api import async_playwright
from pixel_qa_flow0150 import FlowQA,ROOT
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',required=True);a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True);report={'kind':'explicit-location-period-fixtures-on-final-archive-original-art','archive_sha256':json.load(urllib.request.urlopen(a.url+'game-transport.json'))['archive_sha256'],'shots':[]}
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);pg=await b.new_page(viewport={'width':1280,'height':720});q=FlowQA(pg,out)
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub')
   for loc,period,offset in [('square',0,0),('square',0,640),('square',1,320),('inn',1,640),('inn',2,640)]:
    code='''import renpy
s=renpy.store
s.room13=dict(s.room13,location=%r,day=1,period=%d,flags=['lodging','entry_corrected'])
s.place=s.R13_PLACES[s.room13['location']][0]
s.r13_world_cameras={s.room13['location']:%d}
renpy.exports.scene()
renpy.exports.hide_screen('r13_hub')
renpy.exports.show_screen('r13_hub',entry=False)
renpy.exports.restart_interaction()
result={'actors':s.r13_stage_people(),'people':s.r13_people()}
'''%(loc,period,offset)
    row=await q.py(code);assert set(row['people'])==set(a['person']for a in row['actors'])
    if loc=='inn':
     granny=next(a for a in row['actors']if a['person']=='granny');assert granny['pose']=='world_counter_wipe'and granny['occlusion']==[];assert granny['y']+granny['height']<=642
    if loc=='square'and period==0:
     assert len(row['people'])==4
     assert next(a for a in row['actors']if a['person']=='resident_tori')['pose']=='world_bench_left'
     assert next(a for a in row['actors']if a['person']=='doto')['pose']=='world_bulletin_back'
    if loc=='square'and period==1:assert len(row['people'])==3
    await asyncio.sleep(.65);name=f'{loc}-p{period}-x{offset}';await q.shot(name);report['shots'].append({'file':name+'.png',**row})
   report['status']='passed-pending-visual-review'
  except Exception as e:report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
  finally:await b.close();(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(report['status'],report.get('error'),flush=True)
 if report['status']=='failed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
