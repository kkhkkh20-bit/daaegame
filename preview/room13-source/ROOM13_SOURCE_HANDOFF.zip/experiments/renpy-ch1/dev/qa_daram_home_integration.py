"""Verify final shared main after detailed home/calendar QA; same home module."""
import asyncio,json,shutil,urllib.request,hashlib
from pathlib import Path
from playwright.async_api import async_playwright
from qa_poc_three_days import Q,URL
OUT=Path('qa-room13-daram-home')
async def main():
 prior=json.loads((OUT/'report.json').read_text());assert prior['status']=='passed'
 earned=json.loads(Path('qa-room13-poc-three-days/day2-checkpoint.json').read_text())['room']
 report=dict(status='running',kind='final shared-main integration using earned room state and real home dialogue/save clicks',archive_sha256=json.load(urllib.request.urlopen(URL+'game-transport.json'))['archive_sha256'],detailed_archive_sha256=prior['archive_sha256'],home_module_sha256=hashlib.sha256(Path('game/systems/room13_daram_home.rpy').read_bytes()).hexdigest(),checks=[])
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=Q(pg,OUT);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  try:
   await pg.goto(URL);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;s=renpy.store;s.preferences.text_cps=0;s.preferences.afm_enable=False;s.room13='+repr(earned)+';s.room13_mode=True;s.winter_mode=True;s.winter=s.winter_new();s.source_mode=False;s.typing_allowed=True;s.r13_scene_key=None;s.r13_world_cameras={};result=True')
   await q.py('import renpy\ns=renpy.store\nfor f in renpy.display.focus.focus_list:\n w=f.widget\n if isinstance(getattr(w,"action",None),s.Start):\n  w.action=s.Start("r13_roam");w.clicked=w.action\nresult=True');await q.press('처음부터');await q.wait('r13_hub');await q.py('import renpy;renpy.exports.show_screen("r13_hud");result=True');await q.shot('07-final-room')
   before=await q.room();await q.talk('daram');assert not await q.py('import renpy;result=any(k=="intro:direction" for k,t in renpy.store.r13_topics("daram"))');await q.value('home:daram:rest');await q.advance_to('r13_topics');assert await q.py('import renpy;result=renpy.store.r13_daram_home_seen("home:daram:rest")');await q.press('돌아가기');await q.wait('r13_hub');after=await q.room();assert all(after.get(k)==before.get(k) for k in ('day','period','evidence','livelihood','mom_state','case_state'))
   await q.save(4);saved=await q.room();await q.load(4);assert await q.room()==saved;assert await q.py('import renpy;result=renpy.store.r13_daram_home_seen("home:daram:rest")');report['checks'].append('Final-main room actor, actual home question and read mark, free dialogue and exact save/load')
   assert await q.py('import renpy;s=renpy.store;fresh=s.r13_new();result=not fresh.get("daram_home_discussions") and not fresh.get("learning_archive") and not fresh.get("secret_route_unlocked")');report['checks'].append('Fresh-run model does not carry home discussions or old route knowledge')
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.talk('daram');await q.shot('08-final-mobile-questions');assert not errors;report.update(status='passed-pending-visual-review',page_errors=errors)
  except Exception as e:
   import traceback
   report.update(status='failed',error=repr(e),traceback=traceback.format_exc());await pg.screenshot(path=str(OUT/'integration-failure.png'))
  (OUT/'final-integration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ('error','traceback')},ensure_ascii=False),flush=True);await b.close()
  if report['status']=='failed':raise SystemExit(1)
asyncio.run(main())
