"""Reviewed authored content for days 8–14; no live model/API dependency."""
def extend(D,bible):
    D['schema']=2
    D['scope']='complete-day1-day14-campaign'
    D['evidence'].update({e['id']:e for e in bible['evidence']})
    D['claims']=bible['claims']
    D['endings']=bible['endings']
    D['sensitive']={'E19':'현재 연락 장소와 접촉 신호가 들어 있다. 알려 주면 그곳에 먼저 갈 수도 있다.',
        'E30':'연구 원본에 관측 장소와 협력자의 이름이 있다. 사본을 안전하게 맡기기 전 공개하면 감시 대상이 될 수 있다.'}
    D['presentations']=[
        dict(npc='resident_lamplighter',items=['E01','E03'],topic='w2_contact',reply='가족이 맞는지는 확인했습니다. 어디서 만날지는 따로 정해야 합니다.'),
        dict(npc='resident_seori',items=['E21','E22'],all_shown=True,topic='w2_erased',reply='두 기록을 같이 가져왔군요. 내가 지운 줄도 보셨겠네요.'),
        dict(npc='resident_nubi',items=['E27'],topic='w2_laundry',reply='그날 제가 드나드는 문이 있어요. 우리 식구가 안전해질 수 있다면 얘기할게요.'),
        dict(npc='neoul',items=['E27','E28'],all_shown=True,topic='w2_stay_order',reply='진료 대상과 실제 호송 명단이 다르군요. 원본을 대조할 근거는 됩니다.'),
        dict(npc='buri',items=['E05'],topic='w2_maintenance',reply='그 길을 걸어 봤다면 말이 되겠네요. 북쪽 시설에도 같은 점검문이 있어요. 지금 열리는지는 직접 봐야 해요.'),
        dict(npc='resident_eunho',items=['E26'],topic='w2_supply_receipt',reply='인수 기록은 남겼군요. 누가 나눠 쓰는지도 함께 적어 주세요.'),
        dict(npc='resident_owlgp',items=['E16','E18'],all_shown=True,topic='w2_prevented_plan',reply='아이를 따로 맡기라는 쪽지가 내게도 왔소. 내 원본과 발신 장부를 함께 대조합시다.'),
    ]
    def topic(key,npc,title,lines,**kw):
        d=dict(npc=npc,title=title,lines=lines,day=[8,13],need=[],flags=[],give=[])
        d.update(kw);D['topics'][key]=d
    def activity(key,place,title,lines,**kw):
        d=dict(place=place,title=title,lines=lines,day=[8,13],need=[],flags=[],give=[],cost=1)
        d.update(kw);D['activities'][key]=d
    def obj(place,key,rect,text,**kw):
        d=dict(rect=rect,text=text,give=[],need=[],flags=[]);d.update(kw)
        D['objects'].setdefault(place,{})[key]=d
    # Preserve routes from earlier missed clues; an early discovery still saves activities.
    for key in ['buri_consent','buri_records','bami_boundary','bami_saw','nabi_alibi','nabi_gap','doto_corridor','tok_pin']:
        D['topics'][key]['day'][1]=13
    for key in ['map','passage','interview','wax','protect_bami','custody_draft','warning']:
        D['activities'][key]['day'][1]=13
    D['activities']['interview']['state']={'daram_state':['held']}
    D['topics']['lamplighter_warning']['day'][1]=13
    D['activities']['warning']['lines']=[
        [None,'봉투 안쪽에는 가족끼리 쓰던 매듭이 묶여 있었다.'],
        [None,'「편지를 보내라고 부탁한 적 없어. 여관에 내 행선지를 말하지 마. 등불을 고치는 사람을 통해 답해 줘. 혼자 누구를 만나러 가지 말고.」'],
        ['dad','아내 글씨다. 지금 전달된 이유부터 확인해야겠어.']]
    topic('w2_contact','resident_lamplighter','연락을 맡길 수 있습니까',[
        ['resident_lamplighter','어머니와 친해서 숨기는 게 아닙니다. 내가 말하면 그분이 죽어요.'],
        ['dad','당신이 말하지 않으면 내가 찾을 방법도 없습니다.'],
        ['resident_lamplighter','그리고 누가 뒤를 따라오면요?'],
        ['dad','내가 왔다고만 전해 주세요. 기다리라는 말은 하지 말고.'],
        ['resident_lamplighter','왜요?'],['dad','아내도 움직이고 있을 테니까요.'],
        ['resident_lamplighter','전에 보낸 경고도 등 점검함에 남아 있어요. 가져가서 새 답장과 함께 읽어 보세요.']],need=['topic:w2_contact'],flags=['reply_agreed','warning_location'])
    topic('w2_lamps','resident_lamplighter','등불을 따라오는 사람',[
        ['resident_lamplighter','불이 고장났는지 보는 사람은 저뿐인데, 요즘은 제가 간 자리마다 경비가 와요.'],
        ['dad','연락 장소도 따라올 수 있겠군요.'],['resident_lamplighter','주소를 말하지 않아도 동선을 주면 찾을 수 있어요. 만날 곳부터 확인합시다.']],flags=['tail_hint'])
    topic('w2_doctor','resident_seori','지금도 돌아오는 환자가 있습니까',[
        ['resident_seori','전부는 아닙니다. 어떤 분은 이름을 다시 말하고, 어떤 분은 알아듣기만 해요.'],
        ['dad','모두 돌아오지 못한다고 들었습니다.'],['resident_seori','누가 그렇게 적었는지까지 보십시오. 제 서명도 있을 겁니다.']],flags=['clinic_observation'])
    topic('w2_erased','resident_seori','새로 열린 이야기 · 지워진 경과',[
        ['resident_seori','이 줄은 내가 지웠습니다. 다음 검사 때 다시 나빠졌으니 회복이라고 쓰면 안 된다고 했죠.'],
        ['dad','잠깐 나아졌다는 사실도 지워야 했습니까?'],['resident_seori','아니요. 그건 지울 일이 아니었습니다.'],
        ['dad','누가 지시했습니까?'],['resident_seori','할머니요. 정정 전 사본에 그분 확인도 남아 있습니다.']],need=['topic:w2_erased'],give=['E31'],flags=['seori_witness'])
    topic('w2_school','resident_teacher','비어 있는 교실을 쓸 수 있습니까',[
        ['resident_teacher','교실은 있어요. 하지만 아이들이 돌아올 집까지 없앨 수는 없어요.'],
        ['dad','환자와 아이들이 쉬는 곳을 나누겠습니다. 출입도 기록하고요.'],
        ['resident_teacher','책상부터 옮겨야 합니다. 자리만 빌려주는 걸로 끝내진 마세요.']],flags=['shelter_agreed'])
    topic('w2_eunho','resident_eunho','비축 식량과 장작',[
        ['resident_eunho','한 번 풀면 내 가게는 끝입니다. 배급이 떨어질 때마다 다들 내 창고만 보겠죠.'],
        ['dad','얼마를 누가 가져갔는지 공동 장부에 남기겠습니다.'],['resident_eunho','나중에 갚겠다는 사람들, 눈 녹으면 먼저 떠나더군요. 서리도 입회시키세요.']],flags=['supply_terms'])
    topic('w2_supply_receipt','resident_eunho','새로 열린 이야기 · 남겨 둘 몫',[
        ['resident_eunho','제 몫도 적혔군요. 적어도 누가 가져갔는지는 남겠어요.'],['dad','사용한 수량까지 적겠습니다.'],
        ['resident_eunho','그러면 약속한 나머지도 학교로 보낼게요. 부자가 착해진 얘기로 만들지는 마세요.']],need=['topic:w2_supply_receipt'],flags=['eunho_committed'])
    topic('w2_buri_ops','buri','장치를 멈추면 누가 남아야 합니까',[
        ['buri','돌리는 건 돼요. 계속 잡고 있을 사람이 있어야지.'],['dad','교대를 구하면 맡아주겠습니까?'],
        ['buri','내가 떠나도 되는 시간을 먼저 정해요. 나한테도 돌아갈 곳이 있어요.']],flags=['operators_terms'])
    topic('w2_bori','resident_bori','짐을 옮겨 줄 수 있습니까',[
        ['resident_bori','밤새는 건 안 돼. 우리 집에도 사람이 있어.'],['dad','가족이 먼저 대피하면 낮에 옮길 수 있습니까?'],
        ['resident_bori','누울 자리까지 확인하면. 문 앞에 세워 두는 거면 안 해.']],flags=['transport_terms'])
    topic('w2_nubi','resident_nubi','세탁물은 어디로 갑니까',[
        ['resident_nubi','제가 나서면 우리 집에도 찾아옵니다. 돌아왔을 때 문을 열 수 있게 해 줘요.'],
        ['dad','가족이 같이 머물 자리가 필요하군요.'],['resident_nubi','그 약속을 지키면, 제가 보는 문도 말씀드릴게요.']],flags=['nubi_needs_shelter'])
    topic('w2_laundry','resident_nubi','새로 열린 이야기 · 현행 세탁 반입',[
        ['resident_nubi','안에서 오래 기다리면 들켜요. 나오는 사람이 없으면 돌아서야 해요.'],
        ['dad','당신까지 안으로 들어갈 필요는 없습니다.'],['resident_nubi','내가 여기서 멈추는 것도 눈에 띄어요. 서로 약속한 대로 합시다.']],
        need=['topic:w2_laundry','nubi_protected'],flags=['laundry_support'])
    topic('w2_stay_order','neoul','새로 열린 이야기 · 명령의 대상',[
        ['neoul','이 명령은 치료받는 성인 환자 셋입니다. 아이는 다음 장의 별도 대상이군요.'],
        ['dad','그런데 같은 수레에 태우려 합니다.'],['neoul','실제 움직임을 확인했다면 서리에게 원본 대조를 요청하겠습니다. 서명까지 바뀌기 전에요.']],
        need=['topic:w2_stay_order'],flags=['injunction_support'])
    topic('w2_maintenance','buri','새로 열린 이야기 · 바깥 점검문',[
        ['buri','시설 문은 다른 자물쇠예요. 안에 숨을 자리도 없고.'],['dad','도면만 믿고 가지는 않겠습니다. 같이 확인해 주십시오.'],
        ['buri','바둑이에게 순찰 방향을 물어볼게요. 혼자서 문만 열면 아이를 데리고 나올 때 막혀요.']],
        need=['topic:w2_maintenance'],flags=['maintenance_support'])
    topic('w2_route','karo','고개 말고 다른 길은 없습니까',[
        ['karo','마차는 못 가도 낮은 물길은 있어요. 지금도 얼었는지는 가 봐야 합니다.'],
        ['dad','아이와 걸을 수 있습니까?'],['karo','발 디딜 곳과 바람을 같이 봐야죠. 지난겨울 얘기로는 못 보냅니다.']],flags=['route_hint'])
    topic('w2_prevented_plan','resident_owlgp','새로 열린 이야기 · 그날 따로 받으라는 쪽지',[
        ['resident_owlgp','사람들 없는 방에서 아이를 기다리라고 했소. 병이 심해지는 걸 알면서도.'],
        ['dad','입구에서는 이미 동행 등록이 끝났는데 별도 구금까지 준비했군요.'],
        ['resident_owlgp','내 보관 사본이오. 부인에게 받은 말과 실종된 이들을 조사한 내용도 있소.'],
        ['dad','이 쪽지와 함께 대조해도 되겠습니까?'],['resident_owlgp','원본은 내가 가지고 있겠소. 사람들 앞에서 같이 봅시다.']],
        need=['topic:w2_prevented_plan'],case='prevented',give=['E17'],flags=['prevention_witness'])
    topic('w2_mom_past','mom','왜 직접 나타나지 못했어',[
        ['mom','회복한 사람을 다시 회복 불가로 적었어. 내가 정정하려 하니까 자료부터 가져가더라.'],
        ['dad','할머니가?'],['mom','응. 그 뒤로는 내가 있는 곳을 알면 잡으러 왔어. 초롱이 음식과 편지를 옮겨 줬고.'],
        ['dad','우리가 온 건 언제 알았어?'],['mom','둘째 날 저녁. 다음 날 경고를 보냈어. 읽었는지 확인도 못 받았어.']],need=['mom_reunited'])
    topic('w2_mom_stone','mom','돌은 원래 무엇이었어',[
        ['mom','처음에는 생각을 잇고 말을 익히도록 돕는 장치였어. 말할 힘을 계속 공급하는 건 아니야.'],
        ['dad','밖에서도 말하는 동물이 있으니까?'],['mom','응. 그런데 여기는 그걸 난방과 동력에까지 연결했어. 낡은 장치가 감당하지 못하는 거야.'],
        ['dad','누굴 연결하면 잠깐 살아난다는 건?'],['mom','살아 있는 의식에서 강제로 뽑아 쓰는 거야. 끝까지 뽑으면 죽어. 죽은 사람을 넣는다고 돌아가지는 않고.']],need=['mom_reunited'])
    topic('w2_mom_plan','mom','그냥 끄면 안 돼?',[
        ['mom','끊으면 변동은 줄어. 하지만 병도 추위도 한 번에 사라지진 않아.'],['dad','오늘 밤 잘 곳부터 모아야겠네.'],
        ['mom','맞아. 난방 쪽만 떼고 작게 확인해 보자. 내가 맞다는 말보다 남이 다시 봐도 같은 기록이 필요해.']],need=['mom_reunited'],flags=['measurement_plan'])
    activity('w2_reply','square','초롱과 답장을 전달한다',[
        ['dad','여기에 아내만 알아볼 말을 썼습니다. 찾아갈 주소는 넣지 않았어요.'],
        ['resident_lamplighter','오가는 데 하루쯤 걸립니다. 내일 등을 다시 확인해 주세요.'],[None,'답장을 점검함에 넣고, 누가 뒤따르는지 확인하며 돌아왔다.']],
        need=['reply_agreed'],flags=['reply_sent'])
    activity('w2_secure_contact','greenhouse','현재 신호를 확인하고 뒤따르는 발길을 끊는다',[
        [None,'눈 위에는 오늘 새로 눌린 발자국과 돌아 나간 자국이 있었다. 초롱이 등 표식을 바꿨다.'],
        ['resident_lamplighter','이쪽으로 따라오면 안 됩니다. 돌아서서 다시 확인하죠.'],
        [None,'약속한 시간을 보내고 다른 출입구에서 새 신호를 확인했다.']],need=['E19'],flags=['contact_safe'],not_flags=['contact_safe'])
    activity('w2_meet','greenhouse','연락 신호를 따라 가족을 만난다',[],need=['E19','contact_safe'],special='meet_mom',not_flags=['mom_reunited'])
    activity('w2_recovery','clinic','조용한 방에서 환자의 경과를 함께 관찰한다',[
        ['resident_seori','제 말을 따라 하는 건 회복 기록으로 적지 마십시오. 스스로 알아보는지 기다려야 해요.'],
        [None,'피코는 이름을 몇 번 틀린 뒤 자기 붓을 찾아 그림을 마저 그렸다. 검사원은 나아진 부분과 여전히 어려운 부분을 따로 적었다.']],
        need=['clinic_observation'],give=['E20'],flags=['recovery_witness'])
    activity('w2_archive','store','과거 출력과 사망 명부의 원본을 대조한다',[
        [None,'실종된 사람의 번호를 추출 가동일과 대조했다. 출력은 당일 올랐다가 이전보다 낮아졌다. 어머니가 오기 전 기록도 같은 순서였다.'],
        ['resident_seori','날짜가 있는 원본과 함께 남깁시다. 일부만 베껴 가면 상승했다는 말도, 하락했다는 말도 만들 수 있어요.']],
        need=['observed:store:ledger'],give=['E21','E22'])
    activity('w2_shelter','school','책상을 옮기고 대피 장소를 실제로 준비한다',[
        [None,'난로 가까운 방과 조용한 방을 나눴다. 누울 자리와 출입 명부를 맞춰 보니 받을 수 있는 인원이 정해졌다.'],
        ['resident_teacher','더 받겠다고 약속하지 마세요. 지금 비워 둔 자리가 전부예요.']],need=['shelter_agreed'],give=['E25'],flags=['shelter_ready'])
    activity('w2_supplies','store','공동 인수에 서명하고 식량과 장작을 운반한다',[
        ['resident_eunho','누가 가져가는지, 나중에 누가 갚는지 여기 남깁시다.'],['resident_seori','제가 입회하겠습니다. 빈 창고를 찬 창고로 적지는 않겠습니다.'],
        [None,'마른 장작과 실제 남은 곡물을 확인하고 학교로 옮겼다. 빈 자루 수까지 인수 기록에 남겼다.']],
        need=['supply_terms','shelter_ready'],give=['E26'],flags=['supplies_ready','restitution_agreed'])
    activity('w2_operators','workshop','수동 운용과 독립 기록의 교대조를 꾸린다',[
        ['buri','톡이 다음 교대를 맡고, 서리가 기록하면 돼요. 내가 틀렸을 때도 멈춰 줄 사람이 있어야 해요.'],
        [None,'가족을 돌볼 시간을 빼고 교대 시간을 정했다. 부리 혼자 밤을 새우는 계획은 지웠다.']],
        need=['operators_terms','shelter_ready'],flags=['operators_ready'])
    activity('w2_transport','school','환자와 가족을 옮길 길을 확보한다',[
        ['resident_bori','우리 식구가 누울 데 확인했어. 이제 수레 가져올게.'],
        [None,'학교까지의 길에서 눈을 치우고 짐을 내려 놓을 자리를 마련했다. 스스로 걷기 어려운 주민의 이름도 기록했다.']],
        need=['transport_terms','shelter_ready'],flags=['patient_transport'])
    activity('w2_measure1','workshop','빈 창고로 가는 회로를 분리해 관측한다',[
        ['mom','사람 있는 방부터 끊지는 않을 거야. 이 줄은 빈 창고로 가.'],['buri','돌아오지 않으면 여기서 수동으로 돌릴게요.'],
        [None,'분리 전후의 변동을 독립적으로 기록했다. 작은 구간의 흔들림은 줄었다.'],['resident_seori','오늘 한 번은 이랬습니다. 다른 부하에서도 봐야 합니다.']],
        need=['E30','measurement_plan','operators_ready'],give=['E23'])
    activity('w2_measure2','workshop','수요가 큰 저녁에 다시 관측한다',[
        ['resident_seori','지난번보다 부하가 큽니다.'],['mom','같은 숫자가 나와야 하는 게 아니에요. 어느 쪽이 흔들리는지 보세요.'],
        [None,'부하가 늘어난 구간의 분리 전후를 다시 기록했다. 첫 관측의 숫자를 복사하지 않았다.']],
        need=['E23','operators_ready'],period=[2],give=['E24'],flags=['two_observations_complete'],special='measurement2')
    activity('w2_original','greenhouse','연구 원본과 연락 기록을 독립 보관한다',[
        ['mom','여기 있는 것만 가져가면 한 번 빼앗기는 걸로 끝이야.'],
        [None,'원본은 봉인해 별도로 맡기고 대조한 사본을 두 곳에 나눴다. 연락 장소는 공개본에서 가렸다.']],
        need=['E30','seori_witness'],flags=['mother_original_safe','contact_safe'])
    activity('w2_route','gate','까로와 낮은 길의 결빙과 바람을 확인한다',[
        ['karo','바람이 꺾인 틈에는 걸어갈 수 있겠어요. 마차는 두고 가야 합니다.'],
        [None,'발 디딜 곳과 돌아올 표식을 직접 확인했다. 길을 아는 것과 지금 건널 수 있는 것은 달랐다.']],
        need=['route_hint'],give=['E29'],flags=['safe_route'])
    activity('w2_scout','facility','현재 호송 명령과 교대를 직접 확인한다',[
        [None,'배식이 끝난 뒤의 교대와 세탁 반입을 지켜봤다. 기존 치료 명단과 새 호송 명령에는 대상이 다르게 적혀 있었다.'],
        ['neoul','가족 면회는 여기까지입니다. 그 종이에 누구 이름이 있는지는 함께 확인하죠.']],
        need=['observed:facility:notice'],state={'daram_state':['held']},give=['E27','E28'],flags=['convoy_observed'])
    activity('w2_nubi_safety','school','누비 가족을 대피소로 데려온다',[
        ['resident_nubi','돌아가도 문을 열 수 있을지 몰라서 못 움직였어요.'],
        [None,'가족의 짐을 옮기고 머물 자리를 확인했다. 누비는 자기 이름으로 출입 명부에 서명했다.']],
        need=['shelter_ready','nubi_needs_shelter'],flags=['nubi_protected'])
    activity('w2_rescue_order','facility','현행 명령의 모순을 대조해 이송 중지를 요구한다',[],
        need=['E27','E28','injunction_support'],state={'daram_state':['held']},special='rescue_order')
    activity('w2_rescue_laundry','facility','세탁 반입 교대에 맞춰 아이를 데리고 나온다',[],
        need=['E27','E28','laundry_support','shelter_ready'],state={'daram_state':['held']},special='rescue_laundry')
    activity('w2_rescue_maintenance','facility','현재 점검문을 확인하며 부리와 우회한다',[],
        need=['E27','E28','maintenance_support','operators_ready'],state={'daram_state':['held']},special='rescue_maintenance')
    activity('w2_spring_proof','post','사전 분리 지시의 발신 원본을 확인한다',[
        ['seryeon','사건이 일어나기 전에 보낸 요청입니다. 그 사실은 장부로 확인할 수 있습니다.'],
        [None,'할머니가 보낸 초안과 발신 날짜를 대조했다. 아이를 분리하려는 계획과 실제로 벌어진 일을 구별해서 남겼다.']],
        need=['E02'],give=['E16'])
    activity('w2_plan_proof','post','살아 있는 어르신과 유인 지시를 공개 대조한다',[
        ['resident_owlgp','아이에게 문제가 있었다는 말은 내가 한 적 없소. 이 요청이 먼저 왔소.'],
        ['resident_seori','원본의 날짜와 발신을 확인했습니다. 아이를 고립시켜 어머니를 불러내려 한 계획은 따로 판단하겠습니다.']],
        need=['E16','E18','E17','prevention_witness'],case='prevented',flags=['premeditation_prevented_proven','witness_protected'])
    activity('w2_protect_seori','school','정정 증언자의 가족과 기록을 보호한다',[
        ['resident_seori','제 잘못까지 적겠습니다. 대신 아이들이 집으로 돌아가 압박받는 일은 막아 주세요.'],
        [None,'가족을 대피소에 인계하고 정정 원본을 여러 사람 앞에서 봉인했다. 책임을 면제한다는 약속은 하지 않았다.']],
        need=['seori_witness','shelter_ready'],flags=['witness_protected'])
    activity('w2_escape','gate','기상 창에 맞춰 가족과 낮은 길로 떠난다',[],
        need=['E29'],not_state={'daram_state':['held','lost']},special='escape',cost=0)
    activity('w2_break_tail','gate','귀로의 감시를 확인하고 합류 지점을 바꾼다',[
        ['karo','뒤의 등불이 우리하고 같이 움직여요. 먼저 길을 보여 주면 안 되겠어요.'],
        [None,'짐을 두고 돌아오는 길과 실제로 떠날 길을 나눴다. 마지막 합류 지점에는 확인한 사람만 왔다.']],
        need=['E29','pursuit_active'],flags=['pursuit_managed'])
    for p,k,r,t in [
        ('clinic','notes',[55,340,355,230],'서명된 진료 메모가 날짜별로 꽂혀 있다. 회복 항목에 덧칠한 자국이 있다.'),
        ('clinic','bed',[935,315,335,270],'환자가 담요 끝을 만지고 있다. 큰 소리가 나면 귀부터 가린다.'),
        ('school','desks',[45,310,385,250],'책상을 모으면 잠자리를 나눌 수 있겠다. 식량과 난방은 따로 마련해야 한다.'),
        ('school','stove',[940,285,320,315],'빈 솥은 놓여 있지만 장작은 얼마 없다. 장소만으로 겨울을 날 수는 없다.'),
        ('store','ledger',[180,385,260,130],'원본 장부에는 출력 수치와 이름 대신 쓴 번호가 같은 날짜에 적혀 있다.'),
        ('store','sacks',[865,385,350,215],'묶인 자루와 이미 비운 자루가 섞였다. 겉으로 센 숫자만으로는 식량을 알 수 없다.'),
        ('greenhouse','cloth',[20,385,300,150],'유리 아래 천이 새로 젖었다. 누군가 이곳을 최근에 썼지만 지금도 있는지는 알 수 없다.'),
        ('greenhouse','signal',[1030,260,200,265],'등 표식의 방향이 바뀌었다. 이전에 알던 주소만 따라 들어가면 안 되겠다.'),
        ('facility','notice',[960,175,305,320],'치료 대상 명부와 호송 명령이 따로 걸렸다. 이름과 시행 날짜가 서로 맞는지 확인해야 한다.'),
        ('facility','sidegate',[15,220,370,380],'세탁 수레가 돌아 나가는 문이다. 어제와 같은 경비가 서 있으리라는 보장은 없다.'),
        ('altar','valve',[850,370,320,210],'사람을 연결하는 관과 난방으로 나가는 관은 서로 다르다. 손잡이 하나로 전부 안전해지는 장치는 아니다.'),
    ]:obj(p,k,r,t)
