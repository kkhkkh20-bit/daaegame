import asyncio,json,shutil,ast
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'qa-room13-012'
module=ast.parse((ROOT/'dev/qa_room13_live.py').read_text())
PROBE=next(ast.literal_eval(n.value) for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PROBE' for t in n.targets))
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720});pg=await c.new_page();errors=[];bad=[]
  pg.on('pageerror',lambda e:errors.append(str(e)))
  pg.on('response',lambda r:bad.append([r.status,r.url]) if r.status>=400 and 'favicon'not in r.url else None)
  await pg.goto('http://127.0.0.1:8093/preview/room13-dev/');await pg.wait_for_function("typeof renpy_exec==='function'",timeout=90000)
  async def state():return await pg.evaluate('code=>renpy_exec(code)','ns={};exec('+repr(PROBE)+',ns);result=ns["result"]')
  for _ in range(100):
   s=await state()
   if 'main_menu'in s['screens']:break
   await asyncio.sleep(.1)
  await pg.screenshot(path=str(OUT/'release-title.png'))
  item=next(x for x in s['buttons'] if x['text'].strip()=='처음부터');x,y,w,h=item['rect'];await pg.mouse.click(x+w/2,y+h/2)
  for _ in range(100):
   s=await state()
   if 'say'in s['screens']:break
   await asyncio.sleep(.2)
  await asyncio.sleep(1);await pg.screenshot(path=str(OUT/'release-opening.png'))
  assert 'say'in s['screens'],s
  info=await pg.evaluate('code=>renpy_exec(code)',"import renpy; result={'version':renpy.store.config.version,'font':renpy.store.r13_ui_font(),'characters':len(renpy.store.CAST),'cinematics':len(renpy.store.R13_CINEMATICS),'motion':renpy.store.persistent.room13_motion}")
  assert info['version']=='0.12.0-dev' and info['cinematics']==12 and info['font']=='assets/Room13Sans.ttf'
  assert not errors,errors
  assert not bad,bad
  (OUT/'release-smoke.json').write_text(json.dumps({'status':'passed','info':info,'errors':errors,'http_errors':bad},ensure_ascii=False,indent=2))
  print(json.dumps(info,ensure_ascii=False),flush=True);await b.close()
asyncio.run(main())
