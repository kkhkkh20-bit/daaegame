import asyncio,json,shutil,urllib.request
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_ui0156 import UIQA
OUT=Path('/workspace/room13-review/scale-final');OUT.mkdir(exist_ok=True)
URL='http://127.0.0.1:8094/room13-dev/'
class Q(UIQA):
 async def save(self,slot):
  expected='say' if 'say' in (await self.state())['screens'] else 'r13_hub'
  await self.press('옵션');await self.wait('pause_menu');await self.press('저장');await self.wait('save');await self.press('1쪽 '+str(slot)+'번');await self.press('돌아가기');await self.wait(expected)
 async def load(self,slot):
  expected='say' if 'say' in (await self.state())['screens'] else 'r13_hub'
  await self.press('옵션');await self.wait('pause_menu');await self.press('불러오기');await self.wait('load');await self.press('1쪽 '+str(slot)+'번');await self.press('예');await self.wait(expected)
async def main():
 report={'archive_sha256':json.load(urllib.request.urlopen(URL+'game-transport.json'))['archive_sha256'],'checks':[],'kind':'natural gate; explicit crowded store calendar/branch fixtures; actual UI clicks'}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=Q(pg,OUT)
  try:
   await pg.goto(URL);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub')
   await q.press('까로');await q.wait('r13_entry_karo_topics');await q.value('road');await q.wait('say');await q.input(810,610);await q.wait('say');line=await q.line();assert line['speaker']=='karo';await q.save(1);await q.input(810,610);await q.load(1);await q.wait('say');assert await q.line()==line;await q.shot('karo-restored')
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.py('import renpy;s=renpy.store;s.persistent.room13_large_text=True;renpy.exports.restart_interaction();result=True');await q.shot('karo-mobile-large');await q.advance();await q.wait('r13_entry_karo_topics');await q.shot('karo-topics-mobile-large');await q.press('돌아가기');await q.wait('r13_hub');await pg.set_viewport_size({'width':1280,'height':720});q.touch=False
   report['checks'].append('Karo actual dialogue save/load exact line; mobile 844x390 large text; rapid dialogue advance and topics return')
   matrix=await q.py('''import renpy,copy
s=renpy.store;original=copy.deepcopy(s.room13);rows=[];bad=[]
try:
 for day in range(1,15):
  for period in range(3):
   for case in (["pending"] if day<=4 else ["occurred","prevented"]):
    s.r13_edit(location="store",day=day,period=period,case_state=case,trial_ended=day>=8,week2_started=day>=8,victim_state="dead" if case=="occurred" else "protected" if case=="prevented" else "alive")
    actors=s.r13_stage_people();row=dict(day=day,period=period,case=case,count=len(actors));rows.append(row)
    assert set(a['person'] for a in actors)==set(s.r13_people())
    for a in actors:
     if a['x']<0 or a['y']<0 or a['x']+a['width']>1920 or a['y']+a['height']>720:bad.append(dict(state=row,actor=a))
finally:
 s.room13=original;s.R13_STAGE_CACHE.clear()
result=dict(rows=rows,bad=bad)''');report['matrix']=matrix;assert not matrix['bad'],matrix['bad'][:2];report['checks'].append('72 store day/period/occurred/prevented geometry states: no missing residents or out-of-world sprites')
   await q.py('import renpy;s=renpy.store;s.r13_edit(location="store",day=11,period=1,case_state="prevented",trial_ended=True,week2_started=True);s.r13_upgrade();s.r13_event("day11_warning");s.place=s.R13_PLACES["store"][0];renpy.exports.scene();renpy.exports.show("qa_bg",what=s.r13_background(s.R13_PLACES["store"][1]));w=renpy.exports.get_widget("r13_hub","r13_options_gear");w.action=s.Jump("r13_field");w.clicked=w.action;result=True');await q.input(1220,50);await q.wait('r13_hub')
   actors=await q.py('import renpy;result=renpy.store.r13_stage_people()');report['crowd']=actors;assert len(actors)==8
   for right in [False,True]:
    await pg.mouse.move(1100 if right else 220,650);await pg.mouse.down();await pg.mouse.move(220 if right else 1100,650,steps=20);await pg.mouse.up();await asyncio.sleep(.6);await q.shot('store-11-'+('right' if right else 'left'))
   before=await q.room();await q.save(2);await q.py('import renpy;renpy.store.r13_edit(period=2);result=True');await q.load(2);await q.wait('r13_hub');assert await q.room()==before
   await q.value(('person','resident_madam'));await q.advance();await q.wait('r13_resident_approach');before=await q.room();await q.value(False);await q.wait('r13_hub');assert await q.room()==before
   report['checks'].append('Explicit day11 event-already-read fixture. Eight-person store real nameplate click; approach cancel preserves state; actual save/load restores store state')
   await q.py('import renpy;s=renpy.store;renpy.exports.show_screen("r13_question_list",person="resident_nubi",pose="neutral",title="선택",entries=[],ready=True);renpy.exports.restart_interaction();result=True');await q.shot('nubi-unchanged');await q.py('import renpy;renpy.exports.hide_screen("r13_question_list");result=True')
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.shot('store-mobile-large');report['status']='passed'
  except Exception as e:
   report.update(status='failed',error=repr(e));await pg.screenshot(path=str(OUT/'failure.png'))
   try:(OUT/'failure-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
   except:pass
  (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(report['status'],report.get('error'),flush=True);await b.close()
asyncio.run(main())
