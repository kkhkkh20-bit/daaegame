"""Investigation rectangles in the adopted backgrounds (1280x720 view).

Clinic/school/store/greenhouse/facility use the approved pixel atlas's
682x384 panels. Their rectangles were remeasured after the widescreen redraw
and raised foreground books, rather than stretched from the former atlas.
"""
def extend(d):
    geometry={
      'gate':{'booth':[1098,357,57,50],'rules':[350,273,83,133],'ledger':[1048,408,133,33],
        'road':[76,425,223,152],'bundles':[5,294,188,123],'shovel':[451,380,70,179],
        'crates':[920,519,225,91],'woodpile':[1190,430,88,115]},
      'room13':{'window':[197,25,193,248],'bed':[605,311,537,151],
        'under':[600,480,437,60],'books':[1195,267,50,72],'floor':[590,523,208,82],
        'boxes':[9,567,382,60],'cup':[244,358,64,60],'letters':[155,389,79,22],
        'notebook':[135,416,148,30],'coat':[437,336,137,239],
        'sewing':[1186,409,88,131],'socks':[336,279,91,78],
        'bedside_books':[626,274,83,32],'bread':[311,382,80,36]},
      'hall':{'door':[705,134,208,305],'rail':[9,217,410,239],
        'towels':[203,468,218,72],'boots':[603,383,106,86],
        'bucket':[928,329,81,158],'lamp':[641,147,59,85]},
      'inn':{'desk':[470,425,807,198],'door':[4,132,146,443],
        'keys':[1060,56,202,276],'register':[850,431,195,57],
        'knitting':[1109,439,169,140],'coats':[238,126,161,346],
        'cups':[643,23,297,290]},
      'kitchen':{'shelf':[281,406,252,117],'rear':[13,94,238,517],
        'stove':[941,229,335,312],'vegetables':[458,522,300,97],
        'flour':[887,431,142,89],'dishes':[332,170,213,142],
        'herbs':[572,3,268,175],'ladles':[712,217,149,154]},
      'dining':{'table':[420,493,855,129],'mittens':[1061,38,118,139],
        'blankets':[69,456,153,167],'breadboard':[814,476,187,105],
        'pot':[689,406,191,121]},
      'passage':{'steps':[442,211,319,288],'handle':[960,154,157,224],
        'linen':[6,20,270,301],'mop':[374,180,109,432],'baskets':[78,411,265,214]},
      'square':{'stone':[772,222,150,295],'offerings':[1020,478,184,112],
        'lamp':[1065,93,208,367],'stall':[6,211,350,265],
        'cart':[419,448,310,176],'wood':[0,494,192,129]},
      'post':{'notice':[982,239,66,134],'parcels':[1052,374,221,86],
        'cup':[1156,477,121,138],'scarf':[206,405,134,259],
        'twine':[576,293,232,185]},
      'workshop':{'plans':[840,74,268,241],'wood':[0,422,216,173],
        'axle':[665,384,484,107],'bolts':[551,491,196,44],
        'rag':[1005,523,254,99],'wheel':[1059,193,218,269],
        'tools':[0,88,263,276]},
      'clinic':{'notes':[325,512,326,77],'bed':[717,347,495,242],
        'basin':[280,378,230,116],'bottles':[0,122,201,319],'curtain':[771,109,210,266]},
      'school':{'desks':[34,386,882,225],'stove':[970,441,255,182],
        'blankets':[0,520,332,101],'lessons':[248,431,178,43],
        'firewood':[1120,547,159,76]},
      'store':{'ledger':[96,458,347,88],'sacks':[897,124,375,403],
        'scale':[92,306,310,148],'burlap':[503,352,170,65]},
      'greenhouse':{'cloth':[1045,365,166,134],'signal':[160,167,105,145],
        'pots':[831,215,370,182],'tools':[0,137,155,207],
        'watercan':[1100,532,145,89]},
      'facility':{'notice':[1050,101,129,190],'sidegate':[180,120,236,410],
        'blankets':[0,423,250,193],'clipboard':[1050,101,129,190],
        'mug':[660,372,66,39]},
      'altar':{'valve':[806,243,137,150],'offerings':[809,489,364,132],
        'ledger':[180,272,93,41],'supplies':[91,246,110,136],
        'village_view':[1094,329,183,222],'approach':[120,414,267,123]},
    }
    for place,items in geometry.items():
        for key,rect in items.items():
            d['objects'][place][key]['rect']=rect
    # Avoid two overlapping targets for the same posted clipboard.
    d['objects']['facility'].pop('clipboard',None)
    d['objects']['clinic']['bed']['text']='깨끗한 담요를 침대 끝에 접어 놓았다. 가림막 옆에는 사람을 부르는 붉은 줄이 내려와 있다.'
    d['objects']['post']['twine']['text']='봉투를 묶어 둔 끈들이 우편함 칸 밖으로 조금씩 나와 있다. 묶음은 뜯지 않고 겉면부터 확인했다.'
    d['objects']['inn']['door']['text']='여관 현관이다. 눈 묻은 신발을 털도록 작은 깔개와 우산꽂이를 두었다.'
    d['objects']['room13']['floor']['text']='침대 앞의 나무 바닥이다. 책상에서 떨어진 물건이라면 이쪽으로 굴러올 수도 있겠다.'
    d['objects']['room13']['books']['text']='책장 오른쪽 아래 칸의 붉은 책. 다른 책들과 달리 책장이 벌어지지 않는다.'
    d['objects']['hall']['lamp']['time_text'][0]='아침빛이 계단 쪽에서 들어온다. 작은 유리갓은 밤이면 복도 끝의 문을 비춘다.'
    d['objects']['hall']['lamp']['time_text'][1]='낮빛이 닿는 문 옆에 등을 달았다. 어두워져도 손잡이와 번호판은 확인할 수 있는 자리다.'
