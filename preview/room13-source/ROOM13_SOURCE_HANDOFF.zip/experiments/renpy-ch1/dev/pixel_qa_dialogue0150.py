"""All dialogue expressions rendered through the actual engine, explicitly fixtures."""
import argparse,asyncio,json,shutil
from playwright.async_api import async_playwright
from pixel_qa_flow0150 import FlowQA,ROOT
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',default='qa-room13-0150/dialogue-final');ap.add_argument('--required-profiles',type=int,default=43);ap.add_argument('--poses',nargs='+',choices=['neutral','thinking','distressed','expressive'],default=['neutral','thinking','distressed','expressive']);a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True)
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();errors=[];bad=[];pg.on('pageerror',lambda e:errors.append(str(e)));pg.on('response',lambda r:bad.append([r.status,r.url])if r.status>=400 and 'favicon'not in r.url else None);q=FlowQA(pg,out);report={'kind':'all-character-dialogue-expression-engine-fixtures-not-natural-story-play','shots':[]}
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub')
   before=(await q.state())['room'];cast=await q.py('import renpy;result=sorted(renpy.store.CAST)');assert len(cast)==43,cast
   for person in cast:
    for pose in a.poses:
     code="""import renpy
s=renpy.store
person=%r;pose=%r
spec=s.r13_close_spec(person,pose)
assert spec is not None,('world-pose fallback',person,pose)
avatar=s.CAST[person]['avatar_'+pose]
if pose=='neutral' and (avatar.get('source_kind')=='dedicated_profile_original' or avatar.get('dedicated_avatar')):assert avatar['file']!=spec['file'],('independent neutral profile is main portrait crop',person)
if pose!='neutral' and avatar['file']==spec['file']:
 px,py,pw,ph=spec['crop'];ax,ay,aw,ah=avatar['crop']
 assert px<=ax and py<=ay and ax+aw<=px+pw and ay+ah<=py+ph,('emotion profile is not matching front expression',person,pose)
for name in ('r13_hub','r13_entry_topics','r13_entry_karo_topics','r13_topics','say'):renpy.exports.hide_screen(name)
renpy.exports.scene()
background='winter_workshop' if person=='buri' else 'room' if person in ('daram','dad','mom') else 'winter' if person in ('karo','guard') else 'front'
renpy.exports.show('qa_dialogue_background',what=s.r13_background(background))
renpy.exports.show('r13_actor',what=s.r13_close_art(person,pose,840),tag='r13_visitor',at_list=[s.r13_portrait_close(s.r13_close_y(person,pose=pose))])
s.dialogue_speaker=person;s.dialogue_expression=pose;s.r13_current_pose=pose
renpy.exports.show_screen('say',who=s.R13_NAMES[person],what='지금 확인한 일을 함께 살펴보죠. 알고 계신 이야기를 들려주세요.')
renpy.exports.restart_interaction()
scale=s.r13_close_scale(person,pose,840);head=s.r13_close_head(person,pose);width,height=s.r13_close_geometry(person,pose);y=s.r13_close_y(person,pose=pose)
result={'person':person,'pose':pose,'file':spec['file'],'crop':spec['crop'],'profile_file':avatar['file'],'profile_kind':avatar.get('source_kind'),'profile_independent':bool(avatar.get('source_kind')=='dedicated_profile_original' or avatar.get('dedicated_avatar')),'profile_crop':avatar['crop'],'face_rect':[640-width*scale/2+head[0]*scale,y+head[1]*scale,head[2]*scale,head[3]*scale],'portrait_bottom':y+height*scale}
"""%(person,pose)
     info=await q.py(code);x,y,w,h=info['face_rect'];assert 0<=x and x+w<=1280 and y>=90 and y+h<=551,('face overlaps frame/HUD/dialogue',info);assert info['portrait_bottom']>=551,('bust cut floats above dialogue',info);await asyncio.sleep(.45);st=await q.state();assert 'say'in st['screens'];name=person+'-'+pose;await pg.screenshot(path=str(out/(name+'.png')));info['screenshot']=name+'.png';report['shots'].append(info);print('FRAME',name,flush=True)
   independent_profiles={x['person'] for x in report['shots']if x['pose']=='neutral' and x['profile_independent']};report['independent_profiles']=sorted(independent_profiles);assert len(independent_profiles)>=a.required_profiles,(len(independent_profiles),a.required_profiles);assert (await q.state())['room']==before;assert not errors,errors;assert not bad,bad;report.update(status='passed',character_count=len(cast),expression_count=len(a.poses),world_state_unchanged=True,visual_review='pending-independent-manual-review')
   # Browser contact sheets use untouched screenshots; no original art edits.
   contact=await b.new_page(viewport={'width':2048,'height':1320})
   for start in range(0,len(cast),4 if len(a.poses)>1 else 16):
    people=cast[start:start+(4 if len(a.poses)>1 else 16)];html='<style>body{margin:0;background:#15242b;color:white;font:15px sans-serif}main{display:grid;grid-template-columns:repeat(4,1fr)}figure{margin:3px}img{width:100%;display:block}</style><main>'
    for person in people:
     for pose in a.poses:
      stem=person+'-'+pose;html+='<figure><img src="'+stem+'.png"><figcaption>'+stem+'</figcaption></figure>'
    stem='contact-dialogue-%02d'%(start//4);path=out/(stem+'.html');path.write_text(html+'</main>');await contact.goto('http://127.0.0.1:8094/'+str(path.relative_to('/workspace')));await contact.wait_for_function('Array.from(document.images).every(i=>i.complete&&i.naturalWidth)');await contact.screenshot(path=str(out/(stem+'.png')),full_page=True)
   await contact.close()
  except Exception as e:report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
  report.update(errors=errors,http_errors=bad,url=a.url);(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items()if k!='shots'},ensure_ascii=False),flush=True);await b.close()
  if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
