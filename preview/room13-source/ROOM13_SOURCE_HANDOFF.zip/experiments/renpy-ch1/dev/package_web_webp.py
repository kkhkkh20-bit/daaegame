"""Repackage a published Room13 web release with a smaller, pixel-identical game.zip.

Starts from the release's own game.zip (reassembled from game.partNN), so the large
art that is not in the source handoff is reused as published. Then:

1. overlays game/ scripts and data (.rpy/.json/.txt) from the source project,
2. drops the dialogue backup folder and room13-pixel sheets no file references,
3. stores active room13-pixel-*.png as lossless WebP (every pixel compared),
   rewriting references in the packaged copy only. Source keeps PNG for
   prepare_assets.py; room13_webp_alias.rpy covers PNG paths kept in old saves,
4. subsets Room13Sans/Galmuri11 to Korean + symbol ranges (no Reserved Font Name
   applies to either; Room13Title/NanumMyeongjo is left untouched for that reason),
5. recompiles and lints with the matching SDK, re-splits the archive and updates the
   loader, transport, PWA catalog and build manifest.

python dev/package_web_webp.py --release ../../preview/room13-dev --sdk /path/renpy-8.5.3-sdk
"""
import argparse, hashlib, io, json, os, re, shutil, subprocess, sys, time, zipfile
from multiprocessing import Pool
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TEXT = (".rpy", ".json", ".txt")
STORED = (".png", ".webp", ".jpg", ".mp3", ".ogg", ".opus", ".woff2")
UNICODES = ("U+0000-00FF,U+0131,U+0152-0153,U+02C6-02DC,U+2000-206F,U+2190-21FF,"
            "U+2460-24FF,U+2500-25FF,U+2600-26FF,U+2700-27BF,U+3000-303F,U+3130-318F,"
            "U+AC00-D7A3,U+1100-11FF,U+FF00-FFEF,U+FFFD")
SUBSET_FONTS = ("Room13Sans.ttf", "Galmuri11.ttf")
PIXEL_REF = re.compile(r"(room13-pixel-[^\"'\s,)\]]*?)\.png")


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while block := f.read(1 << 20):
            h.update(block)
    return h.hexdigest()


def reassemble(release, target):
    transport = json.loads((release / "game-transport.json").read_text())
    with open(target, "wb") as out:
        for part in transport["parts"]:
            out.write((release / part["file"]).read_bytes())
    assert sha(target) == transport["archive_sha256"], "release parts do not match transport"


def text_files(stage):
    for path in sorted(stage.rglob("*")):
        if path.is_file() and path.suffix in TEXT and "cache" not in path.parts:
            yield path


def convert(job):
    from PIL import Image
    src, out = job
    if not out.exists():
        im = Image.open(src); im.load()
        if im.mode not in ("RGB", "RGBA"):
            im = im.convert("RGBA")
        tmp = out.with_suffix(".tmp")
        im.save(tmp, "WEBP", lossless=True, method=6, quality=100, exact=True)
        os.replace(tmp, out)
    a = Image.open(src).convert("RGBA"); b = Image.open(out).convert("RGBA")
    return src.name, a.size == b.size and a.tobytes() == b.tobytes()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--release", type=Path, required=True)
    ap.add_argument("--sdk", type=Path, required=True)
    ap.add_argument("--work", type=Path, default=Path("/tmp/room13-webp-package"))
    a = ap.parse_args()
    release, work = a.release.resolve(), a.work.resolve()
    stage, cache = work / "stage", work / "webp-cache"
    cache.mkdir(parents=True, exist_ok=True)
    shutil.rmtree(stage, ignore_errors=True); stage.mkdir(parents=True)
    original = work / "original-game.zip"
    reassemble(release, original)
    with zipfile.ZipFile(original) as z:
        z.extractall(stage)
    game = stage / "game"

    # 1. scripts and data from source
    overlaid = 0
    for path in (ROOT / "game").rglob("*"):
        if path.is_file() and path.suffix in TEXT:
            dest = game / path.relative_to(ROOT / "game")
            # The SDK build leaves some data out (saves/, painted layouts); keep that.
            if not dest.exists() and path.suffix != ".rpy":
                continue
            if not dest.exists() or dest.read_bytes() != path.read_bytes():
                dest.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(path, dest); overlaid += 1
    for path in list(game.rglob("*.rpyc")):
        if not path.with_suffix(".rpy").exists():
            path.unlink()
    shutil.rmtree(game / "cache", ignore_errors=True)

    # 2. dead weight
    shutil.rmtree(stage / "dialogue-backup-20261013", ignore_errors=True)
    corpus = "".join(p.read_text(errors="ignore") for p in text_files(stage))
    dropped = [p.name for p in sorted((game / "assets").glob("room13-pixel-*.png")) if p.stem not in corpus]
    for name in dropped:
        (game / "assets" / name).unlink()

    # 3. lossless WebP
    pngs = sorted((game / "assets").glob("room13-pixel-*.png"))
    with Pool(os.cpu_count()) as pool:
        results = pool.map(convert, [(p, cache / (p.stem + ".webp")) for p in pngs], chunksize=1)
    bad = [n for n, same in results if not same]
    assert not bad, "pixel mismatch: %s" % bad
    for p in pngs:
        shutil.copy2(cache / (p.stem + ".webp"), p.with_suffix(".webp")); p.unlink()
    for path in text_files(stage):
        s = path.read_text()
        n = PIXEL_REF.sub(r"\1.webp", s)
        if n != s:
            path.write_text(n)
    missing = sorted({m for p in text_files(stage) for m in re.findall(r"assets/room13-pixel-[\w\-]+\.webp", p.read_text())
                      if not (game / m).exists()})
    assert not missing, "unresolved references: %s" % missing[:10]

    # 4. fonts
    for name in SUBSET_FONTS:
        font = game / "assets" / name
        subprocess.run([sys.executable, "-m", "fontTools.subset", str(font), "--unicodes=" + UNICODES,
            "--layout-features=*", "--glyph-names", "--notdef-outline", "--name-IDs=*",
            "--name-languages=*", "--output-file=" + str(font) + ".sub"], check=True)
        os.replace(str(font) + ".sub", font)

    # 5. compile, lint, archive
    renpy = a.sdk / "renpy.sh"
    subprocess.run([str(renpy), str(stage), "compile"], check=True)
    lint = subprocess.run([str(renpy), str(stage), "lint"], capture_output=True, text=True)
    report = [l for l in lint.stdout.splitlines() if l.strip() and "is not loadable" not in l]
    (work / "lint.txt").write_text(lint.stdout)
    # Remote progressive images (renpyweb_remote_files.txt) are the only accepted lint noise.
    if any(re.search(r"\.rpy:\d+ ", l) for l in report):
        raise SystemExit("lint reported problems; see " + str(work / "lint.txt"))

    archive = work / "game.zip"
    with zipfile.ZipFile(original) as old:
        order = [i.filename for i in old.infolist()]
    generated = {"log.txt", "errors.txt", "traceback.txt", "lint.txt"}
    present = sorted(str(p.relative_to(stage)) for p in stage.rglob("*") if p.is_file()
                     and str(p.relative_to(stage)) not in generated and "saves" not in p.relative_to(stage).parts)
    ordered = [n for n in order if n in set(present)] + [n for n in present if n not in set(order)]
    with zipfile.ZipFile(archive, "w") as z:
        for name in ordered:
            info = zipfile.ZipInfo(name, (2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_STORED if name.endswith(STORED) else zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            z.writestr(info, (stage / name).read_bytes())

    digest, size = sha(archive), archive.stat().st_size
    for stale in release.glob("game.part[0-9][0-9]"):
        stale.unlink()
    parts = []
    with open(archive, "rb") as src:
        index = 1
        while data := src.read(60 * 1024 * 1024):
            name = "game.part%02d" % index
            (release / name).write_bytes(data)
            parts.append({"file": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
            index += 1
    transport = {"multipart": True, "archive_bytes": size, "archive_sha256": digest, "parts": parts}
    (release / "game-transport.json").write_text(json.dumps(transport, indent=2))

    pre = release / "renpy-pre.js"; s = pre.read_text()
    s, n1 = re.subn(r"const parts = \[.*?\];", lambda m: "const parts = " + json.dumps(parts) + ";", s, count=1)
    s, n2 = re.subn(r"'Content-Length': '\d+'", "'Content-Length': '%d'" % size, s, count=1)
    assert n1 == n2 == 1, "renpy-pre.js loader layout changed"
    pre.write_text(s)
    index = release / "index.html"; s = index.read_text()
    s, n = re.subn(r"renpy-pre\.js\?v=[0-9a-f]+", "renpy-pre.js?v=" + digest[:12], s)
    assert n == 1; index.write_text(s)
    catalog = json.loads((release / "pwa_catalog.json").read_text())
    catalog["version"] = int(time.time())
    (release / "pwa_catalog.json").write_text(json.dumps(catalog))

    manifest_path = release / "build-manifest.json"
    manifest = json.loads(manifest_path.read_text())
    files = {k: v for k, v in manifest["files"].items() if not k.startswith("game.part")}
    for k in list(files):
        if (release / k).exists():
            files[k] = {"bytes": (release / k).stat().st_size, "sha256": sha(release / k)}
    for part in parts:
        files[part["file"]] = {"bytes": part["bytes"], "sha256": part["sha256"]}
    manifest["files"] = dict(sorted(files.items()))
    manifest["game_transport"] = transport
    manifest["total_bytes"] = sum(v["bytes"] for v in files.values())
    manifest_path.write_text(json.dumps(manifest, indent=2))

    summary = dict(original_bytes=original.stat().st_size, archive_bytes=size, archive_sha256=digest,
        parts=len(parts), overlaid_files=overlaid, dropped_unreferenced=dropped,
        webp_converted=len(pngs), pixel_identical=True, fonts_subset=list(SUBSET_FONTS))
    (work / "package-report.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False))
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
