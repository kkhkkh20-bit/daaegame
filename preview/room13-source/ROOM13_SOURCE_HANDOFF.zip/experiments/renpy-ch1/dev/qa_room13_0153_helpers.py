"""Browser test adapter for 0.15.3 arrival cards and composite click actions."""
import asyncio
import pixel_qa_flow0150 as flow
from pixel_qa_flow0150 import ROOT
flow.FLOW_PROBE=flow.FLOW_PROBE.replace("getattr(a,'value','')", "next((getattr(v,'value') for v in (a if isinstance(a,(list,tuple)) else [a]) if hasattr(v,'value')),'')").replace('names=[',"names=['r13_arrival_card',")
class FlowQA(flow.FlowQA):
 async def press(self,label):
  aliases={'마저 둘러본다':'조사','주변을 더':'조사','원본 대조':'원본과 다시 대조'}
  label=aliases.get(label,label)
  screens=(await self.state())['screens'] if label=='돌아가기' else []
  if any(n in screens for n in ['r13_topics','r13_entry_topics','r13_entry_karo_topics']):label='조사'
  return await super().press(label)
 async def advance(self):
  for _ in range(280):
   st=await self.state()
   if 'r13_arrival_card'in st['screens']:await self.input(640,360);continue
   if 'r13_cinematic_view'in st['screens']:await self.press('계속');continue
   if any(x in st['screens'] for x in ('choice','r13_hub','r13_book','r13_confirm','r13_topics','r13_entry_topics','r13_entry_karo_topics','r13_object_context','r13_map')):
    await asyncio.sleep(.5);return await self.state()
   if 'say'in st['screens']:await self.input(810,640)
   else:await asyncio.sleep(.15)
  raise AssertionError(st)
