"""0.15 independent direct-input QA; injected eligibility fixtures are explicit."""
import argparse,asyncio,ast,json,shutil
from playwright.async_api import async_playwright
from qa_room13_ui0122 import QA,ROOT,PROBE
FLOW_PROBE=PROBE.replace('names=[',"names=['_exception','r13_entry_topics','r13_entry_karo_topics','r13_object_context',")
MATRIX='''import renpy,copy
s=renpy.store
original=copy.deepcopy(s.room13)
rows=[];failures=[]
try:
 links={key:(place,obj) for (place,obj),keys in s.R13_CONTEXT_ACTIVITIES.items() for key in keys}
 for key,a in s.ROOM13['activities'].items():
  n=copy.deepcopy(original);n.update(day=max(a.get('day',[1,13])[0],8 if key.startswith('w2_') else 1),period=a.get('period',[0])[0],location=a['place'],done=[])
  n['case_state']=a.get('case','prevented');n['flags']=['lodging'];n['evidence']=[];n['passage_open']=True
  for flag in a.get('need',[]):n['evidence' if flag in s.ROOM13['evidence'] else 'flags'].append(flag)
  for name,values in a.get('state',{}).items():n[name]=values[0]
  for name,values in a.get('not_state',{}).items():
   if n.get(name) in values:n[name]='rescued' if name=='daram_state' else None
  n['observations']={'first':{'time':(n['day']-1)*4+n['period']-1,'load':'day_low'}}
  n['scout_revision']=n.get('convoy_revision',0)
  s.room13=n
  available={k for k,a in s.r13_actions()}
  routed={k for obj in s.ROOM13['objects'].get(n['location'],{}) for k,a in s.r13_object_actions(obj)}
  if key not in available:failures.append([key,'fixture not eligible'])
  if available!=routed:failures.append([key,'unrouted eligible activity',sorted(available-routed)])
  obj=links[key][1]
  if key not in [k for k,a in s.r13_object_actions(obj)]:failures.append([key,'missing own context'])
  fixture_state=copy.deepcopy(n)
  n['done']=[key];s.room13=n
  if key in [k for k,a in s.r13_object_actions(obj)]:failures.append([key,'completed action repeats'])
  n['done']=[];n['day']=a.get('day',[1,13])[1]+1;s.room13=n
  if key in [k for k,a in s.r13_object_actions(obj)]:failures.append([key,'invalid day allowed'])
  rows.append({'activity':key,'location':a['place'],'object':obj,'eligible_actions':sorted(available),'state':fixture_state})
 for loc,objects in s.ROOM13['objects'].items():
  n=copy.deepcopy(original);n['location']=loc;n['flags']=['lodging'];s.room13=n
  for obj in objects:
   if bool(s.r13_bed_available(obj))!=(loc=='room13' and obj=='bed'):failures.append([loc,obj,'sleep location mismatch'])
 n=copy.deepcopy(original);n['location']='room13';n['flags']=[];s.room13=n
 if s.r13_bed_available('bed'):failures.append(['room13','bed','sleep before lodging'])
 for displaced_case,displaced_flags in [('occurred',['lodging']),('pending',['lodging','family_room_unusable'])]:
  for loc in ('room13','guestroom','clinic'):
   n=copy.deepcopy(original);n.update(location=loc,case_state=displaced_case,flags=displaced_flags);s.room13=n
   if bool(s.r13_bed_available('bed'))!=(loc=='guestroom'):failures.append([loc,'bed','displaced sleep mismatch'])
  if 'guestroom'not in s.r13_places():failures.append(['guestroom','not reachable after displacement'])
finally:s.room13=original
result={'kind':'injected-activity-eligibility-and-sleep-location-fixtures','rows':rows,'failures':failures,'state_restored':s.room13==original}
'''
class FlowQA(QA):
 async def py(self,code):return await asyncio.wait_for(self.p.evaluate('code=>renpy_exec(code)','exec('+ascii(code)+')'),35)
 async def state(self):
  st=await self.py('ns={};exec('+ascii(FLOW_PROBE)+',ns);result=ns["result"]');assert '_exception'not in st['screens'],st;return st
 async def advance(self):
  for _ in range(260):
   st=await self.state()
   if 'r13_cinematic_view'in st['screens']:await self.press('계속');continue
   if any(x in st['screens'] for x in ('choice','r13_hub','r13_book','r13_confirm','r13_topics','r13_entry_topics','r13_entry_karo_topics','r13_object_context','r13_map')):
    await asyncio.sleep(.5);return await self.state()
   if 'say'in st['screens']:await self.input(810,640)
   else:await asyncio.sleep(.15)
  raise AssertionError(st)
 async def value(self,value):
  st=await self.state();matches=[]
  for b in st['buttons']:
   try:v=ast.literal_eval(b.get('value',''))
   except (ValueError,SyntaxError):v=b.get('value','')
   if v==value and b['rect'][2]>0 and b['rect'][3]>0:matches.append(b)
  assert matches,('No direct target',value,st)
  if isinstance(value,tuple) and value[0]=='person':matches=[b for b in matches if not b['text'].strip()] or matches
  b=min(matches,key=lambda x:x['rect'][2]*x['rect'][3]);x,y,w,h=b['rect'];await self.input(x+w/2,y+h/2)
 async def natural_entry(self,route='proof'):
  await self.wait('main_menu');await self.press('처음부터');await self.advance();await self.wait('r13_hub');await self.shot('01-direct-entry')
  buttons=(await self.state())['buttons'];assert not any(x in b['text'] for b in buttons for x in ('현장 활동','여관에서 쉬기','조사하기','대화하기','제시하기'))
  before=(await self.state())['room'];await self.press('까로');await self.advance();await self.wait('r13_entry_karo_topics');await self.shot('02-karo-direct');await self.press('마저 둘러본다');await self.advance();await self.wait('r13_hub');assert (await self.state())['room']==before
  await self.value(('person','guard'));await self.wait('r13_entry_topics');await self.shot('03-guard-direct');await self.press('주변을 더');await self.wait('r13_hub');assert (await self.state())['room']==before
  if getattr(self,'gallery_say',False):
   await self.press('까로');await self.wait('r13_entry_karo_topics');await self.press('짐 좀 부탁합니다');await self.wait('say');assert (await self.info())['speaker']=='karo';await self.shot('02b-karo-real-dialogue');await self.advance();await self.wait('r13_hub')
  if route=='proof':
   for obj in ('booth','rules'):
    await self.value(('object',obj));await self.advance();await self.wait('r13_hub')
   st=await self.state();assert {'G1','G2'}<=set(st['room']['evidence']);assert st['room']['period']==1
   await self.value(('person','guard'));await self.wait('r13_entry_topics');await self.press('확인한 자료');await self.wait('r13_book')
   title=await self.py("import renpy;result=renpy.store.ROOM13['evidence']['G1']['name']");await self.press(title);await self.press('보여주기');await self.advance();await self.wait('choice');await self.shot('03b-proof-reason-choice')
   if getattr(self,'choice_persistence',False):await self.choice_save_restore()
   if getattr(self,'force_choice_migration',False):await self.forced_choice_migration()
   await self.press('원본에는 두 명');await self.advance();await self.wait('r13_hub');assert (await self.state())['room']['period']==1
  else:
   await self.value(('person','guard'));await self.wait('r13_entry_topics');await self.press('원본 대조');await self.wait('r13_confirm');await self.press('진행한다');await self.advance();await self.wait('r13_hub');assert (await self.state())['room']['period']==2
  assert 'entry_corrected'in (await self.state())['room']['flags'];await self.shot('04-entry-complete');self.events.append('Natural '+route+' entry; visible Karo direct click; guard/direct object interactions')
 async def travel(self,label,region=None):
  await self.press('지도 · 이동');await self.wait('r13_map')
  if region:await self.press(region)
  await self.press(label);await self.press('이곳으로 이동');await self.advance();await self.wait('r13_hub')
 async def natural_exploration(self):
  before=(await self.state())['room'];await self.press('지도 · 이동');await self.wait('r13_map');await self.shot('05-spatial-map');await self.press('진료실');assert not any('이곳으로 이동'in b['text'] for b in (await self.state())['buttons']);await self.press('현장으로 돌아가기');await self.wait('r13_hub');assert (await self.state())['room']==before
  await self.travel('여관 접수대');assert (await self.state())['room']['location']=='inn';await self.value(('person','granny'));await self.advance();await self.wait('r13_topics');await self.press('방을 부탁한다');await self.advance();await self.wait('r13_topics');assert 'lodging'in (await self.state())['room']['flags'];await self.press('돌아가기');await self.advance();await self.wait('r13_hub');await self.shot('06-inn-direct')
  await self.travel('13호실','여관 안');assert (await self.state())['room']['location']=='room13';await self.value(('object','bed'));await self.advance();await self.wait('r13_object_context');await self.shot('07-real-bed');before=(await self.state())['room'];await self.press('침대에서 잠자기');await self.wait('r13_confirm');await self.press('아직 할 일이');await self.advance();await self.wait('r13_hub');assert (await self.state())['room']==before
  await self.travel('수리점','마을');await self.value(('person','buri'));await self.advance();await self.wait('r13_topics');await self.shot('08-buri-direct-topics');before=(await self.state())['room'];await self.value('present');await self.wait('r13_book');await self.press('제시 취소');await self.wait('r13_topics');assert (await self.state())['room']==before;await self.press('돌아가기');await self.advance();await self.wait('r13_hub')
  await self.travel('마을 입구');await self.value(('person','karo'));await self.advance();await self.wait('r13_topics');await self.value('present');await self.wait('r13_book');await self.press(await self.py("import renpy;result=renpy.store.ROOM13['evidence']['E01']['name']"));st=await self.state();assert any('까로에게 보여주기'in b['text'] for b in st['buttons']);assert not any('부리에게 보여주기'in b['text'] for b in st['buttons']);before=st['room'];await self.press('까로에게 보여주기');await self.advance();await self.wait('r13_confirm');await self.shot('09-recipient-confirm');await self.press('취소한다');await self.advance();await self.wait('r13_topics');assert (await self.state())['room']==before;await self.press('돌아가기');await self.advance();await self.wait('r13_hub')
  await self.press('수첩');await self.wait('r13_book');await self.press(await self.py("import renpy;result=renpy.store.ROOM13['evidence']['E01']['name']"));assert not any('보여주기'in b['text'] for b in (await self.state())['buttons']);await self.press('닫기');await self.wait('r13_hub')
  await self.p.set_viewport_size({'width':844,'height':390});self.touch=True;await self.travel('13호실','여관 안');await self.value(('object','bed'));await self.advance();await self.wait('r13_object_context');await self.shot('10-mobile-bed-context');before=(await self.state())['room'];await self.press('침대에서 잠자기');await self.wait('r13_confirm');await self.press('아직 할 일이');await self.advance();await self.wait('r13_hub');assert (await self.state())['room']==before;await self.press('지도 · 이동');await self.wait('r13_map');await self.shot('11-mobile-map');await self.press('현장으로 돌아가기');await self.wait('r13_hub')
  self.events.append('Natural direct-map lodging/bed and sleep cancel; Buri→Karo recipient isolation; notebook has no stale present action; 844x390 touch map/bed')
  before=(await self.state())['room'];await self.value(('object','bed'));await self.advance();await self.wait('r13_object_context');await self.press('침대에서 잠자기');await self.wait('r13_confirm');await self.press('잠자리에 든다');await self.advance();await self.wait('choice');await self.press('다람이 옆에 앉는다');await self.advance();await self.wait('r13_hub');after=(await self.state())['room'];assert after['day']==before['day']+1 and after['period']==0 and after['location']=='inn',after;await self.shot('12-mobile-real-sleep-next-day');self.events.append('Actual room-bed sleep executes first-night scenes and reaches day2 morning inn')

 async def activity_click_fixtures(self,matrix):
  shots=[]
  for i,row in enumerate(matrix['rows']):
   state=row['state']
   await self.py("import renpy\ns=renpy.store\ns.room13="+ascii(state)+"\ns.place=s.R13_PLACES[s.room13['location']][0]\nrenpy.exports.scene()\nrenpy.exports.show('qa_flow_background',what=s.r13_background(s.R13_PLACES[s.room13['location']][1]))\nrenpy.exports.restart_interaction()\nresult=True")
   await self.wait('r13_hub');await self.value(('object',row['object']));await self.advance();await self.wait('r13_object_context')
   st=await self.state();assert any(b['value']==repr(('activity',row['activity'])) for b in st['buttons']),('activity missing from actual object screen',row['activity'],st)
   name='activity-%02d-%s'%(i,row['activity']);await self.shot(name);shots.append({'activity':row['activity'],'file':name+'.png','object':row['object']})
   before=st['room'];await self.value(('activity',row['activity']));await self.wait('r13_confirm');assert (await self.state())['room']==before
   # Fixture exits the confirmation via an explicit label reset, so synthetic
   # day/state combinations cannot accidentally run unrelated story events.
   # No activity is completed or claimed naturally played by this matrix.
   await self.py("import renpy\ns=renpy.store\nfor f in renpy.display.focus.focus_list:\n action=getattr(f.widget,'action',None)\n if getattr(action,'value',None) is False:\n  f.widget.action=s.Jump('r13_field');f.widget.clicked=f.widget.action\nresult=True")
   await self.press('돌아간다');await self.wait('r13_hub');assert (await self.state())['room']==before
  return {'kind':'injected-state-real-object-and-activity-clicks-to-confirmation-not-completion','shots':shots}

 async def map_lock_fixtures(self):
  original=(await self.state())['room'];checks=[]
  cases=[('unregistered',1,[],False),('lodging',1,['lodging'],False),('passage-known-closed',5,['lodging','passage_known'],False),('passage-open',5,['lodging','passage_known'],True),('week2-no-signal',8,['lodging'],False),('week2-signal',8,['lodging','E19'],False),('displaced-guestroom',4,['lodging','family_room_unusable'],False)]
  for name,day,flags,opened in cases:
   state=json.loads(json.dumps(original));state.update(day=day,period=0,location='gate',flags=flags,passage_open=opened,evidence=[])
   await self.py('import renpy;s=renpy.store;s.room13='+ascii(state)+';renpy.exports.restart_interaction();result=True');await self.wait('r13_hub');await self.press('지도 · 이동');await self.wait('r13_map')
   allowed=await self.py('import renpy;result=renpy.store.r13_places()')
   for region,label in [('village','마을'),('inn','여관 안')]+([('mountain','북쪽 산길')]if day>=8 else []):
    await self.press(label)
    data=await self.py("import renpy;s=renpy.store;result={'region':renpy.display.screen.get_screen('r13_map').scope['region'],'nodes':s.r13_map_nodes(%r)}"%region);assert data['region']==region,data
    keys=[key for key,point in data['nodes']]
    if not opened:assert 'passage'not in keys
    if 'E19'not in flags:assert 'greenhouse'not in keys
    if 'family_room_unusable'not in flags:assert 'guestroom'not in keys
    assert 'altar'not in keys
    for key,(x,y) in data['nodes']:
     await self.input(30+x,143+y);st=await self.state();can_move=any('이곳으로 이동'in b['text']for b in st['buttons']);assert can_move==(key in allowed and key!='gate'),(name,key,can_move,allowed)
     assert st['room']==state,(name,key,'map selection changed world')
     checks.append({'scenario':name,'region':region,'node':key,'travel_enabled':can_move})
   await self.shot('map-lock-'+name);await self.press('현장으로 돌아가기');await self.wait('r13_hub');assert (await self.state())['room']==state
  await self.py('import renpy;renpy.store.room13='+ascii(original)+';renpy.exports.restart_interaction();result=True')
  return {'kind':'injected-map-access-states-real-pin-selection-not-travel','checks':checks}

 async def bed_boundary_fixtures(self):
  base=(await self.state())['room'];n=json.loads(json.dumps(base));n.update(day=4,period=3,location='inn',case_state='occurred',victim_state='dead',daram_state='held',flags=['lodging','family_room_unusable'],done=[])
  await self.py('import renpy;s=renpy.store;s.room13='+ascii(n)+';renpy.exports.restart_interaction();result=True');await self.wait('r13_hub');await self.travel('13호실','여관 안');await self.value(('object','bed'));await self.advance();await self.wait('r13_hub');assert 'r13_object_context'not in (await self.state())['screens'];assert (await self.state())['room']['day']==4
  await self.travel('임시 객실','여관 안');await self.shot('bed-displaced-clean-guestroom');await self.value(('object','bed'));await self.advance();await self.wait('r13_object_context');before=(await self.state())['room'];await self.press('침대에서 잠자기');await self.wait('r13_confirm');await self.press('아직 할 일이');await self.advance();await self.wait('r13_hub');assert (await self.state())['room']==before
  await self.value(('object','bed'));await self.advance();await self.wait('r13_object_context');await self.press('침대에서 잠자기');await self.wait('r13_confirm');await self.press('잠자리에 든다');await self.advance();await self.wait('r13_hub');after=(await self.state())['room'];assert after['day']==5 and after['period']==0 and after['daram_state']=='held' and after['case_state']=='occurred',after;assert after['evidence']==before['evidence'];await self.shot('bed-displaced-next-morning')
  n=json.loads(json.dumps(base));n.update(day=4,period=0,location='inn',case_state='pending',victim_state='alive',daram_state='with_dad',flags=['lodging'],done=[])
  await self.py('import renpy;renpy.store.room13='+ascii(n)+';renpy.exports.restart_interaction();result=True');await self.wait('r13_hub');await self.travel('13호실','여관 안');await self.value(('object','bed'));await self.advance();await self.wait('r13_object_context');await self.press('침대에서 잠자기');await self.wait('r13_confirm');await self.press('잠자리에 든다');await self.advance();await self.wait('choice');st=await self.state();assert st['room']['day']==4 and st['room']['period']==2 and st['room']['case_state']=='pending';assert any('반송품은 미루고'in b['text']for b in st['buttons']);await self.shot('bed-day4-case-not-skipped')
  return {'kind':'injected-boundary-states-with-real-map-bed-confirmation-inputs','checks':['Crime-scene bed cannot sleep after displacement','Temporary guestroom reached on map, bed cancel preserves state','Temporary bed advances to day5 without releasing held Daram or changing evidence','Day4 early sleep reaches case choice instead of skipping to day5']}

 async def forced_choice_migration(self):
  check=await self.py("""import renpy,copy
s=renpy.store
before=copy.deepcopy(s.room13);speaker=s.dialogue_speaker
bounds=renpy.exports.get_image_bounds('r13_visitor')
assert bounds is not None
s.room13['visual_revision']='pixel-b-acting-v2'
s.r13_upgrade()
renpy.exports.restart_interaction()
after=copy.deepcopy(s.room13)
for key in ('visual_revision','checks','last_inspection'):before.pop(key,None);after.pop(key,None)
assert before==after,('story state changed',before,after)
assert s.dialogue_speaker==speaker,('speaker changed',speaker,s.dialogue_speaker)
result={'kind':'injected-old-visual-revision-on-natural-proof-choice','story_state_preserved':before==after,'speaker_preserved':s.dialogue_speaker==speaker,'revision':s.room13['visual_revision'],'bounds_before':bounds}
""")
  await self.wait('choice');check['bounds_after']=await self.py("import renpy;result=renpy.exports.get_image_bounds('r13_visitor')");assert check['bounds_before']==check['bounds_after'],check;assert check['revision']=='pixel-b-front-v3';await self.shot('choice-forced-old-revision-restored');self.events.append(check)

 async def choice_save_restore(self):
  before=(await self.state())['room'];bounds=await self.py("import renpy;result=renpy.exports.get_image_bounds('r13_visitor')")
  await self.press('설정');await self.wait('pause_menu');await self.press('저장');await self.wait('save');await self.press('슬롯 2');await asyncio.sleep(.5);await self.press('돌아가기');st=await self.state()
  if 'pause_menu'in st['screens']:await self.press('돌아가기')
  await self.wait('choice');await self.press('설정');await self.wait('pause_menu');await self.press('불러오기');await self.wait('load');await self.press('슬롯 2');await self.wait('choice');assert (await self.state())['room']==before
  restored=await self.py("import renpy;result=renpy.exports.get_image_bounds('r13_visitor')");assert restored==bounds,('choice portrait bounds changed after load',bounds,restored);await self.shot('choice-real-save-load-restored');self.events.append('Actual proof-choice save/load preserves state and left-portrait bounds')

async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',default='qa-room13-0150/flow-prototype');ap.add_argument('--extended',action='store_true');ap.add_argument('--activity-clicks',action='store_true');ap.add_argument('--map-locks',action='store_true');ap.add_argument('--bed-boundaries',action='store_true');ap.add_argument('--choice-persistence',action='store_true');ap.add_argument('--force-choice-migration',action='store_true');ap.add_argument('--gallery-say',action='store_true');ap.add_argument('--route',choices=['proof','wait'],default='proof');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True)
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();errors=[];bad=[];pg.on('pageerror',lambda e:errors.append(str(e)));pg.on('response',lambda r:bad.append([r.status,r.url])if r.status>=400 and 'favicon'not in r.url else None);q=FlowQA(pg,out);q.choice_persistence=a.choice_persistence;q.force_choice_migration=a.force_choice_migration;q.gallery_say=a.gallery_say
  report={}
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.natural_entry(a.route);report['natural_entry']='passed'
   if a.extended:await q.natural_exploration();report['natural_exploration']='passed'
   matrix=await q.py(MATRIX);report['matrix']=matrix;assert not matrix['failures'],matrix['failures'];assert matrix['state_restored']
   if a.map_locks:report['map_locks']=await q.map_lock_fixtures()
   if a.activity_clicks:report['activity_clicks']=await q.activity_click_fixtures(matrix)
   if a.bed_boundaries:report['bed_boundaries']=await q.bed_boundary_fixtures()
   assert not errors,errors;assert not bad,bad;report['status']='passed'
  except Exception as e:report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
  report.update(checks=q.events,errors=errors,http_errors=bad,url=a.url);(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items()if k!='matrix'},ensure_ascii=False),flush=True);await b.close()
  if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
