"""Natural playback/investigation path on the exact release archive."""
import asyncio,json,shutil,urllib.request
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_ui0156 import UIQA
from pixel_qa_flow0150 import FLOW_PROBE
OUT=Path('/workspace/room13-review/after');OUT.mkdir(exist_ok=True)
URL='http://127.0.0.1:8094/room13-dev/'
class ReleaseQA(UIQA):
 async def state(self):
  probe=FLOW_PROBE.replace('names=[',"names=['r13_records','r13_book','r13_backlog','r13_work_board',")
  st=await self.py('ns={};exec('+ascii(probe)+',ns);result=ns["result"]')
  assert '_exception' not in st['screens'],st
  return st
async def main():
 report={'archive_sha256':json.load(urllib.request.urlopen(URL+'game-transport.json'))['archive_sha256'],'checks':[]}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader'])
  context=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='allow')
  pg=await context.new_page();q=ReleaseQA(pg,OUT)
  try:
   await pg.goto(URL);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu')
   await q.py('import renpy;s=renpy.store;s.preferences.text_cps=0;s.preferences.afm_time=5;s.preferences.afm_enable=False;s.preferences.afm_after_click=True;result=True')
   await q.press('처음부터');await q.wait('say');await q.shot('01-carriage-playback')
   before=await q.line();await q.press('자동');await asyncio.sleep(3.5);after=await q.line()
   assert after['index']>before['index'],(before['index'],after['index'])
   await q.press('백로그');await q.wait('r13_backlog');held=await q.line();await q.shot('02-backlog')
   assert not await q.py('import renpy;result=renpy.store.r13_auto_can_advance()')
   await asyncio.sleep(3.5);assert (await q.line())['index']==held['index']
   await q.press('대화로 돌아가기');await q.wait('say')
   if await q.py('import renpy;result=renpy.store.preferences.afm_enable'):await q.press('자동')
   report['checks'].append('Real auto button advances dialogue; backlog pauses auto and preserves current line')
   await q.advance();await q.wait('r13_hub');assert (await q.room())['location']=='gate'
   assert await q.py('import renpy;result=renpy.store.r13_places()')==['gate','square','inn']
   await q.travel('광장');assert (await q.room())['location']=='square'
   await q.travel('여관 접수대');assert (await q.room())['location']=='inn'
   assert 'lodging' not in (await q.room())['flags']
   await q.press('할머니');await q.advance();await q.wait('r13_hub');assert (await q.room())['location']=='inn'
   assert 'lodging' in (await q.room())['flags']
   await q.travel('2층 복도');await q.travel('13호실');assert (await q.room())['location']=='room13'
   report['checks'].append('Day 1 stays at gate; manual square/inn travel; click granny to check in; manual hallway/room travel; other destinations locked')
   await q.input(195,400);await q.advance()
   if 'r13_object_context' in (await q.state())['screens']:await q.press('그만 살펴본다')
   await q.wait('r13_hub');await q.press('기록');await q.wait('r13_records');await q.shot('03-evidence-desktop');await q.press('닫기')
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True
   await q.py('import renpy;renpy.store.persistent.room13_large_text=True;renpy.exports.restart_interaction();result=True')
   await q.press('기록');await q.wait('r13_records');await q.shot('04-evidence-mobile-large');await q.press('닫기')
   await pg.set_viewport_size({'width':1280,'height':720});q.touch=False
   await q.save(1);saved=await q.room();await q.load(1);assert await q.room()==saved
   await q.press('옵션');await q.wait('pause_menu');await q.press('처음 화면');await q.wait('main_menu')
   await pg.reload();await q.wait('main_menu');await q.press('이어하기');await q.wait('r13_hub');assert await q.room()==saved
   report['checks'].append('Service workers enabled: fresh boot, real save/load, reload and Continue')
   report['status']='passed'
  except Exception as e:
   report.update(status='failed',error=repr(e));await pg.screenshot(path=str(OUT/'failure.png'))
   try:(OUT/'failure-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
   except:pass
  (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']=='failed':raise SystemExit(1)
asyncio.run(main())
