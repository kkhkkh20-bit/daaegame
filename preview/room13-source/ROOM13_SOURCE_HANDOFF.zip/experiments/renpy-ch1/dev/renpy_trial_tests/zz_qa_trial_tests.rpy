# Ren'Py test cases for the public meetings (day 7 and day 14).

testcase trial_missing:
    pause 2.0
    click "처음부터"
    pause 3.0
    run Call("r13_qa_trial",('E01', 'E05'),())
    pause 1.0
    click pos (640,600) until screen "choice" timeout 40
    pause 0.6
    click "아이만 그럴 수 있었다는 주장"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "되묻기"
    pause 0.5
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E05"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    screenshot "m_board.png"
    click "결론을 말한다"
    pause 1.0
    click "다른 길이 있으니"
    pause 0.6
    click pos (640,600) until eval room13.get("trial_result") in ("detained","cleared","culprit_proven") timeout 120
    pause 0.5
    screenshot "m_verdict.png"
    $ r13_qa_dump()

testcase trial_giveup:
    pause 2.0
    click "처음부터"
    pause 3.0
    run Call("r13_qa_trial",('E01', 'E06', 'E07', 'E09'),())
    pause 1.0
    click pos (640,600) until screen "choice" timeout 40
    pause 0.6
    click "죽음의 원인이라는 주장"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E01"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E01"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    screenshot "g_board.png"
    click "반론을 그만둔다"
    pause 1.0
    click "반론을 그만둔다"
    pause 0.5
    click pos (640,600) until eval room13.get("trial_result") in ("detained","cleared","culprit_proven") timeout 120
    pause 0.5
    screenshot "g_verdict.png"
    $ r13_qa_dump()

testcase trial_win:
    pause 2.0
    click "처음부터"
    pause 3.0
    run Call("r13_qa_trial",('E01', 'E06', 'E07', 'E09'),())
    pause 1.0
    click pos (640,600) until screen "choice" timeout 40
    pause 0.6
    click "죽음의 원인이라는 주장"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E06"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E07"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E09"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    screenshot "w_ready.png"
    click "결론을 말한다"
    pause 1.0
    click "누군가가 냈다"
    pause 0.6
    click pos (640,600) until eval room13.get("trial_result") in ("detained","cleared","culprit_proven") timeout 120
    pause 0.5
    screenshot "w_verdict.png"
    $ r13_qa_dump()

testcase trial_full:
    pause 2.0
    click "처음부터"
    pause 3.0
    run Call("r13_qa_trial",('E01', 'E05', 'E06', 'E07', 'E09', 'E12', 'E14', 'E15', 'E36'),())
    pause 1.0
    click pos (640,600) until screen "choice" timeout 40
    pause 0.6
    click "아이만 그럴 수 있었다는 주장"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "되묻기"
    pause 0.5
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E05"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "결론을 말한다"
    pause 1.0
    click "다른 길이 있으니"
    pause 0.6
    click pos (640,600) until screen "choice" timeout 40
    pause 0.6
    click "죽음의 원인이라는 주장"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E06"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E07"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E09"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "결론을 말한다"
    pause 1.0
    click "할머니가 어르신을 죽였다"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    screenshot "f_after_wrong.png"
    click "결론을 말한다"
    pause 1.0
    click "누군가가 냈다"
    pause 0.6
    click pos (640,600) until screen "choice" timeout 40
    pause 0.6
    click "그때 식당에 있었다는 말"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    run Return(("select","s2"))
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E12"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E05"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "결론을 말한다"
    pause 1.0
    click "주방에서 그 방까지"
    pause 0.6
    click pos (640,600) until screen "choice" timeout 40
    pause 0.6
    click "도우러 들어갔을 뿐이라는 변명"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E15"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E14"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E36"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "결론을 말한다"
    pause 1.0
    click "구하다 주운 게 아니라"
    pause 0.6
    click pos (640,600) until eval room13.get("trial_result")=="culprit_proven" and room13.get("granny_state")=="detained" timeout 120
    pause 0.5
    screenshot "f_verdict.png"
    $ r13_qa_dump()

testcase finale_win:
    pause 2.0
    click "처음부터"
    pause 3.0
    run Call("r13_qa_finale",('E16', 'E18', 'E20', 'E21', 'E23', 'E25', 'E26', 'E31'),('operators_ready', 'patient_transport', 'shelter_ready', 'supplies_ready'))
    pause 1.0
    click pos (640,600) until screen "r13_crisis" timeout 60
    pause 0.6
    click "누구도 돌아오지 못함"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E20"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E31"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "결론을 말한다"
    pause 1.0
    click "아무도 돌아올 수 없다"
    pause 0.6
    click pos (640,600) until screen "r13_crisis" timeout 60
    pause 0.6
    click "돌릴 방법이 없다"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E23"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "되묻기"
    pause 0.5
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E21"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "결론을 말한다"
    pause 1.0
    click "갈수록 짧아졌다"
    pause 0.6
    click pos (640,600) until screen "r13_crisis" timeout 60
    pause 0.6
    click "오늘 밤 희생 없이"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E25"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E26"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "되묻기"
    pause 0.5
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    screenshot "fi_f3_ready.png"
    click "결론을 말한다"
    pause 1.0
    click "손으로 교대하며"
    pause 0.6
    click pos (640,600) until screen "r13_crisis" timeout 60
    pause 0.6
    click "질서를 깨뜨려"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E18"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "자료로 반박"
    pause 0.8
    click "QA E16"
    pause 0.6
    click pos (640,600) until screen "r13_debate_board" timeout 40
    pause 0.6
    click "결론을 말한다"
    pause 1.0
    click "엄마를 다시 붙잡으려고"
    pause 0.6
    click pos (640,600) until screen "r13_crisis" timeout 60
    pause 0.6
    screenshot "fi_hub.png"
    $ r13_qa_dump()
    click "모은 근거와 해 둔 준비로"
    pause 1.0
    click "사람들과 움직인다"
    pause 1.0
    click pos (640,600) until eval room13.get("ending") is not None timeout 120
    pause 0.5
    screenshot "fi_ending.png"
    $ r13_qa_dump()

testcase finale_missing:
    pause 2.0
    click "처음부터"
    pause 3.0
    run Call("r13_qa_finale",('E20',),('operators_ready', 'patient_transport', 'shelter_ready', 'supplies_ready'))
    pause 1.0
    click pos (640,600) until screen "r13_crisis" timeout 60
    pause 0.6
    screenshot "fm_hub.png"
    click "모은 근거와 해 둔 준비로"
    pause 1.0
    click "사람들과 움직인다"
    pause 1.0
    click pos (640,600) until eval room13.get("ending") is not None timeout 120
    pause 0.5
    $ r13_qa_dump()
