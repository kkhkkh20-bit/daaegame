# 회의 자동 테스트 (Ren'Py test)

7일째 식당 회의와 14일째 제단 회의를 실제 화면에서 조작한다. 자료는 상태 주입으로 넣고, 반박·되묻기·결론·포기는 화면 버튼을 누른다.

| 테스트 | 내용 | 기대 결과 |
|---|---|---|
| trial_missing | C2 자료 없음 → C2는 선택지 없이 지나감, C1만 입증 | 구금 |
| trial_giveup | C2에서 틀린 자료 2번 뒤 반론을 그만둔다 | 구금 |
| trial_win | C2 입증, C3는 자료가 없어 지나감 | 석방 |
| trial_full | C1~C4 입증(C2에서 틀린 결론 1번 포함) | 범인 확인, 할머니 붙잡힘 |
| finale_win | F1~F4 입증 후 움직인다 | 엔딩 E5 |
| finale_missing | 자료 없이 제단 → 모든 주장 잠김, 움직인다 | 엔딩 E3 |

## 실행
1. `dev/package_web_webp.py`의 stage(웹용 게임 폴더) 복사본의 `game/`에 이 폴더의 두 `.rpy`를 넣는다.
2. `run_trial_tests.sh` 위쪽의 경로를 환경에 맞게 고친 뒤 `run_trial_tests.sh trial_missing trial_win ...`.
3. 결과는 게임 폴더의 `qa_result.txt`(판결·입증 논점·닫힌 논점·엔딩)와 `tests/screenshots/`.

주의: 이전 실행의 `tests/` 폴더가 남아 있으면 스크린샷 비교로 실패한다. 실행 전에 지운다. 테스트가 끝난 뒤에도 Ren'Py가 종료되지 않으므로 스크립트가 `Status:` 줄을 보고 프로세스를 끝낸다.
