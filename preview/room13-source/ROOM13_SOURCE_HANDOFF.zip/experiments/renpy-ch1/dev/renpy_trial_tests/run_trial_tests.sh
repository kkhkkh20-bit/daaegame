#!/bin/bash
S=/tmp/claude-0/-home-user-daaegame/0c8bdddd-6033-51af-89a7-6f2166fcb98a/scratchpad
for tc in "$@"; do
  ps -eo pid,comm | awk '$2=="renpy"{print $1}' | xargs -r kill -9 2>/dev/null
  rm -rf $S/qa/game/saves $S/qa/qa_result.txt ~/.renpy/daaegame-renpy-village-ch1-06/sync/*.save
  log=$S/qa_test_$tc.txt; rm -f $log
  timeout 400 xvfb-run -a -s "-screen 0 1280x720x24" $S/sdk/renpy-8.5.3-sdk/renpy.sh $S/qa test $tc > $log 2>&1 &
  for i in $(seq 1 400); do grep -q "Status:" $log 2>/dev/null && break; sleep 1; done
  sleep 1; ps -eo pid,comm | awk '$2=="renpy"{print $1}' | xargs -r kill -9 2>/dev/null
  echo "== $tc $(grep -o 'Status: [A-Z]*' $log | tail -1) $(grep -o 'Time: [0-9.]* s' $log | tail -1)"
  cat $S/qa/qa_result.txt 2>/dev/null; echo
  grep -E "Error:|line [0-9]+, in testcase" $log | head -3
done
