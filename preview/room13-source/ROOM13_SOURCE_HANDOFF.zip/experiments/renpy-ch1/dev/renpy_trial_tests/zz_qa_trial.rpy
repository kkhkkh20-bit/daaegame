init 999:
    screen r13_book(target=None,present=False,hearing=False):
        modal True
        zorder 60
        add Solid("#000c")
        vbox:
            xpos 40 ypos 40 spacing 4
            for k in room13["evidence"]:
                textbutton ("QA "+k) action Return(k)
            textbutton "QA 닫기" action Return(None)

init 999 python:
    def r13_qa_dump():
        d=dict(result=room13.get("trial_result"),daram=room13.get("daram_state"),granny=room13.get("granny_state"),
            props=list(room13["propositions"]),closed=dict(room13.get("debate",{}).get("closed",{})),
            ending=room13.get("ending"),open={c:r13_debate_open(c) for c in ("F1","F2","F3","F4")} if room13.get("finale_started") else None)
        open(renpy.config.basedir+"/qa_result.txt","w").write(repr(d))

label r13_qa_setup(day,ev,flags=()):
    $ room13_mode=True
    $ winter_mode=True
    $ winter=winter_new()
    $ source_mode=False
    $ room13=r13_new()
    $ r13_world_cameras={}
    $ r13_inspection_location=None
    $ r13_prepare_history()
    $ r13_scene_key=None
    $ r13_upgrade()
    $ typing_allowed=True
    hide screen winter_hud
    hide screen hud
    $ room13.update(day=day,period=0,case_state="occurred",victim_state="dead",location="inn",life_poc=True)
    $ room13["evidence"]=list(ev)
    $ room13["flags"]=list(set(room13["flags"])|{"lodging","entry_corrected","livelihood_open"}|set(flags))
    return

label r13_qa_trial(ev,flags=()):
    call r13_qa_setup(7,ev,flags)
    $ room13["daram_state"]="held"
    jump r13_trial

label r13_qa_finale(ev,flags=()):
    call r13_qa_setup(14,ev,flags)
    $ room13.update(daram_state="with_dad",trial_ended=True,trial_result="cleared",finale_started=True,location="altar",mom_state="reunited",week2_started=True)
    $ room13["flags"]=list(set(room13["flags"])|{"mom_reunited"})
    call r13_scene("r13_altar","북쪽 산길 끝 · 숲속 제단","hearing")
    jump r13_final_hub
