"""Render CSS contact pages from untouched runtime QA screenshots."""
import argparse,asyncio,json,shutil
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--source',default='qa-room13-0130/fixtures-final');args=ap.parse_args();base=ROOT/args.source;data=json.loads((base/'report.json').read_text())
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox']);page=await b.new_page(viewport={'width':1600,'height':1250},device_scale_factor=1)
  for period in range(3):
   group=[x for x in data['shots'] if x['type']=='background' and x['period']==period]
   html='<style>body{margin:0;background:#17242c;color:#fff;font:14px sans-serif}main{display:grid;grid-template-columns:repeat(4,1fr)}figure{margin:4px}img{width:100%;display:block}figcaption{height:24px}</style><main>'
   for x in group:html+='<figure><img src="'+x['file']+'"><figcaption>'+x['file']+'</figcaption></figure>'
   path=base/('contact-bg-%d.html'%period);path.write_text(html+'</main>');await page.goto('http://127.0.0.1:8094/'+str(path.relative_to('/workspace')));await page.wait_for_function('Array.from(document.images).every(i=>i.complete&&i.naturalWidth>0)');await page.screenshot(path=str(base/('contact-bg-%d.png'%period)),full_page=True)
  for kind in ('portrait','cinematic'):
   entries=[x for x in data['shots'] if x['type']==kind]
   for start in range(0,len(entries),16):
    group=entries[start:start+16];html='<style>body{margin:0;background:#17242c;color:#fff;font:14px sans-serif}main{display:grid;grid-template-columns:repeat(4,1fr)}figure{margin:4px}img{width:100%;display:block}figcaption{height:24px}</style><main>'
    for x in group:html+='<figure><img src="'+x['file']+'"><figcaption>'+x['file']+'</figcaption></figure>'
    stem='contact-'+kind+'-'+str(start//16);path=base/(stem+'.html');path.write_text(html+'</main>');await page.goto('http://127.0.0.1:8094/'+str(path.relative_to('/workspace')));await page.wait_for_function('Array.from(document.images).every(i=>i.complete&&i.naturalWidth>0)');await page.screenshot(path=str(base/(stem+'.png')),full_page=True)
  await b.close()
asyncio.run(main())
