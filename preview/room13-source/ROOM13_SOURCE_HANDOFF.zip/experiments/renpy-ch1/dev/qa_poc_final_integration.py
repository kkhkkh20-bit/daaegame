"""Targeted final-main integration after natural 3-day QA; reuses earned state."""
import asyncio,json,shutil,urllib.request
from playwright.async_api import async_playwright
from qa_poc_three_days import Q,OUT,URL
async def main():
 natural=json.loads((OUT/'report.json').read_text());fixture=json.loads((OUT/'day3-night-checkpoint.json').read_text())['room'];assert natural['status']=='passed'
 report=dict(status='running',kind='latest shop integration: captured naturally earned day3 state, then real compare/shop/night/save inputs',natural_archive_sha256=natural['archive_sha256'],archive_sha256=json.load(urllib.request.urlopen(URL+'game-transport.json'))['archive_sha256'],checks=[])
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=Q(pg,OUT);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  try:
   await pg.goto(URL);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;s=renpy.store;s.preferences.text_cps=0;s.preferences.afm_enable=False;s.room13='+repr(fixture)+';s.room13_mode=True;s.winter_mode=True;s.winter=s.winter_new();s.source_mode=False;s.typing_allowed=True;s.r13_scene_key=None;s.r13_world_cameras={};result=True')
   await q.py('import renpy\ns=renpy.store\nfor f in renpy.display.focus.focus_list:\n w=f.widget\n if isinstance(getattr(w,"action",None),s.Start):\n  w.action=s.Start("r13_roam");w.clicked=w.action\nresult=True');await q.press('처음부터');await q.wait('r13_hub');version=await q.py('import renpy;result=renpy.store.config.version');assert version=='0.17.17-dev';before=await q.room();await q.compare(['E01','E18']);assert (await q.room())['evidence']==before['evidence'];assert 'poc:letter_conflict' in (await q.room())['flags'];report['checks'].append('Final version and real owned-letter comparison, no automatic evidence award')
   await q.press('일거리 · 상점');await q.wait('r13_work_board');await q.press('상점');await q.shot('06-final-shop-integration');assert (await q.room())['livelihood']==before['livelihood'];await q.press('돌아가기');await q.wait('r13_hub');report['checks'].append('Latest shop entry retained; opening its work-board tab spends no money/time')
   await q.travel('13호실',region='inn');await q.sleep();s=await q.room();assert s['day']==4 and s['period']==0 and s['livelihood']['cash']==13 and s['livelihood']['debt']==0 and 'poc:night:3' in s['flags'];await q.save(3);saved=await q.room();await q.load(3);assert await q.room()==saved;report['checks'].append('Real Daram night recap, explicit sleep settlement, exact save/load with latest options tabs')
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.py('import renpy;renpy.store.persistent.room13_large_text=True;renpy.exports.restart_interaction();result=True');await q.press('기록');await q.wait('r13_records');await q.shot('07-final-mobile-records');assert not errors;report.update(status='passed-pending-visual-review',page_errors=errors)
  except Exception as e:
   import traceback
   report.update(status='failed',error=repr(e),traceback=traceback.format_exc());await pg.screenshot(path=str(OUT/'final-failure.png'))
  (OUT/'final-integration.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']=='failed':raise SystemExit(1)
asyncio.run(main())
