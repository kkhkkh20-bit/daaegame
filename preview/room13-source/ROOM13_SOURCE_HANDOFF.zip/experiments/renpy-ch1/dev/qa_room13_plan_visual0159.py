"""Explicit render fixtures; all puzzle interactions are covered by natural QA."""
import asyncio,shutil,json,argparse,urllib.request
from playwright.async_api import async_playwright
from qa_room13_first_mystery import MysteryQA,ROOT
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);a=ap.parse_args();out=ROOT/'qa-room13-0159/plan-render-fixture';out.mkdir(parents=True,exist_ok=True);r={'kind':'explicit diagram screen states, large-font mobile rendering','archive_sha256':json.load(urllib.request.urlopen(a.url+'game-transport.json'))['archive_sha256']}
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);pg=await b.new_page(viewport={'width':1280,'height':720},has_touch=True);q=MysteryQA(pg,out)
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;s=renpy.store;s.room13=s.r13_new();s.room13["period"]=1;s.room13["inspection_items"]={"inventory":["magnifier"]};renpy.exports.show_screen("r13_plan_comparison");renpy.exports.restart_interaction();result=True');await q.wait('r13_plan_comparison')
   for stage in (0,1,2):
    await q.py('import renpy;sc=renpy.display.screen.get_screen("r13_plan_comparison");sc.scope.update(stage='+str(stage)+',hint=True,lens=True,gap="books",endpoints=("books","kitchen"),reason="latch");renpy.exports.restart_interaction();result=True');await q.shot('PC-stage-'+str(stage))
   await pg.set_viewport_size({'width':844,'height':390});await q.py('import renpy;renpy.store.persistent.room13_large_text=True;renpy.exports.restart_interaction();result=True')
   for stage in (0,1,2):
    await q.py('import renpy;sc=renpy.display.screen.get_screen("r13_plan_comparison");sc.scope["stage"]='+str(stage)+';renpy.exports.restart_interaction();result=True');await q.shot('mobile-large-stage-'+str(stage))
   await q.py('import renpy;sc=renpy.display.screen.get_screen("r13_plan_comparison");sc.scope.update(stage=0,gap=None,hint=False);renpy.exports.restart_interaction();result=True')
   q.touch=True;await q.input(600,383);assert (await q.plan())["gap"]=="books";await q.press('선택한 부분');assert (await q.plan())["stage"]==1;await q.shot('mobile-large-actual-gap-hit')
   r['actual_touch_gap_and_advance']=True
   r['status']='passed-pending-visual-review'
  except Exception as e:r.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
  finally:(out/'report.json').write_text(json.dumps(r,indent=2));await b.close()
 print(r,flush=True)
 if r['status']=='failed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
