"""Real option clicks/touches; injected notebook/plan screens are display fixtures."""
import asyncio,json,shutil,copy
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_ui0156 import UIQA
OUT=Path('/workspace/work/daram-options/qa');OUT.mkdir(exist_ok=True)
URL='http://127.0.0.1:8094/release/'
class Q(UIQA):
 async def prefs(self):
  return await self.py('import renpy;s=renpy.store;result={"version":s.config.version,"typing":s.persistent.room13_typing_sound,"motion":s.persistent.room13_motion,"size":s.r13_text_size(),"alpha":s.persistent.room13_window_alpha,"cps":s.preferences.text_cps,"music":s.preferences.get_volume("music"),"sfx":s.preferences.get_volume("sfx")}')
 async def assert_fit(self):
  st=await self.state()
  for b in st['buttons']:
   x,y,w,h=b['rect']
   if w and h:assert x>=0 and y>=0 and x+w<=1281 and y+h<=721,b
  return st
async def main():
 report={'checks':[],'fixture_note':'Natural title/game entry and option clicks; no campaign fixtures.'};errors=[]
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();pg.on('pageerror',lambda e:errors.append(str(e)));q=Q(pg,OUT)
  try:
   await pg.goto(URL);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=180000);await q.wait('main_menu');await q.press('설정');await q.wait('pause_menu');assert (await q.prefs())['version']=='0.17.19-dev'
   await q.press('소리');await q.shot('01-sound');await q.assert_fit();await q.press('켜짐');await q.press('효과음 듣기')
   # Pick the typing row by its precise action parameter, then a real mouse click.
   st=await q.state();btn=sorted([x for x in st['buttons'] if x['text'].strip() in ('켜짐','꺼짐')],key=lambda x:x['rect'][1])[2];x,y,w,h=btn['rect'];await q.input(x+w/2,y+h/2);assert not (await q.prefs())['typing']
   await q.press('화면');await q.press('크게');await q.press('진하게');await q.shot('02-screen-large-preview');await q.assert_fit()
   await q.press('게임');await q.press('빠르게');await q.shot('03-game-large');await q.assert_fit()
   # Cancel confirmation must retain preference changes.
   before=await q.prefs();await q.press('옵션 초기화');await q.wait('confirm');await q.press('아니');assert await q.prefs()==before
   await q.press('돌아가기');await q.wait('main_menu');await pg.reload();await q.wait('main_menu');await q.press('설정');await q.wait('pause_menu');assert (await q.prefs())['typing']==False;assert (await q.prefs())['size']=='large';report['checks'].append('Real clicks: typing sound separation, size/opacity, text speed, reset cancellation and reload persistence')
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True
   for tab in ('소리','화면','게임'):
    await q.press(tab);await q.assert_fit();await q.shot('04-mobile-'+tab)
   await q.press('옵션 초기화');await q.wait('confirm');await q.shot('05-reset-confirm-mobile');await q.press('예');after=await q.prefs();assert after['typing'] and after['cps']==34;report['checks'].append('Real mobile touches: all three tabs fit with large text and confirmed reset')
   await q.press('돌아가기');await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub');state=await q.room();await q.press('옵션');await q.wait('pause_menu');await q.press('게임');await q.press('빠르게');await q.press('옵션 초기화');await q.wait('confirm');await q.press('예');await q.press('돌아가기');await q.wait('r13_hub');assert await q.room()==state;report['checks'].append('Natural fresh game: options and confirmed reset preserve complete campaign state')
   assert not errors,errors;report['status']='passed'
  except Exception as e:
   report.update(status='failed',error=repr(e));await pg.screenshot(path=str(OUT/'failure.png'))
   try:(OUT/'failure-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
   except:pass
  report['errors']=errors;(OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']=='failed':raise SystemExit(1)
asyncio.run(main())
