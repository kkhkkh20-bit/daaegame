"""Real fresh inputs through three days; optional continuation only from captured earned state."""
import asyncio,ast,json,shutil,urllib.request,sys
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_ui0156 import UIQA
from pixel_qa_flow0150 import FLOW_PROBE
OUT=Path('qa-room13-poc-three-days');OUT.mkdir(exist_ok=True)
URL='http://127.0.0.1:8094/room13-release-0173/'
class Q(UIQA):
 async def state(self):
  extra=['r13_resident_approach','r13_entry_daram_topics','r13_gate_document_inspection','r13_gate_document_read','r13_desk_inspection','r13_record_compare','r13_records','r13_book','r13_work_board','r13_learning_notes']
  probe=FLOW_PROBE.replace('names=[','names='+repr(extra)[:-1]+',')
  st=await self.py('ns={};exec('+ascii(probe)+',ns);result=ns["result"]');assert '_exception' not in st['screens'],st;return st
 async def advance_to(self,name):
  for _ in range(180):
   s=await self.state()
   if name in s['screens']:await asyncio.sleep(.4);return s
   if 'say' in s['screens']:await self.input(810,610)
   elif 'r13_cinematic_view' in s['screens']:await self.press('계속')
   else:await asyncio.sleep(.15)
  raise AssertionError((name,s))
 async def value(self,value):
  for i in range(8):
   try:return await super().value(value)
   except AssertionError:
    if i==7:raise
    await asyncio.sleep(.3)
 async def pan(self,start,end):
  await self.p.mouse.move(start,628);await self.p.mouse.down();await self.p.mouse.move(end,628,steps=16);await self.p.mouse.up();await asyncio.sleep(.4)
 async def reveal(self,x):
  for _ in range(6):
   offset=(await self.camera())['offset']
   if 65<x-offset<1215:return
   await self.pan(1100,350) if x-offset>=1215 else await self.pan(250,1100)
  raise AssertionError(('cannot reveal',x,await self.camera()))
 async def object(self,key):
  x,y,w,h=await self.py('import renpy;s=renpy.store;result=s.ROOM13["objects"][s.room13["location"]]['+repr(key)+']["rect"]')
  faces=await self.py('import renpy;s=renpy.store;result=[s.r13_actor_face(a) for a in s.r13_stage_people()]')
  candidates=[(x+w*.85,y+h*.15),(x+w*.15,y+h*.15),(x+w*.85,y+h*.75),(x+w*.5,y+h*.5)]
  px,py=next((point for point in candidates if not any(fx<=point[0]<=fx+fw and fy<=point[1]<=fy+fh for fx,fy,fw,fh in faces)),candidates[0]);await self.reveal(px);offset=(await self.camera())['offset'];await self.input(px-offset,py)
 async def person(self,key):
  actors=await self.py('import renpy;s=renpy.store;sc=renpy.display.screen.get_screen("r13_hub");result=[dict(person=a["person"],x=a["rect"][0]+a["rect"][2]/2) for a in s.r13_stage_people(bool(sc.scope.get("entry")) if sc else False)]')
  target=next((a for a in actors if a['person']==key),None)
  if target:await self.reveal(target['x'])
  name=await self.py('import renpy;result=renpy.store.R13_NAMES['+repr(key)+']')
  st=await self.state();buttons=[b for b in st['buttons'] if b['text'].strip()==name and b['rect'][3]>15 and 0<b['rect'][0]+b['rect'][2]/2<1280]
  if buttons:await self.press(name)
  else:await self.value(('person',key))
 async def talk(self,key):
  await self.person(key);await self.advance()
  if 'r13_resident_approach' in (await self.state())['screens']:await self.value(True)
  await self.advance_to('r13_topics')
 async def travel(self,label,region=None):
  await self.press('지도 · 이동');await self.wait('r13_map');await asyncio.sleep(.4)
  if region:await self.press('마을' if region=='village' else '여관 안')
  labels=[b['text'] for b in (await self.state())['buttons']]
  if any('지도로 보기' in s for s in labels):await self.press('지도로 보기')
  await self.press(label);await asyncio.sleep(.3);selected=await self.py('import renpy;result=renpy.display.screen.get_screen("r13_map").scope["selected"]');await self.press('이곳으로 이동');await self.advance_to('r13_hub');assert (await self.room())['location']==selected
 async def present(self,person,key):
  await self.press('보여주기');await self.wait('r13_book');category=await self.py('import renpy;result=renpy.store.r13_record_category('+repr(key)+')');await self.press('들은 말' if category=='testimony' else '찾은 것')
  label=await self.py('import renpy;result=renpy.store.R13_RECORD_SHORT.get('+repr(key)+',renpy.store.ROOM13["evidence"]['+repr(key)+']["name"])');await self.press(label);await self.press('보여주기');await self.advance_to('r13_confirm');await self.press('보여준다');await self.advance_to('r13_topics')
 async def work(self,key,choice):
  await self.press('일거리 · 상점');await self.wait('r13_work_board');label=await self.py('import renpy;result=renpy.store.R13_JOBS['+repr(key)+']["title"]');await self.press(label);await self.wait('r13_confirm');await self.press('시작하기');await self.advance_to('choice')
  label='주어진 일을 마친다' if choice=='finish' else '같은 길의 두 배달을 묶어' if choice=='combine' else await self.py('import renpy;result=renpy.store.R13_JOBS['+repr(key)+']["choice"]')
  await self.press(label);await self.advance_to('r13_hub')
 async def compare(self,keys):
  await self.press('기록');await self.wait('r13_records');await self.press('기록 비교');await self.wait('r13_record_compare')
  for key in keys:
   label=await self.py('import renpy;result=renpy.store.R13_RECORD_SHORT.get('+repr(key)+',renpy.store.ROOM13["evidence"]['+repr(key)+']["name"])')
   for _ in range(8):
    buttons=[b for b in (await self.state())['buttons'] if b['text'].strip()==label and 326<=b['rect'][1] and b['rect'][1]+b['rect'][3]<=500]
    if buttons:
     x,y,w,h=buttons[0]['rect'];await self.input(x+w/2,y+h/2);break
    await self.p.mouse.move(600,420);await self.p.mouse.wheel(0,140);await asyncio.sleep(.4)
   else:raise AssertionError(('comparison item not visible',key))
   selected=await self.py('import renpy;result=renpy.display.screen.get_screen("r13_record_compare").scope["selected"]');assert key in selected
  await self.press('비교하기');await self.shot('comparison-'+ '-'.join(keys));await self.press('기록으로 돌아가기');await self.wait('r13_records');await self.press('닫기');await self.wait('r13_hub')
 async def save(self,slot):
  await self.press('옵션');await self.wait('pause_menu');await self.press('게임');await self.press('저장');await self.wait('save');await self.press('1쪽 '+str(slot)+'번');await self.press('돌아가기');await self.wait('r13_hub')
 async def load(self,slot):
  await self.press('옵션');await self.wait('pause_menu');await self.press('게임');await self.press('불러오기');await self.wait('load');await self.press('1쪽 '+str(slot)+'번');await self.press('예');await self.wait('r13_hub')
 async def sleep(self):
  await self.press('자기');await self.wait('r13_confirm');await self.press('자기');await self.advance_to('r13_hub')
async def main():
 report={'archive_sha256':json.load(urllib.request.urlopen(URL+'game-transport.json'))['archive_sha256'],'mode':'fresh natural first-day through third-day inputs; preferences only, no story/evidence/time injection','checks':[]}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=Q(pg,OUT);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)));stage='boot'
  try:
   await pg.goto(URL);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;s=renpy.store;s.preferences.text_cps=0;s.preferences.afm_enable=False;result=True')
   if any(flag in sys.argv for flag in ('--resume-day2','--resume-day1-room','--resume-day3','--resume-day4')):
    checkpoint=json.loads((OUT/('day1-room-checkpoint.json' if '--resume-day1-room' in sys.argv else 'day4-checkpoint.json' if '--resume-day4' in sys.argv else 'day3-checkpoint.json' if '--resume-day3' in sys.argv else 'day2-checkpoint.json')).read_text());assert checkpoint['archive_sha256']==report['archive_sha256'];fixture=checkpoint['room'];report['checks']=checkpoint.get('checks',[]);report['mode']='segmented natural run: captured earned world state, then real remaining inputs'
    await q.py('import renpy;s=renpy.store;s.room13='+repr(fixture)+';s.room13_mode=True;s.winter_mode=True;s.winter=s.winter_new();s.source_mode=False;s.typing_allowed=True;s.r13_scene_key=None;s.r13_world_cameras={};result=True')
    await q.py('import renpy\ns=renpy.store\nfor f in renpy.display.focus.focus_list:\n w=f.widget\n if isinstance(getattr(w,"action",None),s.Start):\n  w.action=s.Start("r13_roam");w.clicked=w.action\nresult=True');await q.press('처음부터');await q.wait('r13_hub')
   else:
    stage='day1-entry';await q.press('처음부터');await q.advance_to('r13_hub');assert 'entry_corrected' not in (await q.room())['flags']
    await q.person('daram');await q.advance_to('r13_entry_daram_topics');await q.value('look');await q.advance_to('r13_entry_daram_topics');await q.press('돌아가기');await q.wait('r13_hub')
    await q.object('gate_documents');await q.wait('r13_gate_document_inspection')
    for label in ('예약 원본','옮겨 쓴 이름 목록'):
     await q.press(label);await q.wait('r13_gate_document_read');await q.press('확인');await q.wait('r13_gate_document_inspection')
    await q.press('현장으로 돌아가기');await q.wait('r13_hub');await q.person('daram');await q.advance_to('r13_entry_daram_topics');await q.value('compare');await q.advance_to('r13_record_compare');await q.press('예약 원본');await q.press('옮겨 쓴 목록');await q.press('비교하기');await q.press('기록으로 돌아가기');await q.wait('r13_entry_daram_topics');await q.press('돌아가기');await q.wait('r13_hub')
    await q.person('guard');await q.wait('r13_entry_topics');await q.press('보여주기');await q.wait('r13_book');await q.press('예약 원본');await q.press('보여주기');await q.advance_to('r13_hub');assert 'entry_corrected' in (await q.room())['flags'] and (await q.room())['location']=='gate'
    await q.travel('광장');await q.travel('여관 접수대')
   if not any(flag in sys.argv for flag in ('--resume-day2','--resume-day3','--resume-day4')):
    stage='day1-room';await q.talk('granny');await q.value('register');await q.advance_to('r13_topics');await q.press('돌아가기');await q.wait('r13_hub');assert (await q.room())['location']=='inn';await q.travel('2층 복도',region='inn');await q.travel('13호실')
    await q.object('desk');await q.wait('r13_desk_inspection');rect=await q.py('import renpy;result=renpy.store.R13_INSPECTION_LAYOUT["desk"]["targets"]["letters"]');x,y,w,h=rect;await q.input(x+w/2,y+h/2);await q.wait('say');assert 'M01' not in (await q.room())['evidence'];await q.advance_to('r13_desk_inspection');assert 'M01' in (await q.room())['evidence'];await q.press('방으로');await q.wait('r13_hub')
    await q.object('bed');await q.advance_to('r13_object_context');assert 'E03' in (await q.room())['evidence'];await q.press('그만 살펴본다');await q.wait('r13_hub');await q.compare(['E01','M01']);await q.travel('여관 접수대');await q.talk('granny');await q.present('granny','M01');await q.press('돌아가기');await q.wait('r13_hub');await q.travel('13호실');await q.sleep();s=await q.room();assert s['day']==2 and s['period']==0 and s['livelihood']['cash']==0 and s['livelihood']['debt']==0
    report['checks'].append('Natural day1: companion registration deduction, manual inn/room navigation, note acquired after reading, room investigation, record comparison, free first night and explicit sleep')
    (OUT/'day2-checkpoint.json').write_text(json.dumps(dict(room=s,archive_sha256=report['archive_sha256'],checks=report['checks']),ensure_ascii=False,indent=2));await q.shot('01-day2-start')
   if not any(flag in sys.argv for flag in ('--resume-day3','--resume-day4')):
    stage='day2-post';await q.travel('마을 입구',region='village');await q.talk('karo');await q.value('life:karo');await q.advance_to('r13_topics');await q.press('돌아가기');await q.wait('r13_hub');await q.travel('수리점');await q.talk('resident_lamplighter');await q.present('resident_lamplighter','M01');await q.value('intro:lamplighter_mother');await q.wait('say');assert 'J02' not in (await q.room())['evidence'];await q.advance_to('r13_topics');await q.press('돌아가기');await q.wait('r13_hub');await q.travel('우체국');await q.talk('seryeon');await q.present('seryeon','J02');await q.present('seryeon','E01');await q.present('seryeon','M01');await q.value('intro:post_visit');await q.advance_to('r13_topics');assert 'J03' in (await q.room())['evidence'];await q.press('돌아가기');await q.wait('r13_hub');assert (await q.room())['period']==0
    stage='day2-kitchen';await q.travel('식당',region='inn');await q.talk('nabi');await q.present('nabi','M01');assert not await q.py('import renpy;result=any(k=="poc:nabi_packet" for k,t in renpy.store.r13_topics("nabi"))');await q.press('돌아가기');await q.wait('r13_hub');await q.work('kitchen','finish');assert 'J04' not in (await q.room())['evidence'];await q.talk('nabi');await q.value('poc:nabi_packet');await q.wait('say');assert 'J04' not in (await q.room())['evidence'];await q.advance_to('r13_topics');assert 'J04' in (await q.room())['evidence'];await q.shot('02-work-opens-witness');await q.press('돌아가기');await q.wait('r13_hub')
    stage='day2-delivery';await q.work('delivery','ask');await q.talk('karo');await q.present('karo','M01');await q.value('poc:karo_box');await q.advance_to('r13_topics');assert 'J05' in (await q.room())['evidence'];await q.press('돌아가기');await q.wait('r13_hub');await q.compare(['M01','J04']);await q.talk('resident_lamplighter');await q.present('resident_lamplighter','J04');assert 'E18' not in (await q.room())['evidence'];await q.press('돌아가기');await q.wait('r13_hub');s=await q.room();assert s['day']==2 and s['period']==2 and s['livelihood']['cash']==13
    await q.travel('13호실',region='inn');await q.sleep();s=await q.room();assert s['day']==3 and s['period']==0 and s['livelihood']['cash']==3 and s['livelihood']['debt']==0;assert 'poc:night:2' in s['flags'];report['checks'].append('Natural day2: postal testimony before work, note presentation plus real kitchen/delivery, explicit followups award two distinct witnesses, two jobs pay13 and leave3 on sleep; no shop required')
    (OUT/'day3-checkpoint.json').write_text(json.dumps(dict(room=s,archive_sha256=report['archive_sha256'],checks=report['checks']),ensure_ascii=False,indent=2));await q.shot('03-day3-debt-and-direction')
   if '--resume-day4' not in sys.argv:
    stage='day3-work';await q.work('delivery','combine');await q.work('kitchen','finish');s=await q.room();assert s['day']==3 and s['period']==2 and s['livelihood']['cash']==23 and s['livelihood']['debt']==0 and not s['livelihood']['items'];assert s['livelihood']['combined_paid']
    stage='day3-letter';await q.travel('마을 입구',region='village');await q.talk('resident_lamplighter');await q.present('resident_lamplighter','J05');await q.value('lamplighter_warning');await q.advance_to('r13_topics');assert 'warning_location' in (await q.room())['flags'] and 'E18' not in (await q.room())['evidence'];await q.press('돌아가기');await q.wait('r13_hub');await q.travel('광장');await q.object('lamp');await q.advance_to('r13_object_context');before=await q.room();await q.value(('activity','warning'));await q.wait('r13_confirm');await q.press('진행한다');await q.wait('say');assert 'E18' not in (await q.room())['evidence'];await q.advance_to('r13_hub');s=await q.room();assert 'E18' in s['evidence'] and s['period']==before['period'] and s['livelihood']==before['livelihood'];await q.compare(['E01','E18']);assert 'poc:letter_conflict' in (await q.room())['flags']
    stage='day3-question';await q.travel('여관 접수대');await q.talk('granny');await q.present('granny','E18');await q.value('poc:granny_letter');await q.wait('say');assert 'J06' not in (await q.room())['evidence'];await q.advance_to('r13_topics');assert 'J06' in (await q.room())['evidence'];await q.shot('04-invitation-question');await q.press('돌아가기');await q.wait('r13_hub');assert (await q.room())['period']==2
    stage='day3-night';await q.press('일거리 · 상점');await q.wait('r13_work_board');await q.press('생활 장부');
    if (await q.room())['livelihood']['debt']:await q.press('가진 돈으로 외상 갚기')
    await q.press('돌아가기');await q.wait('r13_hub');s=await q.room();assert s['livelihood']['cash']==23 and s['livelihood']['debt']==0;await q.travel('13호실',region='inn');await q.sleep();s=await q.room();assert s['day']==4 and s['period']==0 and s['livelihood']['cash']==13 and s['livelihood']['debt']==0 and 'poc:night:3' in s['flags'];report['checks'].append('Natural day3: combined delivery14 with borrowed cord, kitchen6, free read-before-acquire warning letter, owned-letter comparison, evidence presentation and explicit Granny followup, zero-debt repayment is safe and lodging leaves13; no forced verdict')
    (OUT/'day4-checkpoint.json').write_text(json.dumps(dict(room=s,archive_sha256=report['archive_sha256'],checks=report['checks']),ensure_ascii=False,indent=2))
   stage='save-mobile';await q.save(3);saved=await q.room();await q.load(3);assert await q.room()==saved;await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.py('import renpy;renpy.store.persistent.room13_large_text=True;renpy.exports.restart_interaction();result=True');await q.press('기록');await q.wait('r13_records');await q.shot('05-mobile-three-day-records');report['checks'].append('Exact save/load after three natural days; mobile large-text records render');assert not errors,errors;report['status']='passed-pending-visual-review'
  except Exception as e:
   import traceback
   report.update(status='failed',stage=stage,error=repr(e),traceback=traceback.format_exc());await pg.screenshot(path=str(OUT/'failure.png'))
   try:(OUT/'failure-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
   except:pass
  report['page_errors']=errors;(OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ('error','traceback')},ensure_ascii=False),flush=True);await b.close()
  if report['status']=='failed':raise SystemExit(1)
if __name__=="__main__":asyncio.run(main())
