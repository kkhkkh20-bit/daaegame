"""Explicitly injected single-family-actor world staging fixtures, not narrative play."""
import asyncio,json,shutil
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_browser import PixelQA,ROOT
OUT=ROOT/'qa-room13-0150/family-world-runtime-mom-schedule';OUT.mkdir(parents=True,exist_ok=True)
URL='http://127.0.0.1:8094/room13-release-0150/'
CASES=[('mom','action_1','greenhouse',0),('mom','action_2','greenhouse',2)]
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);ctx=await browser.new_context(viewport={'width':1280,'height':720},service_workers='block');page=await ctx.new_page();errors=[];bad=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('response',lambda r:bad.append([r.status,r.url]) if r.status>=400 and 'favicon'not in r.url else None);q=PixelQA(page,OUT);report={'kind':'injected-day9-reunion-state-actual-scheduled-people-and-poses-not-natural-play','url':URL,'shots':[]}
  try:
   await page.goto(URL);await page.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub')
   await q.py("import renpy,copy\ns=renpy.store\ns.qa_family_state=copy.deepcopy(s.room13)\ns.qa_family_visible=s.r13_visible_people\ns.qa_family_living=s.r13_living_pose\nresult=True")
   for who,pose,location,period in CASES:
    code="""import renpy
s=renpy.store
s.room13.update(day=9,period=%d,location=%r,case_state='prevented',daram_state='rescued')
if 'mom_reunited' not in s.room13['flags']:s.room13['flags'].append('mom_reunited')
s.r13_visible_people=s.qa_family_visible # %r
s.r13_living_pose=s.qa_family_living # %r
s.r13_inspection_location=None
s.place=s.R13_PLACES[s.room13['location']][0]
for n in ['r13_hub','say','r13_hud']:renpy.exports.hide_screen(n)
renpy.exports.scene()
renpy.exports.show('qa_family_world_bg',what=s.r13_background(s.R13_PLACES[s.room13['location']][1]))
renpy.exports.show_screen('r13_hub',entry=False)
renpy.exports.show_screen('r13_hud')
renpy.exports.restart_interaction()
result={'actors':s.r13_stage_people(),'spec':s.r13_acting_spec(%r,%r),'floor_explicit':%r in s.R13_STAGE_FLOORS,'floors':s.R13_STAGE_FLOORS.get(%r),'version':s.config.version,'scheduled_people':s.r13_people()}
"""%(period,location,who,pose,who,pose,location,location)
    data=await q.py(code);await asyncio.sleep(.7);await q.state();name=f'{who}-{pose}-{location}-p{period}';await q.shot(name);report['shots'].append({'file':name+'.png',**data})
   await q.py('import renpy;s=renpy.store;s.room13=s.qa_family_state;s.r13_visible_people=s.qa_family_visible;s.r13_living_pose=s.qa_family_living;result=True');report['state_restored']=True;report['status']='rendered-needs-visual-review'
  except Exception as e:
   report['status']='failed';report['exception']=repr(e);await page.screenshot(path=str(OUT/'failure.png'))
  report['page_errors']=errors;report['http_errors']=bad;(OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='shots'},ensure_ascii=False));await browser.close()
asyncio.run(main())
