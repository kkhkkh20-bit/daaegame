"""Public-meeting engine: data integrity, judging, trust reset, proofs only via r13_prove."""
import copy,json,textwrap,types
from pathlib import Path
root=Path(__file__).resolve().parents[1]
content=json.loads((root/'game/room13-content.json').read_text())
evidence=content['evidence'] if isinstance(content['evidence'],dict) else {e['id']:e for e in content['evidence']}
claims={c['id']:c for c in content['claims']}
block=(root/'game/systems/room13_debate.rpy').read_text().split('init 98 python:\n',1)[1].split('\nlabel ',1)[0]
store=types.SimpleNamespace(room13=dict(propositions=[],flags=[],evidence=[],finale_started=False))
env=dict(store=store,winter_copy=copy,R13_NAMES={},
    r13_has=lambda k:k in store.room13['flags'] or k in store.room13['evidence'])
exec(compile(textwrap.dedent(block),'debate','exec'),env)
D=env['R13_DEBATE'];checks=[]

# Data: every claim exists, every accepted/soft item is a real evidence id, reveal targets exist.
assert set(D)=={'C1','C2','C3','C4','F1','F2','F3','F4'}
for cid,spec in D.items():
    assert cid in claims
    ids=[st['id'] for st in spec['statements']]
    assert len(ids)==len(set(ids))
    for st in spec['statements']:
        assert '【' in st['text'] and '】' in st['text'],(cid,st['id'])
        assert st.get('hint') and st.get('wrong')
        for key in st.get('accept',[])+list(st.get('soft',{})):
            assert key in evidence,(cid,st['id'],key)
        if st.get('reveals'):assert st['reveals'] in ids
        if not st.get('truth'):
            assert st.get('accept') or st.get('ready_flags'),(cid,st['id'])
    kinds=[k for k,t in spec['conclusion']['options']]
    assert sorted(kinds)==['correct','over','weak']
    for k in ('correct','over','weak'):assert spec['conclusion'][k]
checks.append('8 claims, statements, conclusions and evidence ids are consistent')

# Every accepted item was already part of that claim's original support evidence (obtainability kept),
# except E37 which is the direct operation record of the same passage as E05.
for cid,spec in D.items():
    old={e for path in claims[cid]['support_sets'] for e in path}|({'E37'} if 'E05' in str(claims[cid]['support_sets']) else set())
    for st in spec['statements']:
        for key in st.get('accept',[]):
            assert key in old,(cid,st['id'],key)
checks.append('accepted evidence is a subset of the original support sets')

# Judging on C2.
store.room13['evidence']=['E06','E07','E10','E01']
j=env['r13_debate_judge']
assert j('C2','s1','E06')[0]=='break'
assert j('C2','s1','E07')[0]=='soft'          # breaks another visible statement: no penalty
assert j('C2','s1','E01')[0]=='wrong'
assert j('C2','s3','E10')[0]=='soft'          # E10 needs bami's consent
store.room13['flags'].append('bami_consent');assert j('C2','s3','E10')[0]=='break'
checks.append('break / soft (other statement, consent) / wrong')

# Hidden statements appear only after pressing the revealing one; truths are not required.
assert not env['r13_debate_visible']('C1',env['r13_debate_statement']('C1','s2'))
env['r13_debate_mark']('pressed','C1','s1')
assert env['r13_debate_visible']('C1',env['r13_debate_statement']('C1','s2'))
assert env['r13_debate_required']('C1')==['s2']
checks.append('press reveals hidden statement; true statements are not required')

# Ready only when every required statement is broken; proofs are not written by the engine.
assert not env['r13_debate_ready']('C2')
for sid in ('s1','s2','s3'):env['r13_debate_mark']('broken','C2',sid)
assert env['r13_debate_ready']('C2') and 'C2' not in store.room13['propositions']
checks.append('conclusion unlocks after all required statements; propositions untouched')

# Trust: five misses reset only that claim's progress and refill trust; evidence stays.
before=list(store.room13['evidence'])
for i in range(4):assert env['r13_debate_lose_trust']('C2')==4-i
assert env['r13_debate_lose_trust']('C2')==0
env['r13_debate_reset_claim']('C2')
assert env['r13_debate_trust']('C2')==5 and not env['r13_debate_ready']('C2') and store.room13['evidence']==before
assert env['r13_debate_is_pressed']('C1','s1')   # other claims keep progress
checks.append('trust 0 resets the claim only; evidence and other claims kept')

# F3 manpower statement breaks by pressing once the real preparation flags exist.
env['r13_debate_mark']('pressed','F3','s3')
assert not env['r13_debate_is_broken']('F3','s3')
store.room13['flags']+=['operators_ready','patient_transport']
assert env['r13_debate_is_broken']('F3','s3')
checks.append('F3 manpower depends on real preparation flags')

# F4 separation statement counts as settled once C4 was proven.
assert not env['r13_debate_is_broken']('F4','s2')
store.room13['propositions'].append('C4');assert env['r13_debate_is_broken']('F4','s2')
checks.append('F4 s2 skipped after C4')

# Seats move with progress; the accuser never moves; sessions are separate.
seats=dict(env['r13_debate_seats']('trial'))
assert seats['seryeon']==0 and seats['buri']>=1
assert env['r13_debate_session']('C2')=='trial'
store.room13['finale_started']=True;assert env['r13_debate_session']('C2')=='finale'
checks.append('seat stances derived from progress; sessions separated')

# Conclusion order is deterministic and not always first.
firsts={cid:env['r13_debate_conclusion_options'](cid)[0][0] for cid in D}
assert len(set(firsts.values()))>1
checks.append('conclusion positions vary per claim')
print(json.dumps({'passed':True,'checks':checks},ensure_ascii=False,indent=2))
