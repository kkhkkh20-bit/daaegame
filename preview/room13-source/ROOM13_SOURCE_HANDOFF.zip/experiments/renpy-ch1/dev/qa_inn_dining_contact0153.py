"""Explicit source-injected staging census/render fixtures, not story playthroughs."""
import asyncio,json,shutil,textwrap
from playwright.async_api import async_playwright
from pixel_qa_browser import PixelQA,ROOT
OUT=ROOT/'qa-room13-0153/inn-dining-contact';OUT.mkdir(parents=True,exist_ok=True)
s=(ROOT/'game/room13_acting.rpy').read_text();SRC=textwrap.dedent(s[s.index('    class R13FurnitureMask('):s.index('    def r13_staged_art(')])
CENSUS='''import renpy,copy
s=renpy.store
s.qa_crowd_original=copy.deepcopy(s.room13)
maxima={};conditions=0
for day in range(1,15):
 for period in range(3):
  for victim,granny,case,flags in [('alive','trusted','prevented',[]),('dead','trusted','occurred',['bami_protected']),('alive','detained','prevented',['mom_reunited','shelter_ready','patient_transport','nubi_protected','bami_protected']),('dead','detained','occurred',['mom_reunited','shelter_ready','patient_transport','nubi_protected','bami_protected'])]:
   for loc in ['inn','dining']:
    state=copy.deepcopy(s.qa_crowd_original);state.update(day=day,period=period,location=loc,victim_state=victim,granny_state=granny,case_state=case,daram_state='rescued' if day>=8 else 'with_dad');state['flags']+=flags;s.room13=state
    people=list(s.r13_people());actors=s.r13_stage_people();conditions+=1
    assert set(people)==set(a['person'] for a in actors),(day,period,loc,'missing resident')
    if loc=='inn':
     assert all(not a['occlusion'] for a in actors if a['person']!='granny'),(day,period,'guest behind counter')
     slots=[a['slot'] for a in actors if a.get('slot')];assert len(slots)==len(set(slots)),(day,period,'shared floor slot')
    if loc=='dining':
     assert all(a['contact'] not in ('portable_stool','portable_bucket') for a in actors),(day,period,'floating portable seat')
    if len(people)>len(maxima.get(loc+'-p'+str(period),{}).get('people',[])):maxima[loc+'-p'+str(period)]={'state':copy.deepcopy(state),'people':people}
result={'maxima':maxima,'conditions':conditions}
'''
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},service_workers='block');pg=await c.new_page();q=PixelQA(pg,OUT);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)));report={'kind':'source-injected-0152-layout-fixtures-not-natural-play','shots':[]}
  try:
   await pg.goto('http://127.0.0.1:8094/room13-release-0152/');await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub');await q.py('import renpy;exec('+repr(SRC)+',renpy.store.__dict__);result=True');census=await q.py(CENSUS);report.update(census)
   for place in ['inn','dining']:
    await q.py("import renpy;s=renpy.store;s.room13.update(location="+repr(place)+",period=1);renpy.exports.hide_screen('r13_hub');renpy.exports.hide_screen('say');renpy.exports.scene();renpy.exports.show('qa_empty',what=s.r13_background(s.R13_PLACES["+repr(place)+"][1]));renpy.exports.restart_interaction();result=True")
    await asyncio.sleep(.3);await pg.screenshot(path=str(OUT/(place+'-empty.png')))
   for loc,row in census['maxima'].items():
    data=await q.py("""import renpy
s=renpy.store
s.room13="""+ascii(row['state'])+"""
s.place=s.R13_PLACES[s.room13['location']][0]
for n in ['r13_hub','r13_hud','say']:renpy.exports.hide_screen(n)
renpy.exports.scene()
renpy.exports.show('qa_crowd_bg',what=s.r13_background(s.R13_PLACES[s.room13['location']][1]))
actors=s.r13_stage_people()
for i,a in enumerate(actors):
 art=s.r13_staged_art(a)
 if a['occlusion']:art=s.AlphaMask(art,s.R13FurnitureMask(a['occlusion'],size=(a['width'],a['height']),origin=(a['x'],a['y'])),invert=True)
 renpy.exports.show('qa_crowd_'+str(i),what=art,at_list=[s.Transform(xpos=a['x'],ypos=a['y'])])
renpy.exports.show_screen('r13_hud')
renpy.exports.restart_interaction()
result={'actors':actors,'people':s.r13_people()}
""")
    assert set(a['person'] for a in data['actors'])==set(data['people']),(loc,data)
    await asyncio.sleep(.5);await pg.screenshot(path=str(OUT/(loc+'.png')));report['shots'].append({'location':loc,**data});print('SHOT',loc,len(data['actors']),flush=True)
   await q.py('import renpy;renpy.store.room13=renpy.store.qa_crowd_original;result=True');report['status']='rendered-needs-visual-review'
  except Exception as e:report['status']='failed';report['error']=repr(e);await pg.screenshot(path=str(OUT/'failure.png'))
  report['page_errors']=errors;(OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(report['status'],report.get('error'),flush=True);await b.close()
asyncio.run(main())
