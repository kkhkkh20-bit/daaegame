"""Natural wait entry and inn journey; actual mouse/touch and slot save/load."""
import asyncio,argparse,json,shutil,urllib.request
from playwright.async_api import async_playwright
from pixel_qa_navigation0153 import SpatialQA,ROOT
from pixel_qa_ui0156 import UIQA
class FinalQA(SpatialQA):
 state=UIQA.state
 advance=UIQA.advance
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',required=True);a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True);report={'kind':'natural-entry-inn-mouse-touch-offset-save','archive_sha256':json.load(urllib.request.urlopen(a.url+'game-transport.json'))['archive_sha256']}
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);pg=await b.new_page(viewport={'width':1280,'height':720},has_touch=True);q=FinalQA(pg,out)
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub');await q.value(('person','guard'));await q.wait('r13_entry_topics');await q.value(('entry','wait'));await q.wait('r13_confirm');await q.value(True);await q.advance();await q.wait('r13_hub');await q.travel('여관 접수대');await q.wait('r13_hub')
   before=(await q.state())['room'];initial=await q.camera();assert initial['offset']==640;assert not any(b['text'].strip()in('‹','›','둘러보기')for b in(await q.state())['buttons'])
   await q.drag((400,230),(850,230));saved=await q.camera();assert 0<saved['offset']<640;saved_state=(await q.state())['room'];assert saved_state==before;await q.shot('01-mouse-pan-nondefault')
   await q.press('옵션');await q.wait('pause_menu');await q.press('저장');await q.wait('save');await q.press('1쪽 3번');await q.press('돌아가기');st=await q.state()
   if 'pause_menu'in st['screens']:await q.press('돌아가기')
   await q.wait('r13_hub');await q.drag((400,230),(1000,230));assert(await q.camera())['offset']==0
   await q.press('옵션');await q.wait('pause_menu');await q.press('불러오기');await q.wait('load');await q.press('1쪽 3번');await q.press('예');await q.wait('r13_hub');loaded=await q.camera();assert loaded['offset']==saved['offset'],(saved,loaded);assert(await q.state())['room']==saved_state;await q.shot('02-actual-loaded-nondefault-offset')
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.drag((900,230),(400,230));mobile=await q.camera();assert mobile['offset']>loaded['offset'];assert(await q.state())['room']==before;await q.shot('03-touch-swipe-no-controls')
   # Touch starts on the visible Granny face, not an empty map area.
   actor=await q.py('import renpy;s=renpy.store;result=next(a for a in s.r13_stage_people()if a["person"]=="granny")')
   spec=await q.py('import renpy;s=renpy.store;result=s.r13_acting_spec("granny",'+repr(actor['pose'])+')')
   scale=actor['height']/spec['crop'][3];hx,hy,hw,hh=spec['head'];start=(actor['x']+(hx+hw/2)*scale-mobile['offset'],actor['y']+(hy+hh/2)*scale)
   await q.drag(start,(start[0]+220,start[1]));after_npc=await q.camera();assert 'r13_hub'in(await q.state())['screens'];assert after_npc['offset']<mobile['offset'];assert(await q.state())['room']==before
   await q.value(('person','granny'));await q.advance()
   if 'r13_resident_approach'in(await q.state())['screens']:
    await q.value(True);await q.advance()
   await q.wait('r13_topics');await q.shot('04-npc-drag-then-tap-talk')
   report.update(status='passed',initial=initial,saved=saved,loaded=loaded,mobile=mobile,npc_drag=after_npc,npc_tap_opens_topics=True,story_time_unchanged=True)
  except Exception as e:report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
  finally:await b.close();(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(report,flush=True)
 if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
