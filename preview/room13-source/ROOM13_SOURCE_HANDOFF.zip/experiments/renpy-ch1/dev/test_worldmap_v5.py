"""Source-level map invariants; actual input is covered by qa_worldmap_v5.py."""
import ast, textwrap, json, types, copy, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]/'game'
ns={'store':types.SimpleNamespace(room13={})}
def extract(file,names):
 text=(ROOT/file).read_text();start=text.index(' python:\n')+len(' python:\n');lines=[]
 for line in text[start:].splitlines():
  if line and not line.startswith((' ','#')):break
  lines.append(line)
 tree=ast.parse(textwrap.dedent('\n'.join(lines)))
 chosen=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in names or isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in names for t in n.targets)]
 exec(compile(ast.Module(body=chosen,type_ignores=[]),file,'exec'),ns)
extract('room13_rules.rpy',{'r13_places'})
ns['r13_has']=lambda f:f in ns['store'].room13['flags'] or f in ns['store'].room13['evidence']
ns['_r13_route_places']=ns['r13_places'];extract('room13_route_knowledge.rpy',{'r13_places','r13_secret_route_available'})
extract('room13_navigation.rpy',{'R13_MAP_NODES','R13_LOCAL_CONNECTIONS','r13_map_nodes','r13_map_discovered','r13_map_selection','r13_local_connections','r13_local_destination'})
checks=[]
for day in (1,4,8,14):
 for lodging in (False,True):
  for discovered in (False,True):
   for opened in (False,True):
    for case in ('pending','occurred'):
     for current in ('gate','passage','greenhouse','altar'):
      state=dict(day=day,location=current,flags=['lodging'] if lodging else [],evidence=[],case_state=case,passage_open=opened,secret_route_unlocked=discovered)
      ns['store'].room13=state;before=copy.deepcopy(state)
      allowed=set(ns['r13_places']());assert ('guestroom'in allowed)==(lodging and case=='occurred')
      for region in ns['R13_MAP_NODES']:
       visible={k for k,p in ns['r13_map_nodes'](region)}
       assert ('passage'in visible)==(region=='inn' and discovered and opened)
       assert 'greenhouse'not in visible and 'altar'not in visible
       for stale in ('passage','greenhouse','altar','invalid',None):
        selected=ns['r13_map_selection'](region,stale);assert selected in visible or selected is None
      assert before==state
      checks.append([day,lodging,discovered,opened,case,current])
data=json.loads((ROOT/'room13-worldmap-v5.json').read_text());dest={k for k,v in data['layers'].items() if v['node']}
assert dest==set(ns['R13_MAP_NODES']['village'])
assert not any(x in dest for x in ('shrine','quarry_home','quarry_shed'))
assert hashlib.sha256((ROOT/'assets/room13-worldmap-v5.png').read_bytes()).hexdigest()==data['sha256']=='86ef28a4971e244aadca28833414a800f22a03c0f0a82081dea7c4fc5210f4fd'
for k,s in data['layers'].items():
 assert len(s['polygon'])>4
 assert all(0<=x<1672 and 0<=y<941 for x,y in s['polygon'])
labels=[]
for k in dest:
 x,y=data['layers'][k]['label'];x=round(x*860/1672);y=round(y*860/1672);labels.append((k,x-57,y-18,x+57,y+18))
for i,(k,a,b,c,d) in enumerate(labels):
 assert 0<=a<c<=860 and 0<=b<d<=484
 for j,e,f,g,h in labels[i+1:]:assert c<=e or g<=a or d<=f or h<=b,(k,j,'overlapping label boxes')
report=dict(scope='Limited extracted-function contract: base room13_rules.rpy plus route_knowledge; not the complete installed runtime wrapper chain or whole-game state coverage.',status='passed',eligibility_states=len(checks),transparent_polygon_layers=len(data['layers']),travel_nodes=len(dest),label_overlap=False,source_pixels='unchanged original PNG; runtime AlphaMask and SVG clipPath',checks=['Hidden secret current-location saves excluded','Stale selection falls back to visible target or None','Lodging and case-state locks unchanged','Every label inside map and pairwise nonoverlapping','Shrine/quarry/scenery have no destination node'])
Path('v5-contract-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False))
