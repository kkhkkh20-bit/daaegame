"""Read-only acting atlas audit. Pixel hashes reject alias poses; never certify
body acting from a filename, crop rectangle or hash difference alone. Human
silhouette/contact review remains an explicit separate acceptance gate.
"""
import argparse, hashlib, json
from collections import defaultdict
from pathlib import Path
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
EXPRESSIONS=('neutral','thinking','distressed','expressive')
PRIMARY={'daram','dad','granny','seryeon','nabi','bami','doto','buri','karo','neoul','mom','guard'}

def canonical(im):
 bbox=im.getchannel('A').getbbox()
 if not bbox:return None,None
 visible=im.crop(bbox)
 # Invisible RGB noise must not make identical displayed art count as new.
 raw=bytearray(visible.tobytes())
 for i in range(0,len(raw),4):
  if raw[i+3]==0:raw[i:i+3]=b'\0\0\0'
 digest=hashlib.sha256(str(visible.size).encode()+raw).hexdigest()
 return digest,bbox

def run():
 ap=argparse.ArgumentParser();ap.add_argument('--manifest',action='append',type=Path);ap.add_argument('--art-root',type=Path,default=ROOT/'art/pixel-b');ap.add_argument('--out',type=Path,default=ROOT/'qa-room13-0140/acting-inventory.json');ap.add_argument('--require-acting',action='store_true');ap.add_argument('--expected-count',type=int,default=0);ap.add_argument('--directions',type=Path);a=ap.parse_args()
 manifests=a.manifest or [a.art_root/'cast-main.json',a.art_root/'cast-support.json']
 cast={};duplicates=[]
 for manifest in manifests:
  data=json.loads(manifest.read_text());data=data.get('characters',data)
  for person,poses in data.items():
   if person in cast:duplicates.append(person)
   cast.setdefault(person,{}).update(poses)
 cache={};rows={};failures=[];warnings=[]
 def source(spec):
  p=Path(spec['file']);choices=[p,a.art_root/p.name,a.art_root/'acting'/p.name,a.art_root/'acting'/p.name.replace('room13-pixel-acting-','room13-acting-'),ROOT/'game'/p]
  return next((p for p in choices if p.is_file()),choices[1])
 for person,poses in cast.items():
  out={};groups=defaultdict(list)
  for pose,spec in poses.items():
   if not isinstance(spec,dict) or 'crop'not in spec:continue
   path=source(spec)
   if not path.exists():failures.append(f'{person}/{pose}: missing {path}');continue
   if path not in cache:cache[path]=Image.open(path).convert('RGBA')
   im=cache[path];x,y,w,h=spec['crop']
   if not (w>0 and h>0 and 0<=x<x+w<=im.width and 0<=y<y+h<=im.height):failures.append(f'{person}/{pose}: crop outside source');continue
   crop=im.crop((x,y,x+w,y+h));digest,bbox=canonical(crop)
   if not bbox:failures.append(f'{person}/{pose}: empty crop');continue
   alpha=crop.getchannel('A');extrema=alpha.getextrema()
   if extrema[0]!=0:failures.append(f'{person}/{pose}: no transparent margin/background')
   if not pose.startswith('avatar_'):groups[digest].append(pose)
   out[pose]={'sha256':digest,'source':str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path),'crop':[x,y,w,h],'alpha_bbox':list(bbox),'alpha_extrema':list(extrema),'native_visible_size':[bbox[2]-bbox[0],bbox[3]-bbox[1]]}
  expressions={e:out.get(e,{}).get('sha256') for e in EXPRESSIONS};n=len({h for h in expressions.values() if h})
  living={p:v['sha256'] for p,v in out.items() if not p.startswith('avatar_') and (p.startswith('living') or p.startswith(('activity','action_')) or p in ('inn_activity','inspect_floor','work','read','sit','carry','serve'))}
  unique_living=set(living.values())-set(expressions.values())
  rows[person]={'poses':out,'identical_pixel_groups':[v for v in groups.values() if len(v)>1],'distinct_emotion_pixels':n,'unique_living_outside_emotions':len(unique_living),'living_pose_hashes':living,'body_acting_review':'manual review required; pixel differences alone do not prove gesture changes'}
  if n<4:(failures if a.require_acting else warnings).append(f'{person}: only {n}/4 distinct emotion images')
  minimum=2 if person in PRIMARY else 1
  if len(unique_living)<minimum:(failures if a.require_acting else warnings).append(f'{person}: {len(unique_living)}/{minimum} distinct living poses beyond emotions')
 direction_report=None
 if a.directions:
  direction=json.loads(a.directions.read_text());missing=[];unique=set();total=0
  for identity,lines in direction.items():
   for index,cue in lines.items():
    who=cue['person'];pose=cue['pose'];total+=1;unique.add((who,cue.get('text'),pose))
    if who not in cast or pose not in cast[who]:missing.append({'identity':identity,'line':index,'person':who,'pose':pose})
  direction_report={'identities':len(direction),'line_cues':total,'unique_person_text_pose':len(unique),'missing_pose_references':missing}
  if missing:failures.append(f'{len(missing)} line cues refer to missing authored poses')
 if a.expected_count and len(rows)!=a.expected_count:failures.append(f'Expected {a.expected_count} identities, got {len(rows)}')
 report={'kind':'read-only-pixel-alias-and-crop-audit-not-body-performance-approval','status':'failed'if failures else'needs-review'if warnings else'passed','identities':len(rows),'direction_audit':direction_report,'characters':rows,'failures':failures,'warnings':warnings,'merged_manifest_identities':duplicates,'manual_gates':['All 43 identities have four visibly distinct BODY gestures, not only eyes/mouth','12 primary identities have at least two authored living actions; 31 supporting identities have at least one','Crouching thoughtful pilot is inspect_floor, not dialogue thinking','Family silhouettes/species/palette distinct from Doto; left-facing and subdued worry available','Furniture contact and occlusion verified in actual desktop/mobile renderer','Contact animations do not oscillate hands/feet away from anchors']}
 a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k!='characters'},ensure_ascii=False))
 return bool(failures)
if __name__=='__main__':raise SystemExit(run())
