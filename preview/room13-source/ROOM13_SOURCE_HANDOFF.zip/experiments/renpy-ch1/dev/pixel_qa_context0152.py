"""Natural entry document/proof/loops and father thoughts, with explicit state fixtures."""
import argparse,asyncio,json,shutil
from playwright.async_api import async_playwright
from pixel_qa_flow0150 import FlowQA,ROOT
MIGRATE='''import renpy,copy,json
s=renpy.store;before=copy.deepcopy(s.room13);who=s.dialogue_speaker;pose=s.r13_current_pose;expr=s.dialogue_expression
bounds=renpy.exports.get_image_bounds('r13_visitor');background=renpy.exports.get_image_bounds('qa_background')
s.room13.pop('interaction_revision',None);s.r13_upgrade();renpy.exports.restart_interaction()
after=copy.deepcopy(s.room13)
for key in ('interaction_revision','last_inspection'):before.pop(key,None);after.pop(key,None)
before=json.loads(json.dumps(before));after=json.loads(json.dumps(after))
assert before==after,('state changed',before,after)
assert s.dialogue_speaker==who and s.dialogue_expression==expr and s.r13_current_pose==pose
result={'kind':'forced-interaction-revision-migration-fixture','state_preserved':True,'speaker':who,'pose':pose,'expression':expr,'bounds_before':bounds,'revision':s.room13.get('interaction_revision')}
'''
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',default='qa-room13-0152/context-final');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True);report={'checks':[]}
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=FlowQA(pg,out);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub')
   # Guard body/face point selected from final candidate picture, not focus-list center.
   await q.input(930,393);await q.wait('r13_entry_topics');await q.value(('entry','explain'));await q.advance();await q.wait('r13_entry_topics');await q.shot('guard-explanation-retains-topics');report['checks'].append('Natural guard explanation returns to same topics')
   await q.value(('entry','wait'));await q.wait('r13_confirm');await q.value(False);await q.wait('r13_entry_topics');await q.value(('entry','argue'));await q.wait('r13_book');await q.press('제시 취소');await q.wait('r13_entry_topics');await q.value(('entry','back'));await q.wait('r13_hub');report['checks'].append('Natural guard wait/present cancellation returns to same topics')
   for obj,x,y in [('booth',1125,380),('rules',390,321),('ledger',1100,427)]:
    await q.input(x,y);await q.wait('say');st=await q.state();assert st['room']['last_inspection']['key']==obj,(obj,st);await q.shot('visible-document-'+obj);await q.advance();await q.wait('r13_hub')
   assert {'G1','G2','G3'}<=set((await q.state())['room']['evidence']);report['checks'].append('Visibly exposed booth/posted-rules/ledger give G1/G2/G3 via actual scene clicks')
   await q.input(930,393);await q.wait('r13_entry_topics');await q.value(('entry','argue'));await q.wait('r13_book');await q.press(await q.py("import renpy;result=renpy.store.ROOM13['evidence']['G1']['name']"));await q.press('보여주기');await q.advance();await q.wait('choice')
   check=await q.py(MIGRATE);await q.wait('choice');check['bounds_after']=await q.py("import renpy;result=renpy.exports.get_image_bounds('r13_visitor')");assert check['bounds_before']==check['bounds_after'];assert check['revision']==2;report['checks'].append(check);await q.shot('migration-natural-proof-choice');await q.press('원본에는 두 명');await q.advance();await q.wait('r13_hub')
   # Natural newly reunited child participates after one explicit spoken bridge.
   await q.input(475,473);await q.wait('say');await q.shot('natural-shovel-dad-thought');speakers=[]
   for i in range(8):
    st=await q.state()
    if 'say'not in st['screens']:break
    row=await q.py("import renpy;s=renpy.store;result={'speaker':s.dialogue_speaker,'thought':s.r13_thought_active,'text':s.r13_packet[1]}");speakers.append(row);await q.shot('shovel-line-'+str(i));await q.input(810,640)
   await q.advance();await q.wait('r13_hub');assert [r['speaker']for r in speakers]==['dad','dad','daram'],speakers;assert [r['thought']for r in speakers]==[True,False,False];report['checks'].append({'natural_companion_lines':speakers})
   # Inject custody only, then repeat the real object input; no child may speak.
   await q.py("import renpy;s=renpy.store;s.room13['daram_state']='held';s.room13['observation_chats']=[];renpy.exports.restart_interaction();result=True");await q.wait('r13_hub');await q.input(475,473);await q.wait('say');await q.shot('fixture-held-child-thought-only');assert await q.py("import renpy;result=[p[0]for p in renpy.store.r13_observed_lines]")==['dad'];await q.advance();await q.wait('r13_hub');report['checks'].append('Explicit held-state fixture + real shovel click: father thought only, no absent child')
   assert not errors,errors;report['status']='passed'
  except Exception as e:report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
  report.update(errors=errors,url=a.url);(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False));await b.close()
  if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
