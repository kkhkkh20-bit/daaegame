"""Fresh run, real UI: first-night deduction and day-two corroboration."""
import asyncio,json,shutil,urllib.request
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_ui0156 import UIQA
from pixel_qa_flow0150 import FLOW_PROBE
OUT=Path('qa-room13-intro-clues');OUT.mkdir(exist_ok=True)
URL='http://127.0.0.1:8094/room13-release-0173/'
class IntroQA(UIQA):
 async def state(self):
  probe=FLOW_PROBE.replace('names=[',"names=['r13_entry_daram_topics','r13_gate_document_inspection','r13_gate_document_read','r13_resident_approach','r13_desk_inspection','r13_record_compare','r13_records','r13_book','r13_backlog',")
  st=await self.py('ns={};exec('+ascii(probe)+',ns);result=ns["result"]');assert '_exception' not in st['screens'],st;return st
 async def advance_to(self,name):
  for _ in range(150):
   st=await self.state()
   if name in st['screens']:await asyncio.sleep(.4);return st
   if 'say' in st['screens']:await self.input(810,610)
   elif 'r13_cinematic_view' in st['screens']:await self.press('계속')
   else:await asyncio.sleep(.2)
  raise AssertionError((name,st))
 async def talk(self,label):
  await self.press(label);await self.advance()
  if 'r13_resident_approach' in (await self.state())['screens']:
   await self.value(True)
  await self.advance_to('r13_topics')
 async def value(self,value):
  for attempt in range(10):
   try:return await super().value(value)
   except AssertionError:
    if attempt==9:raise
    await asyncio.sleep(.3)
 async def present(self,label):
  await self.press('보여주기');await self.wait('r13_book');await self.press('들은 말' if label=='초롱의 목격담' else '증거');await self.press(label);await self.press('보여주기');await self.wait('r13_confirm');await self.press('보여준다');await self.advance_to('r13_topics')
async def main():
 report={'archive_sha256':json.load(urllib.request.urlopen(URL+'game-transport.json'))['archive_sha256'],'checks':[]}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader'])
  context=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='allow');pg=await context.new_page();q=IntroQA(pg,OUT)
  try:
   await pg.goto(URL);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu')
   await q.py('import renpy;s=renpy.store;s.preferences.text_cps=0;s.preferences.afm_enable=False;result=True')
   captured=json.loads((OUT/'postal-captured-state.json').read_text())['room']
   await q.py('import renpy;s=renpy.store;s.room13='+repr(captured)+';s.room13_mode=True;s.winter_mode=True;s.winter=s.winter_new();s.source_mode=False;s.typing_allowed=True;s.r13_scene_key=None;s.r13_world_cameras={};result=True')
   await q.py('import renpy\ns=renpy.store\nfor f in renpy.display.focus.focus_list:\n w=f.widget\n if isinstance(getattr(w,"action",None),s.Start):\n  w.action=s.Start("r13_roam");w.clicked=w.action\nresult=True')
   await q.press('처음부터');await q.wait('r13_hub');assert (await q.room())['location']=='post'
   report['mode']='Natural first day through lamplighter; postal/record continuation from captured world state in isolated browser'
   report['checks']=json.loads((OUT/'natural-before-qa-label-correction.json').read_text())['checks']
   await q.talk('세련');await q.present('초롱의 목격담');assert 'J03' not in (await q.room())['evidence']
   await q.present('초대 편지');assert not await q.py('import renpy;result=any(k=="intro:post_visit" for k,s in renpy.store.r13_topics("seryeon"))')
   await q.present('엄마의 메모');assert await q.py('import renpy;result=any(k=="intro:post_visit" for k,s in renpy.store.r13_topics("seryeon"))')
   await q.value('intro:post_visit');await q.wait('say');assert 'J03' not in (await q.room())['evidence'];await q.advance_to('r13_topics');assert 'J03' in (await q.room())['evidence'];await q.shot('04-corroborated-visit');await q.press('돌아가기');await q.wait('r13_hub')
   report['checks'].append('Captured-state continuation: postal followup requires both owned family records and read conversation; testimony acquisition and save/load checked')
   assert (await q.room())['day']==2 and (await q.room())['period']==0
   await q.save(2);saved=await q.room();await q.load(2);assert await q.room()==saved
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.press('기록');await q.wait('r13_records');await q.shot('05-mobile-records');report['checks'].append('Investigation/presentation does not consume work slots; save/load preserves clues; mobile records render')
   report['status']='passed'
  except Exception as e:
   report.update(status='failed',error=repr(e));await pg.screenshot(path=str(OUT/'failure.png'))
   try:(OUT/'postal-captured-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
   except:pass
   try:
    details=await q.py('import renpy;sc=renpy.display.screen.get_screen("r13_resident_approach");result={k:repr(sc.scope.get(k)) for k in ("ready","choices","person","target","_scope","_use_scope")} if sc else {}')
    (OUT/"failure-scope.json").write_text(json.dumps(details,ensure_ascii=False,indent=2))
   except:pass
  (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']=='failed':raise SystemExit(1)
asyncio.run(main())
