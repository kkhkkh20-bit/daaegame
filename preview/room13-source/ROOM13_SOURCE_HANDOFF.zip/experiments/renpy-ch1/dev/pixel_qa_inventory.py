"""Read-only coverage/packaging audit for the B-pixel Room13 campaign.
A renamed image or nearest-neighbour flag is never treated as proof of pixel art.
The source digest comparison catches copied painted originals; visual acceptance
is recorded separately in pixel_qa_browser's fixture screenshots.
"""
import argparse, hashlib, json, zipfile
from pathlib import Path
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--build',type=Path);ap.add_argument('--out',type=Path,default=ROOT/'qa-room13-0130/inventory.json');a=ap.parse_args();pixel=ROOT/'art/pixel-b';report={'kind':'static-coverage-and-packaging-not-visual-approval','checks':[]}
 def check(label,value):
  report['checks'].append({'name':label,'passed':bool(value)});assert value,label
 try:
  layouts=json.loads((pixel/'layouts.json').read_text());main=json.loads((pixel/'cast-main.json').read_text());support=json.loads((pixel/'cast-support.json').read_text());cast=main|support;cg=json.loads((pixel/'cinematics.json').read_text())['items']
  oldlayouts=json.loads((ROOT/'art/room13-painted-layouts.json').read_text());oldcast=json.loads((ROOT/'art/room13-painted-cast.json').read_text());oldcg=json.loads((ROOT/'art/room13-cinematics.json').read_text())['items']
  check('all background atlas names covered',set(layouts)=={x.replace('painted','pixel') for x in oldlayouts});check('all cast identities covered without collisions',set(cast)==set(oldcast) and not set(main)&set(support));check('all cinematic IDs covered',{x['id'] for x in cg}=={x['id'] for x in oldcg})
  motion=json.loads((pixel/'motion.json').read_text())
  names={Path(motion['file']).name}|set(layouts)|{Path(x['file']).name for p in cast.values() for x in p.values()}|{Path(x['file']).name for x in cg}
  painted_hashes={hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'art').glob('room13-painted-*.png')}
  for name in sorted(names):
   p=pixel/name;check('immutable pixel source exists '+name,p.is_file());check('not merely a renamed painted image '+name,hashlib.sha256(p.read_bytes()).hexdigest() not in painted_hashes)
  motion_image=Image.open(pixel/Path(motion['file']).name)
  check('independent tail sheet transparent',motion_image.mode=='RGBA' and motion_image.getchannel('A').getextrema()[0]==0)
  check('four motion states',all(x in motion['poses'] for x in ('neutral','thinking','distressed','expressive')))
  for pose,spec in motion['poses'].items():
   for layer in ('body','tail'):
    x,y,w,h=spec[layer];check('motion crop inside atlas '+pose+'/'+layer,0<=x<x+w<=motion_image.width and 0<=y<y+h<=motion_image.height)
  crop_rows=[]
  for person,poses in cast.items():
   for pose,spec in poses.items():
    im=Image.open(pixel/Path(spec['file']).name);x,y,w,h=spec['crop'];check('crop inside atlas '+person+'/'+pose,0<=x<x+w<=im.width and 0<=y<y+h<=im.height)
   check('four facial states '+person,all(e in poses and 'avatar_'+e in poses for e in ('neutral','thinking','distressed','expressive')))
   sheet=Image.open(pixel/Path(poses['neutral']['file']).name)
   check('transparent cast sheet '+person,sheet.mode=='RGBA' and sheet.getchannel('A').getextrema()[0]==0)
  evidence=json.loads((ROOT/'game/room13-content.json').read_text());crop_evidence={k for v in layouts.values() for k in v.get('evidence',{})};sources=evidence['evidence_sources'];fallback=[k for k in evidence['evidence'] if k not in sources and k not in crop_evidence]
  report['expression_variants']={person:len({(poses[e]['file'],tuple(poses[e]['crop'])) for e in ('neutral','thinking','distressed','expressive')}) for person,poses in cast.items()}
  report.update(counts={'background_files':len(layouts),'cast_identities':len(cast),'cast_files':len({x['file'] for p in cast.values() for x in p.values()}),'cinematic_panels':len(cg),'cinematic_files':len({x['file'] for x in cg}),'unique_active_files':len(names)},evidence={'testimony_avatars':sources,'background_detail_crops':sorted(crop_evidence),'generic_pixel_icons':fallback})
  if a.build:
   archive=a.build/'game.zip'
   if not archive.exists():archive=a.build.with_name(a.build.name+'-full-game.zip')
   with zipfile.ZipFile(archive) as z:
    zipped=set(z.namelist());required={'game/assets/'+x for x in names};check('every active original bundled',required<=zipped);check('no active progressive placeholder',not {'_placeholders/'+x for x in required}&zipped)
    castdata=json.loads(z.read('game/assets/cast.json'));check('runtime cast only pixel filenames',all('room13-pixel-' in x['file'] for p in castdata.values() for x in p.values()))
   report['archive_bytes']=archive.stat().st_size
   transport=json.loads((a.build/'game-transport.json').read_text());rebuilt=hashlib.sha256()
   for part in transport['parts']:
    data=(a.build/part['file']).read_bytes();check('GitHub transport part size '+part['file'],len(data)==part['bytes'] and len(data)<100*1024*1024);check('transport part digest '+part['file'],hashlib.sha256(data).hexdigest()==part['sha256']);rebuilt.update(data)
   check('concatenated transport is identical complete archive',rebuilt.hexdigest()==transport['archive_sha256']==hashlib.sha256(archive.read_bytes()).hexdigest())
   report['transport']=transport
  report['status']='passed'
 except Exception as e:report.update(status='failed',error=repr(e))
 a.out.parent.mkdir(parents=True,exist_ok=True);a.out.write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ('checks','evidence')},ensure_ascii=False))
 if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':main()
