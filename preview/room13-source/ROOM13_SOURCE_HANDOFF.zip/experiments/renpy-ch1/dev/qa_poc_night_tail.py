"""Continue only the earned day3 state captured by the natural run, same archive."""
import asyncio,json,shutil,urllib.request
from playwright.async_api import async_playwright
from qa_poc_three_days import Q,OUT,URL
async def main():
 report=json.loads((OUT/'report.json').read_text());checkpoint=json.loads((OUT/'failure-state.json').read_text());room=checkpoint['room'];sha=json.load(urllib.request.urlopen(URL+'game-transport.json'))['archive_sha256'];assert report['archive_sha256']==sha and report['stage']=='day3-night';assert room['day']==3 and room['period']==2 and room['livelihood']['cash']==23 and room['livelihood']['debt']==0 and 'J06' in room['evidence'] and 'poc:letter_conflict' in room['flags']
 report['continuation']={'reason':'QA requested a repayment control correctly hidden when debt is zero','earned_state':'day3-night-checkpoint.json','same_archive':True};(OUT/'day3-night-checkpoint.json').write_text(json.dumps(checkpoint,ensure_ascii=False,indent=2));report['mode']='natural first-day to day3 question; remaining night/save resumed from captured earned state in identical archive'
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=Q(pg,OUT);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  try:
   await pg.goto(URL);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;s=renpy.store;s.preferences.text_cps=0;s.preferences.afm_enable=False;s.room13='+repr(room)+';s.room13_mode=True;s.winter_mode=True;s.winter=s.winter_new();s.source_mode=False;s.typing_allowed=True;s.r13_scene_key=None;s.r13_world_cameras={};result=True')
   await q.py('import renpy\ns=renpy.store\nfor f in renpy.display.focus.focus_list:\n w=f.widget\n if isinstance(getattr(w,"action",None),s.Start):\n  w.action=s.Start("r13_roam");w.clicked=w.action\nresult=True');await q.press('처음부터');await q.wait('r13_hub')
   await q.travel('13호실',region='inn');await q.sleep();s=await q.room();assert s['day']==4 and s['period']==0 and s['livelihood']['cash']==13 and s['livelihood']['debt']==0 and 'poc:night:3' in s['flags'];report['checks'].append('Day3: real combined delivery14 and kitchen6, free read-before-acquire warning, owned-letter comparison, explicit Granny question records her explanation; captured earned state resumes real room night/sleep, lodging leaves13')
   await q.save(3);saved=await q.room();await q.load(3);assert await q.room()==saved;await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.py('import renpy;renpy.store.persistent.room13_large_text=True;renpy.exports.restart_interaction();result=True');await q.press('기록');await q.wait('r13_records');await q.shot('05-mobile-three-day-records');report['checks'].append('Exact save/load after day3 night; mobile 844x390 large-text records');assert not errors;report.update(status='passed-pending-visual-review',stage='complete',page_errors=errors);report.pop('error',None);report.pop('traceback',None)
  except Exception as e:
   import traceback
   report.update(status='failed',error=repr(e),traceback=traceback.format_exc());await pg.screenshot(path=str(OUT/'tail-failure.png'))
  (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']=='failed':raise SystemExit(1)
asyncio.run(main())
