"""Natural gate and approach; explicitly staged day-two/later learning UI fixtures."""
import asyncio,ast,json,shutil,urllib.request,sys
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_ui0156 import UIQA
from pixel_qa_flow0150 import FLOW_PROBE
OUT=Path('qa-room13-learning');OUT.mkdir(exist_ok=True)
URL='http://127.0.0.1:8094/room13-release-0173/'
class Q(UIQA):
 async def state(self):
  names=['r13_learning_notes','r13_work_board','r13_entry_daram_topics','r13_gate_document_inspection','r13_gate_document_read','r13_record_compare','r13_book','r13_records','r13_resident_approach','r13_desk_inspection']
  probe=FLOW_PROBE.replace('names=[','names='+repr(names)[:-1]+',')
  st=await self.py('ns={};exec('+ascii(probe)+',ns);result=ns["result"]');assert '_exception' not in st['screens'],st;return st
 async def advance_to(self,name):
  for _ in range(180):
   st=await self.state()
   if name in st['screens']:await asyncio.sleep(.35);return st
   if 'say' in st['screens']:await self.input(810,610)
   elif 'r13_cinematic_view' in st['screens']:await self.press('계속')
   else:await asyncio.sleep(.15)
  raise AssertionError((name,st))
 async def value(self,value):
  for i in range(8):
   try:return await super().value(value)
   except AssertionError:
    if i==7:raise
    await asyncio.sleep(.25)
 async def pan(self,start,end):
  await self.p.mouse.move(start,628);await self.p.mouse.down();await self.p.mouse.move(end,628,steps=16);await self.p.mouse.up();await asyncio.sleep(.35)
 async def object(self,key):
  rect=await self.py('import renpy;s=renpy.store;result=s.ROOM13["objects"][s.room13["location"]]['+repr(key)+']["rect"]');offset=(await self.camera())['offset'];x,y,w,h=rect
  assert 0<x+w/2-offset<1280,(key,rect,offset);await self.input(x+w/2-offset,y+h/2)
 async def labels(self):return [b['text'].strip() for b in (await self.state())['buttons']]
async def main():
 report={'archive_sha256':json.load(urllib.request.urlopen(URL+'game-transport.json'))['archive_sha256'],'mode':'natural gate and granny approach; explicitly staged day-two and later UI states','checks':[]}
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader'])
  context=await browser.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await context.new_page();q=Q(pg,OUT);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  try:
   await pg.goto(URL);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu')
   await q.py('import renpy;s=renpy.store;s.preferences.text_cps=0;s.preferences.afm_enable=False;result=True')
   if '--continuation' in sys.argv:
    fixture=json.loads((OUT/'day2-fixture.json').read_text())['room']
    await q.py('import renpy;s=renpy.store;s.room13='+repr(fixture)+';s.room13_mode=True;s.winter_mode=True;s.winter=s.winter_new();s.source_mode=False;s.typing_allowed=True;s.r13_scene_key=None;s.r13_world_cameras={};result=True')
    await q.py('import renpy\ns=renpy.store\nfor f in renpy.display.focus.focus_list:\n w=f.widget\n if isinstance(getattr(w,"action",None),s.Start):\n  w.action=s.Start("r13_roam");w.clicked=w.action\nresult=True')
    await q.press('처음부터');await q.wait('r13_hub')
    report['checks']=json.loads((OUT/'natural-report.json').read_text())['checks']
    report['natural_archive_sha256']=json.loads((OUT/'natural-report.json').read_text())['archive_sha256']
   else:
    await q.press('처음부터');await q.advance_to('r13_hub');s=await q.room();assert 'entry_corrected' not in s['flags'] and s['learning_archive']==[]
    await q.press('기록');await q.wait('r13_records');assert '찾은 것' in await q.labels() and '지난 플레이' not in await q.labels()
    await q.press('조사 메모');await q.wait('r13_learning_notes');assert '알게 된 세계' not in await q.labels();await q.shot('01-natural-gate-question');await q.press('닫기');await q.wait('r13_records');await q.press('닫기');await q.wait('r13_hub')
    await q.value(('person','daram'));await q.advance_to('r13_entry_daram_topics');await q.value('look');await q.advance_to('r13_entry_daram_topics');await q.shot('02-natural-daram-questions');await q.press('돌아가기');await q.wait('r13_hub')
    await q.pan(1100,350);await q.object('gate_documents');await q.wait('r13_gate_document_inspection')
    for title in ('예약 원본','옮겨 쓴 이름 목록'):
     await q.press(title);await q.wait('r13_gate_document_read');await q.press('확인');await q.wait('r13_gate_document_inspection')
    await q.press('현장으로 돌아가기');await q.wait('r13_hub');await q.pan(250,1100)
    await q.value(('person','daram'));await q.advance_to('r13_entry_daram_topics');await q.value('compare');await q.advance_to('r13_record_compare');await q.press('예약 원본');await q.press('옮겨 쓴 목록');await q.press('비교하기');assert 'gate_documents_compared' in (await q.room())['flags'];await q.press('기록으로 돌아가기');await q.wait('r13_entry_daram_topics');await q.press('돌아가기');await q.wait('r13_hub')
    await q.press('돌목');await q.wait('r13_entry_topics');await q.press('보여주기');await q.wait('r13_book');assert '찾은 것' in await q.labels();await q.press('예약 원본');await q.press('보여주기');await q.advance_to('r13_hub');assert 'entry_corrected' in (await q.room())['flags'] and (await q.room())['location']=='gate'
    report['checks'].append('Natural original gate: Daram questions, individual document reading, comparison and presentation; new record category; no automatic travel')
    await q.travel('광장');await q.travel('여관 접수대');before=await q.room();await q.press('할머니');await q.advance_to('r13_resident_approach');await q.shot('03-natural-role-approach');await q.value(False);await q.wait('r13_hub');assert await q.room()==before
    report['checks'].append('Natural resident notice and centered role caption; decline preserves full state')
   # Clearly labelled UI fixture: no claim of naturally reaching these states.
   await q.py('import renpy;s=renpy.store;s.r13_edit(day=2,period=0,flags=s.room13["flags"]+["lodging","livelihood_open"],evidence=s.room13["evidence"]+["M01","E03"],livelihood={});renpy.exports.restart_interaction();result=True')
   await q.travel('13호실');before=await q.room();await q.press('자기');await q.wait('r13_confirm');await q.shot('04-day2-sleep-debt-preview');await q.press('아직 할 일이');await q.wait('r13_hub');assert await q.room()==before
   await q.press('일거리 · 상점');await q.wait('r13_work_board');before=await q.room();await q.shot('05-day2-work-money-preview');await q.press('여관 식사 준비');await q.wait('r13_confirm');await q.press('돌아가기');await q.wait('r13_hub');assert await q.room()==before
   await q.press('일거리 · 상점');await q.wait('r13_work_board');await q.press('여관 식사 준비');await q.wait('r13_confirm');await q.press('시작하기');await q.advance_to('choice');await q.press('따로 놓인 그릇');await q.advance_to('r13_hub');s=await q.room();assert s['period']==1 and s['livelihood']['cash']==4 and 'life:nabi_helped' in s['flags'] and 'J01' not in s['evidence']
   await q.press('일거리 · 상점');await q.wait('r13_work_board');await q.shot('06-work-followup-readable');await q.press('돌아가기');await q.wait('r13_hub')
   report['checks'].append('Staged day two: cancel sleep/work leaves state intact; actual kitchen choice pays 4, advances one period, opens question without granting testimony; money preview does not mutate settlement')
   # Late owned-evidence fixture verifies optional descriptions and permission.
   await q.py('import renpy;s=renpy.store;s.r13_edit(evidence=s.room13["evidence"]+["E23","E10"],flags=s.room13["flags"]+["bami_protected"]);result=True')
   await q.press('기록');await q.wait('r13_records');before=await q.room();await q.press('조사 메모');await q.wait('r13_learning_notes');await q.press('알게 된 세계');await q.shot('07-owned-world-note');assert await q.room()==before
   rows=await q.py('import renpy;result=[n["title"] for n in renpy.store.r13_learning_terms()]');assert rows==['힘을 옮긴다는 것'],rows
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.py('import renpy;renpy.store.persistent.room13_large_text=True;renpy.exports.restart_interaction();result=True');await q.shot('08-mobile-large-world-note');await q.press('닫기');await q.wait('r13_records');await q.shot('09-mobile-large-records');await q.press('닫기');await q.wait('r13_hub')
   await pg.set_viewport_size({'width':1280,'height':720});q.touch=False;await q.py('import renpy;renpy.store.persistent.room13_large_text=False;renpy.exports.restart_interaction();result=True')
   await q.save(4);saved=await q.room();await q.load(4);assert await q.room()==saved
   report['checks'].append('Staged later evidence: only owned term appears; note open read-only; mobile large-font notes/records render; real save/load preserves archive snapshot and livelihood')
   assert not errors,errors;report['status']='passed-pending-visual-review'
  except Exception as e:
   report.update(status='failed',error=repr(e));import traceback;report['traceback']=traceback.format_exc();await pg.screenshot(path=str(OUT/'failure.png'))
   try:(OUT/'failure-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
   except:pass
  report['page_errors']=errors;(OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await browser.close()
  if report['status']=='failed':raise SystemExit(1)
asyncio.run(main())
