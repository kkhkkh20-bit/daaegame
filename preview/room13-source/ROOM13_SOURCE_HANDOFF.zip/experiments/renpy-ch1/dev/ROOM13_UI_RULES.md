# Room13 UI rules

- Default field is investigation. Select a visible person to talk. The same people remain when entrance permission changes without time passing.
- Four actions: 조사 (return to field), 제시 (current partner only), 기록 (evidence/testimony/people/history), 옵션 (save/load/settings). Map and adjacent destinations stay at upper right. Right-click does not open options.
- Finish the active line/choice before investigation or presentation; reading records and options never jumps out of the dialogue call stack.
- Acquired evidence appears with its icon/name and a short sound. Reinspection does not award or announce a duplicate. Everyday observations do not pretend to award evidence.
- One physical bundle has one field target; its contents are examined in a close-up. Evidence and testimony share two-row icon pagination with an explicit category, detail, acquisition source and current-run ownership.
- Proof limitations remain in story/rules, not repetitive UI disclaimers. Do not expose future evidence, meeting times or mystery answers.
- Questions use spoken Korean, opaque-enough dark scrim, centered text, clear strikethrough/dimming when read; rereading remains available.
- Father is the player viewpoint: no normal dialogue/thought avatar. Inner thoughts use blue parentheses. Other portraits stay within a fixed left panel; cinematic art is preserved.
- Arrival cards use actual story day, weekday, period and canonical location. No invented calendar date or minute precision.

## Typography

Common definitions: game/room13_typography.rpy. Body uses real Galmuri11 Regular. Current pixel family has no bundled Light/Medium/Black; keep Regular rather than synthesize weights. The existing title font is a real Bold. Italic requires asking the user.

Small Korean secondary text stays Regular with sufficient contrast. Emphasis colors have semantic roles (person, place, evidence, testimony, thought); no arbitrary rainbow hints. Dark and paper backgrounds have separate foreground tokens.

Container padding roles: button/row=(18,12), compact=(12,8), panel=(24,20), name=(16,8). Values are horizontal, vertical logical pixels at 1280×720. Update shared roles globally. Fixed hitboxes and no-padding artwork containers are geometry exceptions. Check mobile landscape wrapping and touch areas after changing sizes.
