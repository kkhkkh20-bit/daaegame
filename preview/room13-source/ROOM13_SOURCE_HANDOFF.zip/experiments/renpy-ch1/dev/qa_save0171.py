"""Save review/deletion UI tested on generated slots in a disposable browser only."""
import asyncio,json,shutil
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_ui0156 import UIQA
from pixel_qa_flow0150 import FLOW_PROBE
OUT=Path('/workspace/room13-review/save0171');OUT.mkdir(exist_ok=True)
class Q(UIQA):
 async def state(self):
  probe=FLOW_PROBE.replace('names=[',"names=['r13_save_cleanup','r13_save_review',")
  s=await self.py('ns={};exec('+ascii(probe)+',ns);result=ns["result"]');assert '_exception' not in s['screens'],s;return s
async def main():
 report={'kind':'Synthetic save metadata fixtures in a fresh disposable browser; no user browser data accessed','checks':[]}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=Q(pg,OUT)
  try:
   await pg.goto('http://127.0.0.1:8094/room13-dev/');await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub')
   await q.save(1)
   await q.py('import renpy;s=renpy.store;callbacks=list(s.config.save_json_callbacks);s.config.save_json_callbacks=[];renpy.exports.save("2-1");renpy.exports.save("auto-1");renpy.exports.save("quick-1");s.config.save_json_callbacks=callbacks;result=True')
   kept=await q.py('import renpy;s=renpy.store;result={"read":list(s.persistent.room13_read),"knowledge":list(s.persistent.room13_knowledge),"endings":list(s.persistent.room13_endings),"large":s.persistent.room13_large_text}')
   assert await q.py('import renpy;result=renpy.store.r13_continue_slot()')=='1-1'
   await q.press('옵션');await q.wait('pause_menu');await q.press('불러오기');await q.wait('load');await q.shot('01-versioned-load')
   await q.press('최근 자동저장');await q.wait('r13_save_review');await q.shot('02-old-save-warning');await q.press('돌아가기');await q.wait('load')
   await q.press('이전 저장 정리');await q.wait('r13_save_cleanup');await q.shot('03-exact-delete-scope')
   before=await q.py('import renpy;result=renpy.store.r13_save_slots()');await q.press('취소');assert before==await q.py('import renpy;result=renpy.store.r13_save_slots()')
   await q.press('이전 저장 정리');await q.wait('r13_save_cleanup');await q.press('위 진행 저장 삭제');await q.wait('load')
   after=await q.py('import renpy;result=renpy.store.r13_save_slots()');assert '1-1' in after and all(s not in after for s in ('2-1','auto-1','quick-1')),after
   assert kept==await q.py('import renpy;s=renpy.store;result={"read":list(s.persistent.room13_read),"knowledge":list(s.persistent.room13_knowledge),"endings":list(s.persistent.room13_endings),"large":s.persistent.room13_large_text}')
   report['checks'].append('Unknown manual/auto/quick saves excluded from Continue; old load warning; cancellation deletes nothing; explicit old-save deletion preserves compatible slot and all persistent records/settings')
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.press('모든 진행 저장 정리');await q.wait('r13_save_cleanup');await q.shot('04-mobile-cleanup');await q.press('취소');assert '1-1' in await q.py('import renpy;result=renpy.store.r13_save_slots()')
   report['status']='passed'
  except Exception as e:
   report.update(status='failed',error=repr(e));await pg.screenshot(path=str(OUT/'failure.png'))
   try:(OUT/'failure-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
   except:pass
  (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False),flush=True);await b.close()
  if report['status']=='failed':raise SystemExit(1)
asyncio.run(main())
