"""Natural spatial navigation and camera input checks for 0.15.3."""
import argparse,asyncio,json,shutil,urllib.request
from playwright.async_api import async_playwright
from pixel_qa_flow0150 import FlowQA,ROOT
class SpatialQA(FlowQA):
 async def camera(self):return await self.py("import renpy;s=renpy.store;sc=renpy.display.screen.get_screen('r13_hub');result={'location':s.room13['location'],'offset':s.r13_world_offset(),'width':s.r13_world_width(),'cameras':s.r13_world_cameras,'adjustment':sc.scope['world_adjustment'].value if sc else None}")
 async def pan(self,direction):
  glyph='›' if direction>0 else '‹';st=await self.state();rows=[b for b in st['buttons']if b['text'].strip()==glyph];assert len(rows)==1,(glyph,rows)
  x,y,w,h=rows[0]['rect'];await self.input(x+w/2,y+h/2)
 async def drag(self,start,end):
  vp=self.p.viewport_size;scale=min(vp['width']/1280,vp['height']/720);ox=(vp['width']-1280*scale)/2;oy=(vp['height']-720*scale)/2
  if self.touch:
   cdp=await self.p.context.new_cdp_session(self.p)
   await cdp.send('Input.dispatchTouchEvent',{'type':'touchStart','touchPoints':[{'x':ox+start[0]*scale,'y':oy+start[1]*scale}]})
   for i in range(1,21):
    x=start[0]+(end[0]-start[0])*i/20;y=start[1]+(end[1]-start[1])*i/20
    await cdp.send('Input.dispatchTouchEvent',{'type':'touchMove','touchPoints':[{'x':ox+x*scale,'y':oy+y*scale}]});await asyncio.sleep(.015)
   await cdp.send('Input.dispatchTouchEvent',{'type':'touchEnd','touchPoints':[]});await cdp.detach()
  else:
   await self.p.mouse.move(ox+start[0]*scale,oy+start[1]*scale);await self.p.mouse.down();await self.p.mouse.move(ox+end[0]*scale,oy+end[1]*scale,steps=20);await self.p.mouse.up()
  await asyncio.sleep(.5)
 async def save_camera(self):
  await self.pan(-1);old=await self.camera();assert old['offset']==160,old;before=(await self.state())['room'];await self.press('옵션');await self.wait('pause_menu');await self.press('저장');await self.wait('save');await self.press('슬롯 3');await self.press('돌아가기');st=await self.state()
  if 'pause_menu'in st['screens']:await self.press('돌아가기')
  await self.wait('r13_hub');await self.pan(-1);await asyncio.sleep(.5);await self.press('옵션');await self.wait('pause_menu');await self.press('불러오기');await self.wait('load');await self.press('슬롯 3');await self.wait('r13_hub');new=await self.camera();assert new['offset']==old['offset'],(old,new);assert (await self.state())['room']==before;return {'saved':old,'loaded':new}
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',default='qa-room13-0153/navigation-final');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True);report={'kind':'natural-entry-wait-and-inn-navigation-camera','checks':[]}
 report['archive_sha256']=json.load(urllib.request.urlopen(a.url+'game-transport.json'))['archive_sha256']
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=SpatialQA(pg,out);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub');await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.shot('00-mobile-entry-window');await q.input(1069,384);await q.wait('say');assert await q.py("import renpy;result=renpy.store.dialogue_speaker")=='daram';await q.shot('00b-mobile-window-daram-dialogue');await q.advance();await q.wait('r13_hub');await pg.set_viewport_size({'width':1280,'height':720});q.touch=False;await q.value(('person','guard'));await q.wait('r13_entry_topics');await q.value(('entry','wait'));await q.wait('r13_confirm');await q.value(True);await q.advance();await q.wait('r13_hub');await q.travel('여관 접수대');assert(await q.state())['room']['location']=='inn'
   before=(await q.state())['room'];await q.press('지도 · 이동');await q.wait('r13_map');region=await q.py("import renpy;result=renpy.display.screen.get_screen('r13_map').scope['region']");assert region=='inn';await q.shot('01-inn-default-interior-map');await q.press('13호실');assert not any('이곳으로 이동'in b['text']for b in(await q.state())['buttons']);await q.press('현장으로 돌아가기');await q.wait('r13_hub');assert(await q.state())['room']==before;report['checks'].append('Natural inn map defaults interior; unregistered room locked; cancel no state change')
   await q.shot('02-inn-initial-camera');await q.pan(-1);await q.pan(-1);start=await q.camera();assert start['width']>1280 and start['offset']==0,start
   before=(await q.state())['room'];hud_before=[r for r in(await q.state())['buttons']if any(t in r['text']for t in('조사','제시','기록','옵션'))]
   await q.pan(1);await q.wait('r13_hub');right=await q.camera();await q.shot('03-inn-camera-right');assert right['offset']>start['offset'];assert(await q.state())['room']==before
   await q.drag((930,535),(430,535));st=await q.state();assert 'r13_hub'in st['screens'],st;assert st['room']==before;after_drag=await q.camera();assert after_drag['offset']>right['offset'],(right,after_drag);await q.shot('04-inn-after-drag');hud_after=[r for r in st['buttons']if any(t in r['text']for t in('조사','제시','기록','옵션'))];assert hud_after==hud_before;report['checks'].append({'camera_initial':start,'right':right,'drag':after_drag,'hud_fixed':True,'drag_no_action':True})
   report['checks'].append({'actual_camera_save_load':await q.save_camera()})
   # Go to the far right/left to find the actual host, retaining the selected field view in dialogue.
   for _ in range(8):await q.pan(1)
   await q.wait('r13_hub');st=await q.state();granny=[r for r in st['buttons']if r['value']=="('person', 'granny')"and 0<r['rect'][0]+r['rect'][2]/2<1280]
   if not granny:
    for _ in range(8):await q.pan(-1)
    await q.wait('r13_hub')
   offset=await q.camera();await q.press('할머니');await q.advance();await q.wait('r13_topics');assert(await q.camera())['offset']==offset['offset'];await q.shot('05-granny-topics-preserve-camera');await q.value('register');await q.advance();await q.wait('r13_topics');await q.value('back');await q.advance();await q.wait('r13_hub');assert'lodging'in(await q.state())['room']['flags']
   await q.value(('travel','dining'));await q.advance();await q.wait('r13_hub');assert(await q.state())['room']['location']=='dining';await q.shot('06-connected-dining');await q.value(('travel','inn'));await q.advance();await q.wait('r13_hub');await q.value(('travel','hall'));await q.advance();await q.wait('r13_hub');await q.value(('travel','room13'));await q.advance();await q.wait('r13_hub');assert not any(r['value']=="('travel', 'passage')"for r in(await q.state())['buttons']);await q.shot('07-room-locked-passage-no-button');await q.value(('travel','hall'));await q.advance();await q.wait('r13_hub');await q.value(('travel','inn'));await q.advance();await q.wait('r13_hub');report['checks'].append('Actual local buttons connect dining/inn/hall/room13, locked passage absent')
   before=(await q.state())['room'];await q.value(('travel','outside'));await q.wait('r13_map');assert await q.py("import renpy;result=renpy.display.screen.get_screen('r13_map').scope['region']")=='village';await q.shot('08-explicit-outside-world-map');await q.press('현장으로 돌아가기');await q.wait('r13_hub');assert(await q.state())['room']==before
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.pan(-1);await q.wait('r13_hub');mobile_before=(await q.state())['room'];await q.drag((930,535),(430,535));assert 'r13_hub'in(await q.state())['screens'];assert(await q.state())['room']==mobile_before;await q.shot('09-mobile-camera-fixed-controls');await q.press('지도 · 이동');await q.wait('r13_map');assert await q.py("import renpy;result=renpy.display.screen.get_screen('r13_map').scope['region']")=='inn';await q.press('여관 밖으로');assert await q.py("import renpy;result=renpy.display.screen.get_screen('r13_map').scope['region']")=='village';await q.shot('10-mobile-explicit-outside');report['checks'].append('Mobile camera arrow and interior→explicit outside map controls')
   assert not errors,errors;report['status']='passed'
  except Exception as e:report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
  report.update(url=a.url,errors=errors);(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False));await b.close()
  if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
