"""Earned first-day room checkpoint + explicitly labelled calendar/story fixtures."""
import asyncio,json,shutil,urllib.request
from pathlib import Path
from playwright.async_api import async_playwright
from qa_poc_three_days import Q,URL
OUT=Path('qa-room13-daram-home');OUT.mkdir(exist_ok=True)
async def main():
 earned=json.loads(Path('qa-room13-poc-three-days/day2-checkpoint.json').read_text())['room'];assert earned['day']==2 and 'lodging' in earned['flags'] and 'M01' in earned['evidence']
 report=dict(status='running',archive_sha256=json.load(urllib.request.urlopen(URL+'game-transport.json'))['archive_sha256'],kind='captured earned room state; real clicks for home dialogue/save, explicit time and branch fixtures',checks=[])
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=Q(pg,OUT);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  async def fixture(state):
   await q.py('import renpy;s=renpy.store;s.room13='+repr(state)+';s.R13_STAGE_CACHE.clear();renpy.exports.restart_interaction();result=True');await asyncio.sleep(.5)
  try:
   await pg.goto(URL);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;s=renpy.store;s.preferences.text_cps=0;s.preferences.afm_enable=False;s.room13='+repr(earned)+';s.room13_mode=True;s.winter_mode=True;s.winter=s.winter_new();s.source_mode=False;s.typing_allowed=True;s.r13_scene_key=None;s.r13_world_cameras={};result=True')
   await q.py('import renpy\ns=renpy.store\nfor f in renpy.display.focus.focus_list:\n w=f.widget\n if isinstance(getattr(w,"action",None),s.Start):\n  w.action=s.Start("r13_roam");w.clicked=w.action\nresult=True');await q.press('처음부터');await q.wait('r13_hub');await q.py('import renpy;renpy.exports.show_screen("r13_hud");result=True')
   for period,name,pose in [(0,'01-bed-reading','action_1'),(1,'02-desk-drawing','action_2'),(2,'03-room-looking','inspect_floor')]:
    state=dict(earned,period=period);await fixture(state);actors=await q.py('import renpy;result=renpy.store.r13_stage_people()');actor=next(a for a in actors if a['person']=='daram');assert actor['pose']==pose and 0<=actor['x'] and actor['y']+actor['height']<=720;await q.shot(name)
   await fixture(earned);before=await q.room();assert not await q.py('import renpy;result=any(k=="intro:direction" for k,t in renpy.store.r13_topics("daram"))');await q.talk('daram');await q.value('home:daram:rest');await q.wait('say');await q.shot('04-daram-home-dialogue');await q.advance_to('r13_topics');assert await q.py('import renpy;result=renpy.store.r13_calendar_topic_seen("home:daram:rest",renpy.store.ROOM13["topics"]["home:daram:rest"])');await q.value('home:daram:mother');await q.advance_to('r13_topics');await q.press('돌아가기');await q.wait('r13_hub');after=await q.room();assert all(after.get(k)==before.get(k) for k in ('day','period','evidence','livelihood','mom_state','case_state'));report['checks'].append('Morning/afternoon/evening Daram placement; actual face/name click opens home questions, reading spends no time/money and awards no clue')
   await q.save(4);saved=await q.room();await q.load(4);assert await q.room()==saved;assert await q.py('import renpy;result=renpy.store.r13_daram_home_seen("home:daram:rest")');report['checks'].append('Home discussion marks and world state survive exact real save/load')
   state=dict(saved,evidence=saved['evidence']+['E18','J04','J05']);await fixture(state);assert not await q.py('import renpy;result=renpy.store.r13_daram_home_seen("home:daram:rest")');await q.talk('daram');await q.value('home:daram:letters');await q.advance_to('r13_topics');await q.shot('05-owned-letter-questions');await q.press('돌아가기');await q.wait('r13_hub');await q.compare(['E01','E18']);assert 'poc:letter_conflict' in (await q.room())['flags'];report['checks'].append('Explicit owned-evidence fixture opens discussion; preserved comparison progress without action instructions; new information refreshes read mark, no quest destination in dialogue')
   for state in [dict(saved,daram_state='held',day=8,case_state='occurred'),dict(saved,day=5,mom_state='intervened'),dict(saved,day=10,mom_state='hidden'),dict(saved,day=10,mom_state='reunited',week2_started=True,daram_state='rescued',case_state='occurred',trial_result='cleared',trial_ended=True)]:
    await fixture(state);keys=await q.py('import renpy;result=[k for k,t in renpy.store.r13_topics("daram")]');actors=await q.py('import renpy;result=[a["person"] for a in renpy.store.r13_stage_people()]')
    if state['daram_state']=='held':assert 'daram' not in actors and not any(k.startswith('home:daram:') for k in keys)
    elif state['mom_state']=='reunited':assert 'home:daram:reunion' in keys and 'home:daram:cold' in keys;assert await q.py('import renpy;result=any("이제 얼굴을 봤으니까" in line for who,line in renpy.store.r13_conversation_topic_lines("home:daram:mother"))')
    else:assert 'home:daram:reunion' not in keys
   report['checks'].append('Explicit branch fixtures: held Daram absent, day5 intervention/day10 hidden mother gives no reunion topic, real reunion state opens it')
   await fixture(saved);await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.py('import renpy;renpy.store.persistent.room13_large_text=True;renpy.exports.restart_interaction();result=True');await q.talk('daram');await q.shot('06-mobile-home-questions');assert not errors;report.update(status='passed-pending-visual-review',page_errors=errors)
  except Exception as e:
   import traceback
   report.update(status='failed',error=repr(e),traceback=traceback.format_exc());await pg.screenshot(path=str(OUT/'failure.png'))
   try:(OUT/'failure-state.json').write_text(json.dumps(await q.state(),ensure_ascii=False,indent=2))
   except:pass
  (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ('error','traceback')},ensure_ascii=False),flush=True);await b.close()
  if report['status']=='failed':raise SystemExit(1)
asyncio.run(main())
