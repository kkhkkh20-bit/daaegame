#!/usr/bin/env python3
import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'qa-room13-acting-gallery';OUT.mkdir(exist_ok=True)
URL='http://localhost:8093/preview/room13-acting/'
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':1440,'height':1100})
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('response',lambda r:errors.append(f'{r.status} {r.url}')if r.status>=400 else None)
  await page.goto(URL,wait_until='networkidle');catalog=await(await page.request.get(URL+'catalog.json')).json()
  result={'coverage':catalog['coverage'],'errors':errors,'people_checked':0,'poses_checked':0}
  for kind in ['main','support']:
   await page.locator(f'[data-kind={kind}]').click()
   for person in [x for x in catalog['people'] if x['kind']==kind]:
    await page.locator('#person').select_option(person['id']);result['people_checked']+=1
    assert await page.locator('#strip .card').count()==len(person['after'])
    assert all('_'not in t for t in await page.locator('#poses button').all_text_contents()),person['id']
    for n in range(len(person['after'])):
     await page.locator('#poses button').nth(n).click();result['poses_checked']+=1
    if person['id'] in ['daram','dad','mom','doto','resident_tori']:
     await page.locator('#comparison').scroll_into_view_if_needed();await page.wait_for_timeout(200)
     await page.screenshot(path=str(OUT/(person['id']+'-desktop.png')))
  await page.locator('#continuity summary').click();await page.wait_for_function('document.querySelectorAll("#scenegrid .scene-pair").length===13')
  result['continuity_panels']=await page.locator('#scenegrid .scene-pair').count()
  await page.locator('#scenegrid .scene-pair').first.scroll_into_view_if_needed();await page.wait_for_timeout(250)
  await page.screenshot(path=str(OUT/'continuity-desktop.png'))
  for source in catalog['sources']:
   response=await page.request.head(URL+source['file']);assert response.status==200,source
  result['source_urls']=len(catalog['sources'])
  result['runtime_screens']=len(catalog.get('runtime',[]))
  for screen in catalog.get('runtime',[]):
   response=await page.request.head(URL+screen['file']);assert response.status==200,screen
  if catalog.get('runtime'):
   await page.locator('#runtime').scroll_into_view_if_needed();await page.wait_for_timeout(250);await page.screenshot(path=str(OUT/'runtime-preview-desktop.png'))
  context=await browser.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
  mobile=await context.new_page();mobile.on('pageerror',lambda e:errors.append(str(e)))
  await mobile.goto(URL,wait_until='networkidle')
  if catalog.get('runtime'):
   await mobile.locator('#runtime').scroll_into_view_if_needed();await mobile.wait_for_timeout(250)
   await mobile.screenshot(path=str(OUT/'runtime-preview-mobile.png'))
   assert await mobile.locator('#runtimegrid img').count()==len(catalog['runtime'])
  await mobile.locator('#poses button').nth(2).tap()
  await mobile.locator('#comparison').scroll_into_view_if_needed();await mobile.wait_for_timeout(150)
  await mobile.screenshot(path=str(OUT/'daram-mobile.png'))
  await mobile.locator('[data-kind=support]').tap()
  result['mobile_support_options']=await mobile.locator('#person option').count()
  if result['mobile_support_options']:
   await mobile.locator('#poses button').last.tap();await mobile.locator('#strip').scroll_into_view_if_needed();await mobile.wait_for_timeout(150)
   await mobile.screenshot(path=str(OUT/'support-mobile.png'))
  result['mobile_overflow']=await mobile.evaluate('document.documentElement.scrollWidth>innerWidth')
  result['broken_images']=await mobile.evaluate('Array.from(document.images).filter(x=>x.complete&&!x.naturalWidth).map(x=>x.src)')
  assert not result['mobile_overflow'];assert not errors;assert not result['broken_images']
  (OUT/'report.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
  await browser.close()
asyncio.run(main())
