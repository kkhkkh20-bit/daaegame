"""Executable story revision: father POV, conditional passage and pooled stone energy.

Applied last so rebuilding cannot reintroduce the archived v1 story's testimony.
The PDF packet remains an explicitly archived draft; runtime content lives here.
"""
def extend(d):
    d.update(schema=3, story_revision='father-pov-fire-pooling-v3')
    # The generated sheet has unequal panel widths. Never assume equal thirds
    # and accidentally show the neighbouring room in the game.
    d['background_atlases']={'inn':[
        [0,0,778,382],[778,0,719,382],[1497,0,551,382],
        [0,382,689,386],[689,382,652,386],[1341,382,707,386]]}
    def evidence(key, name, establishes, limits, kind='기록'):
        old=d['evidence'].get(key,{})
        d['evidence'][key]=dict(old,id=key,name=name,kind=kind,establishes=establishes,
            does_not_establish=limits,current_run_only=True,retained_on_show=True)
    def topic(key,npc,title,lines,**kw):
        d['topics'][key]=dict(npc=npc,title=title,lines=lines,day=[1,7],need=[],flags=[],give=[])
        d['topics'][key].update(kw)
    def action(key,place,title,lines,**kw):
        d['activities'][key]=dict(place=place,title=title,lines=lines,day=[1,6],need=[],flags=[],give=[],cost=1)
        d['activities'][key].update(kw)
    def obj(place,key,rect,text,**kw):
        d['objects'].setdefault(place,{})[key]=dict(rect=rect,text=text,need=[],give=[],flags=[])
        d['objects'][place][key].update(kw)

    evidence('E04','旧도면의 빈 공간과 덧그린 연결선'.replace('旧','옛 '),'주방 잠금 장치와 13호 책장의 개조 연결','종이만으로 현재 통로의 개방이나 이용자를 확인할 수 없음')
    evidence('E05','직접 작동시킨 서비스 통로','주방 해제 후 책장을 조작하면 열리며 세탁실과 연결됨','길을 아는 사람 모두가 그날 사용했다는 뜻은 아님')
    evidence('E06','다람이의 첫 면회 기록','붙잡힌 팔을 촛대로 치고, 촛대가 떨어진 뒤 침대 아래로 숨었다는 진술','진술만으로 사망 원인이나 범인 확정 불가','증언')
    evidence('E07','바닥에서 회수한 촛대 두 부분','낙하로 갈라진 촛대와 윗부분의 날카로운 파단면','형태만으로 사용 순서나 사용자를 알 수 없음','물증')
    evidence('E08','초기 진료·사망 확인서','아이 손목의 압박 자국, 피해자 팔의 부상과 별개의 머리 손상','처음 본 현장만으로 정확한 사망 시각이나 가해자 확정 불가')
    evidence('E09','구조 전후의 촛농과 발자국','낙하 뒤 통로 쪽에서 접근한 자국과 그 위로 겹친 출혈','발자국만으로 신원 특정 불가','관찰기록')
    evidence('E10','밤이가 본 바닥과 침대 아래','촛대가 바닥에서 갈라진 직후 아이가 숨었고 구조 때까지 나오지 않음','첫 타격 순간과 방 위쪽의 공격자는 보지 못함','증언')
    evidence('E11','복도의 구조 순서','비명 뒤 즉시 구조 시도, 공구 도착 뒤 빗장 파손, 그전 정문 통행 없음','실내의 모든 소리를 공격으로 판별하거나 피해자 생존 발언을 확인한 기록이 아님','증언')
    evidence('E12','공구를 가져오던 공백','나비는 첫 비명 때 할머니와 있었지만 주방 이후 동선을 보지 못함','공백만으로 범행이 확인된 것은 아님','증언')
    evidence('E14','촛대 장식부에 끼인 핀','회수 당시 윗부분의 찌그러진 장식 고리에 눌려 있던 금속 조각','누구의 핀이며 언제 고리가 찌그러졌는지 별도 대조가 필요함','물증')
    evidence('E15','첫 비명 때 여민 브로치','나비가 첫 비명 직후 수리된 잠금핀을 직접 여며 줌','그 이후 행적은 관찰하지 못함','증언')
    evidence('E16','사건 전 가족 분리 요청','사건 이전에 할머니가 아이와 보호자의 분리를 요청함','살인 누명을 처음부터 같은 방식으로 계획했다는 증거는 아님')
    evidence('E21','정상 운전에서 소진까지의 기록','오랜 정상 운전 뒤 최근 잔량 하락과 추출 후 짧은 반등이 반복됨','엄마의 존재나 단 한 번의 변동만으로 원인을 단정하지 못함')
    evidence('E23','잔량 이전의 첫 관측','기증석 잔량은 줄고 수용석 출력이 안정됐으며 총량이 증가하지 않음','작은 부하에서의 한 번의 관측','관찰기록')
    evidence('E24','저녁 부하에서의 재관측','잔량을 다시 셌고 더 큰 부하에서 운용 시간과 손실을 기록함','무한 충전이나 모든 집의 난방 복구를 보장하지 않음','관찰기록')
    evidence('E30','엄마의 룬 해독과 이전 장치 연구','고대 기기의 원래 방향과 역추출, 여러 돌의 잔량을 모으는 방법','문헌 해석만으로 실제 운용의 성공과 안전이 입증되지는 않음')
    evidence('E33','흉기 회수·봉인 대장','구조 직후 촛대를 회수한 사람·시점과 이후 보관 경로','회수 이전의 모든 접촉이나 보존하지 못한 바닥 상태를 알려주지는 않음')
    evidence('E35','파단면과 상처의 대조 기록','머리의 치명상은 분리된 윗부분의 안쪽 날과 대응. 옆의 장식 고리는 타격 방향으로 눌렸고 안의 핀도 함께 변형됨','분리 시점·핀의 주인·아이의 위치는 별도 목격과 현장 자료가 필요함')
    evidence('E36','전날 저녁의 진료 요청','할머니가 직접 적은 강한 전조와 혼자 두지 말라는 서리의 회신','위험을 알았다는 자료이며 살인 행위 자체를 증명하지는 않음')
    for c in d['claims']:
        if c['id']=='C1':c['support_sets']=[['E04','E05'],['E05','E37']]
        if c['id']=='C2':
            c.update(assertion='다람이의 촛대 타격이 죽음의 원인이다',
                support_sets=[['E06','E07','E08','E35','E10','E11'],['E06','E07','E08','E35','E09','E33','E13','E14','E15']],
                counter='낙하 뒤 다른 공격이었다는 순서까지 입증했는가')
        if c['id']=='C4':
            c['support_sets']=[['E13','E14','E15','E33','E35','E09','E36','E17'],['E13','E14','E15','E33','E35','E10','E11','E36','E17']]
            c['counter']='흉기에 손댄 것이 구조 중 접촉이었다는 주장'
        if c['id']=='F2':
            c.update(assertion='희생 외에는 돌을 돌릴 방법이 없다',alternative='추출의 한계와 잔량 집약의 독립 재현을 연결',counter='모은 힘도 결국 소진된다는 반론')
    evidence('E37','잠금 장치의 직접 작동 기록','주방 레버와 책장 하단 책을 함께 조작해야 문이 열림','도면 없이 작동을 확인할 수 있지만 범인 특정과는 별개','관찰기록')

    d['topics']['register']['lines']=[['granny','편지는 받으셨죠.'],['dad','아내가 여기 있었다고 하셨습니다.'],['granny','같은 방으로 드릴게요. 이 층 끝, 13호예요.'],['daram','엄마가 잤던 데요?'],['granny','네. 이불도 그대로 두었어요. 먼저 젖은 양말부터 갈아요.'],['dad','언제 떠났는지도 듣고 싶습니다.'],['granny','장부를 찾아둘게요. 두 분 짐부터 놓고 오세요.']]
    d['topics']['nabi_alibi'].update(lines=[['nabi','할머니는 나랑 있었어. 그때 비명이 났고.'],['dad','목도리 핀을 여며 줬다고 했지?'],['nabi','새 핀이 뻑뻑해서 내가 잠갔어. 그다음에 위로 올라갔지.'],['dad','할머니도 같이 올라갔어?'],['nabi','아니. 공구 가져온다고 주방으로 갔어.']])
    d['topics']['nabi_gap'].update(title='새로 열린 이야기 · 공구를 가지러 간 사이',lines=[['dad','너는 문 앞에 있었고, 할머니는 주방으로 갔어. 그 뒤에도 계속 봤어?'],['nabi','아니. 안에서는 애가 기침하는데 그쪽까지 어떻게 봐.'],['dad','도토가 문을 부수던 때는?'],['nabi','그때도 없었어. 나중에 지렛대를 가져왔지. 같이 있던 건 처음 비명 때까지야.']])
    d['topics']['doto_corridor'].update(title='문을 열 때까지',lines=[['doto','비명 듣자마자 밀었어요. 안의 빗장이 버티더군요.'],['dad','아이도 대답했습니까?'],['doto','침대 밑에 있다고요. 나비가 계속 불렀어요. 저는 문틀을 쳤고.'],['dad','할아버지 목소리는요?'],['doto','못 들었습니다. 두드리는 소리와 기침이 겹쳤어요. 방 안 소리까지 전부 안다고 할 수는 없죠.'],['doto','공구가 온 뒤 고정부를 뜯었습니다. 그 전엔 앞문으로 아무도 못 들어갔어요.']])
    d['topics']['bami_saw'].update(title='새로 열린 이야기 · 촛대가 떨어진 뒤',lines=[['bami','쨍 해서 내려다봤어. 바닥에 닿은 촛대가 둘로 갈라졌어.'],['dad','다람이는?'],['bami','바로 기어들어왔어. 손엔 아무것도 없었고.'],['dad','그다음에 나간 적은?'],['bami','없어. 문 열리고 아빠가 부를 때까지. 연기는 위로 올라가고, 쇠살 아래로 손이랑 무릎은 보였어.'],['dad','그 전에 무엇을 때렸는지는?'],['bami','그건 못 봤어. 못 본 것까지 말하진 않을 거야.']])
    d['topics']['buri_records']['lines']=[['buri','전날 저녁엔 많이 심했어요. 나를 알아보지 못할 때도 있었고.'],['dad','누가 같이 있었습니까?'],['buri','할머니가 검사원에게 사람을 보냈어요. 혼자 두지 말라는 답도 받았고요.'],['dad','그런데 다음 날 아이하고 둘만…….'],['buri','아직 그걸 당신이 원하는 이야기로 만들진 마요. 할아버지는 당신 아내 기록을 넘기려고 했어요. 그 사본부터 봐요.']]
    topic('seori_case','resident_seori','그날 남긴 진료 기록',[['resident_seori','처음에는 불부터 끄고 사람을 옮겼습니다. 그 종이는 사망 확인과 눈에 보인 상처를 적은 겁니다.'],['dad','그 뒤에 더 확인한 것은요?'],['resident_seori','촛대를 가져오십시오. 봉인을 연 사람부터 함께 적고, 부상 기록과 대조합시다.']],day=[5,13],case='occurred',flags=['examination_agreed'])
    topic('seori_previous','resident_seori','전날의 진료 요청',[['dad','할머니가 전날에도 연락했다고 들었습니다.'],['resident_seori','손에 힘이 들어가고 가까운 사람을 못 알아본다는 내용이었어요. 급격히 힘이 빠져 쓰러지기도 했다고요.'],['dad','회신은요?'],['resident_seori','혼자 두지 말고 조용한 곳에서 지켜보라고 썼습니다. 할머니가 받았다는 표시도 있고요.'],['dad','아이와 함께 있어도 된다는 말은 없군요.'],['resident_seori','그런 말을 한 적 없습니다.']],day=[5,13],need=['E17'],case='occurred',give=['E36'])
    action('case_compare','clinic','봉인된 촛대와 부상 기록을 함께 대조한다',[
        ['resident_seori','팔에는 둥근 타박이 있습니다. 머리에는 다른 형태의 깊은 손상이 있고요.'],
        ['resident_tok','조립된 상태에서는 이 안쪽 날이 드러나지 않아요. 갈라진 뒤에야 바깥에 나옵니다.'],
        ['resident_seori','머리의 상처는 그 날과 대응합니다. 하지만 언제 갈라졌는지는 제 기록만으로 말할 수 없습니다.'],
        ['resident_tok','여기 고리도 보세요. 핀을 안에 물고 같은 방향으로 눌렸어요. 나중에 조각만 밀어 넣을 틈은 아닙니다.'],
        ['dad','그 순서는 바닥과 목격한 사람에게 확인하겠습니다.'],
        [None,'원래의 봉인을 기록하고 부품을 대조한 뒤 다시 봉인했다. 촛대의 장식 고리에 끼인 핀도 따로 그림으로 남겼다.']],
        need=['E07','E08','examination_agreed'],case='occurred',day=[5,13],give=['E35','E33'])
    d['activities']['map'].update(day=[1,13],lines=[['buri','집 구조는 옛 도면이에요. 붉은 선은 할머니가 고치면서 덧그린 거고.'],[None,'주방 아래의 작은 걸쇠 기호가 13호 책장 하단으로 이어진다. 밖에서 잰 길이와 방 안 길이 사이에도 빈 폭이 있다.'],['buri','도면대로 지금도 열리는지는 직접 봐야죠.']])
    d['activities'].pop('passage',None)
    action('passage_measure','passage','통로의 길이와 출입구를 직접 확인한다',[[None,'세탁실에서 13호까지 오가며 계단과 걸쇠를 확인했다. 걸어 올라오는 데 약 45초. 주방 이후는 식당에서 보이지 않는다.'],['dad','정문을 지킨 사람이 거짓말한 것은 아니군.']],need=['passage_known'],day=[1,13],give=['E05'])
    d['activities']['interview'].update(special='case_interview',lines=[])
    d['activities']['wax']['lines']=[[None,'물과 구조자의 발이 닿지 않았던 벽장 안쪽 바닥을 최초 그림과 대조했다. 쏟아진 촛농을 밟고 방으로 향한 자국 위에 출혈이 겹친다.'],['dad','촛대가 떨어진 뒤 누군가 이쪽에서 나왔다. 자국만으로 누구인지는 아직 몰라.']]
    d['activities']['wax']['need'].append('floor_preserved')
    d['activities']['custody_draft']['lines']=[['seryeon','사건 전에 여관에서 보낸 분리 요청입니다.'],['dad','이미 가족 동행 등록이 끝났는데요.'],['seryeon','요청은 그렇게 왔습니다. 실행된 판결과는 다릅니다.'],[None,'살인 혐의는 적혀 있지 않았다. 가족을 고립시키려는 요청이 먼저였다는 사실만 기록했다.']]
    # Hotspots follow the shared atlas. Hidden book remains available without owning a map.
    obj('inn','desk',[445,415,495,173],'열쇠패에서 13호 자리가 비었다. 지금 우리가 묵는 방의 열쇠다.')
    obj('room13','bed',[835,265,345,170],'이불 안쪽의 붉은 매듭. 집에서 보던 엄마의 바느질과 같다. 지금도 이 방에 있다는 뜻은 아니다.',give=['E03'])
    obj('room13','window',[590,82,195,195],'안쪽 걸쇠와 고정 철망이 있다. 틈은 작은 동물도 통과할 수 없다.')
    obj('room13','under',[865,395,310,80],'침대 아래에는 작은 아이가 웅크릴 공간이 있다. 벽 아래 철망 틈으로 찬 공기가 들어온다.')
    obj('room13','door',[275,90,215,245],'우리 방의 정문이다. 안쪽 빗장은 복도에서 열쇠를 돌려도 풀리지 않는다.')
    obj('room13','books',[1070,155,195,128],'책장 오른쪽 아래의 책 한 권. 등은 닳았는데 책장이 넘어가지 않는다.',special='book_latch')
    obj('room13','floor',[325,343,505,282],'책상 옆 작은 깔개. 촛불은 책상 위에 놓여 있다.')
    obj('room13','boxes',[5,220,220,130],'우리 여행 가방 옆에 빈 나무 상자가 놓였다. 엄마 물건이 있던 자리라고 했다.')
    obj('kitchen','shelf',[580,225,260,300],'찬장 선반 아래 손이 닿는 홈이 있다. 덮개 한쪽만 유난히 닳았다.',special='kitchen_switch')
    obj('kitchen','stove',[1120,305,160,200],'화덕의 불은 장작으로 때고 있다. 돌 관에서 오는 온기는 전보다 약하다.')
    obj('kitchen','rear',[354,140,192,420],'문 너머는 세탁실이다. 식당에서는 이 안쪽이 보이지 않는다.')
    d['objects']['passage']['steps']['text']='아래 계단은 1층 세탁실로 이어진다. 방과 세탁실 사이를 직접 걸어 시간을 확인할 수 있다.'
    d['objects']['passage']['steps']['rect']=[380,310,380,310]
    obj('passage','handle',[1010,315,240,260],'안쪽 손잡이를 당기면 걸쇠가 직접 물러난다. 주방에서 잠가도 이쪽에서는 방으로 나갈 수 있다.',special='passage_exit')
    obj('passage','linen',[90,195,230,220],'세탁한 천과 여관에서 쓰는 접은 수건. 누가 오늘 놓았는지는 알 수 없다.')
    d['topics']['bami_boundary']['lines'][2][1]='침대 밑하고 그 앞 바닥. 처마 틈에서 낮은 쇠살 사이로 봐. 방 안 얼굴은 안 보여.'
    d['topics']['life:resident_ubak:measurement']['lines'][2][1]='조건이 다른데 숫자만 같으라고 하면 안 돼요. 옮기기 전후의 잔량과 얼마 동안 유지했는지를 보세요.'

    d['topics']['w2_mom_past']['lines']=[['mom','여기서 오래 조사했잖아. 최근에야 돌의 잔량과 사람들 상태가 함께 나빠진다는 걸 알았어.'],['dad','그래서 기록을 가져간 거야?'],['mom','회복한 사람을 없던 일로 만들었어. 고치려 하니까 나까지 가두려 했고.'],['dad','우리 일은 언제 들었어?'],['mom','하루에 한 번 초롱에게 소식을 받았어. 사건 소식을 받은 뒤에는 내가 나서겠다고 전했어. 아이 일은 별개라며 놓아주지 않더라.']]
    d['topics']['w2_mom_stone']['lines']=[['mom','기기의 원래 방향은 돌에서 동물 쪽이었어. 말을 익히고 생각을 나누도록 돕는 장치였지.'],['dad','지금 제단에서는?'],['mom','반대로 연결해. 살아 있는 동물의 생명과 인지를 돌로 거둬들이는 거야. 끝까지 빼앗으면 죽어.'],['dad','그걸 고대 사람들이 시킨 건 아니고?'],['mom','남은 룬과 기계의 연결이 달라. 사용법 일부만 전해졌고, 원래 목적은 사라졌어.']]
    d['topics']['w2_mom_plan']['lines']=[['mom','새 힘을 충전할 방법을 찾은 건 아니야. 약해진 돌들에 남은 힘을 몇 개로 모을 수 있어.'],['dad','그럼 모든 집에 다시 불을 켤 수 있어?'],['mom','아니. 옮기는 동안에도 조금 잃어. 필요한 곳으로 모이고 난방을 줄여야 해.'],['dad','그 시간이 생기면 장작과 식량을 마련할 수 있겠네.'],['mom','응. 사람이 없는 작은 장치부터 직접 확인하자. 내가 해석한 문장만 믿고 연결하면 안 돼.']]
    d['activities']['w2_archive']['lines']=[[None,'수백 년의 정상 운전 기록 끝에 최근 잔량 하락이 나타났다. 엄마가 지적하기 전부터였다. 추출 당일 출력은 반등했지만 다음 유지 기간은 더 짧아졌다.'],['resident_seori','상승만 빼거나 하락만 빼면 다른 이야기가 됩니다. 사람의 번호와 가동일도 함께 남깁시다.']]
    d['activities']['w2_reply']['lines']=[['dad','우리끼리 확인할 말을 썼습니다. 장소는 적지 않았어요.'],['resident_lamplighter','연락은 하루에 한 번입니다. 다음 날 신호를 확인해 주세요.'],[None,'답장을 봉하고 점검함에 넣었다.']]
    d['activities']['w2_measure1'].update(title='여러 돌의 잔량을 한 돌로 옮겨 관측한다',lines=[['mom','사람 쪽 연결은 빼뒀어. 이 빈 작업대에서만 할 거야.'],['buri','보내는 돌도 받는 돌도 먼저 기록하죠.'],[None,'세 돌의 잔량이 줄어드는 동안 한 돌의 출력이 안정됐다. 이전 뒤 남은 총량은 늘지 않았다.'],['resident_seori','작은 등 하나를 유지한 시간까지 적었습니다. 집 한 채를 덥힐 수 있다는 뜻은 아직 아닙니다.']])
    d['activities']['w2_measure2'].update(title='저녁 수요에 맞춰 잔량과 운용 시간을 다시 잰다',lines=[['resident_seori','지난번에 남은 양부터 다시 셉니다. 사용한 돌을 가득 찬 것으로 적지 마십시오.'],['mom','이번에는 더 큰 부하를 연결해요. 한계에 닿으면 멈춥니다.'],[None,'수용석의 감소와 기증석의 잔량, 유지된 시간을 함께 적었다. 같은 장치라도 더 많은 곳에 나누면 오래 버티지 못했다.']])
    for person,spec in d.get('residents',{}).items():
        # Baseline cast metadata is not a second source of the discarded incident.
        if person=='resident_owlgp':spec['private_knowledge']='엄마 연락과 최근 야생화 전조; 생존 시 직접 증언'
