"""Render acting contact sheets with browser CSS crops of unmodified originals.
No generated asset is resized/repainted/exported by an image processing library.
"""
import argparse, asyncio, html, json, shutil
from pathlib import Path
from PIL import Image
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[1]
KNOWN={'neutral','thinking','distressed','expressive'}
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--manifest',action='append',type=Path,required=True);ap.add_argument('--out',type=Path,default=ROOT/'qa-room13-0140/acting-contact');ap.add_argument('--url-root',default='http://127.0.0.1:8094/');a=ap.parse_args();a.out.mkdir(parents=True,exist_ok=True);cast={}
 for p in a.manifest:
  for who,poses in json.loads(p.read_text()).items():cast.setdefault(who,{}).update(poses)
 cards=[]
 for who,poses in cast.items():
  selected=[p for p in ('neutral','thinking','distressed','expressive') if p in poses]
  selected += [p for p in poses if not p.startswith(('avatar_','interview_')) and p not in KNOWN and p not in ('world','inn_activity')]
  if 'living'in poses and 'living'not in selected:selected.append('living')
  rows=[]
  for i,pose in enumerate(selected):
   spec=poses[pose]
   if not isinstance(spec,dict) or 'crop'not in spec:continue
   path=next((p for p in [ROOT/'art/pixel-b/acting'/Path(spec['file']).name,ROOT/'art/pixel-b/acting'/Path(spec['file']).name.replace('room13-pixel-acting-','room13-acting-'),ROOT/'art/pixel-b'/Path(spec['file']).name,ROOT/'game'/spec['file']] if p.exists()),None)
   if not path:continue
   iw,ih=Image.open(path).size;x,y,w,h=spec['crop'];scale=min(238/w,282/h);sw,sh=w*scale,h*scale;url=a.url_root+str(path.relative_to('/workspace'))
   crop=f'<div class="crop" style="width:{sw}px;height:{sh}px"><img src="{url}" style="width:{iw*scale}px;height:{ih*scale}px;left:{-x*scale}px;top:{-y*scale}px"></div>'
   rows.append(f'<div class="card {"dark"if i%2 else"light"}"><div class="art">{crop}</div><div class="label">{html.escape(who)} · {html.escape(pose)}</div></div>')
  cards.append((who,''.join(rows)))
 style='<style>body{margin:0;background:#17262b;font:17px sans-serif;color:#fff}section{display:flex;flex-wrap:wrap;margin:10px 0;border-top:2px solid #ddc288}.card{width:256px;height:322px;margin:3px}.light{background:#eadac0;color:#201c20}.dark{background:#31454b;color:#fff}.art{height:288px;display:flex;align-items:end;justify-content:center}.crop{position:relative;overflow:hidden}.crop img{position:absolute;max-width:none;image-rendering:pixelated}.label{padding:4px;font-size:14px}</style>'
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox']);page=await browser.new_page(viewport={'width':1600,'height':1100},device_scale_factor=1)
  for index,(who,body) in enumerate(cards):
   file=a.out/f'{index:02d}-{who}.html';file.write_text('<!doctype html><meta charset="utf-8">'+style+'<section>'+body+'</section>');url=a.url_root+str(file.relative_to('/workspace'));await page.goto(url);await page.wait_for_function('Array.from(document.images).every(i=>i.complete&&i.naturalWidth>0)');await page.screenshot(path=str(file.with_suffix('.png')),full_page=True)
  await browser.close()
 print(json.dumps({'status':'rendered','identities':len(cards),'out':str(a.out),'kind':'browser-source-crop-contact-sheets-not-runtime-staging'}))
if __name__=='__main__':asyncio.run(main())
