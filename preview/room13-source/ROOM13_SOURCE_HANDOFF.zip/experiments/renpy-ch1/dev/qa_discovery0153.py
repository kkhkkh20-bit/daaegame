"""Pure-state audit using the actual original presentation function and new module.
Browser integration, input flows and popup timing are separate release tests.
"""
import ast,copy,json,textwrap,types
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
base=json.loads((ROOT/'game/room13-content.json').read_text())
props=json.loads((ROOT/'art/pixel-b/panorama/new-object-proposals.json').read_text())
layouts=json.loads((ROOT/'art/pixel-b/panorama/world-layout.json').read_text())
ns={'json':json,'winter_copy':copy,'store':types.SimpleNamespace(),'ROOM13':copy.deepcopy(base),'R13_WORLD_LAYOUTS':layouts,'R13_OBJECT_NAMES':{},'R13_CORE_PEOPLE':{'granny','buri','nabi','bami','karo','seryeon'},'R13_RESIDENTS':base['residents']}
ns['renpy']=types.SimpleNamespace(loadable=lambda p:True,file=lambda p:open(ROOT/'art/pixel-b/panorama/new-object-proposals.json'))
ns['r13_w2_present']=lambda person,key,repeated:[(person,'week2 sentinel')]
ns['r13_actions']=lambda:[('map',base['activities']['map'])]
rules=textwrap.dedent((ROOT/'game/room13_rules.rpy').read_text().split('python:\n',1)[1])
tree=ast.parse(rules)
for node in tree.body:
 if isinstance(node,ast.FunctionDef) and node.name in ('r13_flag','r13_has','r13_present'):
  exec(compile(ast.Module(body=[node],type_ignores=[]),'<actual-rule>','exec'),ns)
original=ns['r13_present']
s=(ROOT/'game/room13_discovery.rpy').read_text()
for block in s.split('init ')[1:]:exec(textwrap.dedent(block.split('python:\n',1)[1]),ns)
def state(**kw):
 d=dict(day=1,period=1,location='inn',evidence=['E01','E04','G1','G2'],flags=['lodging'],resident_knowledge={},records={},read_topics=[],done=[])
 d.update(kw);return d
def run(fn,st,person,key,identity=False):
 ns['store'].room13=copy.deepcopy(st);reply=fn(person,key,identity);return reply,copy.deepcopy(ns['store'].room13)
checks=[]
for person,key in [('granny','E01'),('buri','E04')]:
 st=state();old,oldstate=run(original,st,person,key);new,newstate=run(ns['r13_present'],st,person,key)
 assert oldstate==newstate and old!=new,(person,'presentation changed facts or did not replace fallback')
 repeat,repeatedstate=run(ns['r13_present'],newstate,person,key)
 assert repeatedstate==newstate and repeat!=new,(person,'repeat not idempotent')
 checks.append(person+': tailored first/repeat replies retain exact original state')
for st,person,key,identity in [(state(day=8),'buri','E04',False),(state(evidence=[]),'granny','E01',False),(state(evidence=['E05']),'granny','E05',False),(state(evidence=['E10']),'granny','E10',True),(state(evidence=['E06','E08'],flags=['medical_consent'],resident_knowledge={'buri':['E06:anonymous']}),'buri','E08',False)]:
 assert run(original,st,person,key,identity)==run(ns['r13_present'],st,person,key,identity),(person,key,'legacy flow changed')
checks.append('Unowned evidence, later week, warning flags, named witness disclosure and medical-record unlock unchanged')
ns['store'].room13=state();before=copy.deepcopy(ns['store'].room13)
assert not ns['r13_discovery_observation_feedback']('gate','booth',False)
assert ns['r13_discovery_observation_feedback']('gate','booth',True)
assert ns['r13_discovery_observation_feedback']('workshop','plans',True)
assert before==ns['store'].room13
checks.append('Reinspection advice is read-only and absent on first observation')
assert ns['ROOM13']['evidence']==base['evidence'] and ns['ROOM13']['topics']==base['topics']
count=0
for location,items in props.items():
 for key in base['objects'][location]:assert ns['ROOM13']['objects'][location][key]==base['objects'][location][key]
 for key in items:
  item=ns['ROOM13']['objects'][location][key];assert item['give']==item['need']==item['flags']==[];assert ns['R13_OBJECT_NAMES'][key]==items[key]['name'];count+=1
assert count==13
checks.append('13 lifestyle props registered; evidence/topic definitions and existing objects unchanged')
out=ROOT/'qa-room13-0153/discovery-state-audit.json';out.parent.mkdir(exist_ok=True);out.write_text(json.dumps({'status':'passed','kind':'actual-source-pure-state-invariants-not-browser-playthrough','checks':checks},ensure_ascii=False,indent=2));print(json.dumps({'status':'passed','checks':checks},ensure_ascii=False))
