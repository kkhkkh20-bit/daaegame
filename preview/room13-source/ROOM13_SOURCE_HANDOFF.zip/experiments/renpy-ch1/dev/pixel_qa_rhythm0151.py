"""Focused display-only speech-rhythm QA; synthetic lines are explicit fixtures."""
import argparse,asyncio,json,shutil,time
from playwright.async_api import async_playwright
from pixel_qa_flow0150 import FlowQA,ROOT
from pixel_qa_fade0151 import Recorder
UNIT=r"""import renpy,re
s=renpy.store
old=s.preferences.text_cps;oldfast=s.r13_fast_read;oldskip=renpy.config.skipping
s.preferences.text_cps=34;s.r13_fast_read=False;renpy.config.skipping=None
raw='가, 나. 다? 라... 마 1.5 1,000.'
key=s.r13_read_key('qa:rhythm',0,raw)
formatted=s.r13_rhythmic_text(raw)
assert re.sub(r'\{/?cps(?:=[^}]+)?\}','',formatted)==raw
rates=re.findall(r'\{cps=([0-9.]+)\}(.)\{/cps\}',formatted)
pauses=[]
for rate,char in rates:pauses.append(round(1/float(rate)-1/34,4))
assert pauses==[.12,.26,.26,.30],pauses
assert s.r13_read_key('qa:rhythm',0,raw)==key
s.r13_fast_read=True
assert s.r13_rhythmic_text(raw)==formatted,'unread text lost rhythm when fast-read option enabled'
s.preferences.text_cps=0
assert s.r13_rhythmic_text(raw)==raw
s.preferences.text_cps=34;renpy.config.skipping='slow'
assert s.r13_rhythmic_text(raw)==raw
renpy.config.skipping=None
cluster=s.r13_rhythmic_text('정말.?! 네')
assert cluster.count('{cps=')==1
assert s.r13_rhythmic_text('값은 1.5 또는 1,000이다')=='값은 1.5 또는 1,000이다'
authored='{cps=20}잠깐, 기다려.{/cps}'
assert s.r13_rhythmic_text(authored)==authored
s.preferences.text_cps=old;s.r13_fast_read=oldfast;renpy.config.skipping=oldskip
result={'original':raw,'formatted':formatted,'extra_pauses':pauses,'numeric_untouched':True,'read_key_unchanged':True,'fastread_unread_keeps_rhythm':True,'instant_and_skip_bypass':True,'cluster_single_pause':True,'authored_cps_preserved':True}
"""
TEXT="잠깐, 여기 보세요. 정말 맞나요? 다시... 천천히 확인해요. 숫자는 1.5와 1,000이에요."
SECOND="같은 까로가 이어서 말하는 검수용 다음 문장입니다."
PROBE="""import renpy
s=renpy.store;w=renpy.exports.get_widget('say','what');layout=w.get_layout() if w else None
result={'index':getattr(s,'r13_index',None),'identity':getattr(s,'identity',None),'read_id':getattr(s,'r13_read_id',None),'slow':getattr(w,'slow',None),'slow_done_linked':bool(getattr(w,'slow_done',None)),'widget_id':id(w),'text':getattr(w,'text',None),'max_time':getattr(layout,'max_time',None),'history':s._history_list[-1].what if s._history_list else None,'packet':getattr(s,'r13_packet',None),'after_rollback':renpy.game.after_rollback,'skipping':renpy.config.skipping,'cps':s.preferences.text_cps}
if layout:
 result['glyphs']=[]
 for line in layout.lines:
  for g in line.glyphs:result['glyphs'].append({'character':getattr(g,'character',None),'time':g.time,'x':g.x,'advance':g.advance})
"""
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',default='qa-room13-0151/rhythm-independent');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True)
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},service_workers='block');pg=await c.new_page();errors=[];pg.on('pageerror',lambda e:errors.append(str(e)));q=FlowQA(pg,out);r=Recorder(pg,out);report={'kind':'natural-karo-dialogue-clicks-plus-explicit-formatter-unit-fixtures','captures':[]}
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');report['unit']=await q.py(UNIT);await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub');before=(await q.state())['room']
   await q.press('까로');await q.wait('r13_entry_karo_topics');await q.py('import renpy;renpy.store.preferences.text_cps=34;renpy.store.r13_fast_read=True;result=True')
   st=await q.state();button=next(x for x in st['buttons']if '짐 좀 부탁합니다'in x['text']);x,y,w,h=button['rect']
   await r.start('natural-karo-first-click');t0=time.monotonic();await pg.mouse.click(x+w/2,y+h/2);await asyncio.sleep(.045);timing=await q.py(PROBE);report['layout']=timing;report['probe_ms']=round((time.monotonic()-t0)*1000,2);assert timing['slow'] is True,timing
   raw=timing['packet'][1];assert '{cps='not in raw;assert timing['text']==[raw],timing;assert timing['slow_done_linked'],timing
   await q.py('import renpy;renpy.exports.restart_interaction();result=True');redraw=await q.py(PROBE);report['mid_typewriter_redraw']=redraw;assert redraw['slow'] and redraw['slow_done_linked'],redraw
   await pg.mouse.click(810,640);await asyncio.sleep(.06);afterclick=await q.py(PROBE);assert afterclick['index']==0 and afterclick['slow'] is False,afterclick;assert afterclick['packet'][1]==raw;report['click1']=afterclick;await asyncio.sleep(.35);report['captures'].append(await r.stop());await q.shot('first-click-full-line')
   # The second click now exits this one-line natural topic to the entry hub.
   await pg.mouse.click(810,640);await q.advance();await q.wait('r13_hub');report['click2']='returned to entry hub after exactly one additional click'
   await q.press('까로');await q.wait('r13_entry_karo_topics');await q.py('import renpy;renpy.store.preferences.text_cps=0;renpy.store.r13_fast_read=False;result=True');st=await q.state();button=next(x for x in st['buttons']if '짐 좀 부탁합니다'in x['text']);x,y,w,h=button['rect'];await pg.mouse.click(x+w/2,y+h/2);await asyncio.sleep(.08);instant=await q.py(PROBE);report['instant_natural']=instant;assert instant['slow'] is False and instant['max_time']==0,instant;await pg.mouse.click(810,640);await q.advance();await q.wait('r13_hub')
   assert (await q.state())['room']==before,'presentation-only fixture changed story state';assert not errors,errors;report['status']='passed-pending-frame-review'
  except Exception as e:
   report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
   try:await r.stop()
   except Exception:pass
  report.update(errors=errors,url=a.url);(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items()if k not in('captures','layout','click1','click2','instant')},ensure_ascii=False),flush=True);await b.close()
  if report['status']=='failed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
