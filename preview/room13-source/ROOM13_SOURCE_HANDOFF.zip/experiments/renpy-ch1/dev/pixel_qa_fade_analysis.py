"""Read-only pixel measurements on real browser frames; never edits artwork."""
import argparse,json,numpy as np
from PIL import Image
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('directory');a=ap.parse_args();root=Path(a.directory);p=json.loads((root/'report.json').read_text());out=[]
for cap in p['captures']:
 frames=[np.asarray(Image.open(root/x['file']).convert('RGB'),dtype='int16')for x in cap['frames']]
 regions={'hud':(25,22,672,88),'background':(1000,100,1260,150),'profile':(65,490,279,705),'central':(500,160,760,480),'world':(110,360,325,565),'topics':(120,240,430,460)}
 stats={}
 for name,r in regions.items():
  deltas=[np.abs(f[r[1]:r[3],r[0]:r[2]]-frames[-1][r[1]:r[3],r[0]:r[2]])for f in frames]
  stats[name]={'max_pixel_difference':max(int(d.max())for d in deltas),'mean_difference_to_final_by_frame':[round(float(d.mean()),4)for d in deltas]}
 out.append({'name':cap['name'],'regions':stats})
assert all(row['regions']['hud']['max_pixel_difference']==0 and row['regions']['background']['max_pixel_difference']==0 for row in out)
for row in out:
 if row['name']in('same-speaker-repeated','screen-restart'):assert all(row['regions'][k]['max_pixel_difference']==0 for k in('central','profile'))
 if row['name']=='world-screen-restart':assert row['regions']['world']['max_pixel_difference']==0
(root/'frame-metrics.json').write_text(json.dumps(out,indent=2));print('PASS: all HUD/background unchanged; same speaker and redraw steady; see frame-metrics.json for fade progress')
