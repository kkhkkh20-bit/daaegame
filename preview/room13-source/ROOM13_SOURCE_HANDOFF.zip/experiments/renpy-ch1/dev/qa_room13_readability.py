"""Actual controls and explicit long-line rendering fixtures for reading UI."""
import argparse, asyncio, json, shutil
from pathlib import Path
from playwright.async_api import async_playwright
from pixel_qa_flow0150 import FlowQA, ROOT

LONG_LINE='확인된 부분은 남기겠습니다. 하지만 현재 낸 자료만으로는 이 주장의 빈틈을 모두 메우지 못했습니다. 새로 내지 않은 자료까지 판단에 넣지는 않겠습니다.'

async def main():
    ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--out',default='qa-room13-ui-review/engine');a=ap.parse_args()
    out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True);report={'kind':'actual-reading-options-and-explicit-longest-speaker-fixture','checks':[]};errors=[]
    async with async_playwright() as p:
        browser=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader'])
        context=await browser.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block')
        page=await context.new_page();page.on('pageerror',lambda e:errors.append(str(e)));q=FlowQA(page,out)
        try:
            await page.goto(a.url);await page.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu')
            await q.press('설정');await q.wait('pause_menu');await q.shot('01-options-normal')
            assert not any('이전 겨울'in b['text']for b in (await q.state())['buttons'])
            await q.press('큰 글씨');await q.shot('02-options-large')
            assert await q.py('import renpy;result=renpy.store.persistent.room13_large_text')
            for title,value in [('느리게',24),('빠르게',55),('즉시',0),('보통',34)]:
                await q.press(title);assert await q.py('import renpy;result=renpy.store.preferences.text_cps')==value
            await q.press('돌아가기');await q.wait('main_menu');await page.reload();await page.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu')
            assert await q.py('import renpy;result=renpy.store.persistent.room13_large_text'),'large text did not persist on actual reload'
            report['checks'].append('Actual large-text toggle, four speed presets, no legacy menu, reload persistence')
            await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.advance();await q.wait('r13_hub');await q.shot('03-field-large')
            assert not any(b['text'].strip()=='조사 중'for b in (await q.state())['buttons']),'field mode is still a focusable no-op button'
            await q.press('까로');await q.advance();await q.wait('r13_entry_karo_topics');await q.shot('04-topics-large')
            await page.set_viewport_size({'width':844,'height':390});q.touch=True;await q.shot('05-mobile-topics-large');await q.press('조사');await q.wait('r13_hub')
            # Rendering fixture only: display a real long authored line with its
            # named speaker. No claims of reaching the trial through gameplay.
            await q.py('import renpy\ns=renpy.store\ns.dialogue_speaker="resident_seori"\ns.dialogue_expression="neutral"\ns.r13_thought_active=False\nrenpy.exports.show_screen("say",who="서리",what='+ascii(LONG_LINE)+')\nrenpy.exports.restart_interaction()\nresult=True')
            await asyncio.sleep(.5);await q.shot('06-mobile-long-authored-line')
            layout=await q.py('import renpy\ns=renpy.store\nw=renpy.exports.get_widget("say","what")\nl=w.get_layout()\nbottom=max([line.y+line.height for line in l.lines]or[0])\nresult={"size":w.style.size,"text":w.text,"lines":len(l.lines),"content_height":l.unscale_pair(0,bottom)[1],"available":642-(455+18)}')
            assert layout['size']==34 and layout['text']==[LONG_LINE],layout
            assert layout['content_height']<=layout['available'],layout
            report['long_line']=layout
            await q.py('import renpy;renpy.exports.hide_screen("say");renpy.store.dialogue_speaker=None;renpy.exports.restart_interaction();result=True')
            await q.press('옵션');await q.wait('pause_menu');await q.shot('07-mobile-options-large');await q.press('큰 글씨');await q.press('돌아가기');await q.wait('r13_hub')
            assert not await q.py('import renpy;result=renpy.store.persistent.room13_large_text')
            report['checks'].append('Non-button field status, mobile topic/option input, original long line fits above toolbar, runtime mode reset')
            assert not errors,errors;report['status']='passed-pending-visual-review'
        except Exception as exc:
            report.update(status='failed',error=repr(exc));await page.screenshot(path=str(out/'failure.png'))
        finally:
            report.update(url=a.url,errors=errors);(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));await browser.close()
    print(json.dumps(report,ensure_ascii=False),flush=True)
    if report['status']=='failed':raise SystemExit(1)

if __name__=='__main__':asyncio.run(main())
