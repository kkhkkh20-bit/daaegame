"""Final-candidate regression: natural records navigation + puzzle save/return core."""
import argparse,asyncio,json,shutil,traceback
from playwright.async_api import async_playwright
from qa_room13_inspection import InspectionQA,ROOT
class FinalQA(InspectionQA):
 async def state(self):
  st=await super().state();st['screens']+=await self.py("import renpy;result=[n for n in ['r13_records','r13_calendar'] if renpy.display.screen.get_screen(n)]");return st
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);a=ap.parse_args();base=ROOT/'qa-room13-0154';out=base/'inspection';out.mkdir(parents=True,exist_ok=True);rec=base/'records';rec.mkdir(parents=True,exist_ok=True);reports={name:{'status':'pending','url':a.url,'kind':'final candidate regression via natural input','checks':[]}for name in ['records','inspection']}
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},has_touch=True,service_workers='block');pg=await c.new_page();q=FinalQA(pg,out)
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=120000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.natural_entry('wait')
   q.out=rec;before=(await q.state())['room'];await q.press('기록');await q.wait('r13_records');await q.shot('01-final-records');await q.press('인물');assert {'karo','guard','daram'}<=set(await q.py('import renpy;result=renpy.store.r13_met_people()'));await q.shot('02-final-people');await q.press('대화');assert await q.py('import renpy;result=bool(renpy.store.r13_history_rows())');await q.shot('03-final-dialogue');await q.press('닫기');await q.wait('r13_hub');assert (await q.state())['room']==before
   reports['records'].update(status='passed',checks=['Final-candidate natural entry Karo/guard/Daram all recorded','Real dialogue history and paper contrast visible','Records close preserves full state'])
   q.out=out;await q.travel('여관 접수대');await q.press('할머니');await q.advance();await q.wait('r13_topics');await q.value('register');await q.advance();await q.press('돌아가기');await q.advance();await q.travel('13호실','여관 안');before=(await q.state())['room'];await q.value(('object','desk'));await q.wait('r13_desk_inspection')
   for key in ['pencil','paper','ruler']:await q.target(key)
   await q.target('drawer');await q.press('얇은 종이');await q.target('tag');expected=await q.isp();await q.press('책상으로');await q.press('방으로');await q.wait('r13_hub');await q.press('옵션');await q.wait('pause_menu');await q.press('저장');await q.wait('save');await q.press('슬롯 2');await asyncio.sleep(.5);await q.press('돌아가기')
   if 'pause_menu'in(await q.state())['screens']:await q.press('돌아가기')
   await q.wait('r13_hub');await q.press('옵션');await q.wait('pause_menu');await q.press('불러오기');await q.wait('load');await q.press('슬롯 2');await q.wait('r13_hub');assert await q.isp()==expected
   await pg.set_viewport_size({'width':844,'height':390});q.touch=True;await q.value(('object','desk'));await q.wait('r13_desk_inspection');await q.target('drawer');await q.press('짧은 연필');await q.target('tag');await q.press('납작한 자');await q.target('divider');assert (await q.isp())['compartment_open'];await q.target('compartment');await q.shot('01-final-open-compartment');await q.press('접이식 돋보기');await q.target('buttons');await q.shot('02-final-mobile-magnifier');assert (await q.scope())['lens'];await q.press('돋보기 내려놓기');await q.press('선택 해제');await q.press('책상으로');await q.press('방으로');await q.wait('r13_hub');after=(await q.state())['room']
   for key in ['day','period','location','evidence','flags','daram_state','case_state','records']:assert before[key]==after[key],key
   assert (await q.isp())['inventory'].count('magnifier')==1
   reports['inspection'].update(status='passed',checks=['Natural entry/lodging/desk access in final candidate','Real save/load of placed paper','Mobile touch completes drawer chain and actual magnifier enlargement','Back returns to identical location/time/evidence/case; one magnifier'])
   q.out=rec;await q.press('기록');await q.wait('r13_records');await q.press('아이템');await q.wait('r13_item_bag');await q.shot('04-final-mobile-items');await q.press('닫기');await q.wait('r13_records');await q.press('닫기');await q.wait('r13_hub');reports['records']['checks'].append('Mobile records→actual acquired item bag→records→same room return')
  except Exception as e:
   for name in reports:
    reports[name].update(status='failed',error=repr(e),traceback=traceback.format_exc())
   await pg.screenshot(path=str(base/'regression-failure.png'))
  for name,report in reports.items():(base/name/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
  print(json.dumps(reports,ensure_ascii=False),flush=True);await b.close()
  if any(r['status']!='passed'for r in reports.values()):raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
