async def waitscreen(name):
 for _ in range(120):
  s=await state()
  if name in s['screens']:
   await asyncio.sleep(.45);return await state()
  await asyncio.sleep(.15)
 raise AssertionError(('screen',name,s))
async def press(label):
 await asyncio.sleep(.45);s=await state()
 matches=[b for b in s['buttons'] if label in b['text'] and b['rect'][3]>15]; b=min(matches,key=lambda b:b['rect'][2]*b['rect'][3]) if matches else None
 assert b,(label,s)
 x,y,w,h=b['rect'];await click(x+w/2,y+h/2)
async def advance():
 for _ in range(250):
  s=await state()
  if 'r13_cinematic_view' in s['screens']:
   await shot('cg-'+str(s['room']['day'])+'-'+s['room']['location']);await press('계속');continue
  if any(x in s['screens'] for x in ['choice','r13_hub','r13_book','r13_confirm','r13_interaction','r13_topics','r13_debate','r13_handoff','r13_crisis','r13_crisis_proof','r13_ending_screen']):
   await asyncio.sleep(.45);return await state()
  if 'say'in s['screens']:await click(810,640)
  else:await asyncio.sleep(.2)
 raise AssertionError(s)
async def shot(n):
 print('QA '+n,flush=True);await page.screenshot(path=str(OUT/(n+'.png')))
 (OUT/(n+'.json')).write_text(json.dumps(await state(),ensure_ascii=False,indent=2))
async def move(label):
 await press('이동하기');await waitscreen('r13_map');await press(label);return await advance()
async def rest():
 await press('여관에서 밤 보내기');await waitscreen('r13_confirm');await press('진행한다');return await advance()
async def run():
 before=(await state())['room']
 await press('인물 움직임');await shot('final-08-motion-off')
 assert await page.evaluate("renpy_exec('import renpy; result=renpy.store.persistent.room13_motion')")==False
 await press('인물 움직임');await press('불러오기');await waitscreen('load');await press('1쪽 1번');await advance()
 assert (await state())['room']==before
 await page.reload();await page.wait_for_function("typeof renpy_exec==='function'",timeout=90000);await asyncio.sleep(2)
 await press('이어하기');await waitscreen('load');await press('1쪽 1번');await advance();assert (await state())['room']==before
 await shot('final-09-reload-restored')
 await press('해 볼 일');await waitscreen('r13_activities');await press('돌아가기');await waitscreen('r13_hub');assert (await state())['room']==before
 await page.set_viewport_size({'width':844,'height':390});await asyncio.sleep(1);await shot('mobile-01-room')
 # Use actual touch input in the letterboxed game, preserving virtual coordinates.
 global click
 async def touch(x,y):
  scale=390/720;await page.touchscreen.tap((844-1280*scale)/2+x*scale,y*scale);await asyncio.sleep(.45)
 click=touch
 await press('수첩');await waitscreen('r13_book');await shot('mobile-02-book');await press('닫기')
 await press('설정');await waitscreen('pause_menu');await shot('mobile-03-settings');await press('돌아가기');await advance()
 await page.set_viewport_size({'width':1280,'height':720});await asyncio.sleep(.7)
 async def desktop(x,y):await page.mouse.click(x,y);await asyncio.sleep(.25)
 click=desktop
 for day in range(1,4):
  s=await rest()
  if 'choice'in s['screens']:await press('현관을 살핀다');s=await advance()
  assert s['room']['day']==day+1
  await shot('final-day%d-morning'%(day+1))
 await rest();await press('까로와 반송품');await advance();await shot('final-10-rescue-choice');await press('아이를 안고 너울');await advance();await shot('final-11-case-after')
 for day in (4,5,6):await rest()
 await shot('final-12-trial');await press('지금까지 확인한 사실');await waitscreen('r13_confirm');await press('판단을 요청한다');await advance();await shot('final-13-week2')
 assert (await state())['room']['daram_state']=='held'
 for day in range(8,14):
  await rest();await shot('final-day%d'%(day+1))
 await press('혼자라도 호송을');await advance();await shot('final-14-ending')
 assert (await state())['room']['ending']=='E1'
 return await state()
