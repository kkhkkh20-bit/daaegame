"""Opening CG old-save refresh fixture, preserving the naturally reached line."""
import argparse,asyncio,json,shutil,urllib.request
from playwright.async_api import async_playwright
from pixel_qa_gate0153 import GateQA as FlowQA,ROOT
async def main():
 ap=argparse.ArgumentParser();ap.add_argument('--url',required=True);ap.add_argument('--proof-choice',action='store_true');ap.add_argument('--out',default='qa-room13-0153/carriage-final');a=ap.parse_args();out=ROOT/a.out;out.mkdir(parents=True,exist_ok=True);report={}
 report['archive_sha256']=json.load(urllib.request.urlopen(a.url+'game-transport.json'))['archive_sha256']
 async with async_playwright()as p:
  b=await p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--enable-unsafe-swiftshader']);c=await b.new_context(viewport={'width':1280,'height':720},service_workers='block');pg=await c.new_page();q=FlowQA(pg,out);errors=[];pg.on('pageerror',lambda e:errors.append(str(e)))
  try:
   await pg.goto(a.url);await pg.wait_for_function("typeof renpy_exec==='function'",timeout=150000);await q.wait('main_menu');await q.py('import renpy;renpy.store.preferences.text_cps=0;result=True');await q.press('처음부터');await q.wait('say')
   found=False
   for _ in range(60):
    info=await q.py("import renpy;s=renpy.store;result={'scene':s.r13_scene_key,'read_id':getattr(s,'r13_read_id',None),'packet':getattr(s,'r13_packet',None),'speaker':s.dialogue_speaker,'room':s.room13}")
    if info['scene']and info['scene'][0]=='winter_carriage':found=True;break
    await q.input(810,640)
   assert found,info;await q.shot('01-natural-carriage-fixed-hands-letter');before=info
   await q.py("import renpy;s=renpy.store;s.room13['carriage_art_file']='assets/old-carriage-art.png';renpy.exports.scene();renpy.exports.show('qa_old_carriage',what=s.Solid('#a000a0',xsize=1280,ysize=720));renpy.exports.restart_interaction();result=True")
   await q.input(810,640);await q.wait('say');before=await q.py("import renpy;s=renpy.store;result={'scene':s.r13_scene_key,'read_id':s.r13_read_id,'packet':s.r13_packet,'speaker':s.dialogue_speaker,'room':s.room13}")
   await q.press('옵션');await q.wait('pause_menu');await q.press('저장');await q.wait('save');await q.press('1쪽 2번');await q.press('돌아가기');st=await q.state()
   if 'pause_menu'in st['screens']:await q.press('돌아가기')
   await q.wait('say');await q.press('옵션');await q.wait('pause_menu');await q.press('불러오기');await q.wait('load');await q.press('1쪽 2번');await q.press('예');await q.wait('say');await q.shot('02-actual-load-refreshes-old-carriage')
   after=await q.py("import renpy;s=renpy.store;result={'scene':s.r13_scene_key,'read_id':s.r13_read_id,'packet':s.r13_packet,'speaker':s.dialogue_speaker,'room':s.room13,'current_art':s.R13_CARRIAGE_IMAGE,'tags':list(renpy.exports.get_showing_tags())}")
   assert after['read_id']==before['read_id']and after['packet']==before['packet']and after['speaker']==before['speaker'];assert after['room']['carriage_art_file']==after['current_art'];assert 'r13_restored_background'in after['tags']and 'qa_old_carriage'not in after['tags']
   x=dict(before['room']);y=dict(after['room'])
   for key in ('carriage_art_file','last_inspection'):x.pop(key,None);y.pop(key,None)
   if a.proof_choice:
    await q.advance();await q.wait('r13_hub');await q.input(1128,410);await q.wait('r13_gate_document_inspection');await q.press('기록하기');await q.wait('r13_gate_document_inspection');await q.press('닫기');await q.wait('r13_hub');await q.input(390,321);await q.advance();await q.wait('r13_hub');await q.press('돌목');await q.wait('r13_entry_topics');await q.press('제시');await q.wait('r13_book');short=await q.py("import renpy;result=renpy.store.R13_RECORD_SHORT['G1']");await q.press(short);await q.press('돌목에게 보여주기');await q.wait('say');await q.shot('03-guard-present-icon');await q.advance();await q.wait('choice');await q.shot('04-guard-choice-face-unobscured');assert await q.py("import renpy;result=renpy.display.screen.get_screen('r13_material_corner') is None");report['choice_card_hidden']=True
   assert x==y,(x,y);assert not errors,errors;report={**report,'status':'passed','kind':'natural-opening-with-injected-old-art-marker-and-magenta-placeholder-save-fixture-real-save-load','before':before,'after':after}
  except Exception as e:report.update(status='failed',error=repr(e));await pg.screenshot(path=str(out/'failure.png'))
  report.update(errors=errors,url=a.url);(out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in report.items()if k not in('before','after')},ensure_ascii=False));await b.close()
  if report['status']!='passed':raise SystemExit(1)
if __name__=='__main__':asyncio.run(main())
