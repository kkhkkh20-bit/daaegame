async def waitscreen(name):
 for _ in range(120):
  s=await state()
  if name in s['screens']:
   await asyncio.sleep(.45);return await state()
  await asyncio.sleep(.15)
 raise AssertionError(('screen',name,s))
async def press(label):
 await asyncio.sleep(.45);s=await state()
 matches=[b for b in s['buttons'] if label in b['text'] and b['rect'][3]>15]; b=min(matches,key=lambda b:b['rect'][2]*b['rect'][3]) if matches else None
 assert b,(label,s)
 x,y,w,h=b['rect'];await click(x+w/2,y+h/2)
async def advance():
 for _ in range(250):
  s=await state()
  if 'r13_cinematic_view' in s['screens']:
   await shot('cg-'+str(s['room']['day'])+'-'+s['room']['location']);await press('계속');continue
  if any(x in s['screens'] for x in ['choice','r13_hub','r13_book','r13_confirm','r13_interaction','r13_topics','r13_debate','r13_handoff','r13_crisis','r13_crisis_proof','r13_ending_screen']):
   await asyncio.sleep(.45);return await state()
  if 'say'in s['screens']:await click(810,640)
  else:await asyncio.sleep(.2)
 raise AssertionError(s)
async def shot(n):
 print('QA '+n,flush=True);await page.screenshot(path=str(OUT/(n+'.png')))
 (OUT/(n+'.json')).write_text(json.dumps(await state(),ensure_ascii=False,indent=2))
async def move(label):
 await press('이동하기');await waitscreen('r13_map');await press(label);return await advance()
async def run():
 before=(await state())['room']
 await press('예약 원본');await shot('03-evidence-detail')
 await press('제시 취소');await waitscreen('r13_hub')
 assert (await state())['room']['evidence']==before['evidence']
 await press('확인한 자료');await waitscreen('r13_book');await press('예약 원본');await press('이 사람에게 보여주기');await advance()
 await press('원본에는 두 명');await advance()
 await move('여관 접수대');await shot('04-inn')
 await click(925,265);await advance();await press('대화하기');await waitscreen('r13_topics');await press('방을 부탁한다');await advance();await shot('05-granny-topics')
 await press('돌아가기');await waitscreen('r13_interaction');await press('돌아가기');await advance()
 await press('달력');await waitscreen('r13_calendar');await shot('06-calendar');await press('닫기')
 await move('13호실');await shot('07-room-before');await click(800,370);s=await advance();assert 'E03'in s['room']['evidence']
 await press('복도에서 출입문');await advance();await shot('08-hall-before')
 await press('13호실 안으로');await advance()
 await press('저장');await waitscreen('save');await shot('09-save');return await state()
