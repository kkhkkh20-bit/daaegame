import asyncio,json
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path('/workspace/daaegame/experiments/renpy-ch1/qa-room13-pixel-gallery');OUT.mkdir(exist_ok=True)
async def main():
 async with async_playwright() as p:
  browser=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  page=await browser.new_page(viewport={'width':1440,'height':1000})
  errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.on('response',lambda r:errors.append(f'{r.status} {r.url}') if r.status>=400 else None)
  await page.goto('http://localhost:8093/preview/room13-pixel-art/',wait_until='networkidle')
  await page.screenshot(path=str(OUT/'desktop-backgrounds.png'),full_page=False)
  result={'desktop':{},'mobile':{},'errors':errors}
  for t in ['morning','afternoon','evening']:
   await page.locator(f'[data-time={t}]').click();result['desktop'][t]=await page.locator('#bggrid .card').count()
  await page.locator('[data-tab=cast]').click()
  await page.locator('.pose').first.select_option('distressed');await page.locator('#castgrid').scroll_into_view_if_needed();await page.wait_for_timeout(350);await page.screenshot(path=str(OUT/'desktop-cast.png'))
  result['desktop']['main']=await page.locator('#castgrid .card').count()
  await page.locator('[data-kind=support]').click();result['desktop']['support']=await page.locator('#castgrid .card').count()
  await page.locator('[data-tab=cinematics]').click();assert await page.locator('#spoilers').get_attribute('open') is None
  await page.locator('#spoilers summary').click();await page.wait_for_function('document.querySelectorAll("#cggrid .card").length===12');result['desktop']['cg']=await page.locator('#cggrid .card').count()
  await page.locator('#cggrid').scroll_into_view_if_needed();await page.wait_for_timeout(350);await page.screenshot(path=str(OUT/'desktop-cg.png'))
  await page.set_viewport_size({'width':390,'height':844});await page.locator('[data-tab=cast]').click();await page.locator('[data-kind=main]').click()
  await page.locator('.pose').first.select_option('thinking');await page.locator('#castgrid').scroll_into_view_if_needed();await page.wait_for_timeout(350);await page.screenshot(path=str(OUT/'mobile-cast.png'))
  result['mobile']['overflow']=await page.evaluate('document.documentElement.scrollWidth>innerWidth')
  await page.locator('[data-tab=backgrounds]').click();await page.locator('[data-time=afternoon]').click();await page.locator('#bggrid').scroll_into_view_if_needed();await page.wait_for_timeout(350);await page.screenshot(path=str(OUT/'mobile-backgrounds.png'))
  result['mobile']['backgrounds']=await page.locator('#bggrid .card').count()
  catalog=await (await page.request.get('http://localhost:8093/preview/room13-pixel-art/catalog.json')).json()
  for source in catalog['sources']:
   response=await page.request.get('http://localhost:8093/preview/room13-pixel-art/'+source['file']);assert response.status==200,source
  result['source_requests']=len(catalog['sources'])
  result['coverage']=catalog['coverage']
  result['broken_images']=await page.evaluate('Array.from(document.images).filter(x=>x.complete && !x.naturalWidth).map(x=>x.src)')
  assert not result['broken_images'];assert not result['mobile']['overflow'];assert not errors
  download=await page.request.head('http://localhost:8093/preview/room13-pixel-art/downloads/daram-pixel-art.zip')
  assert download.status==200
  result['download_bytes']=int(download.headers['content-length'])
  ctx=await browser.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True)
  touch=await ctx.new_page()
  await touch.goto('http://localhost:8093/preview/room13-pixel-art/',wait_until='networkidle')
  await touch.locator('[data-tab=cast]').tap()
  assert await touch.locator('#castgrid .card').count()==12
  await touch.locator('[data-kind=support]').tap()
  assert await touch.locator('#castgrid .card').count()==31
  await touch.locator('[data-tab=cinematics]').tap()
  assert await touch.locator('#spoilers').get_attribute('open') is None
  await touch.locator('#spoilers summary').tap()
  await touch.wait_for_function('document.querySelectorAll("#cggrid .card").length===12')
  result['mobile']['touch_navigation']=True
  await ctx.close()
  (OUT/'report.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
  await browser.close()
asyncio.run(main())
