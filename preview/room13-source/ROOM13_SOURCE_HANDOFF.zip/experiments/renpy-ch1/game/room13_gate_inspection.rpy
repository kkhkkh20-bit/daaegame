# The two records share one physical bundle on the gate shelf. Legacy object
# keys and their checkmarks survive; only their separate scene hitboxes retire.
init 63 python:
    R13_GATE_DOCUMENTS = {
        "G1": dict(object="booth", tab="예약 원본", heading="예약 원본 · 동행 인원", text="보호자와 동행 아동, 두 사람이 적혀 있다."),
        "G3": dict(object="ledger", tab="옮겨 쓴 명부", heading="옮겨 쓴 명부 · 동행 인원", text="예약 원본에서 옮긴 사본에는 어른 한 명만 적혀 있다."),
    }
    ROOM13["objects"]["gate"]["gate_documents"] = dict(
        rect=[1034,342,159,111], text="초소 선반에 예약 원본과 옮겨 쓴 명부가 함께 놓여 있다.",
        need=[], give=[], flags=[], inspection_bundle="gate_documents")
    for r13_gate_legacy_key in ("booth", "ledger"):
        ROOM13["objects"]["gate"][r13_gate_legacy_key]["inspection_child"] = "gate_documents"
    R13_OBJECT_NAMES["gate_documents"] = "초소 서류"

    def r13_gate_document_art():
        # Enlarge the shelf from the actual adopted gate background. Text is
        # rendered separately; no invented replacement document art is used.
        return Transform(Crop((1026,328,182,140), r13_background("winter")),
            size=(468,360), nearest=True)

    def r13_gate_record_document(key):
        if store.room13["location"] != "gate" or key not in R13_GATE_DOCUMENTS:
            return False
        object_key=R13_GATE_DOCUMENTS[key]["object"]
        rect=ROOM13["objects"]["gate"][object_key]["rect"]
        r13_mark(object_key,rect[0]+rect[2]//2,rect[1]+rect[3]//2)
        r13_flag("observed:gate:"+object_key)
        if key in store.room13["evidence"]:
            return False
        r13_grant([key],"초소 선반의 서류를 확대해 직접 확인")
        if all(item in store.room13["evidence"] for item in ("G1","G3")):
            rect=ROOM13["objects"]["gate"]["gate_documents"]["rect"]
            r13_mark("gate_documents",rect[0]+rect[2]//2,rect[1]+rect[3]//2)
        return True

    def r13_gate_record_comparison():
        # Document ownership alone never implies that the player compared them.
        if store.room13["location"]!="gate": return False
        r13_flag("gate_documents_compared", "observed:gate:booth", "observed:gate:ledger")
        r13_grant(["G1","G3"],"원본과 사본의 동행 아동 칸을 직접 비교")
        rect=ROOM13["objects"]["gate"]["gate_documents"]["rect"]
        r13_mark("gate_documents",rect[0]+rect[2]//2,rect[1]+rect[3]//2)
        return True

    def r13_visible_check(key, point):
        # Old-save child marks remain stored, but are never separate field ticks.
        return key not in ("gate:booth", "gate:ledger", "gate:gate_documents")

    def r13_gate_bundle_check_point():
        # Synthesize the same single mark for old saves with both records.
        if store.room13["location"] != "gate" or not all(item in store.room13["evidence"] for item in ("G1","G3")):
            return None
        x,y,w,h=ROOM13["objects"]["gate"]["gate_documents"]["rect"]
        return (x+w//2,y+h//2)

init 67 python:
    # Runs after the existing family-desk visibility wrapper. Direct legacy
    # calls still reach the popup through r13_object's early interception.
    r13_before_gate_bundle_visible = r13_object_visible
    def r13_object_visible(spec):
        if spec.get("inspection_child") == "gate_documents":
            return False
        return r13_before_gate_bundle_visible(spec)

label r13_inspect_gate_documents(start_key=None):
    $ r13_gate_selected="G3" if start_key=="ledger" else "G1"
    $ r13_flag("observed:gate:gate_documents")
    while True:
        call screen r13_gate_document_inspection(r13_gate_selected)
        if not isinstance(_return,tuple) or len(_return)!=2:
            return
        if _return[0]=="compare" and _return[1] in ("child","count"):
            $ r13_gate_record_comparison()
        elif _return[0]=="record" and _return[1] in R13_GATE_DOCUMENTS:
            $ r13_gate_selected=_return[1]
            $ r13_gate_record_document(r13_gate_selected)
        else:
            return
    return

screen r13_gate_document_inspection(initial="G1"):
    style_prefix "r13"
    modal True
    zorder 70
    default left_field=None
    default right_field=None
    default feedback="두 서류에서 서로 다른 항목을 하나씩 눌러 비교해 보자."
    $ compared=r13_has("gate_documents_compared")
    add Solid("#081311df")
    frame:
        area (40,60,1200,600) padding (0,0)
        background R13ActionPanel()
    text "초소 서류 · 나란히 비교" xpos 70 ypos 83 size 29 color "#fff2cf"
    textbutton "닫기":
        style "r13_action_button" xpos 1090 ypos 77 xsize 115 ysize 56 text_size 23
        action Return(False)
    key "game_menu" action Return(False)
    for column,key in enumerate(("G1","G3")):
        $ doc_x=70+column*575
        $ selected_field=(left_field if column==0 else right_field) or ("child" if compared else None)
        frame:
            area (doc_x,155,550,333) padding (22,18)
            background R13PaperPanel(False)
        text R13_GATE_DOCUMENTS[key]["tab"] xpos doc_x+24 ypos 173 size 28 color "#765426"
        text "동행 등록" xpos doc_x+24 ypos 218 size 22 color "#536158"
        for index,field in enumerate(("adult","child","count")):
            $ field_label={"adult":"보호자","child":"동행 아동","count":"등록 인원"}[field]
            $ field_value={"G1":{"adult":"1명","child":"다람이","count":"2명"},"G3":{"adult":"1명","child":"—","count":"1명"}}[key][field]
            button:
                area (doc_x+18,258+index*68,514,62) padding (14,10)
                background Solid(("#dae5c9" if compared else "#e8d7ae") if selected_field==field else "#f5efdf")
                hover_background Solid("#e8d7ae")
                action SetScreenVariable("left_field" if column==0 else "right_field",field)
                alt R13_GATE_DOCUMENTS[key]["tab"]+" · "+field_label+" · "+field_value
                fixed:
                    xsize 480 ysize 42
                    text field_label xpos 0 ypos 0 size 28 color "#493e2d" xsize 280
                    text field_value xpos 310 ypos 0 size 30 color ("#8c3937" if compared and key=="G3" and field=="child" else "#342a23") xsize 170 text_align 1.0
        textbutton ("기록됨" if key in room13["evidence"] else "이 서류 기록"):
            style "r13_action_button" xpos doc_x+330 ypos 170 xsize 194 ysize 54 text_size 21
            sensitive key not in room13["evidence"] action Return(("record",key))
    text ("비교 기록: 사본에서 동행 아동이 빠졌다." if compared else feedback):
        xpos 70 ypos 512 xsize 1100 size 24 color ("#c4e3c8" if compared else "#fff2cf")
    textbutton ("비교 기록 완료" if compared else "선택한 항목 비교하기"):
        style "r13_action_button" xpos 70 ypos 582 xsize 440 ysize 58 text_size 25
        sensitive not compared and left_field is not None and right_field is not None
        action (Return(("compare",left_field)) if left_field==right_field and left_field in ("child","count") else SetScreenVariable("feedback","보호자는 양쪽 모두 한 명이다. 다른 항목도 살펴보자." if left_field==right_field else "같은 항목끼리 나란히 비교해 보자."))
    text "기록한 서류는 돌목에게 제시할 수 있다.":
        xpos 545 ypos 597 size 22 color "#d6bd84"
