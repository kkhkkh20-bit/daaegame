# The two records share one physical bundle on the gate shelf. Legacy object
# keys and their checkmarks survive; only their separate scene hitboxes retire.
init 63 python:
    R13_GATE_DOCUMENTS = {
        "G1": dict(object="booth", tab="예약 원본", heading="예약 원본 · 동행 인원", text="보호자와 동행 아동, 두 사람이 적혀 있다."),
        "G3": dict(object="ledger", tab="옮겨 쓴 명부", heading="옮겨 쓴 명부 · 동행 인원", text="예약 원본에서 옮긴 사본에는 어른 한 명만 적혀 있다."),
    }
    ROOM13["objects"]["gate"]["gate_documents"] = dict(
        rect=[1034,342,159,111], text="초소 선반에 예약 원본과 옮겨 쓴 명부가 함께 놓여 있다.",
        need=[], give=[], flags=[], inspection_bundle="gate_documents")
    for r13_gate_legacy_key in ("booth", "ledger"):
        ROOM13["objects"]["gate"][r13_gate_legacy_key]["inspection_child"] = "gate_documents"
    R13_OBJECT_NAMES["gate_documents"] = "초소 서류"

    def r13_gate_document_art():
        # Enlarge the shelf from the actual adopted gate background. Text is
        # rendered separately; no invented replacement document art is used.
        return Transform(Crop((1026,328,182,140), r13_background("winter")),
            size=(468,360), nearest=True)

    def r13_gate_record_document(key):
        if store.room13["location"] != "gate" or key not in R13_GATE_DOCUMENTS:
            return False
        object_key=R13_GATE_DOCUMENTS[key]["object"]
        rect=ROOM13["objects"]["gate"][object_key]["rect"]
        r13_mark(object_key,rect[0]+rect[2]//2,rect[1]+rect[3]//2)
        r13_flag("observed:gate:"+object_key)
        if key in store.room13["evidence"]:
            return False
        r13_grant([key],"초소 선반의 서류를 확대해 직접 확인")
        if all(item in store.room13["evidence"] for item in ("G1","G3")):
            rect=ROOM13["objects"]["gate"]["gate_documents"]["rect"]
            r13_mark("gate_documents",rect[0]+rect[2]//2,rect[1]+rect[3]//2)
        return True

    def r13_visible_check(key, point):
        # Old-save child marks remain stored, but are never separate field ticks.
        return key not in ("gate:booth", "gate:ledger", "gate:gate_documents")

    def r13_gate_bundle_check_point():
        # Synthesize the same single mark for old saves with both records.
        if store.room13["location"] != "gate" or not all(item in store.room13["evidence"] for item in ("G1","G3")):
            return None
        x,y,w,h=ROOM13["objects"]["gate"]["gate_documents"]["rect"]
        return (x+w//2,y+h//2)

init 67 python:
    # Runs after the existing family-desk visibility wrapper. Direct legacy
    # calls still reach the popup through r13_object's early interception.
    r13_before_gate_bundle_visible = r13_object_visible
    def r13_object_visible(spec):
        if spec.get("inspection_child") == "gate_documents":
            return False
        return r13_before_gate_bundle_visible(spec)

label r13_inspect_gate_documents(start_key=None):
    $ r13_gate_selected="G3" if start_key=="ledger" else "G1"
    $ r13_flag("observed:gate:gate_documents")
    while True:
        call screen r13_gate_document_inspection(r13_gate_selected)
        if not isinstance(_return,tuple) or len(_return)!=2 or _return[0]!="record" or _return[1] not in R13_GATE_DOCUMENTS:
            return
        $ r13_gate_selected=_return[1]
        $ r13_gate_record_document(r13_gate_selected)
    return

screen r13_gate_document_inspection(initial="G1"):
    style_prefix "r13"
    modal True
    zorder 70
    default document_key=initial
    $ document=R13_GATE_DOCUMENTS[document_key]
    $ recorded=document_key in room13["evidence"]
    $ recorded_count=sum(1 for item in ("G1","G3") if item in room13["evidence"])
    add Solid("#081311ce")
    frame:
        area (65,95,1150,545) padding (0,0)
        background R13ActionPanel()
    text "초소 서류" xpos 100 ypos 115 size 30 color "#fff2cf"
    text "예약 원본과 옮겨 쓴 명부를 확인한다" xpos 100 ypos 157 size 19 color "#d6bd84"
    text ("서류 확인 완료 · 2/2" if recorded_count==2 else "기록한 서류 · %d/2"%recorded_count):
        xpos 600 ypos 159 size 20 color "#d6bd84"
    textbutton "닫기":
        style "r13_action_button" xpos 1090 ypos 113 xsize 92 ysize 52 text_size 20
        action Return(False)
    key "game_menu" action Return(False)
    add r13_gate_document_art() xpos 100 ypos 204
    text "초소 선반":
        xpos 100 ypos 581 xsize 468 text_align .5 size 20 color "#d6bd84"
    hbox:
        xpos 600 ypos 204 spacing 12
        for item in ("G1","G3"):
            textbutton R13_GATE_DOCUMENTS[item]["tab"]:
                style "r13_action_button" xsize 262 ysize 54 text_size 22
                selected document_key==item action SetScreenVariable("document_key",item)
    text document["heading"] xpos 600 ypos 288 xsize 540 size 25 color "#f4d08a"
    text document["text"] xpos 600 ypos 341 xsize 535 size 27 color "#fff4df" line_spacing 10
    text ("수첩에 기록됨 · 다시 읽는 중" if recorded else "아직 수첩에 기록하지 않은 자료"):
        xpos 600 ypos 465 xsize 540 size 21 color ("#a8c9b3" if recorded else "#e0bf83")
    textbutton ("기록 완료" if recorded else "기록하기"):
        style "r13_action_button" xpos 600 ypos 538 xsize 300 ysize 62 text_size 25
        action Return(("record",document_key)) sensitive not recorded
    text "원본과 사본의 차이는 제시하며 설명할 수 있다.":
        xpos 922 ypos 535 xsize 250 size 18 color "#c8c3b6" line_spacing 5
