# Called by r13_scene after its existing fade to black. This file owns only
# arrival presentation; it never advances the clock or changes the location.
init 59 python:
    def r13_arrival_info(bg,title,mood="calm"):
        state=store.room13
        if not state or mood in ("travel","hearing"):
            return None
        location=state.get("location")
        actual=R13_PLACES.get(location)
        # Several scripted scenes deliberately reuse a background while the
        # exploration location still points elsewhere. Only canonical arrivals
        # qualify, never carriage, courtroom, visits, flashbacks or epilogues.
        if not actual or (title,bg)!=tuple(actual):
            return None
        key=(state["day"],state["period"],location,state.get("case_state"))
        if key in state.get("arrival_seen",[]):
            return None
        return dict(key=key,clock=r13_clock(),place=title)

    def r13_arrival_claim(bg,title,mood="calm"):
        info=r13_arrival_info(bg,title,mood)
        if info is None:
            return None
        # Replace the entire snapshot, just like r13_edit/r13_flag. The record
        # travels with saves and rollback, never persistent cross-playthrough
        # state. Claim before the interaction so loading during it cannot add a
        # second arrival after the displayed card is dismissed.
        state=winter_copy.deepcopy(store.room13)
        state["arrival_seen"]=list(state.get("arrival_seen",[]))+[info["key"]]
        store.room13=state
        return info

transform r13_arrival_reveal:
    alpha 0.0
    linear .16 alpha 1.0

screen r13_arrival_card(info):
    modal True
    zorder 200
    add Solid("#050607")
    key "dismiss" action Return()
    button:
        xfill True
        yfill True
        padding (0,0)
        background None
        hover_background None
        action Return()
        alt (info["clock"]+". "+info["place"]+". 클릭하여 계속")
        vbox:
            xalign .5
            yalign .48
            spacing 20
            at r13_arrival_reveal
            text info["clock"]:
                xalign .5
                size 25
                color "#c0b69e"
                text_align .5
            text info["place"]:
                xalign .5
                size 39
                color "#f3e8cd"
                text_align .5

label r13_arrival(bg,title,mood="calm"):
    $ r13_arrival_packet=r13_arrival_claim(bg,title,mood)
    if r13_arrival_packet and not renpy.is_skipping():
        call screen r13_arrival_card(r13_arrival_packet)
        with Dissolve(.12)
    return
