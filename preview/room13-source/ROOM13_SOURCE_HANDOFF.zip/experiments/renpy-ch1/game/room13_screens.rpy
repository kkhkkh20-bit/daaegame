screen r13_hud():
    style_prefix "r13"
    zorder 20
    frame:
        xpos 24 ypos 20 xsize 654 ysize 70 padding (18,12)
        background R13ActionPanel()
        hbox:
            spacing 22
            text r13_clock() size 19 color "#d6b779" yalign .5
            add Solid("#8a7958",xsize=2,ysize=36) yalign .5
            text place size 22 color "#fff2cf" xsize 310 yalign .5
    hbox:
        xpos 722 ypos 23 spacing 8
        textbutton "달력" style "r13_action_button" action Show("r13_calendar") text_size 19 xsize 170 ysize 64
        textbutton "수첩" style "r13_action_button" action Show("r13_book") text_size 19 xsize 170 ysize 64
        textbutton "설정" style "r13_action_button" action ShowMenu("pause_menu") text_size 19 xsize 170 ysize 64

screen r13_hub(entry=False):
    style_prefix "r13"
    modal True
    default ready=False
    timer .35 action SetScreenVariable("ready",True)
    # Background targets stay behind the visible residents.
    for key,spec in ROOM13["objects"].get(room13["location"],{}).items():
        if r13_object_visible(spec):
            button:
                area tuple(spec["rect"])
                background None hover_background None insensitive_background None padding (0,0)
                action Return(("object",key)) sensitive ready
                tooltip r13_object_name(key)
    use r13_resident_stage(entry,ready)
    for nameplate in r13_actor_nameplates(r13_stage_people(entry)):
        if nameplate["leader"]:
            $ leader=R13NameLeader(nameplate["leader"])
            add leader xpos leader.left ypos leader.top
        textbutton R13_NAMES[nameplate["person"]]:
            area nameplate["rect"]
            padding (12,7) background R13ActionPanel() text_size 18 text_color "#fff2cf"
            action Return(("person",nameplate["person"])) sensitive ready
    if room13["location"] in ("room13","guestroom"):
        textbutton "‹ 복도":
            xpos 24 ypos 108 padding (15,12) background R13ActionPanel() text_color "#fff2cf"
            action Return(("menu","doorway")) sensitive ready text_size 21
    elif room13["location"]=="hall" and r13_has("lodging"):
        textbutton "13호실 안으로 ›":
            xpos 24 ypos 108 padding (15,12) background R13ActionPanel() text_color "#fff2cf"
            action Return(("menu","room_inside")) sensitive ready text_size 21
    if entry:
        button:
            area (24,110,206,154) padding (10,8) background R13ActionPanel()
            action Return(("person","daram")) sensitive ready
            hbox:
                spacing 8
                add Transform(r13_art("daram","avatar_thinking"),size=(92,112),fit="contain",nearest=True):
                    id "r13_waiting_daram"
                    at r13_actor_appear(r13_appearance_duration())
                vbox:
                    yalign .5 spacing 10
                    text "다람이" size 21 color "#fff2cf"
                    text "대기소\n안쪽" size 18 color "#d6bd84"
    else:
        textbutton "지도 · 이동":
            style "r13_action_button" xpos 1075 ypos 642 xsize 180 ysize 62
            text_size 23 action Return(("menu","map")) sensitive ready
    for key,point in room13["checks"].items():
        if key.startswith(room13["location"]+":"):
            add TopicTick() xpos point[0]-13 ypos point[1]-13
    $ hint=GetTooltip()
    if hint:
        frame:
            xpos 24 ypos 580 padding (14,9) background R13ActionPanel()
            text hint size 20 color "#fff2cf"

screen r13_resident_stage(entry=False,ready=False):
    for actor in r13_stage_people(entry):
        add r13_staged_visible_art(actor):
            id ("r13_world_"+actor["person"])
            xpos actor["x"] ypos actor["y"]
            at r13_actor_appear(r13_appearance_duration())
        button:
            area tuple(actor["rect"]) background None hover_background None insensitive_background None padding (0,0)
            focus_mask r13_actor_hit_mask(actor)
            action Return(("person",actor["person"])) sensitive ready
            tooltip (R13_NAMES[actor["person"]]+"에게 말 걸기")


screen r13_entry_topics():
    style_prefix "r13"
    modal True
    default ready=False
    timer .35 action SetScreenVariable("ready",True)
    add r13_close_art("guard","interview_neutral",760):
        id "r13_topics_guard"
        xpos 272 xanchor .5 ypos r13_close_y("guard",760,126,"interview_neutral")
        at r13_actor_appear(r13_appearance_duration())
    frame:
        area (555,170,690,440) padding (24,22) background R13ActionPanel()
        vbox:
            spacing 18
            text "돌목에게 묻기" size 29 color "#efd092"
            textbutton "아이와 따로 확인하는 이유" action Return(("entry","explain")) xsize 642 yminimum 70 sensitive ready
            textbutton "확인한 자료로 이야기한다" action Return(("entry","argue")) xsize 642 yminimum 70 sensitive ready
            textbutton "원본 대조를 요청하고 기다린다" action Return(("entry","wait")) xsize 642 yminimum 70 sensitive ready
            textbutton "대화 종료 · 주변 살피기" style "r13_action_button" action Return(("entry","back")) xsize 642 yminimum 64 sensitive ready

screen r13_entry_karo_topics():
    style_prefix "r13"
    modal True
    default ready=False
    timer .35 action SetScreenVariable("ready",True)
    add r13_close_art("karo","interview_neutral",760):
        id "r13_topics_karo"
        xpos 272 xanchor .5 ypos r13_close_y("karo",760,126,"interview_neutral")
        at r13_actor_appear(r13_appearance_duration())
    frame:
        area (555,170,690,440) padding (24,22) background R13ActionPanel()
        vbox:
            spacing 18
            text "까로에게 묻기" size 29 color "#efd092"
            textbutton "마차는 괜찮습니까?" action Return("road") xsize 642 yminimum 70 sensitive ready
            textbutton "함께 왔다고 말해 주시겠어요?" action Return("witness") xsize 642 yminimum 70 sensitive ready
            textbutton "짐 좀 부탁합니다" action Return("bags") xsize 642 yminimum 70 sensitive ready
            textbutton "대화 종료" style "r13_action_button" action Return("back") xsize 642 yminimum 64 sensitive ready

# Kept as a save-compatible screen name; people open their topics directly.
screen r13_interaction(person):
    use r13_topics(person)

screen r13_material_corner(key):
    style_prefix "r13"
    zorder 15
    frame:
        area (35,172,222,230) padding (13,12)
        background R13QuestionBar(False)
        vbox:
            spacing 8
            add Transform(r13_icon(key),size=(190,143),fit="contain") xalign .5
            text ROOM13["evidence"][key]["name"] size 19 color "#342a23" xsize 192 text_align .5

# The resident stays on the left; opaque questions never cover the face.
screen r13_topics(person):
    style_prefix "r13"
    modal True
    default ready=False
    timer .35 action SetScreenVariable("ready",True)
    $ actor_pose=r13_conversation_pose(person)
    add r13_close_art(person,actor_pose,760):
        id ("r13_topics_"+person)
        xpos 272 xanchor .5 ypos r13_close_y(person,760,126,actor_pose)
        at r13_actor_appear(r13_appearance_duration())
    frame:
        area (555,165,690,530) padding (24,20) background R13ActionPanel()
        vbox:
            spacing 18
            text (R13_NAMES[person]+"에게 묻기") size 29 color "#f6d18a"
            viewport:
                xsize 642 ysize 348
                mousewheel True draggable True scrollbars "vertical"
                vbox:
                    spacing 12
                    for key,spec in r13_topics(person):
                        button:
                            xsize 623 yminimum 80 padding (22,16)
                            background R13QuestionBar(False)
                            hover_background R13QuestionBar(True)
                            insensitive_background R13QuestionBar(False)
                            action Return(key) sensitive ready
                            text (("읽음 · " if key in room13["read_topics"] else "")+spec["title"]):
                                xsize 579 size 24
                                color ("#6b665b" if key in room13["read_topics"] else "#272c2b")
                                outlines []
                    if not r13_topics(person):
                        text "지금 더 물을 이야기는 없다. 가지고 온 자료를 보여줄 수도 있다." size 24 color "#fff4df" xsize 610
            hbox:
                spacing 14
                textbutton (R13_NAMES[person]+"에게 자료 제시") style "r13_action_button" action Return("present") sensitive ready xsize 314 ysize 64
                textbutton "돌아가기" style "r13_action_button" action Return("back") sensitive ready xsize 314 ysize 64

screen r13_confirm(message,yes="진행한다",no="돌아간다"):
    style_prefix "r13"
    modal True
    zorder 65
    default ready=False
    timer .35 action SetScreenVariable("ready",True)
    add Solid("#172a2aa6")
    frame:
        xpos 165 ypos 210 xsize 950 padding (32,28)
        vbox:
            spacing 25
            text message size 26 xsize 880
            hbox:
                spacing 25
                textbutton yes action Return(True) sensitive ready text_size 25
                textbutton no action Return(False) sensitive ready text_size 25

screen r13_activities():
    style_prefix "r13"
    modal True
    zorder 45
    default ready=False
    timer .35 action SetScreenVariable("ready",True)
    add Solid("#172a2aa6")
    frame:
        area (180,160,920,495) padding (26,25)
        vbox:
            spacing 20
            text "이곳에서 할 수 있는 일" size 32 color "#765426"
            viewport:
                xsize 850 ysize 305 draggable True mousewheel True scrollbars "vertical"
                vbox:
                    spacing 16
                    for key,a in r13_actions():
                        textbutton (a["title"]+(" · "+r13_time_target() if a.get("cost",1) else "")):
                            action Return(key) sensitive ready and (room13["period"]<3 or not a.get("cost",1)) xsize 810 text_size 24
                    if not r13_actions():
                        text "주변을 살피거나 주민과 이야기하며 확인할 일을 찾아보자." size 24 xsize 780
            textbutton "돌아가기" action Return(False) sensitive ready

screen r13_book(target=None,present=False,hearing=False):
    style_prefix "r13"
    modal True
    zorder 50
    default detail=None
    default ready=False
    default archive=False
    timer .35 action SetScreenVariable("ready",True)
    add R13NotebookPaper()
    text ("자료 제시 · "+R13_NAMES.get(target,"재판") if present else "다람이의 수첩") xpos 55 ypos 28 size 32 color "#765426"
    if target:
        add Transform(r13_art(target,"avatar_neutral"),size=(75,80),fit="contain") xpos 1155 ypos 15
    if not present:
        hbox:
            xpos 55 ypos 82 spacing 18
            textbutton "이번 여정의 자료" action [SetScreenVariable("archive",False),SetScreenVariable("detail",None)] sensitive ready text_size 20
            textbutton "이전에 발견한 사실" action [SetScreenVariable("archive",True),SetScreenVariable("detail",None)] sensitive ready text_size 20
            textbutton "만난 사람들" action Show("r13_resident_notes") sensitive ready text_size 20
    $ entries=persistent.room13_knowledge if archive else room13["evidence"]
    viewport:
        area (45,150,535,465) mousewheel True draggable True scrollbars "vertical"
        vbox:
            spacing 10
            for key in entries:
                if key in ROOM13["evidence"]:
                    button:
                        xsize 505 yminimum 78 padding (10,6)
                        background R13PaperPanel(detail==key)
                        action SetScreenVariable("detail",key) sensitive ready
                        hbox:
                            spacing 16
                            add Transform(r13_icon(key),size=(62,66),fit="contain")
                            text ROOM13["evidence"][key]["name"] size 21 xsize 385 yalign .5
            if not entries:
                text "아직 기록한 자료가 없다." size 23
    if not detail:
        text ("보여 줄 자료를 골라 내용을 확인하세요." if present else "기록을 펼쳐 그때의 단서를 되짚어 보세요.") xpos 650 ypos 335 xsize 520 size 24 color "#85806e" text_align .5
    if detail:
        $ ev=ROOM13["evidence"][detail]
        text ev["name"] xpos 625 ypos 155 xsize 595 size 29 color "#765426"
        viewport:
            area (625,205,595,365) mousewheel True draggable True scrollbars "vertical"
            vbox:
                spacing 15
                hbox:
                    spacing 20
                    add Transform(r13_icon(detail),size=(155,110),fit="contain")
                    text ev["kind"] size 20 color "#69756a" yalign .5
                text ev["establishes"] size 24 xsize 555
                text ev["does_not_establish"] size 22 xsize 555 color "#68695f"
                if archive:
                    text "이전 여정에서 발견한 사실. 이번 여정의 증거로 제출할 수 없다." xsize 555 size 22 color "#975c32"
                elif detail in room13["records"]:
                    $ rec=room13["records"][detail]
                    text ("%d일째 · %s\n%s"%(rec["day"],R13_PLACES.get(rec["place"],(rec["place"],))[0],rec["source"])) xsize 555 size 20 color "#69756a"
        if present:
            textbutton ("이 주장에 근거로 낸다" if hearing else R13_NAMES.get(target,"상대")+"에게 보여주기"):
                xpos 625 ypos 576 action Return(detail) sensitive ready text_size 24
    textbutton ("제시 취소" if present else "닫기"):
        xpos 55 ypos 650 action (Return(False) if present else Hide("r13_book")) sensitive ready

screen r13_calendar():
    style_prefix "r13"
    modal True
    zorder 55
    default week=(room13["day"]-1)//7
    add Solid("#243732b0")
    add R13PaperPanel() xpos 30 ypos 20 xsize 1220 ysize 685
    text "여행 수첩 · 달력" xpos 60 ypos 35 size 35 color "#765426"
    for i,dayname in enumerate(("월","화","수","목","금","토","일")):
        text dayname xpos 80+i*170 ypos 106 size 24
    for day in range(week*7+1,week*7+8):
        frame:
            area (55+((day-1)%7)*170,155,155,150)
            background R13PaperPanel(day==room13["day"]) padding (14,14)
            vbox:
                spacing 17
                text (str(day)+"일") size 25
                if day==room13["day"]:
                    text "오늘" size 20 color "#765426"
                elif day<room13["day"]:
                    text "지난 날" size 18
    text "확인한 약속" xpos 60 ypos 420 size 26 color "#765426"
    text ("내일 동틀 무렵 · 제단으로 호송한다는 통보를 받았다." if room13["day"]==13 and "day13_warning" in room13.get("events",[]) else "목요일 저녁 · 어르신과 만나기로 했다." if room13["day"]<=4 and r13_has("elder_appointment") else "일요일 · 다람이의 사건을 주민 앞에서 다룬다." if room13["day"]<=7 and r13_has("trial_notice") else "날짜가 정해진 새 약속은 아직 없다.") xpos 60 ypos 467 size 23 xsize 1110
    textbutton "닫기" xpos 60 ypos 650 action Hide("r13_calendar")
    if week>0:
        textbutton "지난 주" xpos 700 ypos 650 action SetScreenVariable("week",week-1)
    textbutton "다음 주" xpos 970 ypos 650 action SetScreenVariable("week",week+1)

screen r13_debate(claim):
    style_prefix "r13"
    modal True
    default ready=False
    timer .35 action SetScreenVariable("ready",True)
    frame:
        area (50,155,1180,425) padding (26,22) background R13PaperPanel()
        vbox:
            spacing 22
            text R13_CLAIMS[claim]["assertion"] size 32 color "#765426"
            text "내가 제시한 근거" size 23
            viewport:
                xsize 1110 ysize 180 draggable True mousewheel True scrollbars "vertical"
                vbox:
                    spacing 7
                    for key in room13["arguments"].get(claim,[]):
                        text ("· "+ROOM13["evidence"][key]["name"]) size 22
                    if not room13["arguments"].get(claim):
                        text "아직 제시하지 않았다." size 22 color "#817e70"
            hbox:
                spacing 18
                textbutton "근거 제시" action Return("present") sensitive ready
                textbutton "되묻기" action Return("press") sensitive ready
                textbutton "논리를 연결한다" action Return("argue") sensitive ready
                textbutton "이 논점은 남겨 둔다" action Return("leave") sensitive ready text_size 22

screen r13_handoff():
    style_prefix "r13"
    modal True
    zorder 40
    add Solid("#172a2aa6")
    frame:
        area (175,135,930,465) padding (35,30)
        vbox:
            spacing 25
            text "13호 사건 · 둘째 주 이어가기" size 35 color "#765426"
            text "이전 개발본의 끝에 도착했습니다.\n이번 판결과 구금 상태를 유지하며 계속합니다." size 27 xsize 840
            text ("다람이: "+("아빠와 동행" if room13["daram_state"]=="with_dad" else "보호시설에 구금")+"\n할머니: "+("구금" if room13["granny_state"]=="detained" else "자유 상태")) size 25
            text "이 화면은 이야기 속 엔딩이 아닙니다." size 22 color "#717367"
            hbox:
                spacing 18
                textbutton "저장하기" action ShowMenu("save")
                textbutton "이어서 진행" action [Hide("r13_handoff"),Jump("r13_week2_opening")]
                textbutton "제목으로" action MainMenu(confirm=False)
