# Explicit reading preference works on desktop and web, independent of Ren'Py
# device variants. It affects presentation only, never story or text speed.
default persistent.room13_large_text = False

init 58 python:
    def r13_read_size(base, large=None):
        if not persistent.room13_large_text:
            return int(base)
        return int(large if large is not None else max(base+4,round(base*1.25)))

    def r13_read_row_height(base=76):
        return int(base+20 if persistent.room13_large_text else base)
