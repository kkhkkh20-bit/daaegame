# Authored acting and physical staging. These are presentation choices only;
# they never change the clock, evidence, relationships, or resident schedules.
default r13_current_pose = "neutral"

init 59 python:
    R13_ACTING = json.load(renpy.file("assets/room13-pixel-acting.json")) if renpy.loadable("assets/room13-pixel-acting.json") else {}
    R13_LINE_DIRECTION = json.load(renpy.file("assets/room13-line-direction.json")) if renpy.loadable("assets/room13-line-direction.json") else {}
    R13_PORTRAITS = json.load(renpy.file("assets/room13-portraits.json")) if renpy.loadable("assets/room13-portraits.json") else {}

    def r13_portrait_pose(person,pose):
        key=pose[10:] if pose.startswith("interview_") else pose
        poses=R13_PORTRAITS.get(person,{})
        if key in poses:return key
        if key in ("joy",):return "expressive"
        if key in ("panic","breakdown"):return "distressed"
        if "read" in key or key=="thinking":return "thinking"
        return key if key in ("neutral","distressed","expressive") else "neutral"

    def r13_close_spec(person,pose):
        return R13_PORTRAITS.get(person,{}).get(r13_portrait_pose(person,pose))

    def r13_close_geometry(person,pose):
        spec=r13_close_spec(person,pose)
        return tuple(spec["crop"][2:]) if spec else r13_actor_geometry(person,pose)

    def r13_close_head(person,pose):
        spec=r13_close_spec(person,pose)
        return spec["head"] if spec else r13_acting_head(person,pose)

    R13_WORLD_PIXEL_GRID = 2
    R13_CLOSE_PIXEL_GRID = 3

    def r13_pixel_scale(art,width,height,grid):
        width=max(1,int(round(width)));height=max(1,int(round(height)))
        if grid>1:
            # Flatten creates an actual low-resolution render texture. Merely
            # composing two scales can otherwise preserve the full-res source.
            low=Transform(art,size=(max(1,width//grid),max(1,height//grid)),nearest=True,subpixel=False)
            art=Flatten(low)
        return Transform(art,size=(width,height),nearest=True,subpixel=False,rotate_pad=False)

    def r13_acting_spec(person,pose):
        poses=R13_ACTING.get(person,{})
        key=pose[10:] if pose.startswith("interview_") else pose
        return poses.get(key) or (poses.get("neutral") if key in ("world","inn_activity","activity") else None)

    def r13_actor_geometry(person,pose):
        spec=r13_acting_spec(person,pose)
        if spec:return tuple(spec["crop"][2:])
        if person=="daram":return tuple(R13_PIXEL_MOTION["canvas"])
        states=CAST[person]
        return tuple(states.get(pose,states["neutral"])["crop"][2:])

    def r13_acting_head(person,pose):
        spec=r13_acting_spec(person,pose)
        if not spec:return None
        if spec.get("head"):return spec["head"]
        emotion=pose[10:] if pose.startswith("interview_") else pose
        avatar=R13_ACTING.get(person,{}).get("avatar_"+emotion)
        if avatar and avatar["file"]==spec["file"]:
            ax,ay,aw,ah=avatar["crop"];x,y,w,h=spec["crop"]
            if x<=ax and y<=ay and ax+aw<=x+w and ay+ah<=y+h:
                return [ax-x,ay-y,aw,ah]
        return None

    def r13_close_scale(person,pose,height):
        width,native_height=r13_close_geometry(person,pose)
        head=r13_close_head(person,pose)
        if head:
            # Different body poses retain a readable face. In particular a
            # crouched child or hanging bat must not disappear behind the UI.
            scale=(height*.30)/head[3]
            if r13_close_spec(person,pose):
                # A bust must continue under the dialogue panel or beyond the
                # viewport in topic mode; never leave its cut edge floating.
                extent=445.0 if height>=800 else 574.0
                scale=max(scale,extent/max(1,native_height-head[1]))
                scale=min(scale,(375.0 if height>=800 else 390.0)/head[3])
            return min(scale,(880.0 if height>=800 else 590.0)/width)
        if person=="daram" and not r13_acting_spec(person,pose):native_height-=20
        return float(height)/native_height

    def r13_line_performance(identity,index,packet):
        person,text=packet[:2]
        expression=R13_DIRECTION.get(identity,{}).get(person,"neutral")
        pose=expression
        cue=R13_LINE_DIRECTION.get(identity,{}).get(str(index))
        if cue and cue.get("person")==person and cue.get("text")==text:
            pose=cue["pose"]
            expression=cue.get("expression",pose if pose in ("neutral","thinking","distressed","expressive") else expression)
        if len(packet)>2:
            if isinstance(packet[2],dict):
                expression=packet[2].get("expression",expression)
                pose=packet[2].get("pose",expression)
            else:
                expression=packet[2]
                pose=expression
        if len(packet)>3:pose=packet[3]
        # A missing authored pose is an explicit neutral fallback, never an
        # activity label attached to an unrelated standing sprite.
        if person in R13_ACTING and pose not in R13_ACTING[person]:pose=expression if expression in R13_ACTING[person] else "neutral"
        return expression,pose

    class R13FurnitureMask(renpy.Displayable):
        def __init__(self,points,**kwargs):
            super(R13FurnitureMask,self).__init__(**kwargs)
            self.points=tuple(tuple(point) for point in points)
        def render(self,width,height,st,at):
            result=renpy.Render(1280,720)
            result.canvas().polygon("#ffffff",self.points)
            return result

    def r13_furniture_foreground(points):
        background=R13_PLACES[store.room13["location"]][1]
        return AlphaMask(r13_background(background),R13FurnitureMask(points))

    # All anchors below were read from the adopted 1280x720 room images.
    # Floor areas avoid chairs; hand slots attach to actual writing/work tops.
    R13_STAGE_FLOORS={
        "gate":[(675,610,248),(400,597,224),(850,614,240)],
        "square":[(805,622,258),(1110,634,260),(325,622,236)],
        "inn":[(335,641,285),(135,621,270),(450,619,244)],
        "dining":[(390,595,250),(650,469,202),(885,457,188)],
        "kitchen":[(128,646,275),(796,548,244),(475,550,235)],
        "hall":[(843,586,276),(657,553,243),(1000,645,290)],
        "workshop":[(215,629,275),(473,606,255),(1058,622,270)],
        "post":[(368,645,265),(700,512,222),(1050,548,236)],
        "clinic":[(860,654,277),(1125,654,266),(415,507,235)],
        "school":[(913,642,272),(570,672,284),(604,390,190)],
        "store":[(724,601,246),(558,560,210),(899,653,278)],
        "greenhouse":[(1112,649,260),(1048,524,229),(335,434,186)],
        "facility":[(383,625,267),(770,602,238),(1111,644,250)],
        "room13":[(637,630,276),(947,620,264),(347,623,260)],
        "guestroom":[(637,630,276),(947,620,264),(347,623,260)],
        "altar":[(495,634,263),(735,603,240),(932,632,253)],
        "passage":[(525,634,260),(790,636,260),(980,637,260)],
    }
    R13_STAGE_COUNTERS={
        "inn":[(465,462),(1279,577),(1279,720),(465,720)],
        "workshop":[(349,497),(690,497),(820,462),(1279,479),(1279,720),(349,720)],
        "post":[(366,552),(1030,466),(1030,392),(1279,392),(1279,720),(366,720)],
        "facility":[(434,419),(1101,438),(1101,648),(434,581)],
        "kitchen":[(216,587),(767,644),(1177,575),(1177,720),(216,720)],
        "dining":[(290,482),(685,484),(920,449),(1280,505),(1280,720),(290,720)],
        "greenhouse":[(104,520),(896,579),(995,444),(995,720),(104,720)],
    }

    R13_STAGE_POSITIONS={
        # Resident-specific work areas; each tuple is a floor contact and
        # authored display height, not an evenly spaced cast lineup.
        ("karo","gate"):(245,610,280),
        ("neoul","gate"):(788,614,280),
        ("resident_bori","gate"):(405,600,230),
        ("resident_badook","gate"):(900,617,257),
        ("resident_siluk","gate"):(634,646,255),
        ("resident_kkwak","gate"):(431,610,235),
        ("resident_lamplighter","gate"):(955,630,251),
        ("doto","square"):(1030,624,245),
        ("resident_ppul","square"):(1090,614,237),
        ("resident_seol","square"):(842,581,218),
        ("resident_piko","square"):(339,607,247),
        ("resident_bori","square"):(214,633,253),
        ("resident_somi","square"):(550,638,245),
        ("resident_kongi","square"):(795,618,230),
        ("resident_tori","inn"):(307,644,259),
        ("resident_yeoni","inn"):(152,643,275),
        ("resident_nubi","inn"):(341,642,255),
        ("resident_madam","inn"):(282,648,250),
        ("resident_owlgp","inn"):(168,634,246),
        ("nabi","dining"):(690,666,340),
        ("resident_owlgp","dining"):(377,618,255),
        ("resident_tok","dining"):(904,460,203),
        ("resident_musoe","workshop"):(202,634,283),
        ("resident_ttadak","workshop"):(473,622,250),
        ("resident_tok","workshop"):(657,572,246),
        ("resident_tori","workshop"):(212,635,278),
        ("resident_yeoni","workshop"):(479,616,257),
        ("resident_ubak","workshop"):(453,620,244),
        ("resident_lamplighter","workshop"):(213,634,266),
        ("resident_librarian","post"):(265,626,248),
        ("resident_momo","post"):(654,534,235),
        ("resident_sling","post"):(694,525,239),
        ("resident_seori","clinic"):(846,640,287),
        ("resident_ubak","clinic"):(1085,660,248),
        ("resident_piko","clinic"):(879,638,254),
        ("resident_teacher","school"):(590,700,330),
        ("resident_badook","school"):(931,622,270),
        ("resident_eunho","store"):(930,655,269),
        ("resident_mungchi","store"):(650,610,245),
        ("resident_madam","store"):(930,655,271),
        ("resident_siluk","store"):(694,639,260),
        ("resident_guseul","store"):(875,642,243),
        ("resident_nubi","store"):(916,640,277),
        ("resident_nero","store"):(674,592,230),
        ("resident_kkwak","store"):(840,625,235),
        ("mom","greenhouse"):(650,700,340),
    }
    R13_LIVING_ALLOWED={
        "resident_musoe":("workshop",),
        "resident_piko":("square",),
        "resident_siluk":("gate","store"),
        "resident_eunho":("store","inn"),
        "resident_mungchi":("store","school","clinic"),
        "resident_ubak":("clinic","workshop"),
        "resident_badook":("gate","square"),
    }

    def r13_living_pose(person,location,period):
        poses=R13_ACTING.get(person,{})
        if person in R13_LIVING_ALLOWED and location not in R13_LIVING_ALLOWED[person]:
            return "distressed" if store.room13["day"]>=8 and person=="resident_piko" else "neutral"
        # Main acting sheets explicitly contain action_1/action_2. These
        # choices follow the activity actually drawn in each reviewed cell.
        desired={
            ("granny","inn"):"action_2" if period==1 else "action_1",
            ("guard","gate"):"action_1",
            ("buri","workshop"):"action_2" if period==2 else "action_1",
            ("seryeon","post"):"chair_read" if period==1 else "action_1",
            ("karo","gate"):"action_2" if period==2 else "action_1",
            ("doto","square"):"action_1",
            ("doto","hall"):"action_2" if period==2 else "action_1",
            ("mom","greenhouse"):"action_2" if period==2 else "action_1",
            ("nabi","dining"):"action_1" if period==0 else "action_2",
            ("nabi","inn"):"action_1",
            ("nabi","school"):"action_2",
            ("neoul","gate"):"action_1",
            ("neoul","facility"):"action_2" if period==2 else "action_1",
            ("bami","hall"):"action_2" if period==2 else "action_1",
            ("bami","inn"):"action_2" if period==2 else "action_1",
        }.get((person,location))
        if desired in poses:return desired
        for key in ("living","activity"):
            if key in poses:return key
        authored_living=[key for key in poses if key.startswith("living_")]
        if authored_living:return authored_living[0]
        return "neutral"

    def r13_visible_people():
        people=r13_people()
        limit=2 if store.room13["location"] in ("inn","workshop","post","dining","clinic","school","store","greenhouse","facility","kitchen") else 3
        if not people:return []
        host={"gate":"karo","inn":"granny","dining":"nabi","workshop":"buri",
            "post":"seryeon","clinic":"resident_seori","store":"resident_eunho",
            "school":"resident_teacher","greenhouse":"mom","facility":"neoul",
            "hall":"doto","square":"doto"}.get(store.room13["location"])
        # A narrow room's only free floor rotates too when its host is away.
        if host not in people and store.room13["location"] in ("inn","workshop","post"):
            return [people[((store.room13["day"]-1)*3+min(store.room13["period"],2)*2)%len(people)]]
        primary=[host] if host in people else [people[0]]
        others=[person for person in people if person not in primary]
        if not others:return primary
        start=((store.room13["day"]-1)*3+min(store.room13["period"],2)*2)%len(others)
        rotation=others[start:]+others[:start]
        return primary+rotation[:limit-1]

    def r13_stage_people(entry=False):
        location=store.room13["location"]
        period=min(store.room13["period"],2)
        people=["guard","karo"] if entry else r13_visible_people()
        floors=R13_STAGE_FLOORS.get(location,R13_STAGE_FLOORS["square"])
        staged=[]
        for index,person in enumerate(people):
            pose=r13_living_pose(person,location,period)
            # The post has no free floor beyond its reserved chair. Visitors
            # listen standing behind the counter; their floor activities are
            # shown at other scheduled locations, never on this tabletop.
            if location=="post" and person!="seryeon":pose="neutral"
            spec=r13_acting_spec(person,pose) or {}
            width,height=r13_actor_geometry(person,pose)
            cx,feet,display_height=floors[index%len(floors)]
            cx,feet,display_height=R13_STAGE_POSITIONS.get((person,location),(cx,feet,display_height))
            if location=="inn" and person!="granny" and spec.get("contact")!="hanging":cx,feet,display_height=235,640,260
            if location=="workshop" and person!="buri":cx,feet,display_height=200,637,265
            if location=="post" and person!="seryeon":cx,feet,display_height=830,675,375
            if person=="seryeon" and location=="post" and pose=="action_2":cx,feet,display_height=670,515,247
            if person=="nabi" and location=="dining" and pose=="action_1":cx,feet,display_height=300,710,360
            contact=spec.get("contact","standing")
            # Furniture contact is used only for an actually authored hand
            # position. Self-contained stools always remain on the floor.
            work={
                ("granny","inn"):(935,463,300),
                ("buri","workshop"):(680,488,280),
                ("seryeon","post"):(927,522,330),
                ("guard","gate"):(1180,430,240),
                ("nabi","dining"):(681,475,350),
                ("mom","greenhouse"):(485,476,350),
                ("neoul","facility"):(792,409,330),
            }.get((person,location))
            if person=="granny" and location=="inn" and pose=="action_2":work=(1080,506,300)
            occlusion=[]
            scale=float(display_height)/height
            foot=spec.get("foot",spec.get("anchor",{}).get("foot",[width/2.0,height]))
            x=int(cx-foot[0]*scale);y=int(feet-foot[1]*scale)
            if contact=="hanging" or (person=="bami" and not spec):
                # Feet grip an actual ceiling beam, not an invisible point
                # above the floor. Hanging artwork is never rotated upright.
                hook=spec.get("hook",spec.get("foot",[width/2.0,0]))
                tx,ty=(635,75) if location=="hall" else (514,48)
                x=int(tx-hook[0]*scale);y=int(ty-hook[1]*scale)
            if work and spec.get("hand") and contact not in ("self_seated","portable_stool","portable_crate","portable_bucket","floor_sit","ground","kneeling","squatting","crouching","background_chair"):
                tx,ty,display_height=work
                scale=float(display_height)/height
                hand=spec["hand"]
                x=int(tx-hand[0]*scale);y=int(ty-hand[1]*scale)
                if location in R13_STAGE_COUNTERS:occlusion=R13_STAGE_COUNTERS[location]
                elif location=="gate":occlusion=[(949,451),(1230,451),(1230,720),(949,720)]
            if location=="post" and person!="seryeon":occlusion=R13_STAGE_COUNTERS["post"]
            if person=="seryeon" and location=="post" and contact=="background_chair":
                seat=spec["seat"]
                scale=108.0/(foot[1]-seat[1])
                x=int(175-seat[0]*scale);y=int(562-seat[1]*scale)
                occlusion=[(188,408),(317,416),(324,583),(184,577)]
            rendered_width=int(width*scale);rendered_height=int(height*scale)
            left=max(0,x);top=max(100,y);right=min(1280,x+rendered_width)
            bottom=min(622,y+rendered_height)
            if occlusion:bottom=min(bottom,min(point[1] for point in occlusion)+5)
            rect=[left,top,max(1,right-left),max(1,bottom-top)]
            # Reject overlapping body rectangles instead of stacking residents.
            # Overflow stays reachable through the people menu and rotates
            # deterministically on another day/period.
            overlaps=False
            for other in staged:
                ox,oy,ow,oh=other["x"],other["y"],other["width"],other["height"]
                overlap_w=max(0,min(x+rendered_width,ox+ow)-max(x,ox))
                overlap_h=max(0,min(y+rendered_height,oy+oh)-max(y,oy))
                if overlap_w*overlap_h>min(rendered_width*rendered_height,ow*oh)*.12:overlaps=True
            if overlaps:continue
            staged.append(dict(person=person,pose=pose,x=x,y=y,width=rendered_width,height=rendered_height,
                rect=rect,depth=y+rendered_height,occlusion=occlusion,contact=contact,
                activity=spec.get("action_ko",spec.get("action",r13_activity_text(person)))))
        return sorted(staged,key=lambda actor:actor["depth"])

    def r13_staged_art(actor):
        return r13_pixel_scale(r13_art(actor["person"],actor["pose"]),actor["width"],actor["height"],R13_WORLD_PIXEL_GRID)

    def r13_conversation_pose(person,pose="neutral"):
        if person=="seryeon" and store.room13["location"]=="post" and min(store.room13["period"],2)==1:
            key="chair_listen" if pose=="neutral" else "chair_read" if pose=="thinking" else pose
            if key in R13_ACTING.get(person,{}):return key
        return pose
