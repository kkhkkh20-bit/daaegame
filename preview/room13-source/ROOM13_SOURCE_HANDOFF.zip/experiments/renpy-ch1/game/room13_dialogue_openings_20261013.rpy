# Dialogue routing only. Existing encounter records remain the source of truth.
default r13_carriage_snack = False
default r13_first_encounter = False
default r13_opening_lines = []

init 58 python:
    import json as r13_opening_json
    R13_OPENING_SCENES = r13_opening_json.load(renpy.file("room13-dialogue-openings.json"))
    # The selectable line is what Dad intends to say, not an instruction to
    # the player. Authored notice/opening dialogue and meeting flags stay intact.
    R13_APPROACH_SPEECH = {
        "resident_tori":"천 끝을 좀 잡아 드릴까요?",
        "resident_bori":"이 장작도 함께 올려 드릴까요?",
        "resident_yeoni":"안녕하세요. 옷을 수선하고 계십니까?",
        "nabi":"지금 식사를 할 수 있을까요?",
        "buri":"부품을 잠깐 구경해도 되겠습니까?",
        "resident_kongi":"가게로 가려면 어느 쪽입니까?",
        "doto":"다 쓰셨으면 잠깐 여쭤봐도 될까요?",
        "resident_kkwak":"여기 물통 놓으시겠어요? 비켜 드릴게요.",
        "granny":"안녕하세요. 이 편지를 받고 찾아왔습니다.",
        "resident_librarian":"마을에 관한 책을 찾아볼 수 있을까요?",
        "resident_owlgp":"안녕하세요. 등을 살펴보고 계십니까?",
        "resident_teacher":"여기가 학교입니까? 길을 좀 여쭤봐도 될까요?",
        "karo":"까로 씨, 잠깐 여쭤봐도 되겠습니까?",
        "resident_nero":"이 길로 가면 어디가 나옵니까?",
        "resident_seol":"방금 울린 종은 무슨 뜻입니까?",
        "resident_ppul":"말씀 끝나셨으면 잠깐 여쭤봐도 될까요?",
        "resident_tok":"부품 내려놓으신 뒤에 잠깐 괜찮으실까요?",
        "bami":"제 목소리 들립니까? 여기서 이야기할게요.",
        "resident_sling":"제 아내의 우편에 관해 여쭤봐도 될까요?",
        "resident_momo":"이 물건은 어디에 쓰는 겁니까?",
        "resident_ttadak":"일 끝나시면 잠깐 이야기 나눌 수 있을까요?",
        "resident_piko":"지금 그림을 좀 봐도 될까요?",
        "resident_mungchi":"상자 옮기는 걸 도와드릴까요?",
        "resident_madam":"다 세신 뒤에 잠깐 여쭤봐도 될까요?",
        "resident_siluk":"수레 세우신 뒤에 길을 좀 여쭙겠습니다.",
        "neoul":"이쪽으로 지나가도 괜찮습니까?",
        "resident_musoe":"안녕하세요. 길을 좀 여쭤봐도 될까요?",
        "resident_somi":"신발이 불편하니?",
        "resident_seori":"안녕하세요. 서류 다 보신 뒤에 잠깐 괜찮으실까요?",
        "resident_ubak":"종이 날아가지 않게 잡아 드릴까요?",
        "resident_nubi":"세탁을 맡길 수 있을까요?",
        "resident_eunho":"물건을 구경해도 되겠습니까?",
        "resident_guseul":"정리 끝나시면 잠깐 이야기 나눌 수 있을까요?",
        "resident_badook":"이 길로 지나가도 됩니까?",
        "resident_lamplighter":"등을 점검하고 계십니까? 방해되지 않게 기다릴게요.",
        "seryeon":"제 아내 앞으로 온 우편을 확인할 수 있을까요?",
    }

    def r13_conversation_opening(person, first):
        spec = R13_OPENING_SCENES["first_meetings"].get(person)
        if spec is None:
            return []
        if not first:
            return spec["revisit"]
        state = store.room13
        early = state["day"] <= 3 and state["case_state"] == "pending"
        if not early:
            return spec["late"]
        with_child = state["daram_state"] in ("with_dad", "rescued")
        return spec["early" if with_child else "early_solo"]

    def r13_conversation_topic_lines(key):
        state = store.room13
        # Optional companion speech does not alter topic visibility or evidence.
        with_child = state["daram_state"] in ("with_dad", "rescued")
        variants = R13_OPENING_SCENES["with_daram"]
        if with_child and key in variants:
            return variants[key]
        return ROOM13["topics"][key]["lines"]


    def r13_resident_notice(person):
        spec = R13_OPENING_SCENES["first_meetings"][person]
        state = store.room13
        special = R13_OPENING_SCENES["special_notices"]
        if person == "buri" and state["victim_state"] == "dead":
            return special["buri_bereaved"]
        if person == "bami" and r13_has("bami_pressured"):
            return special["bami_pressured"]
        early = state["day"] <= 3 and state["case_state"] == "pending"
        if not early:
            return spec["notice_late"]
        with_child = state["daram_state"] in ("with_dad", "rescued")
        return spec["notice_child" if with_child else "notice_solo"]

# Seeing a resident does not record a meeting, grant evidence, or advance time.
# Separate return labels keep existing saved call stacks stable.
label r13_notice_before_talk(person):
    if person not in R13_OPENING_SCENES["first_meetings"] or person in r13_met_people():
        return True
    $ r13_notice_approach = R13_OPENING_SCENES["first_meetings"][person]["approach"]
    call screen r13_resident_approach(r13_notice_approach,person)
    if not _return:
        return False
    if not r13_has("noticed:" + person):
        $ r13_notice_rows = r13_resident_notice(person)
        call r13_lines(r13_notice_rows, "notice:resident:" + person) from r13_notice_lines_return
        $ r13_flag("noticed:" + person)
    return True

screen r13_resident_approach(approach,person=None):
    modal True
    zorder 40
    style_prefix "r13"
    default ready=False
    timer .25 action SetScreenVariable("ready",True)
    $ target=person or r13_target
    $ choices=[(R13_APPROACH_SPEECH.get(target,approach),Return(True),False),("지금은 말을 걸지 않는다",Return(False),False)]
    use r13_question_list(target,r13_conversation_pose(target),R13_NAMES[target]+"에게 말 걸기",choices,ready,return_action=Return(False))
    use r13_toolbar(investigate_action=Return(False),person=target,mode="talk",ready=ready)
