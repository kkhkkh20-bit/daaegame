# Small, character-specific performance. Never deform the flat body drawing to
# imitate a tail: only independently authored tail layers may rotate separately.
default persistent.room13_motion = True
default r13_motion_person = None
image r13_visitor = Null()

init 58 python:
    import math as r13_motion_math

    # Native artwork pixels/degrees. An interview enlarges these by about 1.5x;
    # exploration reduces them. Distinct periods/phases avoid synchronized actors.
    R13_MOTION_PROFILES = {
        "daram": (4.5, 0.90, 0.45, 0.16),
        "dad": (5.6, 0.65, 0.30, 0.10),
        "mom": (5.4, 0.65, 0.25, 0.09),
        "granny": (6.2, 0.42, 0.18, 0.06),
        "seryeon": (5.8, 0.50, 0.24, 0.09),
        "nabi": (4.8, 0.65, 0.35, 0.13),
        "bami": (6.4, 0.22, 0.60, 0.20),
        "doto": (6.1, 0.40, 0.18, 0.06),
        "buri": (5.7, 0.55, 0.20, 0.06),
        "karo": (5.2, 0.55, 0.30, 0.10),
        "neoul": (6.0, 0.42, 0.20, 0.07),
        "guard": (6.4, 0.35, 0.12, 0.04),
    }

    def r13_motion_profile(person):
        seed=sum((i+1)*ord(c) for i,c in enumerate(person))
        profile=R13_MOTION_PROFILES.get(person,
            (5.0+(seed%17)/10.0,0.38+(seed%6)*0.05,0.18+(seed%5)*0.03,0.05+(seed%4)*0.02))
        return profile, (seed%628)/100.0

    class R13CharacterMotion:
        def __init__(self,person,pose,speaking=False,entrance=False):
            self.person=person
            self.pose=pose
            self.profile,self.phase=r13_motion_profile(person)
            self.speaking=speaking
            self.entrance=entrance

        def __call__(self,trans,st,at):
            if not persistent.room13_motion or renpy.is_skipping():
                trans.xoffset=0.0
                trans.yoffset=0.0
                trans.rotate=0.0
                trans.alpha=1.0
                return 0.20
            period,breath,shift,tilt=self.profile
            t=max(0.0,at)
            angle=t*2.0*r13_motion_math.pi/period+self.phase
            # Gentle rigid movement; no squash, stretch, body mesh or fake blink.
            trans.yoffset=int(round(-breath*r13_motion_math.sin(angle)))
            trans.xoffset=int(round(shift*r13_motion_math.sin(angle*0.61+self.phase)))
            trans.rotate=0
            if "distressed" in self.pose:
                # Quiet held tension, never a perpetual panic shake.
                trans.xoffset=0
                trans.rotate=0
            # A single small acknowledgement on arrival, not on every syllable.
            if self.speaking and self.entrance and st<0.55:
                trans.yoffset+=int(round(r13_motion_math.sin(st/0.55*r13_motion_math.pi)))
            trans.alpha=1.0
            return 1.0/8.0

    R13_PIXEL_MOTION=json.load(renpy.file("assets/room13-pixel-motion.json"))

    class R13TailMotion:
        # Pickle compatibility for pre-pixel saves. after_load replaces the
        # old composed actor before rendering; this shim never loads old art.
        def __init__(self,pose):
            self.tense="distressed" in pose
        def __call__(self,trans,st,at):
            trans.rotate=0
            return .2

    class R13PixelTailMotion:
        def __init__(self,pose):
            self.tense="distressed" in pose
        def __call__(self,trans,st,at):
            enabled=persistent.room13_motion and not renpy.is_skipping()
            # The attachment stays behind the separately authored body. One
            # native-pixel step avoids blurred rotation or a painted tail layer.
            trans.xoffset=int(round(r13_motion_math.sin(at*2.0*r13_motion_math.pi/5.8))) if enabled and not self.tense else 0
            trans.yoffset=0
            return .125 if enabled else .2

    def r13_pixel_daram_layers(pose):
        expression=next((key for key in ("thinking","distressed","expressive") if key in pose),"neutral")
        data=R13_PIXEL_MOTION
        spec=data["poses"][expression]
        body=Crop(tuple(spec["body"]),data["file"])
        if spec.get("body_size"):
            body=Transform(body,size=tuple(spec["body_size"]),nearest=True)
        tail=Crop(tuple(spec["tail"]),data["file"])
        kwargs=dict(subpixel=False,nearest=True,function=R13PixelTailMotion(pose))
        if spec.get("tail_size"):kwargs["size"]=tuple(spec["tail_size"])
        tail=Transform(tail,**kwargs)
        return Composite(tuple(data["canvas"]),tuple(spec["tail_pos"]),tail,tuple(spec.get("body_pos",[0,0])),body)

    def r13_motion_art(image_name,person,pose,speaking=False,entrance=False):
        spec=r13_acting_spec(person,pose)
        if spec:
            # Living poses have authored prop/floor contacts: idle translation
            # would make hands float away from tools and feet leave the floor.
            # Redesigned Daram never inherits the old body/tail composite.
            return Transform(Crop(tuple(spec["crop"]),spec["file"]),nearest=True,subpixel=False)
        # Only Daram has independently authored body/tail layers. Other
        # residents receive a restrained whole-sprite idle movement.
        art=r13_pixel_daram_layers(pose) if person=="daram" else image_name
        return Transform(art,subpixel=False,nearest=True,rotate_pad=False,
            function=R13CharacterMotion(person,pose,speaking,entrance))

screen r13_motion_settings():
    textbutton ("인물 움직임: 켜짐" if persistent.room13_motion else "인물 움직임: 정지"):
        action ToggleField(persistent,"room13_motion")
        xfill True
