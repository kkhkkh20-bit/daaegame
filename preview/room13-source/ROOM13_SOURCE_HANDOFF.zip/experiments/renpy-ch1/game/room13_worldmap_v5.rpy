# Source artwork is never repainted: independent transparent displayables use
# polygon alpha masks over the original PNG. SVG counterparts live in design/maps.
init 61 python:
    R13_WORLD_V5 = json.load(renpy.file("room13-worldmap-v5.json"))
    R13_WORLD_V5_ART = "assets/room13-worldmap-v5.png"
    R13_WORLD_V5_SCALE = 860.0 / 1672
    R13_MAP_NODES["village"] = {key: tuple(int(round(p * R13_WORLD_V5_SCALE)) for p in spec["point"])
        for key, spec in R13_WORLD_V5["layers"].items() if spec["node"]}

    def r13_v5_rect(key):
        x, y, w, h = R13_WORLD_V5["layers"][key]["bounds"]
        x0, y0, x1, y1 = [int(round(v * R13_WORLD_V5_SCALE)) for v in (x, y, x+w, y+h)]
        return (x0, y0, x1-x0, y1-y0)

    class R13V5Mask(renpy.Displayable):
        def __init__(self, key, outline=False, **kwargs):
            super(R13V5Mask, self).__init__(**kwargs)
            self.key, self.outline = key, outline
        def render(self, width, height, st, at):
            spec = R13_WORLD_V5["layers"][self.key]
            x, y, w, h = spec["bounds"]
            rv = renpy.Render(w, h)
            points = [(px-x, py-y) for px, py in spec["polygon"]]
            rv.canvas().polygon("#ffd57b" if self.outline else "#fff", points, 7 if self.outline else 0)
            return rv

    def r13_v5_layer(key, highlighted=False):
        spec = R13_WORLD_V5["layers"][key]
        art = AlphaMask(Crop(tuple(spec["bounds"]), R13_WORLD_V5_ART), R13V5Mask(key))
        if highlighted:
            art = Transform(art, matrixcolor=BrightnessMatrix(.18))
        return Transform(art, size=r13_v5_rect(key)[2:], nearest=True)

    def r13_v5_outline(key):
        return Transform(R13V5Mask(key, True), size=r13_v5_rect(key)[2:], nearest=True)

    def r13_v5_label(key):
        return tuple(int(round(p * R13_WORLD_V5_SCALE)) for p in R13_WORLD_V5["layers"][key]["label"])

screen r13_worldmap_v5(selected, ready, map_hover):
    add Transform(R13_WORLD_V5_ART, size=(860,484), nearest=True) xpos 30 ypos 150
    # All structures have their own alpha layer, including unlabelled scenery.
    # Scenery never becomes a focus target, tooltip, or invented visit node.
    for layer_key, spec in R13_WORLD_V5["layers"].items():
        $ lx, ly, lw, lh = r13_v5_rect(layer_key)
        add r13_v5_layer(layer_key) xpos (30+lx) ypos (150+ly)
    for key, point in r13_map_nodes("village"):
        $ lx, ly, lw, lh = r13_v5_rect(key)
        imagebutton:
            id ("v5_building_"+key)
            xpos (30+lx) ypos (150+ly)
            idle r13_v5_layer(key, key==selected or key==map_hover)
            hover r13_v5_layer(key, True)
            insensitive r13_v5_layer(key)
            focus_mask True
            action SetScreenVariable("selected",key)
            hovered SetScreenVariable("map_hover",key)
            unhovered SetScreenVariable("map_hover",None)
            sensitive ready
            alt R13_MAP_LABELS[key]
        if key==selected or key==map_hover:
            add r13_v5_outline(key) xpos (30+lx) ypos (150+ly)
    # Text remains UI text; no painted-in names and no labels for locked nodes.
    for key, point in r13_map_nodes("village"):
        $ tx, ty = r13_v5_label(key)
        textbutton (("● " if key==room13["location"] else "") + R13_MAP_LABELS[key]):
            id ("v5_label_"+key)
            area (30+tx-57,150+ty-18,114,36)
            padding (3,3)
            text_size 20 text_xalign .5 text_yalign .5
            text_color "#fff3d5" text_hover_color "#ffffff"
            background Solid("#325b50f5" if key==selected else "#152e30e8")
            hover_background Solid("#51665af5")
            action SetScreenVariable("selected",key)
            hovered SetScreenVariable("map_hover",key)
            unhovered SetScreenVariable("map_hover",None)
            sensitive ready
            alt R13_MAP_LABELS[key]
