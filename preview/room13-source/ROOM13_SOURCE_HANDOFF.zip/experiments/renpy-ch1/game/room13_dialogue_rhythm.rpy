# Text-compatible screen statement: Character injects substitute/scope/slow
# properties into id "what", which must reach Text directly, never an Add wrapper.
python early:
    def r13_dialogue_displayable(*args,**kwargs):
        return renpy.store.R13DialogueText(*args,**kwargs)
    renpy.register_sl_displayable("r13_dialogue_text",r13_dialogue_displayable,"text",scope=True,replaces=True).copy_properties("text")

# Display-only timing. Original dialogue/history/read keys remain unchanged.
init 62 python:
    import re as r13_rhythm_re

    def r13_rhythmic_text(text):
        cps=float(preferences.text_cps or 0)
        if not isinstance(text,str) or cps<=0 or renpy.is_skipping():
            return text
        # Respect any explicitly authored speed rather than nesting overrides.
        if "{cps=" in text:return text
        result=[]
        pending=0.0
        budget=1.2
        for part in r13_rhythm_re.split(r"(\{[^{}]*\}|\[[^\[\]]*\])",text):
            if part.startswith(("{","[")):
                result.append(part)
                continue
            i=0
            while i<len(part):
                punctuation=r13_rhythm_re.match(r"[,，.。!?！？…]+",part[i:])
                if punctuation:
                    run=punctuation.group(0)
                    end=i+len(run)
                    numeric=(run in (".",",") and i>0 and end<len(part) and part[i-1].isdigit() and part[end].isdigit())
                    result.append(run)
                    if not numeric:
                        pending=.30 if "…" in run or ".." in run else .26 if any(c in run for c in ".。!?！？") else .12
                    i=end
                    continue
                char=part[i]
                if pending and char not in "\n\r\t\"'’”)]»" and budget>0:
                    pause=min(pending,budget)
                    # Ren'Py assigns the delay BEFORE each glyph. Slow the
                    # following space/letter, so punctuation itself stays prompt.
                    rate=1.0/(1.0/cps+pause)
                    result.append("{cps=%.6f}"%rate+char+"{/cps}")
                    budget-=pause
                    pending=0.0
                else:
                    result.append(char)
                i+=1
        # A final punctuation mark already waits for player input; no invisible
        # trailing glyph or extra interaction is added to a completed line.
        return "".join(result)

    class R13DialogueText(renpy.text.text.Text):
        # Character owns the original self.text and installs slow/slow_done by
        # comparing it with the original say string. Only the layout token
        # stream receives punctuation timing, after that contract is preserved.
        def tokenize(self,text):
            display_text=[r13_rhythmic_text(part) if isinstance(part,str) else part for part in text]
            return super(R13DialogueText,self).tokenize(display_text)
