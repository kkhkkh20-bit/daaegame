# Shop (은호, 공동 물품 창고): goods bought with spare coins.
# Goods for residents are handed over through a topic that opens while the item
# is owned; handing it over opens an existing record or topic, then it is used up.
init 94 python:
    # key: (npc, topic title, extra condition, lines, give, flags)
    R13_ITEM_TOPICS = {
        "hat": ("daram","털모자를 씌워 준다",lambda:r13_home_with_daram(),[
            ("dad","이리 와. 오늘 산 거야."),
            ("daram","모자다! 귀가 안 시려."),
            ("dad","밤에는 바람이 세니까 꼭 쓰고 다녀."),
            ("daram","엄마 만나면 보여 줄래. 아빠가 사 줬다고.")],[],["daram_hat"]),
        "postcard": ("daram","엄마에게 엽서를 쓴다",lambda:r13_home_with_daram(),[
            ("dad","엄마한테 보낼 엽서야. 받을 곳은 아직 모르지만, 써 두자."),
            ("daram","나는 그림 그릴래. 여관이랑 눈사람이랑."),
            ("dad","(어디로 부쳐야 할지 모르는 엽서다. 그래도 이 아이가 그린 그림만큼은 꼭 전하고 싶다.)",{"thought":True}),
            ("daram","다 그렸다. 엄마가 보면 웃을 거야.")],[],["postcard_written"]),
        "lamp_oil": ("resident_lamplighter","등잔 기름을 건넨다",lambda:not r13_has("topic:lamplighter_warning"),[
            ("dad","등잔 기름입니다. 밤마다 등을 돌보시느라 모자라실 것 같아서요."),
            ("resident_lamplighter","……고맙습니다. 요즘은 기름도 아껴 써야 해서요."),
            ("resident_lamplighter","부인도 전에 이렇게 기름을 챙겨 주셨어요. 그때 맡기신 봉투가 하나 있었는데……."),
            ("dad","봉투요?"),
            ("resident_lamplighter","다음에 말씀드릴게요. 지금은 등을 마저 돌봐야 해서.")],[],["topic:lamplighter_warning","lamplighter_trust"]),
        "herbs": ("resident_seori","해열 약초를 건넨다",lambda:"E20" not in store.room13.get("evidence",[]),[
            ("dad","해열 약초입니다. 환자들에게 쓰실 수 있을까 해서요."),
            ("resident_seori","마침 떨어져 가던 참이었습니다. 받겠습니다."),
            ("resident_seori","약초를 달이는 동안 환자 곁에 있어 보시겠습니까? 열이 내리면서 어떻게 달라지는지 직접 보시는 게 낫겠군요."),
            (None,"서리와 함께 환자 곁을 지켰다. 열이 내리자 환자는 흐린 눈으로 가족의 이름을 불렀다.")],["E20"],["clinic_observation"]),
        "file": ("resident_tok","정밀 줄칼을 건넨다",lambda:"E13" not in store.room13.get("evidence",[]),[
            ("dad","정밀 줄칼입니다. 작은 핀을 손보실 때 쓰시라고요."),
            ("resident_tok","이런 걸 어떻게……. 마침 날이 무뎌져서 곤란했어요."),
            ("resident_tok","그러고 보니 할머니 브로치 핀도 이걸로 다듬었더라면 좋았을 텐데. 새로 갈아 끼운 핀의 쪽지가 아직 있어요. 보시겠어요?")],["E13"],[]),
        "blanket": ("bami","두꺼운 담요를 건넨다",lambda:"E10" not in store.room13.get("evidence",[]),[
            ("dad","두꺼운 담요야. 처마 밑은 밤에 많이 춥잖아."),
            ("bami","……나한테 주는 거야? 아무것도 안 물어보고?"),
            ("dad","응. 그냥 따뜻하게 지냈으면 해서."),
            ("bami","그럼…… 나중에 그날 본 걸 조금 얘기해 줄게. 아무한테도 내 이름은 말하지 마.")],[],["topic:bami_saw"]),
        "firewood": ("resident_nubi","장작 묶음을 건넨다",lambda:True,[
            ("dad","장작 묶음입니다. 아이들 있는 방부터 데우시라고요."),
            ("resident_nubi","세상에, 이 귀한 걸……. 고마워요. 빨래 말릴 불도 없던 참이에요."),
            ("resident_nubi","도움이 필요하면 말해요. 빨랫감 들고 드나드는 길은 내가 잘 알아요.")],[],["topic:w2_laundry","nubi_trust"]),
    }
    for _key,(_npc,_title,_cond,_lines,_give,_flags) in R13_ITEM_TOPICS.items():
        ROOM13["topics"]["item:"+_key]=dict(npc=_npc,title=_title,day=[2,14],need=[],give=list(_give),flags=list(_flags),lines=list(_lines))
    ROOM13["topics"]["shop:eunho"]=dict(npc="resident_eunho",title="물건을 사고 싶습니다",day=[2,14],need=["livelihood_open"],give=[],flags=[],lines=[])

    def r13_item_owned(key):
        return key in r13_wallet(store.room13)["items"]

    _r13_shop_topics=r13_topics
    def r13_topics(person):
        rows=[]
        for key,spec in _r13_shop_topics(person):
            if key.startswith("item:"):
                item=key[5:]
                if not (r13_item_owned(item) and R13_ITEM_TOPICS[item][2]()):continue
            if key=="shop:eunho" and store.room13.get("period",0)>=2:continue
            rows.append((key,spec))
        return rows

    _r13_shop_finish_topic=r13_finish_topic
    def r13_finish_topic(key):
        _r13_shop_finish_topic(key)
        if key.startswith("item:"):
            n=winter_copy.deepcopy(store.room13);wallet=r13_wallet(n);item=key[5:]
            if item in wallet["items"]:wallet["items"].remove(item)
            wallet["used"]=list(dict.fromkeys(wallet["used"]+[item]))
            n["livelihood"]=wallet;store.room13=n

    def r13_shop_rows():
        state=store.room13;wallet=r13_wallet(state)
        return [(key,item) for key,item in R13_SHOP.items()
            if key not in wallet["used"] and (r13_shop_on_sale(state,key) or key in wallet["items"])]
