# Small drawn controls; no borrowed reference artwork or additional bitmap assets.
init 79 python:
    class R13ReferenceChoice(renpy.Displayable):
        def __init__(self,hover=False,**kwargs):
            super(R13ReferenceChoice,self).__init__(**kwargs)
            self.hover=hover
        def render(self,width,height,st,at):
            w=max(1,int(width));h=max(42,int(height))
            r=renpy.Render(w,h);c=r.canvas()
            c.rect("#3786a5",(0,0,w,h))
            c.polygon("#eef1e7",((0,0),(28,0),(58,h),(0,h)))
            c.rect("#eed17a" if self.hover else "#dce6dc",(0,0,w,h),3 if self.hover else 1)
            return r

    def r13_reference_list_height(entries,width):
        if not entries:return 88
        total=24*max(0,len(entries)-1)
        for label,action,was_read in entries:
            caption=("✓  {s}"+label+"{/s}") if was_read else label
            text=Text(caption,size=r13_read_size(22,28),font=r13_ui_font(),xsize=width-47)
            height=renpy.render(text,width-47,720,0,0).get_size()[1]
            total+=max(42,height+12)
        return min(382,total)

init 80:
    style r13_footer_button is button:
        xsize 92
        ysize 32
        padding (8,4)
        background None
        hover_background Solid("#b8d6df")
    style r13_footer_button_text is text:
        font "assets/Room13Sans.ttf"
        size 17
        color "#285265"
        hover_color "#123b50"
        xalign .5
        yalign .5
