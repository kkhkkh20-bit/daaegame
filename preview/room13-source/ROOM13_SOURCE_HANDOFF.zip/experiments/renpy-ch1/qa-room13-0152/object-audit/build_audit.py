import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
OUT=Path(__file__).parent
objects=json.loads((ROOT/'game/room13-content.json').read_text())['objects']
objects['guestroom']={k:objects['room13'][k] for k in ['bed','window','boxes','cup']}
layouts=json.loads((ROOT/'art/pixel-b/layouts.json').read_text())
scenes=[]
for place,group,panel in [('gate','gate',0),('inn','inn',0),('workshop','village',2),('square','village',0),('room13','room-before',0),('guestroom','room-before',0),('hall','hall-before',0),('room13-after','room-after',0),('hall-after','hall-after',0)]:
 srcplace=place.removesuffix('-after')
 for time in ['morning','afternoon','evening']:
  name=f'room13-pixel-{group}-{time}.png';spec=layouts[name]
  scenes.append(dict(id=place+'-'+time,place=place,time=time,file='../../art/pixel-b/'+name,size=spec['size'],crop=spec['rects'][panel],objects=objects[srcplace]))
(OUT/'scenes.json').write_text(json.dumps(scenes,ensure_ascii=False,indent=2))
(OUT/'index.html').write_text('''<!doctype html><meta charset="utf-8"><style>body{background:#222;color:white;font:14px sans-serif;margin:0}header{padding:8px;display:flex;gap:20px;align-items:center}#stage{width:1280px;height:720px;position:relative;overflow:hidden}.bg{position:absolute;image-rendering:pixelated}.rect{position:absolute;border:2px solid #ff3d68;box-sizing:border-box;color:white;background:#ff00000c}.label{background:#222d;padding:2px;font:bold 13px monospace;white-space:nowrap;position:absolute;left:0;top:0;pointer-events:none}.rect:hover{background:#ffff0033;border-color:yellow;z-index:100}.hud{position:absolute;left:24px;top:20px;width:654px;height:70px;background:#123a;pointer-events:none}#text{max-width:1200px;min-height:42px}button,select{font:inherit}</style><header><select id="scene"></select><label><input id="boxes" type="checkbox" checked>영역</label><span id="target">배경 사물 hit rect · runtime 삽입 순서</span></header><div id="stage"></div><div id="text"></div><script>let scenes;const stage=document.querySelector('#stage'),sel=document.querySelector('#scene');function draw(){const s=scenes.find(s=>s.id===sel.value),[x,y,w,h]=s.crop,[W,H]=s.size;stage.replaceChildren();const img=document.createElement('img');img.className='bg';img.src=s.file;img.style.cssText=`width:${W/w*1280}px;height:${H/h*720}px;left:${-x/w*1280}px;top:${-y/h*720}px`;stage.append(img);Object.entries(s.objects).forEach(([key,o],i)=>{let [l,t,w,h]=o.rect;let el=document.createElement('div');el.className='rect';el.dataset.key=key;el.style.cssText=`left:${l}px;top:${t}px;width:${w}px;height:${h}px;${document.querySelector('#boxes').checked?'':'border-color:transparent;background:transparent;'}`;if(document.querySelector('#boxes').checked){let label=document.createElement('span');label.className='label';label.textContent=i+':'+key;el.append(label)}el.onpointermove=()=>document.querySelector('#target').textContent=key+' ['+o.rect+']';el.onclick=()=>document.querySelector('#text').textContent=key+': '+o.text;stage.append(el)});const hud=document.createElement('div');hud.className='hud';stage.append(hud)}fetch('scenes.json').then(r=>r.json()).then(s=>{scenes=s;s.forEach(s=>{let o=document.createElement('option');o.textContent=s.id;o.value=s.id;sel.append(o)});sel.value='gate-afternoon';draw()});sel.onchange=draw;document.querySelector('#boxes').onchange=draw;</script>''')
# Later object buttons win rectangular overlaps. Report object-center hijacks and overlaps.
report=[]
for place in ['gate','inn','workshop','square','room13','guestroom','hall']:
 rows=list(objects[place].items())
 for i,(key,spec) in enumerate(rows):
  x,y,w,h=spec['rect'];cx,cy=x+w/2,y+h/2
  for other,that in rows[i+1:]:
   X,Y,W,H=that['rect'];iw=max(0,min(x+w,X+W)-max(x,X));ih=max(0,min(y+h,Y+H)-max(y,Y))
   if iw*ih:report.append(dict(place=place,behind=key,on_top=other,overlap_pixels=iw*ih,behind_fraction=round(iw*ih/(w*h),3),center_stolen=X<=cx<X+W and Y<=cy<Y+H))
(OUT/'overlaps.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
