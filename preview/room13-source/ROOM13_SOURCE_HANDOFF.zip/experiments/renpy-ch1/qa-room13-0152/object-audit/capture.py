import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
OUT=Path(__file__).parent
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=await b.new_page(viewport={'width':1280,'height':820})
  await page.goto('http://127.0.0.1:8093/experiments/renpy-ch1/qa-room13-0152/object-audit/',wait_until='networkidle')
  for loc in ['gate','inn','workshop','square','room13','guestroom','hall','room13-after','hall-after']:
   await page.select_option('#scene',loc+'-afternoon');await page.wait_for_timeout(150);await page.screenshot(path=str(OUT/(loc+'-afternoon.png')))
  for loc in ['gate','room13','hall']:
   for time in ['morning','evening']:
    await page.select_option('#scene',loc+'-'+time);await page.wait_for_timeout(150);await page.screenshot(path=str(OUT/(loc+'-'+time+'.png')))
  await b.close()
asyncio.run(main())
