# v0.15.2 independent QA — PASS

Final tested archive SHA-256: `cdaa6bb1b3aea1bcaecc9cd325118a276dc88dcdd950f19578d565b94af411ff` (270,247,599 bytes, five transport parts).

Candidate: `http://127.0.0.1:8094/room13-release-0152/`

## Natural input and conversation

- `hits-cdaa-final/report.json`: Karo’s actual visible eye, coat, head, tail and name clicked at 1280×720 and touched at 844×390. All ten selections open Karo. Original failing eye160,402 and coat225,485 now work. Two consecutive questions return to the same question menu; explicit exit alone returns to the field. Letterbox mapping agrees with the visible image.
- Actual posted rules click shows Dad’s thinking portrait, parenthesized thought, and rendered color #9dc9ff. The thought flag resets on return.
- `context-cdaa-final/report.json`: Guard explanation, wait cancellation and evidence cancellation all return to guard topics. Actual exposed booth/posted rules/ledger clicks obtain G1/G2/G3. The proof route still completes naturally.
- After the natural reunion, a shovel click gives Dad’s thought, then his spoken warning, then Daram’s reply. An explicitly injected held-child state followed by the same real object click yields Dad’s thought only, with no absent-child response.
- A forced interaction-revision migration fixture on the naturally reached proof choice retains story state, speaker=None, expression, pose and exact left actor bounds. Checkmark tuple/list normalization and temporary last_inspection reset are expected migration bookkeeping, not story mutations. Background preservation is independently covered by runtime/motion review; this test did not compare background pixels.

## Population and visible targets

- `population-cdaa-final-rerun/report.json`: 4,760 injected day/period/location/story-state combinations, including shelter flags. At every condition, staged identities equal scheduled identities; 37 residents covered, no duplicates, deterministic placement and absence/custody constraints pass. State restored afterward.
- Final engine screenshots cover every occupied location’s maximum resident condition, including school12, workshop8, square8, store7 and post6. Gate Karo is back on the snow, the store faces are separated, and Buri’s label is above his own head. Dense scenes retain intentional depth/furniture overlap; this is not a claim every body pixel is unobscured.
- `denseclick-cdaa-accepted/report.json`: 38 actual picture-selected face-coordinate inputs: school12 on desktop and mobile (24), post6, workshop8. Every event returns the matching actor identity. This is an injected world fixture with Return.__call__ observed at its dispatch boundary; original widgets, alpha masks and real mouse/touch input remain intact. It is not represented as 38 naturally played conversations.

## Scope and prior failures

Earlier 858f7b3 candidate revealed Karo floating on the gate rail and misleading labels from crop-left anchoring; both were corrected before this approval. An earlier population run exceeded the QA helper’s 35-second timeout; the authoritative rerun above completed with a longer helper timeout. The first dense-click harness replaced individual actions while the underlying entry call stack was still active, causing false None results after screen reevaluation; the final observer fixture avoids that flaw and passes all 38 cases. Earlier failed reports remain for traceability and are not counted as passes.

Existing punctuation/fade code was not broadly replayed; natural dialogue and appearance remained functional in these routes. Motion-specific tests and pure thought/rules tests were owned by other agents and are not claimed as this agent’s work. No production files were edited by this QA agent. All browser contexts are closed; no blocking issues remain for this change.
