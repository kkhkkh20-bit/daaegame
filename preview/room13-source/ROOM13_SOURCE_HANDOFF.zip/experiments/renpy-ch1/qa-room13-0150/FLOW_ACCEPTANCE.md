# 0.15 direct-interaction acceptance — independent QA plan

## Baseline and scope

The checked-in/generated `game/room13-content.json` currently has **32** activities, not 33. `activity-baseline.json` preserves every original ID, eligibility condition, time cost, reward and recommended existing-object entry point before production changes. New activities must be counted separately. No old action may silently disappear when the generic activities menu is removed.

Production implementation belongs to runtime/dialogue agents. This document is acceptance criteria, not a claim that the unreleased change has passed.

## World-first interaction

- Clicking a visible actor opens that named person's dialogue/topics directly. No targetless Talk/Present/Investigate/Menu intermediary, and no stale prior target.
- Karo is visible and selectable at the initial entry scene. The guard's proof/wait interactions remain the guard's. Daram remains inside the waiting hut until release.
- Visible objects are directly clickable in ordinary exploration. If an actor occupies a clue, there must be an understandable direct route to that clue; retaining a hidden investigation mode as the only access does not meet this change.
- Object selection displays its observation and only actions meaningfully belonging to that object. Observation itself costs no time. Returning from a contextual choice does not consume time or mutate evidence/disclosure/state.
- Already obtained evidence remains in the notebook. Presenting is available only with an explicit recipient, named in the confirmation; global notebook browsing does not inherit a stale recipient.
- Any residents omitted from the stage because of space remain reachable through an explicit local resident affordance; no global targetless action dashboard is needed.

## Contextual activities and time

Recommended bindings for all 32 activities are in `activity-baseline.json`. Alternatives are valid if the object exists visibly and each eligible activity is discoverable. A fixed object binding avoids losing a timed action just because the named helper's normal idle schedule puts them elsewhere; the action can explicitly arrange their participation.

Existing high-risk actions:

- `recovery`: day 3 only, square; must remain reachable before advancing beyond the day.
- `w2_measure2`: evening only; needs a discoverable way to advance morning/afternoon without changing day.
- `interview`, `w2_scout`, rescue actions: only while Daram is held; don't expose or perform them after rescue.
- `w2_escape`: zero-time ending action remains possible at period 3; costful actions cannot run free at the period-3 cap.
- `passage_measure`: available only after discovery and physical passage access; maps must not expose the secret prematurely.
- `protect_bami`: usable after testimony even if Bami's regular schedule is elsewhere, and protection must still precede the relevant time-boundary consequence.

Time advances only after explicit contextual confirmation, showing the destination period. A real bench, seat or clock at appropriate public locations may offer waiting, but the HUD must have no global waiting/rest action. Repeating a completed one-time activity cannot consume time or duplicate rewards. Merely changing place, opening the map, inspecting an object, asking a normal question or canceling a choice cannot advance the clock.

## Sleep and day boundaries

- Before the incident, only clicking the actual **13호 room bed** offers sleeping. After the incident makes that room unusable, a real temporary guestroom and its bed replace this sleep route. Clinic beds, school blankets, dining chairs, inn reception and other unrelated locations cannot offer or execute the same sleep action. The crime-scene bedroom remains inspectable but cannot be slept in after displacement.
- A lodging reservation is required. Travel to the bedroom remains possible at period 3, including after all costful actions are exhausted.
- Cancel sleep leaves the entire run state unchanged.
- Confirmed sleep consumes the rest of this day, runs existing time consequences exactly once and advances to the correct next-day event.
- Day 4 pending case cannot be skipped by sleeping early: route into the existing case trigger.
- Day 7 trial and week-two/day-14 events retain their existing day-boundary behavior.
- Sleeping while Daram is held must not fabricate a companion or erase custody state.

## Actual map

The map must depict spatial destinations and their hit areas, not a grid/list pasted over a background. Current location is marked. Labels remain readable at 844×390 touch size. Returning, choosing the current place and selecting unavailable destinations leave state unchanged.

Access gates remain equivalent to `r13_places()`:

- Before lodging: gate, square, post, inn, workshop only.
- After lodging: dining, kitchen, hall, room 13, clinic, school, store.
- Service passage requires `passage_open` (both hidden controls); seeing the floor plan alone does not unlock it.
- Facility from day 8; greenhouse also requires E19.
- Altar is a story destination, not a free early map teleport.
- Locked regions may be shown as geography but must not be actionable; secret destinations must not disclose their name/route early.

## Planned verification

1. Static inventory: compare original 32 IDs/conditions/time cost/rewards with final content. Report intentional additions separately. Confirm every old action has a contextual route to a real object or explicit character affordance.
2. Engine fixtures: construct independently valid activity states; assert each original action appears through the intended scene input, disappears when a prerequisite/day/state is invalid, completes once, and spends its specified time. Special rescue/ending effects need their existing dedicated state tests rather than blindly auto-running all actions.
3. Fresh natural proof entry: actor clicks Karo/guard; visible direct clues; guard evidence recipient; correct proof; no global action dashboard; normal map travel, lodging, physical bedroom/bed, sleep confirmation cancellation.
4. Fresh natural wait entry: wait only from the guard's explicit delay choice; time consequence retained; Karo/Buri direct topics and read state.
5. Recipient regression: talk to Buri, cancel evidence; visit Karo, present evidence; confirm only Karo's knowledge/reaction changes. Browse the global notebook with no recipient and ensure it cannot accidentally present to Buri/Karo. Sensitive-name cancellation preserves disclosure flags.
6. Map lock fixtures: fresh/no lodging, lodging, discovered-but-closed passage, open passage, day-7/day-8 facility, missing/present E19 greenhouse; click actual regions and inspect state. No arbitrary `Return(destination)` injection used to claim UI coverage.
7. Time boundary fixtures with real inputs: day-3 recovery, evening-only second measurement, period-3 route to room and sleep, day-4 case trigger, Bami disclosure consequence, no repeat-action exploit.
8. Desktop and 844×390 touch: actor/object hitboxes, recipient and choice labels, map targets, save/load. No blank or inaccessible new screens; no asset/network/JS errors.

Natural play and injected fixtures will be reported separately. Earlier 0.14 flow test passes do not establish 0.15 behavior because screens/routes are changing substantially.

## Revised 0.15 dialogue/staging visual gates

- All 43 characters' four large conversation expressions use dedicated front/three-quarter art with eyes addressing the player. Sideways world/living sprites are not acceptable fallback conversation portraits.
- Daily neutral/thinking/worried/explaining gestures remain restrained; no panic/yelling/crouching substituted for ordinary listening.
- Independent pilot review: Buri has readable player-facing eyes in all four poses and quiet hand gestures; neutral/worried body changes are subtle, with concern mainly in eyebrows. This is a browser composition preview, not an actual-engine pass.
- Granny and Eunho are compared at the same effective camera/world scale, measuring visible body after furniture occlusion; raw crop height equality alone is insufficient.
- New dialogue portraits must be inspected on real backgrounds with name/choices/dialogue UI at desktop and mobile sizes. Source artwork alone and 0.14 passes do not establish final visual quality.

## Prototype 2 functional findings (not final release approval)

- Natural proof and waiting entries reached by actual inputs. The original prototype's Karo-name/Daram-panel overlap and guard-face/booth obstruction were reproduced and corrected in prototype 2.
- All 32 activities reached through actual object clicks and their relevant context choice, up to confirmation. These are eligible-state fixtures, not completed story branches. Completed/day-invalid action exclusion and sleep-location conditions pass separately.
- Six map eligibility states, 82 actual pin selections pass; selection and cancellation do not travel or spend time. Closed secret passage and undiscovered greenhouse stay hidden.
- Natural inn registration, direct bedroom bed, sleep cancellation, Buri→Karo recipient isolation, global notebook without stale recipient, and 844×390 touch map/bed pass.
- Initial Karo's ordinary menu still covered his face; dedicated right-side questions requested.
- Incident dialogue marked family room unusable while only that bed could sleep. Parent directed a real temporary guestroom/bed route, preserving crime-scene investigation and held-Daram state. Final tests must cover this new route and its pre-incident lock.
- New front portraits were incomplete in the prototype. No final visual acceptance is inferred from these functional tests or older 0.14 results.

## Strict candidate evidence (before final ending-art-only correction)

- `flow-release-proof/report.json`: natural proof entry, actual choice save/load, lodging/bed cancellation, recipient isolation, mobile touch map/bed, real first-night sleep and day-2 arrival PASS. No route flags injected for these natural steps.
- Same report separately marks injected boundary states: crime room cannot sleep after displacement; actual map to clean guestroom, bed cancel and next-day sleep preserve custody/evidence; day-4 early sleep reaches case choice instead of bypassing it.
- `dialogue-prototype3/report.json`: 172 actual-engine expression frames, manual review of all 11 contact sheets PASS. They use a QA sentence and are not natural story screenshots. `front-bundle-identity.json` confirms 31 front-art/metadata files byte-identical in strict candidate.
- `dialogue-release-neutral-verified/report.json`: all 43 independently authored default profiles render and were manually reviewed. Default profile must use independent source art; a nonneutral expression may crop the matching new front portrait when no separate emotional profile exists. Requiring 172 separately generated profile files would exceed the user's stated request.
- `staging-release-family/report.json`: 3,808 injected schedule conditions, all 37 scheduled residents staged in at least one valid condition, no absent/dead/jailed leakage, same-clock determinism and body click geometry PASS. Focused updated mother/inn world screenshots reviewed manually; this does not claim 3,808 natural scenes played.
- Supporting cast thinking/explaining gesture designs repeat; a future art-variety pass could improve individuality. No current face crop, opaque rectangle, sideways conversation fallback or clear furniture-contact blocker found in reviewed frames.
