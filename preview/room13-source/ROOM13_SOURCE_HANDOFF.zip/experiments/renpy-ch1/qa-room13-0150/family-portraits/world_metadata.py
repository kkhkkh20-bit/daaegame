import json,copy,hashlib
from pathlib import Path
from PIL import Image
import numpy as np
from scipy import ndimage
p=Path('art/pixel-b/portraits');old=json.load(open('art/pixel-b/acting/main-acting.json'));out={};report={};issues=[]
mapping={f'room13-pixel-acting-{k}.png':f'room13-pixel-world-{k}-gray'+('-gutter' if k in ['mom','daram'] else '')+'.png' for k in ['daram','dad','mom','family-extra']}
cache={}
for src,dst in mapping.items():
 im=Image.open(p/dst);a=np.array(im)[:,:,3];lab,n=ndimage.label(a>64);objs=ndimage.find_objects(lab);comps=[]
 for k,s in enumerate(objs):
  area=np.sum(lab[s]==k+1) if s else 0
  if area>3000:comps.append((k+1,(s[1].start,s[0].start,s[1].stop,s[0].stop)))
 cache[src]=(dst,im.size,lab,comps);report[dst]={'size':im.size,'sha256':hashlib.sha256((p/dst).read_bytes()).hexdigest(),'components':len(comps),'alpha_edge_pixels':int(np.sum(a[0]>64)+np.sum(a[-1]>64)+np.sum(a[:,0]>64)+np.sum(a[:,-1]>64))}
for person in ['daram','dad','mom']:
 out[person]={}
 for pose,v in old[person].items():
  if pose.startswith('avatar_'):continue
  dst,size,lab,comps=cache[Path(v['file']).name];ox,oy,ow,oh=v['crop']
  match=max(comps,key=lambda c:max(0,min(ox+ow,c[1][2])-max(ox,c[1][0]))*max(0,min(oy+oh,c[1][3])-max(oy,c[1][1])))
  k,(x0,y0,x1,y1)=match;pad=1;x=max(0,x0-pad);y=max(0,y0-pad);w=min(size[0],x1+pad)-x;h=min(size[1],y1+pad)-y
  other=set(np.unique(lab[y:y+h,x:x+w])) & {z[0] for z in comps if z[0]!=k}
  if other:issues.append([person,pose,'foreign sprite',list(map(int,other))])
  s=copy.deepcopy(v);s['file']='assets/'+dst;s['crop']=[x,y,w,h];s['reviewed']=True;s['source_kind']='world_family_palette_teeth_revision'
  for key in ['foot','seat','hand']:
   if key in s:s[key]=[min(w-1,max(0,round(s[key][0]/ow*w))),min(h-1,max(0,round(s[key][1]/oh*h)))]
  if 'head' in s:
   a,b,c,d=s['head'];s['head']=[round(a/ow*w),round(b/oh*h),round(c/ow*w),round(d/oh*h)];s['head'][2]=min(s['head'][2],w-s['head'][0]);s['head'][3]=min(s['head'][3],h-s['head'][1])
  out[person][pose]=s
(p/'family-world.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');(p/'family-world-audit.json').write_text(json.dumps({'assets':report,'issues':issues,'pose_count':sum(map(len,out.values())),'note':'Original PNG bytes preserved; geometry mostly retained, crop and anchors normalized to revised alpha bounds. Dad faces redrawn to remove teeth. Mom row spacing repaired.'},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'issues':issues,'poses':sum(map(len,out.values())),'assets':report},indent=2))
