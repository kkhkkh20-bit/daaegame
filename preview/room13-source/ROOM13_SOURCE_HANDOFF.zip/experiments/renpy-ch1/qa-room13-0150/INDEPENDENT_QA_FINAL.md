# 0.15 independent QA

Status: UI/interaction/front-portrait acceptance passed. Final ending-B art-only correction and its resulting archive hash/smoke are owned by runtime/root; this report does not claim that later file was tested here.

## Evidence

| Scope | Result | Evidence |
|---|---|---|
| Natural proof entry, direct Karo/guard/object clicks | PASS | flow-release-proof/report.json |
| Real proof-choice save/load, same left actor and story state | PASS | flow-release-proof/report.json |
| Natural map/lodging, actual first-night bed sleep, next-day arrival | PASS | flow-release-proof/report.json |
| Buri→Karo evidence recipient isolation; no stale global-notebook present | PASS | flow-release-proof/report.json |
| 844×390 real touch map/bed/confirmation | PASS | flow-release-proof/report.json |
| Incident-room sleep blocked; clean guestroom map/bed cancel/nextday; custody/evidence unchanged | PASS, injected boundary state + real inputs | flow-release-proof/report.json |
| Day-4 early sleep routes to case choice | PASS, injected boundary state + real inputs | flow-release-proof/report.json |
| Natural waiting entry | PASS | flow-final-wait-map/report.json |
| Seven access states, 96 actual map-pin selections; no locked travel/state drift | PASS, injected access fixtures | flow-final-wait-map/report.json |
| Old visual revision migration on actual proof-choice frame | PASS, injected revision only | flow-final-migration/report.json |
| All original 32 activities retain eligible physical-object context | PASS | Every final flow report matrix |
| Actual object→activity→confirmation for all 32 | PASS, eligible-state fixtures, not completed branches | flow-prototype2-activities/report.json |
| 43 characters ×4 front dialogue poses | PASS, real engine fixtures + manual 11 contact sheets | dialogue-prototype3/report.json |
| 43 independent default profiles | PASS, real engine fixtures + manual 3 contact sheets | dialogue-release-neutral-verified/report.json |
| Front source continuity to strict candidate | 31 art/metadata files byte-identical | front-bundle-identity.json |
| Schedule coverage | 3,808 synthetic conditions, 37/37 world residents represented | staging-release-family/report.json |
| Updated mother/inn physical staging | PASS, focused real-engine fixtures/manual review | staging-release-family/report.json |

## Exact candidates

- `e285dec617dd1032f4883ec5eb82b7999725d6ed85a1170d327804fad3f61fe7`: full natural proof/save/mobile/sleep/boundaries, 43 default-profile renders, schedule/updated-family-stage verification.
- `a7d75f2dfe3350cc0c284726d1b79e3da05bebec70136401fcbb9b60ce631a0d`: fresh proof/wait, latest map, retained-choice visual migration, actual Karo dialogue screenshot. Later ending-B-only art correction requires its own smoke and hash.

## Visual review and limits

All 172 large portraits face the viewer front/three-quarter; ears/faces fit, body cuts continue behind dialogue, and ordinary worry/thinking gestures remain restrained. All 43 default profiles use distinct authored profile art rather than a main-body crop. Nonneutral profiles may use the matching front-expression head crop, as explicitly approved. Supporting gesture silhouettes repeat somewhat; future variety would improve individuality but no blocking clipping/staging issue was found in reviewed scenes.

Natural flows and injected fixtures are explicitly separated. This is not a claim that every story branch or every ending was reached naturally. State regression/endings/CG checks are separate reports owned by root/runtime. Failed earlier reports caused by first-night-choice expectation or profile-metadata field mismatch remain preserved, superseded by corrected runs; no runtime defect was hidden by changing their status.

Gallery-safe actual Karo dialogue: `flow-final-migration/02b-karo-real-dialogue.png`. The 172 expression fixtures contain a generic QA sentence and must not be described as natural story dialogue.
