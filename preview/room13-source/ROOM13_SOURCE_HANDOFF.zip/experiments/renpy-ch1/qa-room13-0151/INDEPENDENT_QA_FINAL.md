# v0.15.1 independent focused QA — PASS

Final candidate: `http://127.0.0.1:8094/room13-release-0151/`

Archive SHA-256: `db31cac505b5794a8d5305b025cb8ed7a52046d4352086a8e0fb604c8ad8b16b`

## Natural dialogue and punctuation

`rhythm-accepted/report.json` and its unedited browser frames record a fresh entry followed by Karo’s actual bags topic. At 70.53 ms the original dialogue Text was still typing with its completion callback connected. A screen redraw during typing preserved that connection. The first click completed the current line without advancing; the second click returned to the entry after the one-line topic. The raw packet, widget source string, and read ID remained unchanged. The actual period-to-next-space glyph interval was 0.2894 seconds (normal 1/34 second plus 0.26-second punctuation pause).

Separate helper fixtures checked comma, terminal punctuation, ellipsis clusters, numeric 1.5/1,000, authored cps tags, source preservation, and real skipping. Fast-read ON with unread dialogue retained punctuation rhythm. A natural repeat with fast-read OFF and cps=0 had zero glyph times and displayed immediately. No browser/runtime errors occurred; game state was preserved.

Manual review of the early frame and first-click screenshot confirmed partial-to-full text, actor/profile appearance, and intact background/HUD. Syllable-level Korean wrapping remains a non-blocking typography improvement.

## Appearance fade

`fade-final/report.json` and `fade-final/frame-metrics.json` cover natural Karo entrance plus explicit presentation fixtures for actor replacement, expression/profile replacement, repeated speaker, screen redraw, world/topics and motion-off. Central actor alpha and actual captured pixels progress to opaque. The final profile implementation also fades on changed identity/expression. Repeated speaker and redraw comparisons have zero sampled actor/profile pixel difference; background/HUD sampled regions remain pixel-identical throughout. Motion-off renders opaque immediately.

Fade-specific evidence was captured on archive `38ee634715210c3d80e31dd42ce21e5e69b04cfd9dbb0c9fdc3ba978d1a7f8cc`; those appearance paths were unchanged by subsequent Text integration fixes. The final candidate’s natural Karo frames additionally show central/profile fade.

## Defects caught before approval

The original display-string formatter broke Ren’Py’s raw-text equality contract, making typing immediate. Moving formatting into Text.tokenize preserved the original string. A subsequent generic add statement failed when native Text properties were injected. The final native-compatible registered screen statement copies Text properties, scope and replacement handling. Both defects are resolved in the approved candidate. Earlier failed reports are retained as evidence, not counted as passes.

## Scope

This is focused v0.15.1 regression QA, not a replay of every story route. Natural dialogue checks, synthetic formatter fixtures and presentation fixtures are distinguished above. Existing v0.15 route/asset QA remains documented separately. All browser contexts are closed. No blocking issues remain for this change.
