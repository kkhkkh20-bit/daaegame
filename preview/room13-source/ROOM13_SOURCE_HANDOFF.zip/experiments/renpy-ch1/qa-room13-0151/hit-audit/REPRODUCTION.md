# 0.15.1 visible-art hit mismatch — reproduced

Tested local identical release archive db31cac505b5794a8d5305b025cb8ed7a52046d4352086a8e0fb604c8ad8b16b, fresh natural entry. Actual picture chosen first; source/focus rectangles used afterward to explain results.

| Visible target | Game coordinate | Actual result |
|---|---|---|
| Karo left eye/beak | 160,402 | Wrong: bundles/covered carriage description |
| Karo coat/body | 225,485 | Wrong: road/broken carriage axle description |
| Karo right head | 210,390 | Correct Karo topics |
| Karo name | 120,313 | Correct Karo topics |
| Posted regulations | 390,321 | Correct rules description |

The actor bounds are x90..398,y330..610. The invisible bundles rectangle (5,294,188,123) overlays the left face; road (76,425,223,152) overlays most of the coat. Objects are placed above body buttons. The additional face button explicitly subtracts object rectangles, leaving the right slice x193..267. This reproduces the perceived rightward displacement.

The same eye and name/posted-rules tests used real touch at 844×390. Rendering has scale 390/720=.541667 with horizontal black margins75.333px. Thus eye game160,402 maps to screen162,217.75. Wrong object reproduced there, while name140.333,169.542 and regulations286.583,173.875 map correctly. This is not a global canvas scaling error. Browser canvas covers844×390; letterboxing is inside it.

Karo's actual question '짐 좀 부탁합니다' also returns to hub after its one-line answer without choosing explicit exit. User's updated requirement is to retain Karo topics until explicit exit; previous v0.15.1 tests treated the old route as expected. New regression checks must reflect the updated contract.

Evidence screenshots and paired JSON states are in this directory. Initial entry and screenshots named karo-visible-eye-opens-bundles, karo-visible-coat-opens-road, karo-right-head-opens-correct-topics, karo-topic-ends-without-explicit-exit, mobile-karo-eye-opens-bundles, mobile-name-opens-correct-karo, mobile-visible-rules-correct record the natural route. No story-state injection was used.

Additional repair acceptance: actor opaque pixels must receive the actor click, transparent/occluded pixels must pass through to the visible prop, names remain exact. Essential G1 booth currently sits inside the guard's body (1098,357,57,50); making actors priority must not make G1 unreachable. Verify a visibly exposed document with real input. Desktop and mobile should choose identical targets after letterbox mapping. No production code edited by QA.
