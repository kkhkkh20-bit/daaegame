import asyncio
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2]
async def main():
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  page=await b.new_page(viewport={'width':1280,'height':720})
  await page.goto('http://127.0.0.1:8093/experiments/renpy-ch1/qa-room13-0153/')
  await page.set_content('''<style>body{margin:0;background:#252327}canvas{image-rendering:pixelated}</style><canvas width=1280 height=720></canvas><script>
  const bg=new Image(), ch=new Image(); bg.src='/experiments/renpy-ch1/art/pixel-b/room13-pixel-gate-afternoon.png';ch.src='/experiments/renpy-ch1/art/pixel-b/portraits/room13-pixel-dialogue-daram.png';
  Promise.all([bg.decode(),ch.decode()]).then(()=>{let c=document.querySelector('canvas').getContext('2d');c.imageSmoothingEnabled=false;c.drawImage(bg,0,0,1280,720);c.save();c.beginPath();c.rect(1023,331,90,114);c.rect(1098,357,57,50);c.rect(1048,408,133,33);c.clip('evenodd');c.drawImage(ch,235,6,399,508,1023,331,90,114);c.restore();window.ready=1;});</script>''')
  await page.wait_for_function('window.ready');await page.screenshot(path=str(ROOT/'qa-room13-0153/entry-window/mock.png'))
  await page.screenshot(path=str(ROOT/'qa-room13-0153/entry-window/mock-detail.png'),clip={'x':990,'y':300,'width':255,'height':180})
  await b.close()
asyncio.run(main())
