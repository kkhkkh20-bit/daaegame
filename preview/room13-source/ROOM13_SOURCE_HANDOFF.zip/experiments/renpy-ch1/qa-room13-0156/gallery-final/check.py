import asyncio,json,hashlib
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent;GALLERY=ROOT.parents[1]/'preview/room13-acting'
URL='http://127.0.0.1:8093/preview/room13-acting/'
async def main():
 data=json.loads((GALLERY/'catalog.json').read_text());palette=data['family_palette']
 assert len(palette['assets'])==13
 for item in palette['assets']:assert hashlib.sha256((GALLERY/item['file']).read_bytes()).hexdigest()==item['sha256'],item['file']
 assert data['coverage']['authored']==241
 assert data['portrait_coverage']['drawings']==172 and data['portrait_coverage']['dedicated_avatars']==43
 assert len(data['evidence_icons'])==12
 assert '0156-viewpoint-' in data['front_runtime'][0]['file']
 assert sum('0156-staging-' in s['file'] and '엔진 검수' in s['caption'] for s in data['front_runtime'])==3
 assert all('이전' in s['caption'] for s in data['front_runtime'] if s['file'].startswith('screenshots/0154-'))
 errors=[];responsive=[]
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  page=await b.new_page(viewport={'width':1280,'height':1000});page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto(URL,wait_until='domcontentloaded');await page.wait_for_selector('#front-runtime-grid .card')
  for person in ('daram','dad','mom'):
   await page.locator('#person').select_option(person);await page.locator('#dialogue-comparison').scroll_into_view_if_needed();await page.wait_for_timeout(140)
   assert await page.locator('#front-strip .card').count()==4
   await page.locator('#dialogue-comparison').screenshot(path=str(OUT/(person+'-chestnut.png')))
  for source in data['family_palette']['assets']:
   assert (await page.request.head(URL+source['file'])).status==200,source
  for shot in data['front_runtime']:
   assert (await page.request.head(URL+shot['file'])).status==200,shot
  for width,height in [(1280,1000),(390,844),(320,640)]:
   await page.set_viewport_size({'width':width,'height':height});await page.evaluate("window.scrollTo(0,document.querySelector('#front-runtime').getBoundingClientRect().top+window.scrollY-16)");await page.wait_for_timeout(180)
   assert await page.evaluate('document.documentElement.scrollWidth<=innerWidth')
   await page.screenshot(path=str(OUT/f'runtime-{width}.png'));responsive.append({'width':width,'overflow':False})
  assert not errors,errors
  await b.close()
 report={'status':'passed','source_pixels_unchanged':True,'family_assets':13,'authored_world_poses':241,'dialogue_drawings':172,'dedicated_avatar_sources':43,'evidence_icons':12,'runtime_captures':len(data['front_runtime']),'latest_natural_captures':sum('0156-viewpoint-' in s['file'] for s in data['front_runtime']),'labeled_engine_fixtures':3,'responsive':responsive,'console_errors':errors}
 (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False))
asyncio.run(main())
