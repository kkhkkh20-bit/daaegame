# Topic Return button is outside the viewport

Archive: `8bbfbdbff8aa1fe47560eb642887fc919c8a0b9254ec99c9b3f38229569da147` (`room13-release-0156-ui`).

Natural first run: record G1 and G3 separately, present G1 without G2, choose to find more material, and return to the guard question list. The newly required **돌아가기** button is not visible or focusable. Existing bottom 조사 still exists, so this is a missing explicit control rather than a locked playthrough.

`r13_question_list` uses `xpos list_left+list_width/2`. In Python 3 this produces a float (`800.0`). Ren’Py position floats are relative fractions, putting the button far outside the screen. Use integer division or cast the result to int.

The archive includes the new source, and the question viewport is already 342 pixels high, ruling out old compiled UI as the immediate cause. Evidence: `ui-natural/failure.png` and `failure-state.json`. The naturally reached partial-registration response and actual top-right gear open/close passed before this failure.
