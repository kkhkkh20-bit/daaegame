# Independent final QA — 0.15.6

**PASS within the tested scope.** Publish archive SHA256: `4fc4ea4c53d013318ea5dffc5a9b216d0f1053d128b60c7a7af34b2c4f21b3da`.

`publish-approach/report.json` verifies a fresh natural proof route, first Dad line retaining Karo, and Piko click → immediate large portrait/approach choice. Return or decline changes no room state, noticed flag, encounter, or camera. Accepting runs the observation and greeting; the first Dad greeting retains Piko. PC/mobile screenshots were manually reviewed.

`final-natural/report.json` on baseline `8f7d1216…932ad` additionally passes G1+G3 partial acknowledgement → G2 → correct argument; exact immediate favorite/save/unfavorite/load on actual merged Karo dialogue indices 1, 2 and 3; explicit topic Return; field/topic/say gear controls; and compact three-cell UI.

The complete archive comparison `independent-publish-delta.json` finds 847 identical members, no additions/removals, and only two changed game sources plus compiled/cache counterparts. Those source changes are approach-before-observation and seeding the selected actor before a first Dad greeting; both were exercised in the final archive.

Resolved blockers: saved subsequent dialogue no longer advances a line, Return is visible after integer-coordinate correction, and resident observation happens only after accepting approach.

Limits: first-afternoon natural routes, not a 14-day completion claim. QA changed only text-speed preference, never story state. Earlier PageUp-only rollback testing was inconclusive and is not claimed as passed. Audio, art inventory, and gallery validation are separate team reports. All QA browsers are closed.
