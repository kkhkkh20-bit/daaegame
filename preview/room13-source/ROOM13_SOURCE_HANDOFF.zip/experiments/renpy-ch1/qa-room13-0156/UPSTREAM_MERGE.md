# Upstream dialogue merge

Upstream `3e90a4d` (public archive `f2e32d9f756ea5a3d1e481e5b316ba18357bf1c4bc1fd07fbae264b2ce64506b`) was three-way merged using the `345623c` source handoff as base. No conflict markers occurred.

Preserved: 36 resident notice/approach/greeting scenes, snack/letter opening swap, family waiting together, revised Karo/gate dialogue and late/solo branches. Local improvements retained: partial registration feedback, explicit document comparison, records, optional tool loop, stage POV, font controls.

Subsequent local changes: approached resident now visible with spoken question choices and explicit return; story notice/meeting/evidence/time semantics retained. Small dialogue portraits removed, options relocated and lower toolbar simplified. Separate pre-say checkpoint fixes immediate favorite-save restoration.

Release is 0.15.6-dev to distinguish it from the independently published dialogue 0.15.5-dev. Candidate reports in qa-room13-0155 are historical feature/regression evidence, not approval of the final archive.
