# Independent review QA — 0.15.5 candidate

Archive SHA256: `653d10e55c800c35b56a2d1de7521de6575908012cf59f7582e215c354e02dbd`

**PASS**: `review-natural/report.json`. A fresh browser played the first afternoon using real mouse/touch input, without injecting evidence, flags, time, or story state.

- G1 alone and individually recorded G1+G3 receive partial registration acknowledgement and bulletin-board guidance; neither auto-marks comparison.
- Mismatched fields and matching adult fields do not change story state. Explicit child-field comparison works at 844×390.
- Comparison followed immediately by real save, loading the pre-comparison save, and reloading the comparison save restores exactly the saved state.
- Recent evidence order respects same-period acquisition: G3, G1, E01. Favorite/filter/read markers change only record_ui. Immediate favorite save→unfavorite→load restores the complete saved state.
- Reading G2 then presenting enables the correct answer and completes entry during the same afternoon.
- Large-text mobile records renders four columns, unique evidence icons, readable detail and working touch selection. Screenshots manually reviewed.

Limitations: no 14-day completeness claim; only child comparison clicked, not the alternative count row. Parent separately covers missing record_ui old-save defaults with actual-helper tests. This report does not approve a later archive without checking its changed files. Tool discovery E2E belongs to the cinematics agent.
