import asyncio,json,hashlib
from pathlib import Path
from playwright.async_api import async_playwright
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
GALLERY=ROOT.parents[1]/'preview/room13-acting'
async def main():
 data=json.loads((GALLERY/'catalog.json').read_text());spec=json.loads((ROOT/'art/pixel-b/evidence-icons0155.json').read_text())
 assert len(data['evidence_icons'])==12
 assert len(data['people'])==43 and data['portrait_coverage']['drawings']==172
 for item in data['evidence_icons']:assert item['art']['rect']==spec[item['id']]['crop']
 image=data['evidence_atlas']['file'];source=ROOT/'art/pixel-b/room13-pixel-evidence0155.png'
 assert (GALLERY/image).read_bytes()==source.read_bytes()
 assert sum(s['file']==image for s in data['sources'])==1
 errors=[];screens=[]
 async with async_playwright() as p:
  b=await p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
  page=await b.new_page(viewport={'width':1280,'height':1000});page.on('pageerror',lambda e:errors.append(str(e)))
  await page.goto('http://127.0.0.1:8093/preview/room13-acting/',wait_until='domcontentloaded')
  await page.wait_for_selector('#evidence-grid .card')
  assert await page.locator('#evidence-grid .card').count()==12
  for width,height in [(1280,1000),(390,844),(320,640)]:
   await page.set_viewport_size({'width':width,'height':height});await page.locator('#evidence-icons').scroll_into_view_if_needed();await page.wait_for_timeout(180)
   overflow=await page.evaluate('({width:innerWidth,body:document.documentElement.scrollWidth,icons:document.querySelector("#evidence-grid").scrollWidth,box:document.querySelector("#evidence-grid").clientWidth})')
   assert overflow['body']<=width,overflow
   assert overflow['icons']<=overflow['box'],overflow
   for c in await page.locator('#evidence-grid .card').all():
    box=await c.bounding_box();assert box['x']>=0 and box['x']+box['width']<=width,box
   await page.locator('#evidence-icons').screenshot(path=str(OUT/f'icons-{width}.png'))
   screens.append({'viewport':[width,height],'overflow':False})
  assert await page.locator('#evidence-atlas-download').get_attribute('href')==image
  assert (await page.request.head('http://127.0.0.1:8093/preview/room13-acting/'+image)).status==200
  await page.locator('#person').select_option('mom');assert await page.locator('#portrait-poses button').count()==4;assert await page.locator('#front-comparison .card').count()==3
  assert not errors,errors
  await b.close()
 report={'status':'passed','icons':12,'source_png_copies':1,'same_runtime_crop':True,'source_pixels_unchanged':True,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'people':len(data['people']),'dialogue_drawings':data['portrait_coverage']['drawings'],'avatar_count':data['portrait_coverage']['dedicated_avatars'],'responsive':screens,'download_http':200,'console_errors':errors}
 (OUT/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(report,ensure_ascii=False))
asyncio.run(main())
