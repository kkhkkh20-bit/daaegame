# Save/load dialogue progression blocker

Candidate SHA256: `5164e10c9e77122b5050b6d1a87b2fc5cd637ff733ced42b001026bbae3067fc`.

Reproduced twice with a fresh browser and normal story input. No story state or save-context injection was used.

1. Start the game, explicitly compare the gate records, then ask Karo about the road.
2. On Karo's first line, open Records, favorite G1, close Records, save immediately without advancing dialogue, unstar G1, load. First line is restored correctly.
3. Advance once to Dad's second line: “수리하면 돌아갈 수 있습니까?”
4. Repeat favorite/save/unstar/load using G3 and slot 2.
5. The load resumes at Karo's third line, skipping the saved Dad line.

Trace confirms it is the load, not the record or save UI close click:

- `say-save-trace/trace-2-after-save.json`: index 1, Dad.
- `say-save-trace/trace-2-before-load.json`: index 1, Dad.
- `say-save-trace/trace-2-after-load.json`: index 2, Karo.

Entries, conversation identity, evidence, flags, clock, and favorite state are preserved. Only dialogue index, packet, speaker, and read ID move forward. There is no exception screen. First-line success therefore does not establish correct behavior for subsequent lines.

Gate UI label/value spacing and mobile count comparison passed independently in this candidate. The script is `dev/pixel_qa_say_records0155.py`. Browser closed after each attempt.

## Resolution verified

Candidate `a7bb5b7d442f12b4eb61a7781d0f07bcb60dbdb9bf3b9ad4454acdb746bb2bff` inserts a checkpoint before each dynamic Character interaction. Natural first, second, and third dialogue lines now preserve the exact packet, read ID, speaker, index, entries, identity, story state, and favorites after immediate save/load. See `viewpoint-say-regression/report.json`. PC/mobile Dad viewpoint screenshots manually passed. A separate PageUp check remains inconclusive about web key dispatch; it does not change the three successful save/load results.
